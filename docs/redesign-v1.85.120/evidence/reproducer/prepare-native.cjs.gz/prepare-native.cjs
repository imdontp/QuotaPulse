const fs=require('node:fs'),assert=require('node:assert/strict');
let s=fs.readFileSync('tmp/check-cost108-matrix.mts','utf8');
s=s.replace("import assert from 'node:assert/strict';","import assert from 'node:assert/strict';\nimport { installBrowserFixedDate } from '../scripts/browser-fixed-date.mjs';");
assert.ok(s.includes('await page.clock.setFixedTime(fixedNow);'));s=s.replace('await page.clock.setFixedTime(fixedNow);','await installBrowserFixedDate(page,fixedNow);');
s=s.replace("'tmp/cost108-matrix'","'tmp/cost120-native'");
const marker=' results.push({lang,theme,width,closed,expanded,keyboardOpenClose:true,allBucketRows:true});';assert.ok(s.includes(marker));
s=s.replace(marker,` const legend=await page.locator('.qp-cost-providers ol').evaluate(element=>({rect:element.getBoundingClientRect().toJSON(),rows:Array.from(element.children).map(row=>({rect:row.getBoundingClientRect().toJSON(),parts:Array.from(row.querySelectorAll('.qp-cost-provider-name,.qp-cost-provider-amount,.qp-cost-provider-share')).map(part=>({text:part.textContent,rect:part.getBoundingClientRect().toJSON()}))}))}));
 for(const row of legend.rows){assert.equal(row.parts.length,3);for(const part of row.parts)assert.ok(part.rect.left>=row.rect.left-.1&&part.rect.right<=row.rect.right+.1&&part.rect.top>=row.rect.top-.1&&part.rect.bottom<=row.rect.bottom+.1,key+': provider legend value clipped');if(width>=1536)assert.ok(row.parts[0].rect.right<=row.parts[1].rect.left+.1&&row.parts[1].rect.right<=row.parts[2].rect.left+.1,key+': provider legend columns overlap');}
 results.push({lang,theme,width,closed,expanded,legend,keyboardOpenClose:true,allBucketRows:true});`);
fs.writeFileSync('tmp/check-native120.mts',s);
