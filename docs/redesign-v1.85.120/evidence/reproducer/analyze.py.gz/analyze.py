import json
from pathlib import Path
from PIL import Image,ImageChops
root=Path('tmp/cost120')
before=json.loads((root/'before/cost-rows.json').read_text(encoding='utf-8'));after=json.loads((root/'after/cost-rows.json').read_text(encoding='utf-8'))
assert len(before['models'])==len(after['models'])==6
for a,b in zip(before['models'],after['models']):
 for key in ['text','rect','width']:assert a[key]==b[key],key
for a,b in zip(before['providers'],after['providers']):
 assert a['dot']==b['dot'];assert a['rect']==b['rect'];assert ''.join(a['text'].split())==''.join(b['text'].split()),(a['text'],b['text'])
old=Image.open(root/'before/cost.png').convert('RGB');new=Image.open(root/'after/cost.png').convert('RGB');cs=ImageChops.difference(old,new).split();d=ImageChops.lighter(ImageChops.lighter(cs[0],cs[1]),cs[2]);h=d.histogram()
outside=[]
for y in range(old.height):
 for x in range(old.width):
  if old.getpixel((x,y))!=new.getpixel((x,y)) and not ((1435<=x<1648 and 150<=y<285)or(1514<=x<1594 and 419<=y<600)):outside.append(dict(x=x,y=y,before=old.getpixel((x,y)),after=new.getpixel((x,y))))
manifest=json.loads((root/'after/verification.json').read_text(encoding='utf-8'))
ref=Image.open('docs/redesign-v1.85.69/refs/cost.png').convert('RGB');samples={str(y):[ref.getpixel((x,y))for x in [1532,1535,1540,1545]]for y in [431,463,494,524,556,585,616]}
report=dict(productionIndexSha256=manifest['productionIndexSha256'],modelRows=6,providerRows=len(after['providers']),preservedModelFacts=['text','width','rect'],providerTextColorsBoundsPreserved=True,changedPixels=sum(h[1:]),maxChannelDelta=max(i for i,n in enumerate(h)if n),bounds=d.getbbox(),pixelsOutsideIntendedRegions=len(outside),unplannedPixels=outside,immediateRepeatIdentical=manifest['results'][0]['repeatIdentical'],sourcePaletteSamples=dict(file='refs/cost.png',x=[1532,1535,1540,1545],rows=samples),scope='Cost identity colors and legend columns; not whole-reference acceptance')
(root/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
