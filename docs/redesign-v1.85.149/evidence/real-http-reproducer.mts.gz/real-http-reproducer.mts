import assert from 'node:assert/strict';
import { request } from 'node:http';
import { once } from 'node:events';
import { setImmediate as turn } from 'node:timers/promises';
import { writeFileSync } from 'node:fs';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
const db=openDb(':memory:'),scheduler=new Scheduler(db,[]),app=buildServer(db,scheduler,{token:'sse-abort-test',port:0});
let enter!:()=>void,release!:()=>void,reply:any,client:ReturnType<typeof request>|undefined;
const entered=new Promise<void>(resolve=>enter=resolve),gate=new Promise<void>(resolve=>release=resolve);
app.addHook('preHandler',async(req,res)=>{if(!req.url.startsWith('/api/events/stream'))return;reply=res;enter();await gate;});
try{
 await app.listen({host:'127.0.0.1',port:0});const address=app.server.address();assert.ok(address&&typeof address==='object');
 client=request({host:'127.0.0.1',port:address.port,path:'/api/events/stream',headers:{'x-quotapulse-token':'sse-abort-test'}});client.on('error',()=>{});client.end();
 await entered;const closed=once(reply.raw,'close');client.destroy();await closed;
 const before={data:scheduler.listenerCount('data'),settings:scheduler.listenerCount('settings'),responseDestroyed:reply.raw.destroyed};
 release();await turn();await turn();
 const after={data:scheduler.listenerCount('data'),settings:scheduler.listenerCount('settings'),responseDestroyed:reply.raw.destroyed};
 const report={controlledSchedule:'real HTTP client aborts after auth/preHandler entry but before production SSE handler executes',before,after,leakObserved:after.data!==0||after.settings!==0,cleanupReplaysCloseOnlyAfterObservation:true};
 writeFileSync('tmp/sse149-reproduction.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
}finally{
 release();client?.destroy();await turn();reply?.raw.emit('close');await app.close();db.close();
}
