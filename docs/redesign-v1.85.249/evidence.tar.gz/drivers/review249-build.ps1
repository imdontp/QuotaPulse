$ErrorActionPreference = 'Stop'
$root249 = Split-Path -Parent $PSScriptRoot
$output249 = Join-Path $root249 'tmp\review249-build'
if (Test-Path -LiteralPath $output249) { throw 'Build evidence directory already exists' }
New-Item -ItemType Directory -Path $output249 | Out-Null
$commit249 = (& git -C $root249 rev-parse HEAD).Trim()
if ($LASTEXITCODE -ne 0 -or $commit249 -notmatch '^[a-f0-9]{40}$') { throw 'Cannot bind build to source commit' }
$steps249 = @(
  @{name='daemon-build'; args=@('run','build','-w','@quotapulse/daemon')},
  @{name='web-build'; args=@('run','build','-w','@quotapulse/web')},
  @{name='tray-build'; args=@('run','build','-w','@quotapulse/tray')},
  @{name='daemon-test'; args=@('run','test','-w','@quotapulse/daemon')},
  @{name='web-test'; args=@('run','test','-w','@quotapulse/web')},
  @{name='tray-test'; args=@('run','test','-w','@quotapulse/tray')}
)
$results249 = [Collections.Generic.List[object]]::new()
Push-Location $root249
try {
  foreach ($step249 in $steps249) {
    Write-Host "Starting $($step249.name)"
    $log249 = Join-Path $output249 ($step249.name+'.log')
    $start249 = [DateTimeOffset]::UtcNow.ToString('o')
    $ErrorActionPreference = 'Continue'
    & npm.cmd @($step249.args) *> $log249
    $code249 = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    $results249.Add(@{name=$step249.name; arguments=$step249.args; exitCode=$code249; started=$start249; log=$log249})
    $receipt249 = @{sourceCommit=$commit249; steps=@($results249.ToArray()); status=$(if($code249 -eq 0 -and $results249.Count -eq 6){'passed'}else{'incomplete'})}
    [IO.File]::WriteAllText((Join-Path $output249 'receipt.json'),($receipt249 | ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
    if ($code249 -ne 0) { throw "$($step249.name) failed: $log249" }
    Write-Host "Passed $($step249.name)"
  }
} finally { Pop-Location }
