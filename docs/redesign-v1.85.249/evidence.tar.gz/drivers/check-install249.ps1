$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$project=[IO.Path]::GetFullPath((Join-Path $root '../../..'))
$out=Join-Path $root 'tmp\review249-build'
$input=Get-Content -LiteralPath (Join-Path $out 'native-input.json') -Raw | ConvertFrom-Json
$archive=Get-Content -LiteralPath (Join-Path $out 'archive.json') -Raw | ConvertFrom-Json
. (Join-Path $root 'scripts/review-profile.ps1')
$base=Join-Path $project 'tmp\installation-review249'
Assert-ReviewPlainPath $base
New-Item -ItemType Directory -Path $base -Force | Out-Null
$fixture=Join-Path $base ('run-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $fixture | Out-Null
$target=Join-Path $fixture 'review'
$record=Join-Path $out 'installation-smoke.json'
$success=$false;$failure=$null;$checks=@();$pidRecords=@()
try {
  if((Get-FileHash -LiteralPath $archive.archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $archive.sha256){throw 'Archive changed'}
  $installer=Join-Path $input.bundle 'scripts\install-review.ps1'
  if((Get-FileHash -LiteralPath $installer -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath (Join-Path $root 'scripts/install-review.ps1') -Algorithm SHA256).Hash){throw 'Bundled installer differs from source'}
  & $installer -Archive $archive.archive -ExpectedSha256 $archive.sha256 -Destination $target
  $marker=Get-Content -LiteralPath (Join-Path $target 'installation.json') -Raw | ConvertFrom-Json
  if($marker.active -ne ('release-'+$archive.sha256)){throw 'Installed release identity mismatch'}
  $runtime=Join-Path (Join-Path $target 'releases') $marker.active
  & node (Join-Path $root 'tmp/check-installed236.cjs') $input.bundle $runtime
  if($LASTEXITCODE -ne 0){throw 'Installed runtime inventory mismatch'}
  $checks+='actual delivered ZIP installed with identical file inventory and the current bundled installer'
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $zip=[IO.Compression.ZipFile]::OpenRead($archive.archive)
  try {$longest=$zip.Entries | Where-Object {$_.Name} | Sort-Object {$_.FullName.Length} -Descending | Select-Object -First 1}
  finally {$zip.Dispose()}
  $longFile=[IO.Path]::Combine($runtime,$longest.FullName.Replace('/','\'))
  if($longFile.Length -le 260 -or -not [IO.File]::Exists('\\?\'+$longFile)){throw 'Long installed ZIP entry missing'}
  $checks+='ZIP entry longer than 260 characters extracted into isolated installation'
  & (Join-Path $target 'start.ps1') -Port 7821
  $state=Get-Content -LiteralPath (Join-Path $target 'review-data\review-processes.json') -Raw | ConvertFrom-Json
  $lock=Get-Content -LiteralPath (Join-Path $target 'review-data\daemon.lock') -Raw | ConvertFrom-Json
  $health=Invoke-RestMethod -Uri "http://127.0.0.1:$($lock.port)/api/health" -Headers @{'x-quotapulse-token'=$lock.token} -TimeoutSec 5
  if(-not $health.ok -or @($health.scheduler.sources).Count -ne 0 -or $state.readersEnabled){throw 'Readers-off installed launch failed'}
  foreach($role in @('daemon','tray')){
    $process=$state.$role;$actual=Get-CimInstance Win32_Process -Filter "ProcessId=$([int]$process.pid)"
    if(-not $actual -or -not $actual.CommandLine.Contains($runtime) -or -not $actual.CommandLine.Contains((Join-Path $target 'review-data'))){throw 'Installed process identity mismatch'}
    $pidRecords+=@{pid=$process.pid;created=$process.created;role=$role}
  }
  $checks+='installed daemon and tray start with readers off and an independent review profile'
  & (Join-Path $target 'stop.ps1')
  foreach($process in $pidRecords){$actual=Get-CimInstance Win32_Process -Filter "ProcessId=$([int]$process.pid)" -ErrorAction SilentlyContinue;if($actual -and $actual.CreationDate.ToUniversalTime().ToString('O') -eq $process.created){throw 'Owned process did not stop'}}
  if(-not (Test-Path -LiteralPath (Join-Path $target 'review-data\usage.db'))){throw 'Profile database missing after stop'}
  $checks+='scoped stop ends owned processes and retains the isolated database'
  $success=$true
}catch{$failure=$_.Exception.ToString();throw}
finally{
  if(Test-Path -LiteralPath (Join-Path $target 'review-data\review-processes.json')){& (Join-Path $target 'stop.ps1')}
  $report=@{status=$(if($success){'passed'}else{'failed'});fixture=$fixture;target=$target;runtime=$runtime;archiveSha256=$archive.sha256;sourceCommit=$input.sourceCommit;longEntryLength=$longFile.Length;checks=$checks;failure=$failure;processes=$pidRecords;limitations=@('owned isolated profile, readers disabled','portable review installer, not a signed production release','no physical monitor or native dashboard UI verification')}
  [IO.File]::WriteAllText($record,($report | ConvertTo-Json -Depth 7),[Text.UTF8Encoding]::new($false))
}

