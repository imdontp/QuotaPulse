$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$project = [IO.Path]::GetFullPath((Join-Path $root '../../..'))
$out = Join-Path $root 'tmp/review249-build'
$receipt = Get-Content -LiteralPath (Join-Path $out 'archive-verification.json') -Raw | ConvertFrom-Json
$input = Get-Content -LiteralPath (Join-Path $out 'native-input.json') -Raw | ConvertFrom-Json
if ($receipt.status -ne 'passed' -or $receipt.checkpoint -ne 'v1.85.248-review249' -or $input.sourceCommit -ne '0976caf04664cd27b19b2d1abedf1a1ea5e5874f') { throw 'Archive provenance mismatch' }
$source = [IO.Path]::GetFullPath($receipt.archive)
if ($source -ne ($input.bundle + '.zip')) { throw 'Unexpected archive location' }
if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $receipt.sha256) { throw 'Archive hash mismatch' }
$destination = Join-Path $project 'tmp/releases/QuotaPulse-v1.85.248-review249.zip'
if (Test-Path -LiteralPath $destination) { throw 'Refusing to overwrite release' }
Copy-Item -LiteralPath $source -Destination $destination
if ((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant() -ne $receipt.sha256) { throw 'Delivered copy mismatch' }
$record = @{archive=$destination; source=$source; sha256=$receipt.sha256; archiveBytes=$receipt.archiveBytes; fileCount=$receipt.fileCount; allEntryBytesMatch=$true; sourceCommit=$input.sourceCommit}
[IO.File]::WriteAllText((Join-Path $out 'archive.json'),($record | ConvertTo-Json -Depth 4),[Text.UTF8Encoding]::new($false))
$record | ConvertTo-Json -Depth 4
