$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$project=[IO.Path]::GetFullPath((Join-Path $root '../../..'))
$out=Join-Path $root 'tmp\review249-build'
$input=Get-Content -LiteralPath (Join-Path $out 'native-input.json') -Raw | ConvertFrom-Json
$reader=Get-Content -LiteralPath (Join-Path $out 'reader-smoke.json') -Raw | ConvertFrom-Json
$installed=Get-Content -LiteralPath (Join-Path $out 'installation-smoke.json') -Raw | ConvertFrom-Json
$archive=Get-Content -LiteralPath (Join-Path $out 'archive.json') -Raw | ConvertFrom-Json
$temp=(Resolve-Path -LiteralPath ([IO.Path]::GetTempPath())).Path.TrimEnd('\')
$plan=Get-Content -LiteralPath (Join-Path $out 'cleanup-plan.json') -Raw | ConvertFrom-Json
$results=@()
foreach($row in $plan){
 $target=(Resolve-Path -LiteralPath $row.path).Path.TrimEnd('\')
 $expectedTarget=switch($row.stage){'unused-build' {$input.bundle}; 'reader' {$reader.extracted}; 'installed' {$installed.runtime}; default {throw 'Unexpected cleanup stage'}}
 if($target -ne [IO.Path]::GetFullPath($expectedTarget).TrimEnd('\')){throw 'Cleanup target does not match its test receipt'}
 if($row.stage -eq 'unused-build'){
  if([IO.Path]::GetDirectoryName($target) -ne (Join-Path $root 'tmp\review-bundles') -or [IO.Path]::GetFileName($target) -notmatch '^QuotaPulse-v1\.85\.248-review249-[a-zA-Z0-9]+$'){throw 'Unexpected build target'}
 }elseif($row.stage -eq 'installed'){
  $fixture=(Resolve-Path -LiteralPath $installed.fixture).Path.TrimEnd('\')
  if([IO.Path]::GetDirectoryName($fixture) -ne (Join-Path $project 'tmp\installation-review249') -or [IO.Path]::GetFileName($fixture) -notmatch '^run-[a-f0-9]{32}$'){throw 'Unexpected install fixture'}
  if($target -ne (Join-Path $fixture ('review\releases\release-'+$archive.sha256))){throw 'Unexpected installed release'}
 }elseif([IO.Path]::GetDirectoryName($target) -ne $temp -or [IO.Path]::GetFileName($target) -notmatch '^QuotaPulse-review-[a-zA-Z0-9]+$'){throw 'Unexpected extraction target'}
 $needle=if($row.stage -eq 'installed'){$installed.fixture}else{$target}
 $live=@(Get-CimInstance Win32_Process | Where-Object {$_.CommandLine -and $_.CommandLine.IndexOf($needle,[StringComparison]::OrdinalIgnoreCase) -ge 0})
 if($live.Count){throw 'A fixture process still references the cleanup target'}
 $long='\\?\'+$target
 if((Get-Item -LiteralPath $long -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Linked cleanup root'}
 $items=@(Get-ChildItem -LiteralPath $long -Recurse -Force -ErrorAction Stop)
 if(@($items | Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint}).Count){throw 'Linked cleanup entry'}
 $expected=@{};foreach($file in $row.files){$expected[$file.relative.Replace('/','\')]=[long]$file.bytes}
 $files=@($items | Where-Object {-not $_.PSIsContainer -and -not $_.FullName.StartsWith($long+'\review-data\',[StringComparison]::OrdinalIgnoreCase)})
 if($files.Count -ne @($row.files).Count){throw 'File inventory changed since verification'}
 foreach($file in $files){
  if(-not $file.FullName.StartsWith($long+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'File escaped cleanup root'}
  $relative=$file.FullName.Substring($long.Length+1)
  if(-not $expected.ContainsKey($relative) -or $file.Length -ne $expected[$relative]){throw 'File changed since verification'}
 }
 @{stage=$row.stage;path=$target;action='verified-delete-intent';archiveSha256=$row.archiveSha256} | ConvertTo-Json -Compress | Add-Content -LiteralPath (Join-Path $out 'cleanup-journal.jsonl') -Encoding UTF8
 foreach($file in $files){if($file.Extension -ne '.asar'){[IO.File]::Delete($file.FullName)}}
 foreach($dir in @($items | Where-Object {$_.PSIsContainer} | Sort-Object {$_.FullName.Length} -Descending)){if([IO.Directory]::GetFileSystemEntries($dir.FullName).Count -eq 0){[IO.Directory]::Delete($dir.FullName)}}
 $remaining=@(Get-ChildItem -LiteralPath $long -File -Force -Recurse | Where-Object {-not $_.FullName.StartsWith($long+'\review-data\',[StringComparison]::OrdinalIgnoreCase)})
 if(@($remaining | Where-Object {$_.Extension -ne '.asar'}).Count){throw 'Unexpected cleanup residue'}
 if([IO.Directory]::GetFileSystemEntries($long).Count -eq 0){[IO.Directory]::Delete($long)}
 $results+=@{stage=$row.stage;path=$target;status='cleaned';beforeBytes=$row.bytes;retainedBytes=($remaining | Measure-Object Length -Sum).Sum;retainedAsarFiles=$remaining.Count}
 [IO.File]::WriteAllText((Join-Path $out 'cleanup-results.json'),($results | ConvertTo-Json -Depth 4),[Text.UTF8Encoding]::new($false))
 Write-Output "Cleaned $($row.stage): $target"
}


