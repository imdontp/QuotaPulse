from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import json

root = Path(__file__).resolve().parents[1]
assets = root / 'packages/tray/dist-package/pets'
archive = root.parents[2] / 'tmp/releases/QuotaPulse-v1.85.242-review243.zip'
prefix = 'packages/tray/assets/pets/'
files = {p.relative_to(assets).as_posix(): p for p in assets.rglob('*') if p.is_file()}
with ZipFile(archive) as source:
    names = {n[len(prefix):] for n in source.namelist() if n.startswith(prefix) and not n.endswith('/')}
    assert names == files.keys(), (len(names), len(files), sorted(names ^ files.keys())[:10])
    for name, path in files.items():
        assert sha256(path.read_bytes()).digest() == sha256(source.read(prefix + name)).digest(), name
result = {'status': 'passed', 'reference': str(archive), 'files': len(files), 'scope': 'packaged pet runtime assets; byte-for-byte against review243'}
(root / 'tmp/review249-build/assets-verification.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf8')
print(json.dumps(result))
