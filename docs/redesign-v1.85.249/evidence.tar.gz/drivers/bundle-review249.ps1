$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$out = Join-Path $root 'tmp/review249-build'
$report = Join-Path $root 'screens/tray-recovery/bundle-build.json'
$saved = $null
if (Test-Path -LiteralPath $report) { $saved = [IO.File]::ReadAllBytes($report) }
$env:QUOTAPULSE_REVIEW_CHECKPOINT = 'v1.85.248-review249'
Push-Location $root
try {
  $head = (& git rev-parse HEAD).Trim()
  if ($head -ne '0976caf04664cd27b19b2d1abedf1a1ea5e5874f') { throw 'Source changed since build' }
  & git diff --exit-code HEAD -- packages scripts package.json package-lock.json tsconfig.base.json
  if ($LASTEXITCODE -ne 0) { throw 'Source has uncommitted changes' }
  & node --import tsx scripts/build-review-bundle.mts
  if ($LASTEXITCODE -ne 0) { throw 'Bundle failed' }
  $built = Get-Content -LiteralPath $report -Raw | ConvertFrom-Json
  if ($built.checkpoint -ne $env:QUOTAPULSE_REVIEW_CHECKPOINT) { throw 'Wrong bundle checkpoint' }
  Copy-Item -LiteralPath $report -Destination (Join-Path $out 'bundle-build.json')
  $input = @{checkout=$root; sourceCommit=$head; bundle=$built.bundle; buildReceipt=(Join-Path $out 'receipt.json')}
  [IO.File]::WriteAllText((Join-Path $out 'native-input.json'), ($input | ConvertTo-Json -Depth 4), [Text.UTF8Encoding]::new($false))
} finally {
  if ($null -ne $saved) { [IO.File]::WriteAllBytes($report,$saved) }
  Pop-Location
}
