from pathlib import Path
from hashlib import sha256
from PIL import Image, ImageChops
import json

root=Path(__file__).resolve().parents[1]
base=root/'tmp/fidelity235'
before=base/'history251-before'
after=base/'history251-after'
read=lambda p:json.loads(p.read_text(encoding='utf8'))
b,a=read(before/'history-legend-geometry.json'),read(after/'history-legend-geometry.json')
assert len(b['overlap'])==1 and len(a['overlap'])==0
assert b['svg']==a['svg'] and b['points']==a['points']
plot_top=b['svg']['top'] + 18*b['svg']['height']/144
marker_radius=3*b['svg']['height']/144
assert b['spans'][1]['rect']['bottom'] > plot_top-marker_radius
assert a['spans'][1]['rect']['bottom'] <= plot_top-marker_radius
with Image.open(before/'history.png') as first, Image.open(after/'history.png') as last:
    first,last=first.convert('RGB'),last.convert('RGB')
    assert first.size==last.size
    diff=ImageChops.difference(first,last)
    mask=diff.convert('L').point(lambda p: 255 if p else 0)
    changed=sum(mask.histogram()[1:])
    bounds=mask.getbbox()
    lower = mask.crop((0,315,mask.width,mask.height))
    lower_count=sum(lower.histogram()[1:])
    # A separate native select label differs between fresh browser contexts.
    # Compare the original pixels after a one-pixel translation; do not mask it.
    label_box=(1090,482,1185,498)
    x1,y1,x2,y2=label_box
    translated=sum(first.getpixel((x,y)) != last.getpixel((x,y-1))
                   for y in range(y1,y2) for x in range(x1,x2))
    assert lower_count == 418 and translated == 0
result={'beforeOverlaps':len(b['overlap']),'afterOverlaps':len(a['overlap']),
        'svgAndEveryPointUnchanged':True,'points':len(a['points']),
        'beforeLegendBottom':b['spans'][1]['rect']['bottom'],'afterLegendBottom':a['spans'][1]['rect']['bottom'],
        'topOfMaximumMarker':plot_top-marker_radius,
        'changedPixels':changed,'changedBounds':bounds,
        'lowerNativeSelectChangedPixels':lower_count,
        'lowerNativeSelectTranslatedByMinusOnePixelMatches':translated == 0,
        'beforeSha256':sha256((before/'history.png').read_bytes()).hexdigest(),
        'afterSha256':sha256((after/'history.png').read_bytes()).hexdigest(),
        'scope':'unmasked English/dark screenshot from isolated synthetic fixture, not full visual acceptance'}
(after/'analysis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
