from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root/'tmp/capture-project235.mts').read_text(encoding='utf8')
needle = "    if(routeName==='history'){\n      const density="
assert source.count(needle) == 1
insert = """    if(routeName==='history'){
      const legendData = await page.locator('.qp-history-timeline').evaluate(panel => {
        const svg = panel.querySelector('svg[role=group]')!;
        const spans = [...panel.querySelectorAll('.qp-history-legend span')].map(node => ({text: node.textContent, rect: node.getBoundingClientRect().toJSON()}));
        const points = [...svg.querySelectorAll('g[data-bucket-at] circle')].map(node => ({at: node.parentElement!.getAttribute('data-bucket-at'), value: node.parentElement!.getAttribute(node === node.parentElement!.firstElementChild ? 'data-input' : 'data-output'), rect: node.getBoundingClientRect().toJSON()}));
        const svgRect = svg.getBoundingClientRect().toJSON();
        const overlap = points.flatMap(point => spans.filter(span => point.rect.left < span.rect.right && point.rect.right > span.rect.left && point.rect.top < span.rect.bottom && point.rect.bottom > span.rect.top).map(span => ({point, span})));
        return {svg: svgRect, spans, points, overlap};
      });
      writeFileSync(resolve(output,'history-legend-geometry.json'),JSON.stringify(legendData,null,2)+'\\n');
      const density="""
source = source.replace(needle, insert)
target = root/'tmp/capture-history-legend251.mts'
assert not target.exists()
target.write_text(source,encoding='utf8',newline='\n')
print('Prepared local History legend geometry capture')
