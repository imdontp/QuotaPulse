// Actual-version rollback evidence helper. Only the PS orchestrator creates owned fixtures.
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const { existsSync, lstatSync, readFileSync, readdirSync, realpathSync, writeFileSync } = require('node:fs');
const { join, relative, resolve, sep } = require('node:path');
const { createRequire } = require('node:module');
const { spawnSync } = require('node:child_process');
const ROOT = resolve(__dirname, '..');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const json = path => JSON.parse(readFileSync(path, 'utf8').replace(/^\uFEFF/, ''));
const save = (path, value) => writeFileSync(path, JSON.stringify(value, null, 2) + '\n');
function plain(path) {
  let cursor = resolve(path);
  while (true) {
    if (existsSync(cursor)) assert.equal(lstatSync(cursor).isSymbolicLink(), false, `Linked path refused: ${cursor}`);
    const parent = resolve(cursor, '..'); if (parent === cursor) break; cursor = parent;
  }
  return resolve(path);
}
function inventory(root) {
  const files = {};
  function walk(dir) {
    assert.ok(existsSync(join(root, dir)), `Missing runtime tree ${dir}`);
    for (const item of readdirSync(join(root, dir), { withFileTypes: true })) {
      assert.equal(item.isSymbolicLink(), false, `Linked runtime entry ${item.name}`);
      const path = `${dir}/${item.name}`;
      if (item.isDirectory()) walk(path); else if (item.isFile()) files[path] = sha(readFileSync(join(root, path)));
    }
  }
  for (const tree of ['packages/daemon/dist', 'packages/tray/dist', 'packages/tray/dist-preload', 'packages/web/dist']) walk(tree);
  for (const path of ['scripts/task-entry.cjs', 'scripts/start-review.ps1', 'scripts/stop-review.ps1', 'scripts/review-profile.ps1', 'scripts/install-review.ps1', 'scripts/uninstall-review.ps1', 'packages/daemon/package.json', 'packages/tray/package.json', 'packages/tray/src/pet.html', 'packages/tray/src/gallery.html', 'packages/tray/src/gallery.css']) {
    files[path] = sha(readFileSync(join(root, path)));
  }
  return Object.fromEntries(Object.entries(files).sort(([a], [b]) => a.localeCompare(b, 'en')));
}
function git(executable, checkout, args) {
  const child = spawnSync(executable, ['-C', checkout, ...args], { encoding: 'utf8', windowsHide: true });
  assert.equal(child.status, 0, `Git read failed: ${child.stderr || child.error || child.stdout}`);
  return child.stdout.trim();
}
function inspect(archivePath, provenancePath, gitExecutable) {
  const archive=plain(realpathSync(archivePath)), provenance=json(provenancePath);
  assert.equal(provenance.archive,archive); assert.match(provenance.sourceCommit,/^[a-f0-9]{40}$/);
  assert.equal(sha(readFileSync(archive)),provenance.archiveSha256,'Original archive checksum changed');
  assert.equal(sha(readFileSync(join(ROOT,provenance.delivery))),provenance.deliverySha256,'Committed delivery receipt changed');
  assert.equal(git(gitExecutable,ROOT,['cat-file','-t',provenance.sourceCommit]),'commit');
  assert.equal(provenance.entries,3161);assert.equal(provenance.isolatedEntryChecks,true);
  const runtime=provenance.runtime;
  assert.equal(runtime['packages/web/dist/index.html'],provenance.productionIndexSha256);
  return {archive,sourceCommit:provenance.sourceCommit,provenanceSha256:sha(readFileSync(provenancePath)),runtime,runtimeInventorySha256:sha(Buffer.from(JSON.stringify(runtime))),checkpoint:provenance.checkpoint};
}
function owned(fixture) {
  fixture = plain(realpathSync(fixture));
  const base = resolve(ROOT, '..', '..', '..', 'tmp', 'version-rollback176');
  const boundary = base + sep;
  assert.ok(fixture.toLowerCase().startsWith(boundary.toLowerCase()), 'Fixture must remain under repository tmp/version-rollback');
  assert.match(relative(base, fixture), /^run-[a-f0-9]{32}$/, 'Invalid owned fixture name');
  const marker = json(join(fixture, 'fixture.json'));
  assert.equal(marker.mode, 'synthetic-two-archive-rollback');
  assert.equal(resolve(marker.fixture), fixture);
  return { fixture, data: join(fixture, 'installation', 'review-data') };
}
function database(fixture, runtime, readonly) {
  const { data } = owned(fixture);
  const req = createRequire(join(runtime, 'package.json'));
  const entry = realpathSync(req.resolve('better-sqlite3'));
  assert.ok(entry.toLowerCase().startsWith((realpathSync(runtime) + sep).toLowerCase()), 'SQLite must resolve inside active release');
  return new (req('better-sqlite3'))(join(data, 'usage.db'), { readonly, fileMustExist: true });
}
function snapshot(fixture, runtime) {
  const db = database(fixture, runtime, true);
  try {
    return {
      schemaVersion: db.prepare("SELECT value FROM meta WHERE key='schema_version'").get(),
      sources: db.prepare('SELECT * FROM source ORDER BY id').all(),
      sessions: db.prepare('SELECT * FROM session ORDER BY id').all(),
      usage: db.prepare('SELECT * FROM usage_event ORDER BY id').all(),
      price: db.prepare('SELECT * FROM price ORDER BY provider,model').all(),
      settings: db.prepare('SELECT pet_enabled,tray_animation_enabled,hidden_subscriptions FROM app_setting WHERE id=1').get(),
      notifications: db.prepare('SELECT enabled,snooze_until,quiet_start,quiet_end FROM notification_setting WHERE id=1').get(),
      windowSize: json(join(owned(fixture).data, 'window-size.json')),
    };
  } finally { db.close(); }
}
function seed(fixture, runtime) {
  const { data } = owned(fixture); const db = database(fixture, runtime, false);
  try {
    assert.equal(db.prepare("SELECT value FROM meta WHERE key='schema_version'").get()?.value, '7', 'This fixture targets the existing no-migration schema7 contract');
    assert.equal(db.prepare('SELECT COUNT(*) n FROM usage_event').get().n, 0, 'Only a newly created empty synthetic DB may be seeded');
    assert.equal(db.prepare('SELECT COUNT(*) n FROM source').get().n, 0, 'Fresh fixture required');
    db.transaction(() => {
    db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at,enabled) VALUES(9101,'codex','rollback-synthetic','/synthetic/nonexistent','Rollback fixture',0,0);
        INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES(9101,9101,'rollback-null',NULL,1747489320000),(9102,9101,'rollback-empty','',1747489320000);
        INSERT INTO price(model,provider,input_per_1m,cached_input_per_1m,cache_write_per_1m,output_per_1m,origin,updated_at) VALUES('rollback-priced-model','rollback-provider',2,0.2,3,8,'synthetic-rollback-only',1);
        INSERT INTO usage_event(id,source_id,session_id,dedup_key,ts,model,provider,effort,input_tokens,cached_input_tokens,cache_write_tokens,output_tokens,reasoning_tokens,total_tokens,call_count,cost_usd,cost_source,cost_input_usd,cost_cached_input_usd,cost_cache_write_usd,cost_output_usd,cost_cache_saving_usd,price_provider) VALUES
          (9101,9101,9101,'rollback-computed',1747489320000,'rollback-priced-model','rollback-provider',NULL,100,40,10,50,20,200,1,0.000638,'computed',0.0002,0.000008,0.00003,0.0004,0.000072,'rollback-provider'),
          (9102,9101,9102,'rollback-native',1747489320001,'rollback-priced-model','rollback-provider','',10,0,0,10,0,20,1,0.123456,'native',NULL,NULL,NULL,NULL,NULL,NULL),
          (9103,9101,NULL,'rollback-unknown',1747489320002,NULL,NULL,'high',1,0,0,0,0,1,1,NULL,'unknown',NULL,NULL,NULL,NULL,NULL,NULL);
        INSERT OR REPLACE INTO app_setting(id,pet_enabled,tray_animation_enabled,hidden_subscriptions,updated_at) VALUES(1,0,0,'["rollback-hidden-owner"]',1);
        INSERT OR REPLACE INTO notification_setting(id,enabled,snooze_until,quiet_start,quiet_end,updated_at) VALUES(1,0,4102444800000,1320,420,1);`);
    })();
    writeFileSync(join(data, 'window-size.json'), JSON.stringify({ width: 1371, height: 887 }) + '\n');
    writeFileSync(join(data, 'rollback-sentinel.txt'), 'synthetic-only; preserve across actual app checkout rollback\n');
  } finally { db.close(); }
  const result = snapshot(fixture, runtime);
  assert.equal(result.usage.length, 3); assert.equal(result.sessions[0].project, null); assert.equal(result.sessions[1].project, '');
  return result;
}
// sendStatic serves HTML with one exact, synthetic-token insertion. Derive the
// expected bytes from the hash-verified raw bundle, never by stripping response HTML.
function expectedServedBytes(fixture, identity, path, token) {
  const marker=json(join(fixture,'installation','installation.json')); const raw=readFileSync(join(fixture,'installation','releases',marker.active,path));
  assert.equal(sha(raw), identity.runtime[path], `Raw bundle asset changed since provenance verification: ${path}`);
  const html = path.toLowerCase().endsWith('.html');
  return {
    rawSha256: identity.runtime[path],
    transform: html ? 'exact daemon token insertion before first </head>' : 'none',
    bytes: html ? Buffer.from(raw.toString('utf8').replace('</head>', `<script>window.__QUOTAPULSE_TOKEN__=${JSON.stringify(token)};</script></head>`), 'utf8') : raw,
  };
}
async function live(fixture, identity) {
  const { data } = owned(fixture); const lock = json(join(data, 'daemon.lock'));
  assert.ok(Number.isSafeInteger(lock.port) && lock.port >= 1024 && lock.port <= 65535);
  const origin = `http://127.0.0.1:${lock.port}`;
  const get = async path => {
    const response = await fetch(origin + path, { headers: { 'x-quotapulse-token': lock.token }, signal: AbortSignal.timeout(10000), redirect: 'error' });
    assert.equal(response.status, 200, `Local API/asset failed: ${path}`); return response;
  };
  const health = await (await get('/api/health')).json();
  assert.equal(health.ok, true); assert.deepEqual(health.scheduler.sources, [], 'No adapters/readers allowed');
  // Check served bytes against this checkout, not just a changed release label.
  const served = {};
  for (const [path, hash] of Object.entries(identity.runtime)) if (path.startsWith('packages/web/dist/')) {
    const url = '/' + path.slice('packages/web/dist/'.length).split('/').map(encodeURIComponent).join('/');
    const expected = expectedServedBytes(fixture, identity, path, lock.token);
    const actual = Buffer.from(await (await get(url)).arrayBuffer());
    assert.deepEqual(actual, expected.bytes, `Wrong served web asset: ${path}`);
    served[path] = { rawSha256: hash, expectedServedSha256: sha(expected.bytes), actualServedSha256: sha(actual), transform: expected.transform };
  }
  const settings = await (await get('/api/settings')).json();
  const notifications = await (await get('/api/notification-settings')).json();
  assert.equal(settings.pet_enabled, false); assert.equal(settings.tray_animation_enabled, false);
  assert.deepEqual(settings.hidden_subscriptions, ['rollback-hidden-owner']);
  assert.equal(notifications.enabled, false); assert.equal(notifications.snooze_until, 4102444800000);
  assert.equal(notifications.quiet_start, 1320); assert.equal(notifications.quiet_end, 420);
  return { sourceCommit: identity.sourceCommit, runtimeInventorySha256: identity.runtimeInventorySha256, served, readersDisabled: true, settings, notifications };
}
async function main() {
  const [mode, ...args] = process.argv.slice(2);
  if (mode === 'inspect') {
    const [configFile, output] = args; const c = json(configFile);
    const previous = inspect(c.previousBundle, c.previousProvenance, c.gitExecutable);
    const current = inspect(c.currentBundle, c.currentProvenance, c.gitExecutable);
    assert.notEqual(previous.sourceCommit, current.sourceCommit, 'Actual two different application commits required');
    const code = id => Object.fromEntries(Object.entries(id.runtime).filter(([p]) => /\.(js|cjs|css|html)$/.test(p) && /^(packages\/(daemon|tray)\/dist|packages\/web\/dist)/.test(p)));
    assert.notDeepEqual(code(previous), code(current), 'Identical application runtime; manifest labels/notices/assets alone are not actual-version rollback');
    const orchestrationInputs = {};
    // The orchestrator uses these local helpers before generated installed wrappers
    // take over; bind their bytes to the selected current checkout as well.
    for (const path of ['scripts/install-review.ps1', 'scripts/review-profile.ps1']) {
      const hash = sha(readFileSync(join(ROOT, path)));
      if (path !== 'scripts/install-review.ps1') assert.equal(hash, current.runtime[path], `Local helper differs from archived bundle: ${path}`);
      orchestrationInputs[path] = hash;
    }
    orchestrationInputs.installerDiffersFromCurrentArchive = orchestrationInputs['scripts/install-review.ps1'] !== current.runtime['scripts/install-review.ps1'];
    for (const path of ['tmp/check-archive-rollback176.ps1', 'tmp/check-archive-rollback176.cjs']) orchestrationInputs[path] = sha(readFileSync(join(ROOT, path)));
    save(output, { previous, current, orchestrationInputs });
  } else if (mode === 'seed') save(args[2], seed(args[0], args[1]));
  else if (mode === 'installed') {
    const [fixture, identityFile, output] = args; owned(fixture); const identity = json(identityFile);
    const marker = json(join(fixture, 'installation', 'installation.json')); assert.match(marker.active, /^release-[a-f0-9]{64}$/);
    const runtime = join(fixture, 'installation', 'releases', marker.active);
    assert.deepEqual(inventory(runtime), identity.runtime, 'Installed runtime differs from checkout-bound bundle');
    save(output, { runtime, sourceCommit: identity.sourceCommit, runtimeInventorySha256: identity.runtimeInventorySha256 });
  } else if (mode === 'snapshot') save(args[2], snapshot(args[0], args[1]));
  else if (mode === 'live') save(args[2], await live(args[0], json(args[1])));
  else if (mode === 'inventory') save(args[1], inventory(args[0]));
  else throw new Error('Expected inspect, seed, snapshot, live or inventory mode');
}
if (require.main === module) main().catch(error => { console.error(error); process.exitCode = 1; });
module.exports = { inventory, expectedServedBytes };
