from pathlib import Path
import json,hashlib,gzip,subprocess
root=Path('docs/redesign-v1.85.131');root.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text(encoding='utf8').lstrip('\ufeff'))
def write(name,value):
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
def copy(src,name,zipped=False):
 b=Path(src).read_bytes()
 if str(src).endswith('.log'):b=b.decode('utf-16'if b[:2]==b'\xff\xfe'else'utf8').lstrip('\ufeff').replace('\r\n','\n').encode()
 if str(src).endswith('.json'):b=b.decode('utf8').lstrip('\ufeff').replace('\r\n','\n').encode()
 if zipped:b=gzip.compress(b,mtime=0)
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
before=load('tmp/wrap131/before/verification.json');after=load('tmp/wrap131/after/verification.json');index=sha(Path('packages/web/dist/index.html').read_bytes())
assert before['index']=='35c6f598ea7ea32f55faef8be725ec73c6ccda602aaf52d7f447b14eb47a91f7' and after['index']==index and len(after['results'])==32
assert before['results'][0]['facts']['values'][1]['text']=='221' and len(before['results'][0]['facts']['values'][1]['lineTops'])==2
assert all(len(v['lineTops'])==1 for row in after['results'] for v in row['facts']['values'])
for phase,report in [('before',before),('after',after)]:
 copy('tmp/wrap131/'+phase+'/verification.json','evidence/'+phase+'.json.gz',True)
 for name in ['th-light-1355-THB','en-dark-1280-THB']:
  r=next((r for r in report['results']if r['name']==name),None)
  if r:
   p=Path('tmp/wrap131')/phase/(name+'.png');assert sha(p.read_bytes())==r['sha256'];copy(p,'images/'+phase+'/'+name+'.png')
native=Path('tmp/review131/native-a530db86-90eb-4fd5-9e32-5882ba6eb55d');copy(native/'restored-th-light-models.png','images/source130-native-before.png');copy(native/'verification.json','evidence/source130-native-candidate.json.gz',True)
copy('tmp/release131/archive.json','evidence/source130-candidate-archive.json')
for name in ['wrap131-before.log','wrap131-after.log','wrap131-after-final.log','build131-wrap-web-final.log']:copy('tmp/'+name,'evidence/logs/'+name+'.gz',True)
for name in ['prepare-wrap131.cjs','check-wrap131.mts','package-wrap131.py']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
paths=subprocess.check_output(['git','diff','HEAD','--name-only','--','packages/web/src'],text=True).splitlines();assert paths==['packages/web/src/redesign/models.css']
write('source-fingerprints.json',[{'path':p,'rawSha256':sha(Path(p).read_bytes()),'lfSha256':sha(Path(p).read_bytes().replace(b'\r\n',b'\n'))}for p in paths])
write('summary.json',{'checkpoint':'v1.85.131','parent':'ea66edfce5c1e665a7a5ecfd592e6eab12bd0545','index':index,'beforeIndex':before['index'],'browserCases':32,'valuesCheckedPerCase':4,'beforeTokenLines':2,'afterAllShortValuesSingleLine':True,'source130ReviewCandidate':'Withheld after native visual review found221 split at restored width1355','fullRedesignComplete':False})
(root/'README.md').write_text('''# Models intrinsic summary columns v1.85.131

Actual source130 Electron review passed its functional checks and the two earlier fragment assertions, but visual inspection of the restored Thai light window found stored token total221 rendered as22 and1. Its ZIP remains a withheld candidate. This correction follows the observed native data, rather than treating those passing checks as full visual acceptance.

## Cause and fix

At the restored1355px content width, the four summary cards had a46px icon, a64px chart, gaps and a flexible value column. That value column shrank below the width of three digits. The defect reproduced using the same three-event owned dataset in the compiled browser, with two DOM Range line positions for221.

Between731px and1535px the value track now uses its intrinsic max-content width and the sparkline uses the remaining flexible space. Wide monetary values use the full card row; their icon/header, facts and chart retain explicit separate positions. The first candidate exposedTHB0.46+ at1280px still wrapping; the final wide layout corrects that recorded case. Desktop reference widths1536+ and the existing narrow rules retain their layout. No text is hidden or clipped and no data is rewritten.

## Evidence

- Final TypeScript/production build passed.
-32 actual browser cases: EN/TH, dark/light,390/1280/1355/1688, USD/THB at37.25. All four visible summary values occupy one line in these cases; their children stay inside the cards, with no horizontal page overflow, browser errors or forbidden writes. The exact UI Models query independently retains221 tokens and three model/route pairs.
- The original restored Electron frame, browser causal before/after frames, line rectangles, initial failing medium-width currency log and final checks are retained here.
- Earlier656 repository tests/native16 captures belong to the source130 review candidate, not a fresh source131 delivery. The fixed source must be rebuilt and rechecked before publishing its replacement ZIP. No customer database or fixture is packaged.

Overall redesign and99–100% acceptance remain incomplete. The earlier whole-page repeat issues, remaining visual/material work and real-reader/physical-desktop acceptance remain open. Main is unchanged. Review125/source124 remains the last delivered portable ZIP until the corrected replacement is verified.
''',encoding='utf8',newline='\n')
write('artifact-hashes.json',{str(p.relative_to(root)).replace('\\','/'):sha(p.read_bytes())for p in sorted(root.rglob('*'))if p.is_file()and p.name!='artifact-hashes.json'})
print(json.dumps({'index':index,'cases':32,'artifacts':len(load(root/'artifact-hashes.json'))}))
