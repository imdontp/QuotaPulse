import assert from 'node:assert/strict';
import { openDb, upsertSource } from '../packages/daemon/src/db/index.js';
import { health } from '../packages/daemon/src/api/queries.js';

const db = openDb(':memory:');
const sourceId = upsertSource(db, { harness: 'codex', profile: 'bench', rootPath: '/synthetic', displayName: 'Synthetic benchmark' });
const insert = db.prepare('INSERT INTO ingest_state(source_id,target_key,kind,byte_offset,meta) VALUES(?,?,\'file\',?,?)');
const known = JSON.stringify({ jsonlIntegrityVersion: 1, jsonlMalformedLines: 0, jsonlPriorUnverified: 0 });
const add = db.transaction((from: number, to: number) => {
  for (let i = from; i < to; i++) insert.run(sourceId, `/synthetic/session-${i}.jsonl`, 10, i % 2 ? known : '{}');
});
for (const count of [0, 10000, 50000]) {
  if (count === 10000) add(0, count);
  if (count === 50000) add(10000, count);
  const check = health(db).transcriptParseWarnings;
  if (count === 0) assert.deepEqual(check, []);
  else assert.equal(check[0]!.unverifiedFiles, count / 2);
  const samples: number[] = [];
  for (let i = 0; i < 5; i++) { const start = performance.now(); health(db); samples.push(performance.now() - start); }
  samples.sort((a, b) => a - b);
  console.log(JSON.stringify({ cursors: count, medianMs: samples[2], maxMs: samples[4], samples }));
}
db.close();
