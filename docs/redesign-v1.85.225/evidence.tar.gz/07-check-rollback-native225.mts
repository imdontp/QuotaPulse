/** Actual packaged tray/dashboard, isolated fixture and profile; no real readers. */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { join, relative, resolve, sep } from 'node:path';
import { spawn, type ChildProcess } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';
import { _electron, type ElectronApplication } from 'playwright';

const root = resolve('.');
const base = realpathSync(resolve(root, '../../../tmp/version-rollback225'));
const fixture = realpathSync(process.argv[2]!);
const stage = process.argv[3]!;
assert.match(relative(base, fixture), /^run-[a-f0-9]{32}$/);
assert.equal(JSON.parse(readFileSync(join(fixture,'fixture.json'),'utf8')).mode, 'synthetic-two-archive-rollback');
assert.ok(['previous-seeded','current-upgrade','previous-rollback','current-recovery'].includes(stage));
const target = join(fixture,'installation'), data = join(target,'review-data');
const marker = JSON.parse(readFileSync(join(target,'installation.json'),'utf8'));
assert.match(marker.active, /^release-[a-f0-9]{64}$/);
const runtime = realpathSync(join(target,'releases',marker.active));
assert.ok(runtime.toLowerCase().startsWith((realpathSync(join(target,'releases'))+sep).toLowerCase()));
const entry = join(runtime,'scripts/task-entry.cjs'), electron = join(runtime,'node_modules/electron/dist/electron.exe');
const webRoot = join(runtime,'packages/web/dist');
const port = 7818, baseUrl = `http://127.0.0.1:${port}`;
const expected = {lang:'th',currency:'THB',rate:37.25,theme:'light'};
const failures:string[] = [], forbidden:string[] = [];
let daemon:ChildProcess|undefined, desktop:ElectronApplication|undefined, token='', result:any;
const sha=(bytes:Buffer)=>createHash('sha256').update(bytes).digest('hex');
async function until(check:()=>Promise<boolean>, message:string){const end=performance.now()+30000;while(performance.now()<end){if(await check())return;await delay(100)}throw Error(message)}
try {
  daemon=spawn(process.execPath,[entry,'--role','daemon','--port',String(port),'--data-dir',data,'--node-exe',process.execPath,'--no-readers'],{cwd:runtime,windowsHide:true,env:{...process.env,ELECTRON_RUN_AS_NODE:undefined,QUOTAPULSE_READERS:'off'},stdio:'ignore'});
  await until(async()=>{if(daemon!.exitCode!==null)throw Error('Fixture daemon exited');try{const lock=JSON.parse(readFileSync(join(data,'daemon.lock'),'utf8'));if(lock.pid!==daemon!.pid)return false;const res=await fetch(baseUrl+'/api/health',{headers:{'x-quotapulse-token':lock.token},signal:AbortSignal.timeout(1500)});const health=await res.json() as any;if(!res.ok||!health.ok||health.scheduler.sources.length)return false;token=lock.token;return true}catch{return false}},'Isolated daemon did not start');
  const response=await fetch(baseUrl+'/',{headers:{'x-quotapulse-token':token}});assert.equal(response.status,200);
  const raw=readFileSync(join(webRoot,'index.html'));
  const html=Buffer.from(raw.toString('utf8').replace('</head>',`<script>window.__QUOTAPULSE_TOKEN__=${JSON.stringify(token)};</script></head>`));
  assert.deepEqual(Buffer.from(await response.arrayBuffer()),html,'Served HTML is bound to active installed release');
  desktop=await _electron.launch({timeout:30000,executablePath:electron,args:['--disable-backgrounding-occluded-windows','--disable-renderer-backgrounding','--disable-features=CalculateNativeWinOcclusion',entry,'--role','tray','--port',String(port),'--data-dir',data,'--node-exe',process.execPath,'--no-readers'],env:{...process.env,ELECTRON_RUN_AS_NODE:undefined,QUOTAPULSE_READERS:'off'}});
  await desktop.evaluate(({app})=>app.whenReady());
  await desktop.evaluate(({app,ipcMain,screen})=>{
    (globalThis as any).rollbackNative={shown:[],errors:[]};
    app.on('browser-window-created',(_event,window)=>{
      window.webContents.setBackgroundThrottling(false);
      const displays=screen.getAllDisplays().map(display=>display.bounds);
      window.setPosition(Math.max(...displays.map(bounds=>bounds.x+bounds.width))+2048,Math.max(...displays.map(bounds=>bounds.y+bounds.height))+2048,false);
      window.setSkipTaskbar(true);window.setFocusable(false);
      window.on('show',()=>{const r=window.getBounds();if(displays.some(b=>r.x<b.x+b.width&&r.x+r.width>b.x&&r.y<b.y+b.height&&r.y+r.height>b.y)){window.hide();(globalThis as any).rollbackNative.errors.push('Window overlapped a display')}else (globalThis as any).rollbackNative.shown.push(window.id)});
      window.webContents.on('preload-error',(_event,_path,error)=>(globalThis as any).rollbackNative.errors.push(error.message));
    });
    ipcMain.emit('qp-popup-open-dashboard');
  });
  const context=desktop.context();
  await context.route('**/*',route=>{const req=route.request(),url=new URL(req.url());if(url.origin!==baseUrl||!['GET','HEAD'].includes(req.method())){forbidden.push(req.method()+' '+url.pathname);return route.abort()}return route.continue()});
  const page=await desktop.firstWindow();page.setDefaultTimeout(20000);page.on('pageerror',error=>failures.push(error.message));
  await page.emulateMedia({reducedMotion:'reduce'});
  const loadedMetrics=page.getByTestId('production-live').locator('.qp-live-metrics:not(.qp-live-initial-metrics)>div strong');
  await loadedMetrics.first().waitFor({timeout:30000});
  const observedMetrics=await loadedMetrics.allTextContents();assert.equal(observedMetrics.length,4);
  const identity=await desktop.evaluate(({app,BrowserWindow})=>({userData:app.getPath('userData'),sessionData:app.getPath('sessionData'),size:BrowserWindow.getAllWindows()[0].getSize(),native:(globalThis as any).rollbackNative}));
  assert.equal(identity.userData,join(data,'electron'));assert.equal(identity.sessionData,identity.userData);
  assert.deepEqual(identity.native.errors,[]);assert.ok(identity.native.shown.length>0);
  if(stage==='previous-seeded'){
    await page.goto(baseUrl+'/#settings');await page.getByTestId('production-settings').getByRole('button',{name:/THB$/}).click();
    const rate=page.getByRole('textbox',{name:'Rate',exact:true});await rate.fill('37.25');await rate.press('Enter');
    await page.getByRole('spinbutton',{name:'Width (px)',exact:true}).fill('1371');
    await page.getByRole('spinbutton',{name:'Height (px)',exact:true}).fill('887');
    await until(async()=>{try{const size=JSON.parse(readFileSync(join(data,'window-size.json'),'utf8'));return size.width===1371&&size.height===887}catch{return false}},'Window size was not persisted');
    await page.getByRole('button',{name:'Thai',exact:true}).click();await page.waitForFunction(()=>document.documentElement.lang==='th');
    if(await page.locator('.qp-redesign').getAttribute('data-theme')==='light'){
      await page.locator('.qp-tools button').first().click();await page.waitForFunction(()=>document.querySelector('.qp-redesign')?.getAttribute('data-theme')==='dark');
    }
    await page.locator('.qp-tools button').first().click();await page.waitForFunction(()=>localStorage.getItem('quotapulse-theme')==='light');
  }
  const state=await page.evaluate(()=>{const prefs=JSON.parse(localStorage.getItem('quotapulse-prefs')??'{}');return{lang:prefs.lang,currency:prefs.currency,rate:prefs.rate,theme:localStorage.getItem('quotapulse-theme'),windowSize:JSON.parse(localStorage.getItem('quotapulse_window_size')??'null'),documentLanguage:document.documentElement.lang,renderedTheme:document.querySelector('.qp-redesign')?.getAttribute('data-theme')}});
  assert.deepEqual({lang:state.lang,currency:state.currency,rate:state.rate,theme:state.theme},expected);
  assert.equal(state.documentLanguage,'th');assert.equal(state.renderedTheme,'light');
  assert.deepEqual(state.windowSize,{width:1371,height:887});
  assert.deepEqual(await desktop.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].getSize()),[1371,887]);
  await page.goto(baseUrl+'/#settings');
  assert.equal(await page.getByRole('spinbutton',{name:'ความกว้าง (px)',exact:true}).inputValue(),'1371');
  assert.equal(await page.getByRole('spinbutton',{name:'ความสูง (px)',exact:true}).inputValue(),'887');
  await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))));
  await page.waitForTimeout(400);
  const captureErrors:string[]=[];let image:{empty:boolean;png:string}|undefined;
  for(let attempt=0;attempt<3&&!image;attempt++){
    try{image=await desktop.evaluate(async({BrowserWindow})=>{const img=await BrowserWindow.getAllWindows()[0].webContents.capturePage(undefined,{stayHidden:true,stayAwake:true});return{empty:img.isEmpty(),png:img.toPNG().toString('base64')}})}
    catch(error){captureErrors.push(String(error));await delay(500)}
  }
  assert.ok(image,`Native capture failed after three attempts: ${captureErrors.join('; ')}`);
  assert.equal(image.empty,false);writeFileSync(join(fixture,`${stage}-native.png`),Buffer.from(image.png,'base64'));
  assert.deepEqual(failures,[]);assert.deepEqual(forbidden,[]);
  result={status:'passed',stage,release:marker.active,indexSha256:sha(raw),state,size:identity.size,offscreen:true,readersDisabled:true,liveDataReady:true,observedMetrics,captureErrors,errors:failures,forbidden};
} finally {
  if(desktop){const app=desktop;const closed=app.waitForEvent('close',{timeout:15000});await app.evaluate(async({app,session})=>{await session.defaultSession.flushStorageData();app.quit()});await closed}
  if(daemon&&daemon.exitCode===null&&daemon.signalCode===null){const exited=new Promise<void>(resolve=>daemon!.once('exit',()=>resolve()));daemon.kill();await Promise.race([exited,delay(10000).then(()=>{throw Error('Owned daemon did not stop')})])}
}
assert.ok(result);writeFileSync(join(fixture,`${stage}-native.json`),JSON.stringify(result,null,2)+'\n');
console.log(`Native isolated profile ${stage}: language, currency, rate and theme verified.`);
