from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib
base=Path('tmp/provider153');rows=[]
files=[Path('tmp/fidelity151/final/providers.png'),Path('tmp/fidelity152/final/providers.png')]+sorted(base.glob('run*/providers.png'))
for left,right in zip(files,files[1:]):
 a=np.asarray(Image.open(left).convert('RGB')).astype(int);b=np.asarray(Image.open(right).convert('RGB')).astype(int);d=np.abs(a-b);yy,xx=np.where(d.max(2)>0)
 rows.append({'left':left.as_posix(),'right':right.as_posix(),'changedPixels':len(xx),'maxChannelDelta':int(d.max()),'bounds':None if not len(xx)else[int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())]})
 a=np.asarray(Image.open(left).convert('RGB'));b=np.asarray(Image.open(right).convert('RGB'))
 if len(xx):
  points=[{'x':int(x),'y':int(y),'before':a[y,x].tolist(),'after':b[y,x].tolist()} for x,y in zip(xx,yy)]
  (base/'diff-points.json').write_text(json.dumps(points,indent=2)+'\n')
reports=[]
for path in sorted(base.glob('run*/header.json')):
 r=json.loads(path.read_text());reports.append({'run':path.parent.name,'headerSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'rect':r['rect'],'animations':r['animations']})
result={'comparisons':rows,'headers':reports};(base/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
