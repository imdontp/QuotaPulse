from pathlib import Path
import subprocess,zipfile,io,json
root=Path.cwd().resolve();dest=root/'tmp/provider153/source151'
assert not dest.exists()
commit='ab9fadcd197f775ed03d97efc7548df88ab4e271'
raw=subprocess.run(['git','archive','--format=zip',commit,'packages/web'],capture_output=True,check=True).stdout
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
 for entry in archive.infolist():
  path=dest/entry.filename
  assert path.resolve().is_relative_to(dest.resolve()) and not (entry.external_attr>>16)&0o170000==0o120000
 archive.extractall(dest)
a=json.loads((root/'tmp/provider153/run1/header.json').read_text());b=json.loads((root/'tmp/provider153/run2/header.json').read_text())
diff={}
for name in a:
 if a[name]!=b[name]:diff[name]=({key:[a[name].get(key),b[name].get(key)] for key in a[name].keys()|b[name].keys() if a[name].get(key)!=b[name].get(key)} if isinstance(a[name],dict) else [a[name],b[name]])
(root/'tmp/provider153/header-diff.json').write_text(json.dumps(diff,indent=2)+'\n');print(json.dumps(diff))
