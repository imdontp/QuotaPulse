from PIL import Image
from collections import Counter
from pathlib import Path
import json
im=Image.open('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/providers.png').convert('RGB')
rows=[]
for y in range(781,788):
 rows.append({'y':y,'pixels':[{'x':x,'rgb':im.getpixel((x,y))} for x in range(295,315)]})
Path('tmp/provider153/reference-grid-samples.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
