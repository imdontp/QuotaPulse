from pathlib import Path
import gzip,hashlib,json,sys
out=Path('docs/redesign-v1.85.153');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,compressed=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not compressed and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0) if compressed else b)
before=load('tmp/fidelity152/final/verification.json');after=load('tmp/fidelity153/final/verification.json');focused=load('tmp/provider153/chart-checks/verification.json');diffs=load('tmp/fidelity153/analysis.json')
assert before['productionIndexSha256']=='1444e3a6bf00cf8c673140a418a06529e707d4e2b73c07c5826bd1d3e18123f8'
assert after['productionIndexSha256']==focused['productionIndexSha256']==sha(Path('packages/web/dist/index.html').read_bytes())
assert load('tmp/provider153-build-result.json')['status']==0
assert len(focused['cases'])==16 and focused['errors']==[]
assert len(after['results'])==8 and all(row['repeatIdentical'] and not row['errors'] and not row['forbidden'] for row in after['results'])
assert len([row for row in diffs if row['changedPixels']==0])==6
assert next(row for row in diffs if row['route']=='models')['changedPixels']==3
assert next(row for row in diffs if row['route']=='providers')['changedPixels']>0
reference=Path('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/providers.png')
assert sha(reference.read_bytes())==next(row for row in after['results'] if row['route']=='providers')['referenceSha256']
copy(reference,'refs/providers.png')
for phase,report,src in [('before',before,'tmp/fidelity152/final/providers.png'),('after',after,'tmp/fidelity153/final/providers.png')]:
 assert sha(Path(src).read_bytes())==next(row for row in report['results'] if row['route']=='providers')['sha256'];copy(src,phase+'/providers.png')
for src,dst in [('tmp/fidelity152/final/verification.json','canonical-before.json'),('tmp/fidelity153/final/verification.json','canonical-current.json'),('tmp/fidelity153/analysis.json','comparison.json'),('tmp/provider153/chart-checks/verification.json','focused.json'),('tmp/provider153-build-result.json','build-result.json'),('tmp/provider153/analysis.json','header-reproduction.json'),('tmp/provider153/source-style-diff.json','source-style-diff.json'),('tmp/provider153/header-diff.json','same-source-style-diff.json'),('tmp/provider153/reference-grid-samples.json','reference-grid-samples.json')]:copy(src,'evidence/'+dst)
for name in ['en-dark-1672','th-light-390']:
 for mode in ['positive','zero']:copy('tmp/provider153/chart-checks/'+name+'-'+mode+'.png','images/'+name+'-'+mode+'.png')
copy('tmp/provider153/grid-before-repeat-fix.png','evidence/intermediate-grid.png')
copy('tmp/provider153/grid-before-repeat-report.json','evidence/intermediate-capture.json')
copy('tmp/fidelity153/final/models.png','evidence/models-current.png')
for src,dst in [('tmp/provider153-build-final.log','build'),('tmp/provider153-chart-final.log','focused'),('tmp/provider153-chart-first.log','first-focus-driver'),('tmp/provider153-chart-api-driver.log','api-identity-driver'),('tmp/fidelity153-final.log','canonical-current'),('tmp/provider153-run1.log','header-run1'),('tmp/provider153-run2.log','header-run2'),('tmp/provider153-run151.log','historical-source151')]:copy(src,'evidence/logs/'+dst+'.log.gz',True)
for name in ['run1','run2','run151']:
 copy('tmp/provider153/'+name+'/header.json','evidence/header/'+name+'.json.gz',True)
 copy('tmp/provider153/'+name+'/verification.json','evidence/header/'+name+'-capture.json')
for name in ['capture-fidelity153.mts','diff153.py','prepare-chart153.py','check-chart153.mts','capture-provider153.mts','prepare-source151-153.py','analyze-provider153.py','compare-style153.py','sample-grid153.py','build153.cjs','package153.py','check-viewer153.mjs']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
sources={}
for name in ['packages/web/src/redesign/providers.css','packages/web/src/redesign/providers.tsx']:
 b=Path(name).read_bytes();sources[name]={'rawSha256':sha(b),'lfSha256':sha(b.replace(b'\r\n',b'\n'))}
write('source-hashes.json',sources)
verified=(out/'evidence/viewer.json').exists()
if verified:
 viewer=load(out/'evidence/viewer.json');assert viewer['status']=='passed' and viewer['productionIndexSha256']==after['productionIndexSha256'] and len(viewer['cases'])==2 and viewer['errors']==[]
else:assert '--draft' in sys.argv
write('delivery.json',{'parentCommit':'5ccb29cc1d49d076b38fafc9951c40fd6693f4dc','productionIndexSha256':after['productionIndexSha256'],'focusedCases':16,'canonicalRepeatPairs':8,'unchangedOtherFrames':6,'modelsUnexplainedPixels':3,'reviewPageVerified':verified,'unitTestsRerun':False,'fullIntegrationRerun':False,'nativeRevalidated':False,'newArchiveCreated':False,'headerVarianceResolved':False,'sseIntermittenceResolved':False,'fullGoalComplete':False})
(out/'README.md').write_bytes('''# Providers reference comparison columns / source153

[Original / source152 / current gallery](review.html) · [Current Providers](after/providers.png) · [Zero percent](images/en-dark-1672-zero.png) · [Previous all-page gallery](../redesign-v1.85.152/review.html)

Validated bounded visual implementation, parent5ccb29cc1d49d076b38fafc9951c40fd6693f4dc. Desktop comparison columns now use42px tracks and allow the reference halo beyond the track. At the original wide dark viewport they have rounded upper corners, restrained inset edges and a dotted24px percentage grid. Representative original grid pixels near301,783 (15,32,58) informed the darker grid color; this is not an exact reconstruction or similarity percentage. The grid covers only the plot, including its baseline, and does not continue under owner names. Initial visual review found an inherited no-repeat setting suppressing the grid beyond its first tile; the intermediate frame is retained. The final positioned pseudo-element covers the complete plot width.

Actual zero readings carry data-empty and suppress the fill shadow at every responsive theme. This prevents a zero-height column from emitting a misleading halo when its track permits overflow. Existing values, selected quota window, API routes, owner order, recorded account states, reader diagnostics and Settings links are preserved. No accounts, billing facts or provider latencies are invented to fill out the concept's catalogue.

## Verification

The final production build has an explicit captured child exit0. Sixteen compiled browser cases span EN/TH, dark/light and390/900/1280/1672 widths. They check real72%/58% ratios, exact42px desktop tracks, zero API readings with zero fill extent and no shadow, full-width repeating plot-only grid, no page overflow, actual owner selection/inspector opening, exact Settings href and keyboard focus. The first driver attempted focus-visible immediately after a pointer selection; using keyboard modality establishes the actual keyboard focus state. A second driver incorrectly expected a database row ID on the Limit API; matching the documented source/window/observed_at identity fixes that driver without weakening the zero-value check. Original logs are retained.

All eight final within-context canonical screenshot pairs are byte-identical. Six other pages are byte-identical to source152. Models has3 unexplained differing edge pixels at x246,y353–414, maximum channel delta23; its full current frame and unmasked diff are retained, and this gate remains open. Providers body changes are confined to the comparison plot at291,655–928,763; the separate105 header pixels remain unexplained. Original ref SHA, previous/current screenshot SHA and full unmasked differences are retained. This small presentation change was validated with the build, focused16-case browser matrix and eight-page capture; the351 unit tests and144-case full integration from source152 were not rerun and are historical evidence only. No new native, ZIP, performance or migration acceptance is claimed.

## Header investigation still open

Two unchanged source152 Providers captures match its historical screenshot exactly, with no active animations and the same header geometry. A separate git-archive source151 web rebuild reproduces its exact historical index f5f103f6e2292019d95ac13cdb05e50243b9b902b6c34f6bed8be0b677e2b45f and its historical105-pixel header difference. All recorded header/parent computed styles and geometry match. The main CSS file index-QQyhxQjn.css is byte-identical across those builds, so swapping that same file is not a discriminating CSS counterfactual. These facts narrow the investigation; they do not establish the rendering/compositing cause or a fix. The final source153 header can still differ by105 pixels at maximum channel delta4 from source152. Full differences remain unmasked; this gate stays open.

The intermittent server2/client1 SSE integration failure from source152 also remains unresolved; no transport code changed here. Exact reference approval and remaining visual/control/motion, native/customer/provider, tray/monitor, performance and migration/rollback gates remain open. Review150 is still the previous runnable ZIP and does not include source151–153. Main and unrelated work are preserved.

Reproducers and compressed raw logs are included. The focused/capture scripts use an isolated synthetic in-memory DB and the compiled application. Run them from this worktree after decompression at tmp/ with node --import tsx; their imports resolve against the repository. The canonical historical baseline is source152, not a fresh run relabeled as before. The new gallery is specific to Providers; the previous gallery covers all eight pages.
'''.encode())
(out/'review.html').write_bytes('''<!doctype html><meta charset="utf-8"><title>Providers comparison / source153</title><style>body{font:14px system-ui;margin:20px;background:#071020;color:#def}a{color:#5cf}select{padding:8px;margin:6px}section{display:grid;grid-template-columns:1fr 1fr;gap:12px}img{width:100%;border:1px solid #456}figure{margin:0}figcaption{margin:8px 0}@media(max-width:900px){section{grid-template-columns:1fr}}</style><h1>Providers / original, source152, source153</h1><p>Owned QA data and original concept differ. No approval or similarity percentage is claimed. <a href="README.md">Changes, evidence and limits</a></p><select id="left-source"><option value="refs">Original concept</option><option value="before">Before / source152</option></select><section><figure><figcaption id="left-label"></figcaption><img id="left" alt="Original reference or previous app frame"></figure><figure><figcaption>Current / source153</figcaption><img id="right" src="after/providers.png" alt="Current compiled app frame"></figure></section><script>const source=document.getElementById('left-source');function show(){document.getElementById('left-label').textContent=source.options[source.selectedIndex].text;document.getElementById('left').src=source.value+'/providers.png'}source.onchange=show;show()</script>'''.encode())
write('artifact-hashes.json',{p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='artifact-hashes.json'})
print('Sealed',len(load(out/'artifact-hashes.json')),'artifacts; viewer verified:',verified)
