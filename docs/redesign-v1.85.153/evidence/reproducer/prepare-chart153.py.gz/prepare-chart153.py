from pathlib import Path
s=Path('tmp/capture-fidelity152.mts').read_text(encoding='utf-8')
s=s[:s.index('let browser:')].replace("'tmp/fidelity152/'+(process.env.QP_FIDELITY_PHASE??'before')", "'tmp/provider153/chart-checks'")
s+='''
let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;
const cases:object[]=[],errors:string[]=[];
const monthlyId=db.prepare("SELECT id FROM limit_sample WHERE source_id=1 AND window_kind='monthly' ORDER BY observed_at DESC LIMIT 1").get() as {id:number};
try{
 await daemon.listen({host:'127.0.0.1',port:7816});browser=await chromium.launch({channel:'chrome',headless:true});
 for(const lang of ['en','th'])for(const theme of ['dark','light'])for(const width of [390,900,1280,1672]){
  db.prepare('UPDATE limit_sample SET used_percent=72 WHERE id=?').run(monthlyId.id);
  const name=`${lang}-${theme}-${width}`,context=await browser.newContext({viewport:{width,height:941},reducedMotion:'reduce',timezoneId:'Asia/Bangkok',deviceScaleFactor:1});
  const page=await context.newPage();page.on('pageerror',e=>errors.push(name+': '+e.message));
  await page.addInitScript(({lang,theme})=>{(window as any).__QUOTAPULSE_TOKEN__='stable-capture-test';localStorage.setItem('quotapulse-prefs',JSON.stringify({lang,currency:'USD',rate:1,hiddenSubscriptions:[]}));localStorage.setItem('quotapulse-theme',theme)},{lang,theme});await installBrowserFixedDate(page,fixedNow);
  await page.goto('http://127.0.0.1:7816/#providers');await page.locator('.qp-provider-comparison li').nth(1).waitFor();
  const read=()=>page.locator('.qp-provider-comparison li').evaluateAll(nodes=>nodes.map(node=>{
   const bar=node.querySelector<HTMLElement>('.qp-bar')!,fill=bar.firstElementChild as HTMLElement;
   return{vendor:node.getAttribute('data-vendor'),value:bar.style.getPropertyValue('--qp-quota-used'),empty:bar.getAttribute('data-empty'),bar:bar.getBoundingClientRect().toJSON(),fill:fill.getBoundingClientRect().toJSON(),shadow:getComputedStyle(fill).boxShadow,overflow:getComputedStyle(bar).overflow,caption:node.querySelector('strong')!.textContent};
  }));
  const positive=await read();assert.deepEqual(positive.map(r=>r.value),['72%','58%']);
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,name+' overflow');
  for(const row of positive){if(width>=1280){assert.equal(row.bar.width,42);assert.ok(Math.abs(row.fill.height-row.bar.height*parseFloat(row.value)/100)<.02);assert.equal(row.overflow,'visible');}else assert.ok(Math.abs(row.fill.width-row.bar.width*parseFloat(row.value)/100)<.02);}
  if(width===1672&&theme==='dark'){const grid=await page.locator('.qp-provider-comparison ol').evaluate(node=>{const style=getComputedStyle(node,'::before');return{size:style.backgroundSize,repeat:style.backgroundRepeat,height:style.height,width:parseFloat(style.width),plotWidth:node.getBoundingClientRect().width}});assert.equal(grid.size,'4px 24px');assert.equal(grid.repeat,'repeat');assert.equal(grid.height,'97px');assert.equal(grid.width,grid.plotWidth);assert.ok(positive.every(r=>r.shadow!=='none'));}
  await page.screenshot({path:resolve(output,name+'-positive.png'),animations:'disabled'});
  await page.locator('.qp-provider-comparison li[data-vendor=opencode] button').click();assert.equal(await page.locator('.qp-provider-card[data-vendor=opencode]').getAttribute('data-selected'),'true');assert.equal(await page.locator('.qp-provider-inspector').getAttribute('open'),'');
  const manage=page.locator('.qp-provider-card[data-vendor=opencode] footer a');assert.equal(await manage.getAttribute('href'),'#settings?subscription=opencode%3Ago');await page.keyboard.press('Tab');await manage.focus();assert.equal(await manage.evaluate(node=>getComputedStyle(node).outlineStyle),'solid');
  db.prepare('UPDATE limit_sample SET used_percent=0 WHERE id=?').run(monthlyId.id);
  const pending=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/overview'&&r.ok());await page.reload();const api=await(await pending).json();assert.ok(api.limits.some((row:any)=>row.source_id===1&&row.window_kind==='monthly'&&row.observed_at===fixedNow-30000&&row.used_percent===0));
  await page.waitForFunction(()=>document.querySelector('.qp-provider-comparison li[data-vendor=openai] .qp-bar')?.getAttribute('data-empty')==='true');
  const zero=(await read()).find(r=>r.vendor==='openai')!;assert.equal(zero.value,'0%');assert.equal(zero.shadow,'none');assert.equal(width>=1280?zero.fill.height:zero.fill.width,0);
  await page.screenshot({path:resolve(output,name+'-zero.png'),animations:'disabled'});
  cases.push({name,positive,zero,selectionWorks:true,manageHref:true,keyboardFocus:true,noPageOverflow:true});await context.close();
 }
 assert.equal(cases.length,16);assert.deepEqual(errors,[]);
 writeFileSync(resolve(output,'verification.json'),JSON.stringify({productionIndexSha256:createHash('sha256').update(readFileSync(resolve(webRoot,'index.html'))).digest('hex'),cases,errors},null,2)+'\\n');console.log('PASS16 Providers comparison cases: real percentages, zero fills, responsive geometry, selection and settings links');
}finally{await browser?.close();await daemon.close();db.close();globalThis.Date=realDate;process.env.TZ=priorTimezone;}
'''
Path('tmp/check-chart153.mts').write_bytes(s.encode())
