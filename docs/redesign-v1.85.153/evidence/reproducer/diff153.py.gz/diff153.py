from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib
rows=[]
for name in ['overview','live','projects','models','history','alerts','providers','cost']:
 left=Path(f'tmp/fidelity152/final/{name}.png');right=Path(f'tmp/fidelity153/final/{name}.png')
 a=np.asarray(Image.open(left).convert('RGB')).astype(int);b=np.asarray(Image.open(right).convert('RGB')).astype(int);d=np.abs(a-b);yy,xx=np.where(d.max(2)>0)
 rows.append({'route':name,'beforeSha256':hashlib.sha256(left.read_bytes()).hexdigest(),'afterSha256':hashlib.sha256(right.read_bytes()).hexdigest(),'changedPixels':len(xx),'maxChannelDelta':int(d.max()),'bounds':None if not len(xx)else[int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())]})
 if name=='providers':
  rows[-1]['regions']={}
  for region,selected in [('header',yy<60),('body',yy>=60)]:
   rx,ry=xx[selected],yy[selected]
   rows[-1]['regions'][region]={'changedPixels':len(rx),'maxChannelDelta':int(d[ry,rx].max()) if len(rx) else 0,'bounds':None if not len(rx)else[int(rx.min()),int(ry.min()),int(rx.max()),int(ry.max())]}
Path('tmp/fidelity153/analysis.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(rows))
