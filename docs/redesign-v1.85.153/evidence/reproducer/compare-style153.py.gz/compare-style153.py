from pathlib import Path
import json
a=json.loads(Path('tmp/provider153/run151/header.json').read_text());b=json.loads(Path('tmp/provider153/run1/header.json').read_text())
diff={}
for name in a:
 if a[name]!=b[name]:diff[name]=({key:[a[name].get(key),b[name].get(key)] for key in a[name].keys()|b[name].keys() if a[name].get(key)!=b[name].get(key)} if isinstance(a[name],dict) else [a[name],b[name]])
Path('tmp/provider153/source-style-diff.json').write_text(json.dumps(diff,indent=2)+'\n');print(json.dumps(diff))
