import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {chromium} from 'playwright';
const root=resolve('docs/redesign-v1.85.140'),rows=JSON.parse(readFileSync(resolve(root,'review-manifest.json'))).captures;
const browser=await chromium.launch({channel:'chrome',headless:true});
try{const page=await browser.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(pathToFileURL(resolve(root,'review.html')).href);let checked=0;
for(const row of rows)for(const phase of ['original','before','current']){await page.locator('#route').selectOption(row.route);await page.locator('#phase').selectOption(phase);await page.waitForFunction(()=>{const img=document.getElementById('frame');return img.complete&&img.naturalWidth>0});checked++}
assert.equal(checked,24);assert.deepEqual(errors,[]);writeFileSync(resolve(root,'evidence/viewer.json'),JSON.stringify({checked,errors},null,2)+'\n');console.log(JSON.stringify({checked,errors}));}finally{await browser.close()}
