from pathlib import Path
from PIL import Image
import numpy as np,json,gzip,hashlib,re,zipfile,sys
out=Path('docs/redesign-v1.85.140');out.mkdir(parents=True,exist_ok=True);base=Path('tmp/fidelity140')
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8').lstrip('\ufeff'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,zipped=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes();p.write_bytes(gzip.compress(b,mtime=0)if zipped else b)
before=load(base/'before/verification.json');after=load(base/'final/verification.json');matrix=load(base/'matrix/verification.json');edge=load(base/'edge/verification.json');stable=load('screens/projects-cards/verification.json')
index=sha(Path('packages/web/dist/index.html').read_bytes());assert before['productionIndexSha256']=='0fd855c959228374a5733d3b0aebbb001e8b3394222eebe6c6836bd503cbc2d4'
assert all(x==index for x in [after['productionIndexSha256'],matrix['productionIndexSha256'],edge['productionIndexSha256'],stable['productionIndexSha256']])
assert matrix['status']==edge['status']=='passed'and len(matrix['results'])==16 and len(edge['results'])==2
assert len(stable['cases'])==4 and all(row['sha256']==row['repeatSha256']for row in stable['cases'])
rows=[];captures=[]
for row in after['results']:
 route=row['route'];old=next(x for x in before['results']if x['route']==route);aPath=base/'before'/(route+'.png');bPath=base/'final'/(route+'.png')
 assert sha(aPath.read_bytes())==old['sha256']and sha(bPath.read_bytes())==row['sha256'];assert row['repeatIdentical']and old['repeatIdentical']
 a=np.asarray(Image.open(aPath).convert('RGB')).astype(int);b=np.asarray(Image.open(bPath).convert('RGB')).astype(int);delta=np.abs(a-b);yy,xx=np.where(delta.max(2)>0)
 rows.append({'route':route,'changedPixels':len(xx),'maxChannelDelta':int(delta.max()),'bounds':None if not len(xx)else[int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())],'mainGeometryEqual':old['geometry']['mainRegions']==row['geometry']['mainRegions'],'withinContextRepeatsExact':True})
 beforePath='images/before/'+route+'.png';copy(aPath,beforePath);current=beforePath
 if row['sha256']!=old['sha256']:current='images/final/'+route+'.png';copy(bPath,current)
 reference='../redesign-v1.85.69/refs/'+route+'.png';assert sha((out/reference).read_bytes())==row['referenceSha256'];captures.append({'route':route,'original':reference,'before':beforePath,'current':current})
assert all(r['changedPixels']==0 for r in rows if r['route']not in ['projects','providers'])
provider=next(r for r in rows if r['route']=='providers');assert provider['changedPixels']==105 and provider['bounds']==[955,12,1362,46]
write('analysis.json',{'scope':'Whole unmasked before/after frames. No concept similarity percentage or whole-goal acceptance.','beforeIndex':before['productionIndexSha256'],'index':index,'rows':rows})
oldShared=load(base/'global-before/shared.json');newShared=load(base/'global-after/shared.json')
for name in ['qp-topbar','qp-sidebar']:
 old=next(x for x in oldShared if x['className']==name);new=next(x for x in newShared if x['className']==name)
 assert old['rect']==new['rect']and len(old['elements'])==len(new['elements'])
 assert all(x['css']==y['css']and x['rect']==y['rect']for x,y in zip(old['elements'],new['elements']))
oldRoot=next(x for x in oldShared if x['className']=='qp-redesign');newRoot=next(x for x in newShared if x['className']=='qp-redesign');assert oldRoot['rect']['height']==947.359375 and newRoot['rect']['height']==941
a=np.asarray(Image.open(base/'before/projects.png').convert('RGB')).astype(int);b=np.asarray(Image.open(base/'height-control/projects.png').convert('RGB')).astype(int);d=np.abs(a-b);assert not(d[:60]>0).any()and not(d[60:,:225]>0).any()
write('height-control.json',{'scope':'Diagnostic browser-only minimum height override; not production or an acceptance mask.','oldRootHeight':947.359375,'actualRootHeight':941,'sharedComputedStylesAndGeometryEqual':True,'controlledOldHeightHeaderChangedPixels':0,'controlledOldHeightSidebarChangedPixels':0,'conclusion':'Restoring old height alone restores exact old shared-shell paint. Actual product retains viewport-fitting height941; the precise browser raster/compositing mechanism is not established.'})
for name,path in [('before',base/'before/verification.json'),('final',base/'final/verification.json'),('matrix',base/'matrix/verification.json'),('edge',base/'edge/verification.json'),('stable','screens/projects-cards/verification.json'),('preaction-stable','tmp/stable140-preaction.json')]:copy(path,'evidence/'+name+'.json.gz',True)
for phase in ['global-before','global-after']:copy(base/phase/'shared.json','evidence/'+phase+'-styles.json.gz',True)
copy(base/'height-control/verification.json','evidence/height-control-capture.json.gz',True);copy(base/'height-control/projects.png','images/diagnostic-height-control.png')
for name in ['en-dark-390','th-light-390','en-dark-1280','th-light-1672']:copy(base/'matrix'/(name+'.png'),'images/matrix/'+name+'.png')
for name in ['en-dark-1672','th-light-390']:copy(base/'edge'/(name+'.png'),'images/edge/'+name+'.png')
for name in ['build140-web-action.log','test140-web-final.log','projects140-matrix-final.log','projects140-edge.log','stable140-projects-final.log','fidelity140-final.log','height-control140.log','projects140-matrix-selector-before.log','stable140-projects-action-count.log','stable140-projects-preaction.log']:copy('tmp/'+name,'evidence/logs/'+name+'.gz',True)
for name in ['capture-fidelity140.mts','check-projects140.mts','check-edge140.mts','measure-global140.mts','control-height140.mts','check-viewer140.mjs','diff-frames140.py','package140.py']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
archive=Path('docs/quotapulse_build_blueprint_v1.1.zip');assert sha(archive.read_bytes())=='28bc63571ddf7ecda1e12e8821c6184378ccfe6c3a599d6ccec29bf17fedb054'
with zipfile.ZipFile(archive)as z:
 members=['quotapulse_build_blueprint/screens/projects.md','quotapulse_build_blueprint/11_REFERENCE_OVERRIDES.md'];write('authority.json',{'archiveSha256':sha(archive.read_bytes()),'members':[{ 'path':member,'sha256':sha(z.read(member))}for member in members],'decision':'Retain original three-tile detail/card-footer composition with separate financial bases and recorded last-observed time, not an active duration or budget.'})
test=Path('tmp/test140-web-final.log').read_bytes();test=test.decode('utf-16'if test[:2]==b'\xff\xfe'else'utf-8');assert re.search(r'^# pass 351\r?$',test,re.M)and re.search(r'^# fail 0\r?$',test,re.M)
sources=['packages/web/src/redesign/projects.tsx','packages/web/src/redesign/projects.css','packages/web/src/redesign/project-reference-summary.css','packages/web/src/redesign/project-observed-identities.ts','packages/web/test/project-observed-identities.test.ts','packages/web/src/i18n/en.ts','packages/web/src/i18n/th.ts','scripts/check-history.mts','scripts/check-stable-captures.mts']
write('source-fingerprints.json',[{'path':p,'rawSha256':sha(Path(p).read_bytes()),'lfSha256':sha(Path(p).read_bytes().replace(b'\r\n',b'\n'))}for p in sources])
viewer=out/'evidence/viewer.json';verified=viewer.exists()
if verified:assert load(viewer)['checked']==24 and load(viewer)['errors']==[]
else:assert '--draft'in sys.argv
write('summary.json',{'checkpoint':'v1.85.140','parent':'e596b1ecee6def892d6a7807e8f77c697cedee5f','index':index,'webTests':351,'browserCases':16,'unavailableCases':2,'stableExactPairs':4,'otherPagesByteIdentical':6,'providersHeaderRasterGate':'open:105 pixels, cause unestablished','fullGoalComplete':False,'reviewPageVerified':verified,'latestRunnableZip':'review139/source138; excludes Projects140'})
write('review-manifest.json',{'index':index,'captures':captures})
(out/'README.md').write_text('''# Projects reference summary v1.85.140

[Original / source138 / current comparison](review.html). Validated bounded UI change; full blueprint and99–100% visual acceptance remain open.

Projects cards restore the reference footer order: Sessions, Harnesses, Providers. Counts use scoped distinct sessions and exact recorded identities. Calls stay visible in card metadata and selected-project facts. Footer marks use source-like blue plates. Provider identities are not inferred from maker/pricing/catalogue metadata; null/empty/whitespace identities contribute an explicit unknown qualifier, not an invented provider. Selected-provider marks and card counts use the same pure helper.

The selected-project rail now uses the reference three-tile composition: recorded tokens with usage-share bar, independently labelled reported-native/API monetary values, and a recorded last-observed timestamp. The time slot implements OVR-012; it does not assert an active duration. Calls/sessions/harness/provider facts remain above the detail tabs. The existing metadata-breakdown action moves into the Providers panel as a compact View All button with its full accessible target label. Actual currencies, partial-cost annotations, scoped dates, null provenance and existing detail/History behavior are preserved. No API/schema/dependency, synthetic production data, authoring, budget or lifecycle feature was added.

Web build and351 tests pass. Sixteen Chrome cases cover EN/TH, dark/light,390/900/1280/1672 and USD/THB, exact API counts/money/timestamp, containment, keyboard selection and detail tabs. Two additional cases exercise actual missing-provider records plus a valid nullable timestamp API variant, no fake clock value, no page overflow and keyboard View All into the existing complete metadata breakdown. The maintained Projects gate finishes with four byte-identical pairs. Test selectors now count actual identity marks (the action is not a provider) and locate Calls by its fact identity rather than old box position. The large check-history suite itself was not rerun; its monetary/fact assertions remain intact with the changed selector. Initial broad time-selector and action-li count failures are retained, not relabelled as application defects.

Whole unmasked source138/current frames are retained for all eight routes: six other pages are byte-identical; Providers keeps the known105-pixel global-header difference with unestablished cause. Within-context repeats are exact on all eight routes. These results do not close the full distinct-document raster gate.

The Projects root now fits941px rather than overflowing to947.359375px. This also changes shared-shell raster paint despite identical complete computed styles and geometry for header/sidebar. A separate browser-only experiment restoring the old root height restores old header/sidebar pixels exactly. The production page retains941px; no artificial height, masks or tolerance exception was added. The exact browser compositing mechanism is not established. Diagnostic images/styles and control results are retained separately from product acceptance frames. An intermediate pre-action build had only three exact pairs; the final build has four.

Approved v1.1 archive/member hashes are recorded in authority.json. Renderer tests use owned in-memory data only; no customer logs or credentials were read. Native Electron, installed runtime, all long-identity/large-currency boundaries and physical/performance behavior are not newly recertified. Existing accepted gap ledger/requirement trace remain authoritative. Latest runnable ZIP is review139/source138 and does not include this140 Projects change. Main and unrelated work remain unchanged.
''',encoding='utf-8',newline='\n')
html='''<!doctype html><meta charset="utf-8"><title>QuotaPulse Projects review140</title><style>body{font:14px system-ui;background:#071020;color:#def;margin:20px}select{padding:8px;margin:6px}img{display:block;max-width:100%;border:1px solid #456;margin-top:12px}a{color:#5cf}</style><h1>Original / source138 / Projects140</h1><p>Owned QA data. No99–100% parity claim. <a href="README.md">Changes, evidence and limits</a></p><select id="route"></select><select id="phase"><option value="original">Original reference</option><option value="before">Source138</option><option value="current" selected>Projects140</option></select><img id="frame" alt="Selected dashboard comparison"><script>const rows=DATA,route=document.getElementById('route'),phase=document.getElementById('phase'),frame=document.getElementById('frame');for(const row of rows){const o=document.createElement('option');o.value=row.route;o.textContent=row.route;route.append(o)}route.value='projects';function show(){frame.src=rows.find(row=>row.route===route.value)[phase.value]}route.onchange=phase.onchange=show;show()</script>'''.replace('DATA',json.dumps(captures))
(out/'review.html').write_text(html,encoding='utf-8',newline='\n')
write('artifact-hashes.json',{str(p.relative_to(out)).replace('\\','/'):sha(p.read_bytes())for p in sorted(out.rglob('*'))if p.is_file()and p.name!='artifact-hashes.json'})
print(json.dumps({'index':index,'artifacts':len(load(out/'artifact-hashes.json')),'rows':rows}))
