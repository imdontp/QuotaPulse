from PIL import Image
import numpy as np,json
for left,right in [('before','global-before'),('final','global-after'),('global-before','global-after')]:
 a=np.asarray(Image.open(f'tmp/fidelity140/{left}/projects.png').convert('RGB')).astype(int);b=np.asarray(Image.open(f'tmp/fidelity140/{right}/projects.png').convert('RGB')).astype(int);d=np.abs(a-b);yy,xx=np.where(d.max(2)>0)
 print(json.dumps({'left':left,'right':right,'pixels':len(xx),'max':int(d.max()),'bounds':None if not len(xx)else[int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())],'headerPixels':int((d[:60].max(2)>0).sum()),'sidebarPixels':int((d[60:,:225].max(2)>0).sum())}))
