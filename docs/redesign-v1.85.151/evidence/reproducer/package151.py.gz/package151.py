from pathlib import Path
import gzip,hashlib,json,sys
from PIL import Image
out=Path('docs/redesign-v1.85.151');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,compressed=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not compressed and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0) if compressed else b)
def log(name):
 b=Path(name).read_bytes();return b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
before=load('tmp/fidelity151/before/verification.json');after=load('tmp/fidelity151/final/verification.json');bars=load('screens/history-token-bars/verification.json');diffs=load('tmp/fidelity151/analysis.json');density=load('tmp/fidelity151/final/history-table-density.json')
assert before['productionIndexSha256']=='f9df009691e9ccf99f7c674dfc560c4861cef60273cf327d0c5f46b41c253500'
assert after['productionIndexSha256']==bars['productionIndexSha256']==sha(Path('packages/web/dist/index.html').read_bytes())
assert len(before['results'])==len(after['results'])==8 and all(row['repeatIdentical'] and not row['errors'] and not row['forbidden'] for row in before['results']+after['results'])
assert len(bars['cases'])==16 and bars['errors']==[] and bars['legacyPreserved']
assert '# pass 351' in log('tmp/token151-web-tests.log') and '# fail 0' in log('tmp/token151-web-tests.log')
assert 'History/Overview/Projects/Live/Providers/Models/Cost/Alerts E2E passed' in log('tmp/token151-integration.log') and 'History teardown: database closed' in log('tmp/token151-integration.log')
matrix=load('screens/history/responsive-matrix.json');assert len(matrix['cases'])==144 and all(row['streams']<=1 for row in matrix['cases'])
assert density['clientWidth']==density['scrollWidth']==1124 and len(density['rows'])==10 and all(row['height']==33 and row['bottom']<=941 for row in density['rows'])
assert len([row for row in diffs if row['changedPixels']==0])==6
historyDiff=next(row for row in diffs if row['route']=='history');assert historyDiff['bounds'][0]>=239 and historyDiff['bounds'][1]>=523 and historyDiff['bounds'][2]<=1363 and historyDiff['bounds'][3]<=889
referenceRoot=Path('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs')
for row in after['results']:
 route=row['route'];ref=referenceRoot/(route+'.png');assert sha(ref.read_bytes())==row['referenceSha256'];copy(ref,'refs/'+route+'.png')
 for phase,report in [('before',before),('final',after)]:
  record=next(value for value in report['results'] if value['route']==route);p=Path('tmp/fidelity151')/phase/(route+'.png');assert sha(p.read_bytes())==record['sha256'];copy(p,('before' if phase=='before' else 'after')+'/'+route+'.png')
for src,dst in [('tmp/fidelity151/before/verification.json','canonical-before.json'),('tmp/fidelity151/final/verification.json','canonical-current.json'),('tmp/fidelity151/analysis.json','comparison.json'),('tmp/fidelity151/final/history-table-density.json','density.json'),('screens/history-token-bars/verification.json','token-bars.json'),('tmp/cssom151-control.json','cssom-control.json'),('screens/history/verification.json','integration.json'),('screens/history/responsive-matrix.json','integration-matrix.json')]:copy(src,'evidence/'+dst)
for name in ['en-dark-1672','th-light-390']:copy('screens/history-token-bars/'+name+'.png','images/'+name+'.png')
copy('tmp/fidelity151/history-before-nowrap.png','evidence/intermediate-wrapped-rows.png')
copy('tmp/fidelity151/verification-before-nowrap.json','evidence/intermediate-capture.json')
for src,dst in [('tmp/token151-web-build.log','build'),('tmp/token151-web-tests.log','web-tests'),('tmp/token151-browser-final.log','browser'),('tmp/token151-browser-first.log','first-cssom-failure'),('tmp/token151-browser.log','diagnosed-cssom-failure'),('tmp/token151-integration.log','integration'),('tmp/fidelity151-before.log','canonical-before'),('tmp/fidelity151-final.log','canonical-current')]:copy(src,'evidence/logs/'+dst+'.log.gz',True)
for name in ['capture-fidelity151.mts','diff151.py','cssom151.mjs','package151.py','check-viewer151.mjs']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
ref=Image.open(referenceRoot/'history.png').convert('RGB')
write('evidence/reference-samples.json',{'referenceSha256':sha((referenceRoot/'history.png').read_bytes()),'rowY':574,'samples':[{'x':x,'rgb':ref.getpixel((x,574))} for x in range(928,981,4)],'chosenStops':['#0098f7','#287efa'],'scope':'Representative interior samples guide gradient direction/colors; no exact reconstruction claim.'})
sources={}
for name in ['packages/web/src/sections/history.tsx','packages/web/src/redesign/history.css','packages/web/src/i18n/en.ts','packages/web/src/i18n/th.ts','scripts/check-history-token-bars.mts']:
 b=Path(name).read_bytes();sources[name]={'rawSha256':sha(b),'lfSha256':sha(b.replace(b'\r\n',b'\n'))}
write('source-hashes.json',sources)
verified=(out/'evidence/viewer.json').exists()
if verified:
 viewer=load(out/'evidence/viewer.json');assert viewer['status']=='passed' and viewer['productionIndexSha256']==after['productionIndexSha256'] and len(viewer['cases'])==16 and viewer['errors']==[]
else:assert '--draft' in sys.argv
write('delivery.json',{'parentCommit':'e017b9d6d60246cd35fc0f73c372a82248477734','productionIndexSha256':after['productionIndexSha256'],'webTests':351,'tokenBarCases':16,'fullIntegrationPassed':True,'canonicalRepeatPairs':8,'unchangedOtherFrames':6,'providersChangedPixels':next(row['changedPixels'] for row in diffs if row['route']=='providers'),'referenceWidthTableFits':True,'tenRowsHeight':33,'reviewPageVerified':verified,'nativeRevalidated':False,'newArchiveCreated':False,'fullGoalComplete':False})
(out/'README.md').write_bytes('''# History reference table — source151

[Concept/before/current gallery](review.html) · [Current History](after/history.png) · [Previous runnable review150](../redesign-v1.85.150/README.md)

Validated bounded reference-fidelity change. Parent `e017b9d6d60246cd35fc0f73c372a82248477734`. The reference is the user's original refs directory, SHA-checked against the maintained manifest. Original concepts and owned consistent QA data legitimately differ; this does not claim99–100% approval or copy invented costs, statuses, prompts or benchmarks into the application.

History now shows blue comparison bars beside recorded token counts, with colors/direction informed by actual reference interior pixels. Each bar compares against the largest token record on the currently displayed page; localized hover text explicitly states that basis. API totals/exports/scope are untouched. Paging and filters recompute the visible-page maximum. Raw token counts remain exact in accessible labels and numeric titles. Zero-only pages omit a percentage comparison; tiny positive values retain their true requested ratio and a precise nonzero tooltip. No minimum fill is imposed.

The redesigned columns now follow the concept's primary sequence: time, project, harness, provider, model, tokens, monetary basis, record kind, metadata action. Record kind is real call/aggregate metadata, not an invented Completed/Failed status. The timestamp arrow and aria-sort describe the existing descending API order; no fake sorting button was added. Full project metadata remains in the DOM/title when a long name is clipped. The legacy mode keeps its original column order and raw numeric rendering.

Added bars initially squeezed record-kind/project cells into multiple lines. That candidate is retained as diagnostic evidence. Final compact interior spacing and no-wrap constraints restore ten33px rows within the941px reference viewport. All columns fit the1124px table viewport without horizontal scrolling at1672×941. Header, chart, summaries, filters and detail-rail pixels remain outside the History change bounds; actual History differences are retained unmasked in the comparison JSON.

## Validation

Production web build and351 tests pass with no failures/skips/cancellations. Sixteen compiled cases cover EN/TH, dark/light,390/900/1280/1672 widths,50-row and6-row pages, filtered/zero pages, ratios down to0.000001, exact headers/field mapping, raw labels, aligned50×6px tracks and preserved legacy order. The full unchanged integration passes including144 responsive route cases, actual authenticated HTTP/in-memory SQLite, paging/export, drill-down scopes, pause/in-flight protection, money bases, occupied layouts and SSE counts. All own handles close.

The first tiny-width check incorrectly expected an exact numeric round-trip through CSSOM. An independent detached-element Chrome control reproduces conversion of requested0.00009999999999999999% to9.99e-05%. Verification now strictly compares product serialization against an independently serialized exact API ratio, while keeping exact raw ratios and zero-minimum checks. No numeric tolerance was widened. Logs/control data are retained; this is browser serialization, not a product floor. Tiny tooltip precision was also improved so1/1,000,000 reads0.0001% rather than0%.

All eight final canonical within-context screenshot pairs are byte-identical. Six other before/current page frames are byte-identical. Providers retains105 differing global-header pixels (maximum channel delta4), still unexplained; no mask/tolerance closes that gate. The History changes are confined to its table region. These are browser/owned-fixture checks, not new native or performance acceptance.

```powershell
npm.cmd run build -w @quotapulse/web
npm.cmd run test -w @quotapulse/web
node --import tsx scripts/check-history-token-bars.mts
node --import tsx scripts/check-history.mts
```

The gallery's original/before/current images are complete unmasked frames. Controls/data use the accepted truthful replacements and a consistent owned fixture; screenshot similarity percentages are not invented. Source hashes, strict density checks, raw compressed logs and reproducers are retained. Current source151 still needs native/ZIP validation; review150 remains unchanged and does not include these later table changes. Main/origin and unrelated files are preserved. Original-reference approval, remaining header/control composition, native/customer/provider/performance and migration/rollback gates remain open.
'''.encode())
routes=[row['route'] for row in after['results']]
html='''<!doctype html><meta charset="utf-8"><title>History reference table / source151</title><style>body{font:14px system-ui;margin:20px;background:#071020;color:#def}a{color:#5cf}select{padding:8px;margin:6px}section{display:grid;grid-template-columns:1fr 1fr;gap:12px}img{width:100%;border:1px solid #456}figure{margin:0}figcaption{margin:8px 0}@media(max-width:900px){section{grid-template-columns:1fr}}</style><h1>Source151 / original, before, current</h1><p>Original concept and owned QA app data differ. No approval or similarity percentage is claimed. <a href="README.md">Changes, evidence and limits</a></p><select id="route">'''+''.join('<option'+(' selected' if route=='history' else '')+'>'+route+'</option>' for route in routes)+'''</select><select id="left-source"><option value="refs">Original concept</option><option value="before">Before / source149</option></select><section><figure><figcaption id="left-label"></figcaption><img id="left" alt="Original reference or previous app frame"></figure><figure><figcaption>Current / source151</figcaption><img id="right" alt="Current actual compiled app frame"></figure></section><script>const route=document.getElementById('route'),source=document.getElementById('left-source');function show(){document.getElementById('left-label').textContent=source.options[source.selectedIndex].text;document.getElementById('left').src=source.value+'/'+route.value+'.png';document.getElementById('right').src='after/'+route.value+'.png'}route.onchange=source.onchange=show;show()</script>'''
(out/'review.html').write_bytes(html.encode())
write('artifact-hashes.json',{p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='artifact-hashes.json'})
print('Sealed',len(load(out/'artifact-hashes.json')),'artifacts; viewer verified:',verified)
