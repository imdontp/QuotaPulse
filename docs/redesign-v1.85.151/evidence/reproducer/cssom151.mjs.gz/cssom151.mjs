import { chromium } from 'playwright';
import { writeFileSync } from 'node:fs';
const browser=await chromium.launch({channel:'chrome',headless:true});
try{const page=await browser.newPage();const rows=await page.evaluate(()=>[1/1000000,5/1000000,.25,1,0].map(ratio=>{const control=document.createElement('i'),requested=`${ratio*100}%`;control.style.width=requested;return{ratio,requested,serialized:control.style.width}}));writeFileSync('tmp/cssom151-control.json',JSON.stringify({browser:browser.version(),rows},null,2)+'\n');console.log(JSON.stringify(rows));}finally{await browser.close()}
