import assert from 'node:assert/strict';
import { readFileSync,writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { chromium } from 'playwright';
const root=resolve('docs/redesign-v1.85.151'),report=JSON.parse(readFileSync(resolve(root,'evidence/canonical-current.json')));
assert.equal(report.productionIndexSha256,'f5f103f6e2292019d95ac13cdb05e50243b9b902b6c34f6bed8be0b677e2b45f');
const browser=await chromium.launch({channel:'chrome',headless:true});
try{
 const page=await browser.newPage(),errors=[],cases=[];page.on('pageerror',error=>errors.push(error.message));await page.goto(pathToFileURL(resolve(root,'review.html')).href);
 for(const row of report.results)for(const mode of ['refs','before']){
  await page.locator('#route').selectOption(row.route);await page.locator('#left-source').selectOption(mode);
  await page.waitForFunction(({route,mode,width})=>['left','right'].every(id=>{const img=document.getElementById(id);return img.complete&&img.naturalWidth===width&&decodeURI(img.currentSrc).endsWith((id==='left'?mode:'after')+'/'+route+'.png')}),{route:row.route,mode,width:row.viewport.width});
  cases.push(mode+'/'+row.route);
 }
 assert.equal(cases.length,16);assert.deepEqual(errors,[]);writeFileSync(resolve(root,'evidence/viewer.json'),JSON.stringify({status:'passed',productionIndexSha256:report.productionIndexSha256,browser:browser.version(),cases,errors},null,2)+'\n');console.log(JSON.stringify({checked:cases.length,errors}));
}finally{await browser.close()}
