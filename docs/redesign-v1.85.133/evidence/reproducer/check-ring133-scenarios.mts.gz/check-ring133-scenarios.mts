/** Static canonical reference capture. Isolated synthetic DB, compiled application, no user data. */
import assert from 'node:assert/strict';
import { en } from '../packages/web/src/i18n/en.js';
import { th } from '../packages/web/src/i18n/th.js';
import { installBrowserFixedDate } from '../scripts/browser-fixed-date.mjs';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium, type Page, type Request } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import { recordQuotaAlerts } from '../packages/daemon/src/api/queries.js';
const root = fileURLToPath(new URL('..', import.meta.url));
const output = resolve(root, 'tmp/fidelity133/scenarios'); 
const referenceRoot = 'C:/Users/TH12367283/Downloads/quotapulse_build_blueprint';
const priorTimezone = process.env.TZ;
process.env.TZ = 'Asia/Bangkok';
mkdirSync(output, { recursive: true });

const fixedNow = Date.parse('2025-05-17T13:42:00.000Z');
// Freeze Date only, keeping real timers/performance for HTTP, browser and cleanup.
// This applies to internal query helpers too, without changing production clocks.
const realDate = globalThis.Date;
globalThis.Date = new Proxy(realDate, {
  construct(target, args) { return Reflect.construct(target, args.length ? args : [fixedNow]); },
  apply() { return new realDate(fixedNow).toString(); },
  get(target, property, receiver) { return property === 'now' ? () => fixedNow : Reflect.get(target, property, receiver); },
});
const db = openDb(':memory:');
db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at,account_key,account_provider,account_display_name,account_state,account_last_success_at)
  VALUES (1,'codex','fixed','/synthetic/nonexistent','Codex fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow}),
    (2,'hermes','fixed','/synthetic/nonexistent','Hermes fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (3,'claude-code','fixed','/synthetic/nonexistent','Claude Code fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (4,'opencode','fixed','/synthetic/nonexistent','OpenCode fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow});`);
const referenceProjects = ['QuotaPulse', 'Agent Platform', 'Edge Services', 'Developer Tools', 'Research Lab'];
const referenceModels = [
  { name: 'DeepSeek V4.1', provider: 'deepseek', share: 38 },
  { name: 'GPT-5.x', provider: 'openai', share: 24 },
  { name: 'Claude 3.7', provider: 'anthropic', share: 18 },
  { name: 'Claude 3.5', provider: 'anthropic', share: 11 },
  { name: 'Others', provider: 'openrouter', share: 9 },
  { name: 'GPT-4.1 mini', provider: 'openai', share: 0 },
];
const session = db.prepare('INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (?,?,?,?,?)');
const usage = db.prepare('INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source,cost_input_usd,cost_cached_input_usd,cost_cache_write_usd,cost_output_usd,cost_cache_saving_usd,price_provider) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
// Synthetic catalogue rates for the in-memory visual fixture only. The saved
// amount is derived from the same fresh/cached input components the UI reports.
const fixtureInputUsdPerMillion = 0.0593846153846154, fixtureCachedInputUsdPerMillion = 0.004, fixtureOutputUsdPerMillion = 0.004;
for (let index = 0; index < 12; index++) {
  // Keep the reference map's 4 Codex, 2 Claude Code, 6 Hermes, 0 OpenCode
  // recent-session distribution while preserving the same 12 sessions.
  const source = [1, 1, 1, 1, 3, 3, 2, 2, 2, 2, 2, 2][index]!;
  session.run(index + 1, source, `fixture-session-${index}`, referenceProjects[0], fixedNow - 10_000);
  const model = referenceModels[index % referenceModels.length]!;
  const totalTokens = model.share === 0 ? 1 : model.share * 721_000_000 / 600;
  for (let call = 0; call < 3; call++) {
    const inputShare = [.6, .65, .7][(index + call) % 3]!;
    const inputTokens = totalTokens * inputShare * .58, cachedInputTokens = totalTokens * inputShare * .42;
    const outputTokens = totalTokens * (1 - inputShare);
    const costSource = index === 0 ? 'native' : 'computed';
    const inputUsd = inputTokens / 1_000_000 * fixtureInputUsdPerMillion;
    const cachedInputUsd = cachedInputTokens / 1_000_000 * fixtureCachedInputUsdPerMillion;
    const outputUsd = outputTokens / 1_000_000 * fixtureOutputUsdPerMillion;
    const cacheSavingUsd = cachedInputTokens / 1_000_000 * (fixtureInputUsdPerMillion - fixtureCachedInputUsdPerMillion);
    // Keep each session's latest record within four minutes, then spread older calls across the visible 30-minute interval.
    const ageMs = call === 0 ? 15_000 + index * 20_000 : source === 2
      ? 300_000 + index * 120_000 + (call === 2 ? 30_000 : 0)
      : 300_000 + index * 240_000 + (call === 2 ? 90_000 : 0);
    const recordedAt = fixedNow - ageMs;
    usage.run(source, index + 1, `fixed-${index}-${call}`, recordedAt, model.name, model.provider,
      inputTokens, cachedInputTokens, outputTokens, totalTokens, call + 1,
      costSource === 'native' ? (index + 1) / 100 : inputUsd + cachedInputUsd + outputUsd, costSource,
      costSource === 'native' ? null : inputUsd, costSource === 'native' ? null : cachedInputUsd,
      costSource === 'native' ? null : 0, costSource === 'native' ? null : outputUsd,
      costSource === 'native' ? null : cacheSavingUsd, costSource === 'native' ? null : model.provider);
  }
}
// A stale recorded OpenCode route keeps the concept's zero-active-session edge
// visible without manufacturing a provider relationship or changing live counts.
const openCodeAt = fixedNow - 10 * 60_000;
session.run(13, 4, 'fixture-opencode-quota-pulse', referenceProjects[0], openCodeAt);
usage.run(4, 13, 'fixed-opencode-route', openCodeAt, 'DeepSeek V4.1', 'deepseek', 1, 0, 0, 1, 1,
  null, 'unknown', null, null, null, null, null, null);
// The monthly concept is focused on QuotaPulse while the machine-wide quick
// stats still report all five named projects. Keep four small monthly records
// for the other projects, outside the recent-session window.
for (let index = 1; index < referenceProjects.length; index++) {
  const id = 100 + index, source = [1, 3, 4, 2][index - 1]!;
  const model = referenceModels[index - 1]!;
  const at = fixedNow - 10 * 60_000;
  session.run(id, source, `fixture-project-${index}`, referenceProjects[index], at);
  const inputUsd = fixtureInputUsdPerMillion / 1_000_000;
  usage.run(source, id, `fixture-project-usage-${index}`, at, model.name, model.provider, 1, 0, 0, 1, 1,
    inputUsd, 'computed', inputUsd, 0, 0, 0, 0, model.provider);
}
// Values below the old visual minimum catch inflated nonzero bars in both charts.
const tinyUsage = db.prepare("INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source) VALUES (1,1,?,?,'DeepSeek V4.1','deepseek',1,0,0,1,1,0,'computed')");
tinyUsage.run('fixed-tiny-minute', fixedNow - 15 * 60_000);
tinyUsage.run('fixed-tiny-day', fixedNow - 3 * 86_400_000);
const quota = db.prepare('INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin) VALUES (?,?,?,?,?,?,?,?)');
const addQuotaSample = (sourceId: number, window: string, percent: number | null, resetAt: number | null, observedAt: number) => quota.run(sourceId, window, percent, resetAt, observedAt, observedAt, observedAt, 'fixed-fixture');
// Complete history must include older reset periods, nulls and more than eight
// readings per period, without changing the latest live quota/default selection.
for (let segment = 0; segment < 4; segment++) for (let index = 0; index < 12; index++) {
  const at = fixedNow - (5 - segment) * 3_600_000 + index * 60_000;
  addQuotaSample(1, '5h', index === 4 ? null : index === 1 ? 0.5 : index * 8, segment === 0 ? null : fixedNow - (4 - segment) * 3_600_000, at);
}
addQuotaSample(1, '5h', 38, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 5 * 60_000);
addQuotaSample(1, '5h', 83, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 30_000);
addQuotaSample(1, 'weekly', 62, fixedNow + (3 * 24 + 5) * 3_600_000, fixedNow - 30_000);
const monthlyReset = fixedNow + (6 * 24 + 2) * 3_600_000;
addQuotaSample(1, 'monthly', 59, monthlyReset, fixedNow - 48 * 3_600_000);
addQuotaSample(1, 'monthly', 65.5, monthlyReset, fixedNow - 24 * 3_600_000);
addQuotaSample(1, 'monthly', 72, monthlyReset, fixedNow - 30_000);
addQuotaSample(2, 'monthly', 58, fixedNow + (12 * 24 + 6) * 3_600_000, fixedNow - 30_000);
addQuotaSample(2, 'daily', 34, fixedNow + (7 * 60 + 18) * 60_000, fixedNow - 30_000);
recordQuotaAlerts(db, fixedNow);
const scheduler = new Scheduler(db, [], { pollMs: 1_000_000, detectMs: 1_000_000 });
const daemon = buildServer(db, scheduler, { token: 'stable-capture-test', port: 7816, webRoot: resolve(root, 'packages/web/dist') });

let browser:Awaited<ReturnType<typeof chromium.launch>>|undefined;
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const indexPath=resolve(root,'packages/web/dist/index.html'),index=sha(readFileSync(indexPath));
const results:any[]=[];
async function checkRing(page:Page,group:any,lang:string){
 const root=page.locator('.qp-model-distribution[data-ring=input-output]');await root.waitFor();
 const input=group.inputTokens+group.cachedInputTokens+group.cacheWriteTokens,total=input+group.outputTokens;
 assert.ok(Math.abs(Number(await root.getAttribute('data-component-total'))-total)<1e-6);assert.equal(Number(await root.getAttribute('data-recorded-total')),group.tokens);
 const legend=root.locator('.qp-model-distribution-legend>li');assert.equal(await legend.count(),2);
 for(const[key,value]of [['input',input],['output',group.outputTokens]]as const){const row=legend.locator('[data-token-part='+key+']');assert.equal(Number(await root.locator('[data-token-part='+key+']').getAttribute('data-value')),value)}
 const sectors=await root.locator('circle[data-token-sector]').evaluateAll(nodes=>nodes.map(node=>({key:node.getAttribute('data-token-sector'),value:Number(node.getAttribute('data-value')),share:Number(node.getAttribute('data-share')),sweep:Number(node.getAttribute('data-sweep')),dash:node.getAttribute('stroke-dasharray'),offset:node.getAttribute('stroke-dashoffset')})));
 const available=total>0||group.tokens===0;
 assert.equal(sectors.length,available?[input,group.outputTokens].filter(value=>value>0).length:0);
 for(const part of sectors){const value=part.key==='input'?input:group.outputTokens;assert.equal(part.value,value);assert.ok(Math.abs(part.share-value/total*100)<1e-9);assert.ok(Math.abs(part.sweep-value/total*360)<1e-9);const paint=Number(part.dash!.split(' ')[0]);assert.ok(paint>0&&paint<=part.sweep)}
 const ids=await root.locator('defs [id]').evaluateAll(nodes=>nodes.map(node=>node.id));assert.equal(new Set(ids).size,2);for(const part of await root.locator('circle[data-token-sector]').all())assert.ok(ids.includes((await part.getAttribute('stroke'))!.slice(5,-1)));
 const summary=root.locator('details summary');await summary.focus();await page.keyboard.press('Enter');await root.locator('details[open]').waitFor();assert.equal(await root.locator('dl>div').count(),3);
 const exact=new Intl.NumberFormat(lang==='th'?'th-TH':'en-US',{maximumFractionDigits:8});for(const key of ['inputTokens','cachedInputTokens','cacheWriteTokens'])assert.equal(await root.locator('[data-component='+key+'] dd').innerText(),exact.format(group[key]));
 const body=await root.locator('details').boundingBox(),ring=await root.locator('.qp-model-donut').boundingBox();assert.ok(body!.y>=ring!.y+ring!.height-.5,'Expanded cache facts must not overlap the ring');
 const mismatch=Math.abs(total-group.tokens)>Number.EPSILON*16*Math.max(1,total,group.tokens);assert.equal(await root.getByTestId('model-component-mismatch').count(),mismatch?1:0);
 if(mismatch){const text=await root.getByTestId('model-component-mismatch').innerText();assert.ok(text.includes(exact.format(group.tokens))&&text.includes(exact.format(total)))}
 await summary.focus();await page.keyboard.press('Enter');assert.equal(await root.locator('details[open]').count(),0);
 const geometry=await root.evaluate(element=>({rect:element.getBoundingClientRect().toJSON(),children:[...element.querySelectorAll('h2,.qp-model-donut,.qp-model-distribution-legend,summary')].map(node=>({tag:node.tagName,rect:node.getBoundingClientRect().toJSON()}))}));for(const child of geometry.children)assert.ok(child.rect.left>=geometry.rect.left-.5&&child.rect.right<=geometry.rect.right+.5,JSON.stringify(child));
 return{input,output:group.outputTokens,total,recordedTotal:group.tokens,mismatch,sectors,geometry,keyboardDisclosure:true};
}
try{
 await daemon.listen({host:'127.0.0.1',port:7816});browser=await chromium.launch({channel:'chrome',headless:true});
 const fixtures=[
  ['Component mismatch',11,13,17,19,777],['Zero components',0,0,0,0,0],['Missing components',0,0,0,0,50],
  ['Input only',70,20,10,0,100],['Output only',0,0,0,100,100],['Tiny input',1,0,0,99999999,100000000],
 ] as const;
 const insert=db.prepare('INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,cache_write_tokens,output_tokens,total_tokens,call_count,cost_source) VALUES (1,1,?,?,?,?,?,?,?,?,?,1,?)');
 for(const [model,input,cached,write,output,total]of fixtures)insert.run('ring133-'+model,fixedNow-1000,model,'openai',input,cached,write,output,total,'unknown');
 for(const [lang,theme,width]of [['en','dark',1672],['th','light',390]]as const){
  const context=await browser.newContext({viewport:{width,height:941},deviceScaleFactor:1,reducedMotion:'reduce',timezoneId:'Asia/Bangkok'}),page=await context.newPage(),errors:string[]=[],forbidden:string[]=[];
  page.on('pageerror',e=>errors.push(e.message));await page.route('**/*',route=>{const r=route.request(),u=new URL(r.url());if(u.origin!=='http://127.0.0.1:7816'||r.method()!=='GET'&&!(r.method()==='POST'&&u.pathname==='/api/model-row-trends')){forbidden.push(r.method()+' '+u.pathname);return route.abort()}return route.continue()});
  await page.addInitScript(({lang,theme})=>{(window as any).__QUOTAPULSE_TOKEN__='stable-capture-test';localStorage.setItem('quotapulse-prefs',JSON.stringify({lang,currency:'USD',rate:1,hiddenSubscriptions:[]}));localStorage.setItem('quotapulse-theme',theme)},{lang,theme});await installBrowserFixedDate(page,fixedNow);
  const responsePromise=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/models'&&r.status()===200);
  await page.goto('http://127.0.0.1:7816/#models',{waitUntil:'domcontentloaded'});const u=new URL((await responsePromise).url()),response=await daemon.inject({url:u.pathname+u.search,headers:{'x-quotapulse-token':'stable-capture-test'}});assert.equal(response.statusCode,200);const groups=response.json().groups;
  for(const[model]of fixtures){
   await page.goto('http://127.0.0.1:7816/#models?model='+encodeURIComponent(model)+'&selected_provider=openai');await page.waitForFunction(name=>document.querySelector('.qp-model-detail h3')?.textContent===name,model);await page.evaluate(()=>document.fonts.ready);
   const group=groups.find((group:any)=>group.model===model&&group.provider==='openai');assert.ok(group);const checked=await checkRing(page,group,lang);
   if(model==='Component mismatch'){assert.equal(checked.total,60);assert.equal(checked.recordedTotal,777)}
   if(model==='Missing components')assert.equal(await page.locator('.qp-model-ring-center b').innerText(),'—');
   if(model==='Zero components')assert.equal(await page.locator('.qp-model-ring-center b').innerText(),'0');
   assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);const name=[model.replaceAll(' ','-'),lang,theme,width].join('-');const frame=await page.screenshot({path:resolve(output,name+'.png'),animations:'disabled'});results.push({name,lang,theme,width,model,checked,sha256:sha(frame)});console.log('Passed '+name);
  }
  assert.deepEqual(errors,[]);assert.deepEqual(forbidden,[]);await context.close();
 }
 assert.equal(sha(readFileSync(indexPath)),index);writeFileSync(resolve(output,'verification.json'),JSON.stringify({status:'passed',index,browser:browser.version(),results},null,2));
}finally{await browser?.close();await daemon.close();db.close();globalThis.Date=realDate;process.env.TZ=priorTimezone}
