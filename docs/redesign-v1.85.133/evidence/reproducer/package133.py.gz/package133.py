from pathlib import Path
import json,hashlib,gzip,subprocess,zipfile,re
root=Path('docs/redesign-v1.85.133');base=Path('tmp/fidelity133');root.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text(encoding='utf8').lstrip('\ufeff'))
def write(name,value):
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
def copy(src,name,zipped=False,raw=False):
 b=Path(src).read_bytes()
 if not raw and not str(src).endswith('.png'):b=b.decode('utf-16'if b[:2]==b'\xff\xfe'else'utf8').lstrip('\ufeff').replace('\r\n','\n').encode()
 if zipped:b=gzip.compress(b,mtime=0)
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
index=sha(Path('packages/web/dist/index.html').read_bytes());before=load(base/'before/verification.json');final=load(base/'final/verification.json');native=load(base/'native/verification.json');scenarios=load(base/'scenarios/verification.json');analysis=load(base/'analysis.json');stable=load('screens/models-comparison/verification.json')
assert all(v==index for v in [final['productionIndexSha256'],native['index'],scenarios['index'],analysis['afterIndex'],stable['productionIndexSha256']])
assert before['productionIndexSha256']=='0f6ed0dbbfb677a873e562f3343bf02c21f839e8b099c81eb726eb11be7bd520'
assert native['status']==scenarios['status']=='passed' and len(native['results'])==8 and len(scenarios['results'])==12
assert len(stable['cases'])==4 and all(c['sha256']==c['repeatSha256']for c in stable['cases'])
assert len(analysis['rows'])==8 and all(r['mainGeometryEqual']and r['beforeRepeatExact']and r['afterRepeatExact']for r in analysis['rows'])
assert all(r['changedPixels']==0 for r in analysis['rows']if r['route']!='models')
captures=[]
for row in final['results']:
 name=row['route'];old=next(r for r in before['results']if r['route']==name);beforePath='images/before/'+name+'.png';copy(base/'before'/(name+'.png'),beforePath);assert sha((root/beforePath).read_bytes())==old['sha256']
 current=beforePath
 if row['sha256']!=old['sha256']:current='images/final/'+name+'.png';copy(base/'final'/(name+'.png'),current)
 assert sha((root/current).read_bytes())==row['sha256'];original='../redesign-v1.85.69/refs/'+name+'.png';assert sha((root/original).read_bytes())==row['referenceSha256']
 captures.append({'route':name,'original':original,'before':beforePath,'final':current,'referenceSha256':row['referenceSha256']})
for name in ['before','final','native','scenarios']:copy(base/name/'verification.json','evidence/'+name+'.json.gz',True)
copy(base/'analysis.json','evidence/analysis.json');copy('screens/models-comparison/verification.json','evidence/stable.json.gz',True)
for name in ['en-dark-1672','th-light-390']:copy(base/'native'/(name+'.png'),'images/native/'+name+'.png')
for name in ['Component-mismatch-en-dark-1672','Missing-components-th-light-390','Zero-components-en-dark-1672','Tiny-input-en-dark-1672']:copy(base/'scenarios'/(name+'.png'),'images/scenarios/'+name+'.png')
for name in ['build133-web-verified.log','build133-web-bytecheck.log','test133-web-verified.log','fidelity133-native-verified.log','fidelity133-scenarios-verified.log','fidelity133-before-final.log','fidelity133-final-verified.log','stable133-models.log']:copy('tmp/'+name,'evidence/logs/'+name+'.gz',True)
for name in ['build133-web.log','test133-web.log','fidelity133-before.log','fidelity133-before-diagnosis.log','fidelity133-scenarios.log']:copy('tmp/'+name,'evidence/diagnoses/'+name+'.gz',True)
copy(base/'before/ready-failure.json','evidence/diagnoses/static-root-before.json')
for name in ['capture-fidelity133.mts','check-ring133-native.mts','check-ring133-scenarios.mts','analyze133.py','package133.py','check-viewer133.mjs']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True,True)
archive=Path('docs/quotapulse_build_blueprint_v1.1.zip');assert sha(archive.read_bytes())=='28bc63571ddf7ecda1e12e8821c6184378ccfe6c3a599d6ccec29bf17fedb054'
with zipfile.ZipFile(archive)as z:
 member='quotapulse_build_blueprint/screens/models.md';contract=z.read(member);(root/'evidence/authority').mkdir(parents=True,exist_ok=True);(root/'evidence/authority/models.md').write_bytes(contract.replace(b'\r\n',b'\n'))
 write('evidence/authority.json',{'archive':str(archive),'sha256':sha(archive.read_bytes()),'screenMember':member,'memberSha256':sha(contract),'referenceImageSha256':next(r for r in final['results']if r['route']=='models')['referenceSha256'],'decision':'Restore original two input/output sectors; retain scoped facts, cache components and explicit total provenance.'})
sources=['packages/web/src/redesign/models.tsx','packages/web/src/redesign/model-token-distribution.ts','packages/web/src/redesign/model-token-distribution-panel.tsx','packages/web/src/redesign/model-token-distribution.css','packages/web/src/i18n/en.ts','packages/web/src/i18n/th.ts','packages/web/test/model-token-distribution.test.ts','scripts/check-stable-captures.mts']
write('source-fingerprints.json',[{'path':p,'rawSha256':sha(Path(p).read_bytes()),'lfSha256':sha(Path(p).read_bytes().replace(b'\r\n',b'\n'))}for p in sources])
test=Path('tmp/test133-web-verified.log').read_bytes();test=test.decode('utf-16'if test[:2]==b'\xff\xfe'else'utf8');assert re.search(r'^# pass 341\r?$',test,re.M)and re.search(r'^# fail 0\r?$',test,re.M)
summary={'checkpoint':'v1.85.133','parent':'b844e4b6289ca786202539e239404b93f77a727f','index':index,'webTests':341,'mainBrowserCases':8,'edgeCases':12,'stableExactPairs':4,'sourceSizedExactRepeats':8,'unchangedOtherPages':7,'fullRedesignComplete':False,'latestRunnableZip':'review132/source131; excludes this133 ring change'};write('summary.json',summary);write('review-manifest.json',{'index':index,'captures':captures})
(root/'README.md').write_text('''# Models reference input/output ring v1.85.133

[Open original / before / current comparison](review.html). Bounded Models change validated; full redesign and 99–100% visual acceptance remain incomplete.

## Reference authority and implementation

The approved v1.1 Models contract retains the detail donut and scoped token/cache facts; unlisted reference composition remains authoritative. Original models.png uses two input/output sectors. The previous implementation used four sectors and four legend rows. The current ring restores two blue/purple sectors, two percentage/value rows, a small total caption, the reference-sized dots and measured wide-screen placement. This is native SVG/code artwork, with no new dependency or raster asset.

Input sums fresh input, cache reads and cache writes. Output retains its separate recorded value. The full three-part input breakdown remains behind an actionable native disclosure, with exact localized counts and a note about stored totals. Nothing is removed from the API or reclassified by provider/model. Existing model selection and scope guards are unchanged; the existing finite selection outline remains. Ring interpolation itself is still an open motion requirement; no new animation loop, timer or polling was added.

Sectors describe the component total. When it reconciles with the stored total, the center says Total Tokens. When it differs, the center says Component total and the disclosure/accessible region retain both actual totals. No unknown remainder is invented. A genuine zero has a neutral ring and undefined percentage shares; a positive stored total with no component breakdown shows unavailable values. Invalid/negative/nonfinite components are unavailable. Reconciliation tolerates floating arithmetic noise; regression coverage keeps a one-token difference at 274 million visible. Tiny positive sectors receive no minimum angular floor and cannot be erased by their decorative gap.

## Verification

- Final TypeScript/production build and 341/341 web tests passed, including six new accounting/zero/missing/tiny/precision regressions.
- 8 actual Chrome cases cover EN/TH, dark/light and 390/1672. Each compares the exact Models API response with input/output values, percentages and arcs, verifies local unique gradient IDs, keyboard open/close of all three cache fields, no overlap with the ring, child containment and no page overflow/errors/forbidden writes.
- 12 edge cases cover real API fixture groups in desktop EN/dark and narrow TH/light: stored 777 versus component 60, true zero, positive stored total without components, input-only, output-only and one input token out of 100 million. No synthetic data is shipped in the UI or inserted into a customer database.
- Maintained Models gate now asserts the selected model/provider pair's component values and keyboard disclosure. All four EN/TH × dark/light distinct-document repeat pairs passed byte exactly under the unchanged gate, with no screenshot masks or relaxed tolerance.
- All eight source-sized before/current frames repeat exactly within their contexts; seven other pages are byte unchanged. Main region geometry is unchanged. The 21,329 changed pixels in Models are within its distribution artwork/legend and surrounding glow. See whole-frame analysis.json rather than a masked similarity score.
- Diagnostic color threshold localization finds the current colored ring envelope within 1 px of the reference's four bounds and identical heading glyph row bounds. This is NOT a 99% shape, color, whole-panel or whole-page score. Actual data ratios/numbers differ from concept data, as required by the accepted consistency override.

## Retained implementation/harness corrections

The first build resolved a .ts helper instead of a same-basename .tsx component; the panel now has its own distinct filename. The initial tiny-arc test used exact floating equality; it now tests a tight numerical tolerance while retaining strict no-floor behavior. A preceding-build capture received 403 because the harness passed a Windows root with forward slashes to the strict containment comparison; resolving the harness path fixed that case. The production guard was not changed or bypassed. The first edge fixture attempted null token fields, which correctly violated SQLite's non-null schema; the fixture now expresses a zero component aggregate with a positive stored total. Original failed logs and the 403 diagnosis are retained.

## Remaining work and delivery

The full blueprint trace/accepted gap ledger remain authoritative. Overall material/type/control fidelity, motion interpolation, full all-page repeat stability, real-reader/customer acceptance, physical desktop behavior, performance and human approval remain open. This checkpoint is browser/source evidence, not a fresh Electron or ZIP run. Latest runnable ZIP is review132 built from source131 and excludes this 133 change. Main is unchanged; source/branch/tag remain isolated.
''',encoding='utf8',newline='\n')
data=json.dumps({'captures':captures});(root/'review.html').write_text('''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>QuotaPulse133 comparison</title><style>body{background:#08111e;color:#deecff;font:15px system-ui;margin:20px}a{color:#38c9ff}select{padding:8px;margin:5px}img{width:100%;height:auto;display:block;margin:12px 0;border:1px solid #234}</style><h1>QuotaPulse133</h1><p>Real component accounting and reference input/output composition. Overall redesign incomplete. <a href="README.md">Evidence and limits</a></p><label>Page <select id="route">'''+''.join('<option>'+r['route']+'</option>'for r in captures)+'''</select></label><label>Frame <select id="phase"><option value="final">Current133</option><option value="original">Original concept</option><option value="before">Before131</option></select></label><p id="caption"></p><img id="image" alt="Selected dashboard frame"><h2>Stored/component mismatch case</h2><img src="images/scenarios/Component-mismatch-en-dark-1672.png" alt="Owned fixture with777 stored tokens and60 component tokens"><script>const data='''+data+''',route=document.getElementById('route'),phase=document.getElementById('phase'),frame=document.getElementById('image');function render(){const row=data.captures.find(r=>r.route===route.value);frame.src=row[phase.value];document.getElementById('caption').textContent=route.value+' / '+phase.value}route.onchange=phase.onchange=render;route.value='models';render();</script></html>''',encoding='utf8',newline='\n')
write('artifact-hashes.json',{str(p.relative_to(root)).replace('\\','/'):sha(p.read_bytes())for p in sorted(root.rglob('*'))if p.is_file()and p.name!='artifact-hashes.json'})
print(json.dumps({'artifacts':len(load(root/'artifact-hashes.json')),'index':index,'sources':len(sources)}))
