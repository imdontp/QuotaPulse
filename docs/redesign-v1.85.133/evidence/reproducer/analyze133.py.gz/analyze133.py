from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib
root=Path('tmp/fidelity133');load=lambda p:json.loads(p.read_text(encoding='utf8'));before=load(root/'before/verification.json');after=load(root/'final/verification.json');rows=[]
for entry in after['results']:
 route=entry['route'];old=next(r for r in before['results']if r['route']==route)
 a=np.asarray(Image.open(root/'before'/f'{route}.png').convert('RGB')).astype(int);b=np.asarray(Image.open(root/'final'/f'{route}.png').convert('RGB')).astype(int);d=np.abs(a-b);mask=d.max(2)>0;yy,xx=np.where(mask)
 rows.append({'route':route,'changedPixels':int(mask.sum()),'maxChannelDelta':int(d.max()),'bounds':None if not len(xx)else[int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())],'mainGeometryEqual':old['geometry']['mainRegions']==entry['geometry']['mainRegions'],'beforeRepeatExact':old['repeatIdentical'],'afterRepeatExact':entry['repeatIdentical']})
ring=[]
for name,path in [('reference',Path('docs/redesign-v1.85.69/refs/models.png')),('current',root/'final/models.png')]:
 a=np.asarray(Image.open(path).convert('RGB')).astype(int);crop=a[385:515,1500:1650];r,g,b=crop[:,:,0],crop[:,:,1],crop[:,:,2];mask=(b>120)&(((b>r*1.2)&(b>g*1.15))|((g>100)&(r<80)));yy,xx=np.where(mask)
 heading=a[375:418,1298:1455];white=(heading.min(2)>130)&((heading.max(2)-heading.min(2))<100);rr=np.where(white.sum(1)>3)[0]
 ring.append({'name':name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'coloredRingBounds':[int(xx.min()+1500),int(yy.min()+385),int(xx.max()+1500),int(yy.max()+385)],'headingGlyphRows':[int(rr.min()+375),int(rr.max()+375)]})
summary={'scope':'Whole before/after frames, no masks and no concept similarity percentage. Color/glyph threshold localization is diagnostic only, not a gate mask.','beforeIndex':before['productionIndexSha256'],'afterIndex':after['productionIndexSha256'],'rows':rows,'ringDiagnostics':ring,'ringLocalizationMethod':{'ringCrop':[1500,385,1650,515],'ringColor':'B>120 and ((B>1.2R and B>1.15G) or (G>100 and R<80))','headingCrop':[1298,375,1455,418],'headingColor':'minRGB>130, spread<100, more than3 pixels per row'}}
(root/'analysis.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode());print(json.dumps(summary))
