from pathlib import Path
p=Path('scripts/check-history.mts');s=p.read_text(encoding='utf-8').replace("from './check-alerts-layout.mts'", "from '../scripts/check-alerts-layout.mts'")
needle="const vite = await createServer("
pos=s.index(needle)
s=s[:pos]+'''const lifecycle: object[]=[];
let streamId=0;
daemon.addHook('preHandler',async(req,reply)=>{
 if(!req.url.startsWith('/api/events/stream'))return;
 const id=++streamId,record=(event:string)=>lifecycle.push({layer:'daemon',id,event,at:Date.now(),aborted:req.raw.aborted,destroyed:reply.raw.destroyed,ended:reply.raw.writableEnded,data:scheduler.listenerCount('data'),settings:scheduler.listenerCount('settings')});
 record('handler');req.raw.once('aborted',()=>record('request-aborted'));reply.raw.once('close',()=>{record('response-close');queueMicrotask(()=>record('after-response-close'))});req.raw.socket.once('close',()=>record('socket-close'));
});
''' + s[pos:]
s=s.replace("response.once('close', () => upstream.destroy());",'''const id=++streamId,record=(event:string)=>lifecycle.push({layer:'proxy',id,event,at:Date.now(),requestAborted:request.aborted,responseDestroyed:response.destroyed,upstreamDestroyed:upstream.destroyed});
    record('request');upstream.once('response',r=>{record('headers');r.once('close',()=>record('upstream-response-close'))});upstream.once('close',()=>record('upstream-request-close'));response.once('close', () => {record('downstream-close');upstream.destroy();record('after-destroy')});''')
s=s.replace("await browser?.close();", "writeFileSync(resolve(root,'tmp/sse152-lifecycle.json'),JSON.stringify(lifecycle,null,2)+'\\n');\n  await browser?.close();")
assert "sse152-lifecycle.json" in s
Path('tmp/check-history-sse152.mts').write_bytes(s.encode())
