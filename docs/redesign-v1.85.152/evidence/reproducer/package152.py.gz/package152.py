from pathlib import Path
import gzip,hashlib,json,sys
out=Path('docs/redesign-v1.85.152');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,compressed=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not compressed and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0) if compressed else b)
def log(path):
 b=Path(path).read_bytes();return b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
before=load('tmp/fidelity151/final/verification.json');after=load('tmp/fidelity152/final/verification.json')
picker=load('screens/history-range-picker/verification.json');calendar=load('screens/usage-calendar/verification.json')
diffs=load('tmp/fidelity152/analysis.json');density=load('tmp/fidelity152/final/history-table-density.json')
assert before['productionIndexSha256']=='f5f103f6e2292019d95ac13cdb05e50243b9b902b6c34f6bed8be0b677e2b45f'
assert after['productionIndexSha256']==picker['productionIndexSha256']==calendar['productionIndexSha256']==sha(Path('packages/web/dist/index.html').read_bytes())
assert len(picker['cases'])==16 and picker['legacyPreserved'] and picker['errors']==[]
assert len(calendar['checks'])==42 and calendar['errors']==[] and calendar['clearedInputsPreserveScope']
assert len(after['results'])==8 and all(row['repeatIdentical'] and not row['errors'] and not row['forbidden'] for row in after['results'])
assert '# pass 351' in log('tmp/range152-web-tests.log') and '# fail 0' in log('tmp/range152-web-tests.log')
assert 'History/Overview/Projects/Live/Providers/Models/Cost/Alerts E2E passed' in log('tmp/range152-integration.log') and 'History teardown: database closed' in log('tmp/range152-integration.log')
matrix=load('screens/history/responsive-matrix.json');assert len(matrix['cases'])==144 and all(row['streams']<=1 for row in matrix['cases'])
assert density['clientWidth']==density['scrollWidth']==1124 and len(density['rows'])==10 and all(row['height']==33 and row['bottom']<=941 for row in density['rows'])
assert len([row for row in diffs if row['changedPixels']==0])==6
h=next(row for row in diffs if row['route']=='history');assert h['bounds']==[702,80,1363,125]
reference=Path('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs')
for row in after['results']:
 route=row['route'];assert sha((reference/(route+'.png')).read_bytes())==row['referenceSha256'];copy(reference/(route+'.png'),'refs/'+route+'.png')
 for directory,report,dest in [('tmp/fidelity151/final',before,'before'),('tmp/fidelity152/final',after,'after')]:
  image=Path(directory)/(route+'.png');assert sha(image.read_bytes())==next(r for r in report['results'] if r['route']==route)['sha256'];copy(image,dest+'/'+route+'.png')
for src,dst in [('tmp/fidelity151/final/verification.json','canonical-before.json'),('tmp/fidelity152/final/verification.json','canonical-current.json'),('tmp/fidelity152/analysis.json','comparison.json'),('tmp/fidelity152/final/history-table-density.json','density.json'),('screens/history-range-picker/verification.json','range-picker.json'),('screens/usage-calendar/verification.json','calendar.json'),('screens/history/verification.json','integration.json'),('screens/history/responsive-matrix.json','integration-matrix.json')]:copy(src,'evidence/'+dst)
for name in ['en-dark-1672','th-light-390']:copy('screens/history-range-picker/'+name+'-open.png','images/'+name+'-open.png')
for src,dst in [('tmp/range152-build.log','build'),('tmp/range152-web-tests.log','web-tests'),('tmp/range152-browser.log','range-picker'),('tmp/range152-calendar.log','calendar'),('tmp/range152-browser-first.log','first-popover-overflow'),('tmp/range152-calendar-first.log','first-disclosure-driver'),('tmp/range152-integration-first.log','integration-first-sse-failure'),('tmp/sse152-diagnostic.log','integration-instrumented'),('tmp/range152-sse-tests.log','sse-regression'),('tmp/range152-integration.log','integration'),('tmp/fidelity152-final.log','canonical-current')]:copy(src,'evidence/logs/'+dst+'.log.gz',True)
copy('tmp/sse152-lifecycle.json','evidence/sse-lifecycle.json.gz',True)
for name in ['capture-fidelity152.mts','diff152.py','package152.py','check-viewer152.mjs','prepare-sse152.py','check-history-sse152.mts']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
sources={}
for name in ['packages/web/src/sections/history.tsx','packages/web/src/redesign/history-range-picker.tsx','packages/web/src/redesign/history-range-picker.css','packages/web/src/i18n/en.ts','packages/web/src/i18n/th.ts','scripts/check-history-range-picker.mts','scripts/check-usage-calendar.mts']:
 b=Path(name).read_bytes();sources[name]={'rawSha256':sha(b),'lfSha256':sha(b.replace(b'\r\n',b'\n'))}
write('source-hashes.json',sources)
verified=(out/'evidence/viewer.json').exists()
if verified:
 viewer=load(out/'evidence/viewer.json');assert viewer['status']=='passed' and viewer['productionIndexSha256']==after['productionIndexSha256'] and len(viewer['cases'])==16 and viewer['errors']==[]
else:assert '--draft' in sys.argv
write('delivery.json',{'parentCommit':'ab9fadcd197f775ed03d97efc7548df88ab4e271','productionIndexSha256':after['productionIndexSha256'],'webTests':351,'rangePickerCases':16,'calendarCases':42,'fullIntegrationPassed':True,'intermittentSseIntegrationFailureUnresolved':True,'sseRegressionTests':3,'canonicalRepeatPairs':8,'unchangedOtherFrames':6,'providersChangedPixels':105,'referenceWidthTableFits':True,'tenRowsHeight':33,'reviewPageVerified':verified,'nativeRevalidated':False,'newArchiveCreated':False,'fullGoalComplete':False})
(out/'README.md').write_bytes('''# History compact range controls / source152

[Original / source151 / current gallery](review.html) · [Current History](after/history.png) · [Open range controls](images/en-dark-1672-open.png) · [Last runnable review150](../redesign-v1.85.150/README.md)

Validated bounded implementation. History now presents its existing range, source and custom date controls through a compact calendar capsule, with outlined Export Logs and icon Pause/Resume actions. Resolved dates come from the actual displayed API scope; custom dates retain exact requested bounds, with an inclusive end caption. All-time and pending requests use their actual translated preset labels. An active source remains visible outside the disclosure. Pausing freezes the caption/source to the retained snapshot even when the hash changes; resuming loads the new route. Export keeps the existing exact CSV scope. Full accessible names, tooltip text, legacy controls and actual data semantics remain available. No fake sort, export menu, lifecycle status or customer data is introduced.

The disclosure uses native details/summary and the existing UsageRangeBar. Enter opens it, Tab reaches existing controls, Escape closes and restores summary focus, and outside pointer/focus dismissal leaves focus with the chosen destination. Viewport clamping handles narrow anchors without horizontal overflow. Native date popups may emit a null relatedTarget, which is deliberately ignored. It is nonmodal. Pause disables opening and its controls.

## Validation

Production build and351 web tests passed. Sixteen compiled browser cases cover EN/TH, dark/light and390/900/1280/1672 widths: keyboard, outside dismissal, popover bounds, source/session retention, pending data, disabled pause and retained-snapshot captions. The unchanged42 calendar scope/display/edit assertions pass across Bangkok/UTC/New York, including DST and cleared date fields; only the helper opens the new disclosure conditionally. The first run caught a real negative-left popover at900px, fixed by viewport clamping. The first calendar driver blindly toggled an already-open disclosure on hash-only navigation, corrected by checking native open state. Original failure logs are retained; no assertion or numeric tolerance was relaxed.

The maintained full integration passes with144 responsive cases, paging, CSV, scopes, live updates, pause/in-flight protection, monetary bases and at most one SSE stream. The first integration run failed on Overview with2 server listeners versus1 client EventSource. A temporary per-connection diagnostic copy then passed, followed by the unchanged suite run serially. This does not establish a root cause or fix: the intermittent SSE integration failure remains unresolved. All3 deterministic direct-HTTP SSE abort/disconnect/shutdown regressions pass. Original failure, diagnostic lifecycle trace and subsequent logs are retained; no assertion, retry budget or product transport was changed.

All eight current canonical within-context screenshot pairs are byte-identical. The historical baseline is the already-verified source151 capture, index f5f103f6e2292019d95ac13cdb05e50243b9b902b6c34f6bed8be0b677e2b45f; it was not rerun against source152. Six other frames remain byte-identical. History differences are restricted to702,80–1363,125 in the header; the table remains1124px wide without horizontal overflow and its ten33px rows fit941px. Providers still has105 unexplained global-header pixels, maximum channel delta4; that gate remains open without masks or tolerance changes.

```powershell
npm.cmd run build -w @quotapulse/web
npm.cmd run test -w @quotapulse/web
node --import tsx scripts/check-history-range-picker.mts
node --import tsx scripts/check-usage-calendar.mts
node --import tsx scripts/check-history.mts
```

The gallery contains complete unmasked frames and original refs verified against the maintained manifest. QA uses isolated consistent synthetic data; production displays actual data. Source/index/artifact hashes, exact compressed logs and capture/diff reproducers accompany this change. These checks do not constitute99–100% reference approval, native or performance acceptance. Review150 remains the previous runnable ZIP and does not contain source151/152. Remaining visual/control/motion, native/customer/provider, physical tray/monitor, performance and migration/rollback acceptance remain open. Main and unrelated work remain preserved.
'''.encode())
routes=[row['route'] for row in after['results']]
html='''<!doctype html><meta charset="utf-8"><title>History compact range controls / source152</title><style>body{font:14px system-ui;margin:20px;background:#071020;color:#def}a{color:#5cf}select{padding:8px;margin:6px}section{display:grid;grid-template-columns:1fr 1fr;gap:12px}img{width:100%;border:1px solid #456}figure{margin:0}figcaption{margin:8px 0}@media(max-width:900px){section{grid-template-columns:1fr}}</style><h1>Source152 / original, source151, current</h1><p>Original concept and owned QA app data differ. No approval or similarity percentage is claimed. <a href="README.md">Changes, evidence and limits</a></p><select id="route">'''+''.join('<option'+(' selected' if route=='history' else '')+'>'+route+'</option>' for route in routes)+'''</select><select id="left-source"><option value="refs">Original concept</option><option value="before">Before / source151</option></select><section><figure><figcaption id="left-label"></figcaption><img id="left" alt="Original reference or previous app frame"></figure><figure><figcaption>Current / source152</figcaption><img id="right" alt="Current compiled app frame"></figure></section><script>const route=document.getElementById('route'),source=document.getElementById('left-source');function show(){document.getElementById('left-label').textContent=source.options[source.selectedIndex].text;document.getElementById('left').src=source.value+'/'+route.value+'.png';document.getElementById('right').src='after/'+route.value+'.png'}route.onchange=source.onchange=show;show()</script>'''
(out/'review.html').write_bytes(html.encode())
write('artifact-hashes.json',{p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='artifact-hashes.json'})
print('Sealed',len(load(out/'artifact-hashes.json')),'artifacts; viewer verified:',verified)
