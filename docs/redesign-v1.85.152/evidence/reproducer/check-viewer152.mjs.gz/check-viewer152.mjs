import assert from 'node:assert/strict';
import { readFileSync,writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { chromium } from 'playwright';
const root=resolve('docs/redesign-v1.85.152'),report=JSON.parse(readFileSync(resolve(root,'evidence/canonical-current.json')));
assert.equal(report.productionIndexSha256,createHash('sha256').update(readFileSync('packages/web/dist/index.html')).digest('hex'));
assert.equal(report.productionIndexSha256,'1444e3a6bf00cf8c673140a418a06529e707d4e2b73c07c5826bd1d3e18123f8');
const browser=await chromium.launch({channel:'chrome',headless:true});
try{
 const page=await browser.newPage(),errors=[],cases=[];page.on('pageerror',error=>errors.push(error.message));await page.goto(pathToFileURL(resolve(root,'review.html')).href);
 for(const row of report.results)for(const mode of ['refs','before']){
  await page.locator('#route').selectOption(row.route);await page.locator('#left-source').selectOption(mode);
  await page.waitForFunction(({route,mode,width})=>['left','right'].every(id=>{const img=document.getElementById(id);return img.complete&&img.naturalWidth===width&&decodeURI(img.currentSrc).endsWith((id==='left'?mode:'after')+'/'+route+'.png')}),{route:row.route,mode,width:row.viewport.width});
  cases.push(mode+'/'+row.route);
 }
 assert.equal(cases.length,16);assert.deepEqual(errors,[]);writeFileSync(resolve(root,'evidence/viewer.json'),JSON.stringify({status:'passed',productionIndexSha256:report.productionIndexSha256,browser:browser.version(),cases,errors},null,2)+'\n');console.log(JSON.stringify({checked:cases.length,errors}));
}finally{await browser.close()}
