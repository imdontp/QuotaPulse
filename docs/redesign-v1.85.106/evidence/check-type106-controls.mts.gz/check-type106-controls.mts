import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {chromium} from 'playwright';
const decision=JSON.parse(readFileSync('tmp/type106-results.json','utf8'));
const before=JSON.parse(readFileSync('tmp/type106-probe/verification.json','utf8'));
const after=JSON.parse(readFileSync('tmp/reference106/verification.json','utf8'));
const browser=await chromium.launch({channel:'chrome',headless:true});const results=[];
try {const page=await browser.newPage();for(const entry of after.results){
 const prior=before.results.find(item=>item.route===entry.route);for(const field of ['main','sidebar','quickStats','mainRegions','navigationOrder'])assert.deepEqual(entry.geometry[field],prior.geometry[field],entry.route+': '+field);
 const accepted=decision.rows.filter(row=>row.route===entry.route&&row.accepted);
 const changed=await page.evaluate(async({a,b,candidates})=>{
 const decoded=await Promise.all([a,b,...candidates.map(item=>item.bytes)].map(async source=>{const img=new Image();img.src='data:image/png;base64,'+source;await img.decode();const canvas=document.createElement('canvas');canvas.width=img.width;canvas.height=img.height;const ctx=canvas.getContext('2d')!;ctx.drawImage(img,0,0);return{width:img.width,height:img.height,data:ctx.getImageData(0,0,img.width,img.height).data};}));
 const [aImage,bImage]=decoded;let totalChanged=0,outside=0,maxOutsideDelta=0;const outsideSamples=[];const bounds={x0:Infinity,y0:Infinity,x1:0,y1:0};
 for(let y=0;y<aImage.height;y++)for(let x=0;x<aImage.width;x++){const i=(y*aImage.width+x)*4;let delta=0;for(let c=0;c<4;c++)delta=Math.max(delta,Math.abs(aImage.data[i+c]-bImage.data[i+c]));if(delta){totalChanged++;bounds.x0=Math.min(bounds.x0,x);bounds.y0=Math.min(bounds.y0,y);bounds.x1=Math.max(bounds.x1,x);bounds.y1=Math.max(bounds.y1,y);if(!candidates.some(item=>x>=item.crop[0]&&y>=item.crop[1]&&x<item.crop[2]&&y<item.crop[3])){outside++;maxOutsideDelta=Math.max(maxOutsideDelta,delta);if(outsideSamples.length<100)outsideSamples.push({x,y,delta});}}}
 const trialReproduction=candidates.map((item,index)=>{const trial=decoded[index+2];const [x0,y0,x1,y1]=item.crop;let changedPixels=0,maxDelta=0;for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){const i=(y*aImage.width+x)*4;let delta=0;for(let c=0;c<4;c++)delta=Math.max(delta,Math.abs(trial.data[i+c]-bImage.data[i+c]));if(delta){changedPixels++;maxDelta=Math.max(maxDelta,delta);}}return{id:item.id,changedPixels,maxDelta};});
 return{totalChanged,outside,maxOutsideDelta,outsideSamples,bounds:totalChanged?bounds:null,trialReproduction};
 },{a:readFileSync('tmp/type106-probe/'+entry.route+'.png').toString('base64'),b:readFileSync('tmp/reference106/'+entry.route+'.png').toString('base64'),candidates:accepted.map(row=>({id:row.field.id,crop:row.field.crop,bytes:readFileSync('tmp/type106-trials/'+entry.route+'-'+row.best.trial.name+'.png').toString('base64')}))});
 const headingsBefore=JSON.parse(readFileSync('tmp/type106-probe/'+entry.route+'-heading-geometry.json','utf8'));const headingsAfter=JSON.parse(readFileSync('tmp/reference106/'+entry.route+'-heading-geometry.json','utf8'));assert.equal(headingsBefore.length,headingsAfter.length);
 const headingGeometryChanges=[];
 for(let i=0;i<headingsBefore.length;i++){
 const a=headingsBefore[i],b=headingsAfter[i];for(const field of ['text','tracking','color','shadow','transform'])assert.deepEqual(b[field],a[field],entry.route+': heading '+field);
 const edited=accepted.some(row=>a.text?.includes(row.field.text));
 for(const field of edited?['x','y','height','top','bottom','left']:Object.keys(a.rect))assert.equal(b.rect[field],a.rect[field],entry.route+': heading rect '+field);
 if(JSON.stringify(a.rect)!==JSON.stringify(b.rect))headingGeometryChanges.push({text:a.text,before:a.rect,after:b.rect,reason:'Intrinsic width changes from selected font weight; origin and line box unchanged'});
 }

 for(const item of changed.trialReproduction)assert.equal(item.changedPixels,0,entry.route+': actual source does not reproduce chosen trial '+item.id);
 assert.equal(entry.repeatIdentical,true,entry.route+': unstable repeat');results.push({route:entry.route,panelAndShellGeometryIdentical:true,headingOriginsLineboxesAndNonweightStylesIdentical:true,headingGeometryChanges,...changed,localMetrics:accepted.map(row=>({id:row.field.id,crop:row.field.crop,weightBefore:row.field.weight,weightAfter:row.field.weight+row.best.trial.delta,alphaBefore:row.baseline.alphaMae,alphaAfter:row.best.alphaMae,rgbBefore:row.baseline.rgbMae,rgbAfter:row.best.rgbMae}))});console.log(entry.route+': changed='+changed.totalChanged+', outside six text crops='+changed.outside+', chosen trial reproduced='+changed.trialReproduction.every(item=>!item.changedPixels));
 }
 const status=results.every(row=>!row.outside)?'PASS':'RED';writeFileSync('tmp/type106-controls.json',JSON.stringify({status,beforeIndexSha256:before.productionIndexSha256,afterIndexSha256:after.productionIndexSha256,masks:false,scope:'Every before/after pixel counted. Explicit six same-text rectangles classify intended changes; all outside pixels retained. Source-built crop must be byte-identical to chosen DOM trial. Local alpha/RGB values inherited only after exact crop reproduction, not whole-page likeness.',results},null,2));assert.equal(status,'PASS','Unexplained pixels outside changed typography');
}finally{await browser.close();}
