const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),zlib=require('node:zlib'),assert=require('node:assert/strict');
const root='docs/redesign-v1.85.122',sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function decode(p){const b=fs.readFileSync(p);return b.toString(b[0]===255&&b[1]===254?'utf16le':'utf8').replace(/^\uFEFF/,'');}
const json=p=>JSON.parse(decode(p));
const index=sha(fs.readFileSync('packages/web/dist/index.html'));
const native=json('tmp/history122/native/verification.json'),canonical=json('tmp/history122/final/verification.json');
const receipt=json('tmp/history122/build-receipt.json'),analysis=json('tmp/history122/analysis.json'),difference=json('tmp/history122/stable-difference.json');
assert.equal(receipt.status,'passed'); assert.equal(receipt.matchesTestedBuild,true);
for(const report of [native,canonical,receipt])assert.equal(report.productionIndexSha256,index);
assert.equal(native.results.length,8);assert.deepEqual(native.rendererArgs,[]);
for(const result of native.results){
  const width=Number(result.variant.split('-')[2]);
  assert.equal(result.viewport.width,width);assert.equal(result.geometry.viewport.width,width);
  assert.equal(result.geometry.pageOverflow,false);assert.equal(result.repeatIdentical,true);
  assert.deepEqual(result.errors,[]);assert.deepEqual(result.forbidden,[]);
  const check=json('tmp/history122/native/'+result.variant+'-checks.json');
  assert.equal(check.checks.length,2);assert.deepEqual(check.checks.map(row=>row.range),['last30','today']);
  for(const row of check.checks)for(const key of ['keyboard','pointer','apiFacts','contained'])assert.equal(row[key],true);
}
assert.equal(canonical.results[0].repeatIdentical,true);assert.equal(analysis.outsideAxisPixels,0);assert.equal(analysis.changedPixels,2745);
assert.equal(difference.changedPixels,132);assert.equal(difference.maxChannelDelta,7);assert.equal(difference.chartPixels,0);
const log=decode('tmp/history122-stable-nonmodal.log');
const firstPasses=[...log.matchAll(/Stable capture pass 1: (en|th)\/(dark|light), 1 pages/g)].map(match=>match[1]+'/'+match[2]);
assert.equal(new Set(firstPasses).size,4);assert.ok(log.includes('capture differs beyond raster tolerance'));assert.ok(log.includes('"changedPixels":132'));
assert.equal(fs.existsSync('screens/history-details/verification.json'),false,'Do not relabel the failed gate as passed');
function copy(from,to,gzip=false,text=false){let bytes=text?Buffer.from(decode(from).replace(/\r\n/g,'\n')):fs.readFileSync(from);if(gzip)bytes=zlib.gzipSync(bytes);const dest=root+'/'+to;fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,bytes);}
copy('tmp/history122/before/history.png','images/before.png');copy('tmp/history122/final/history.png','images/history.png');copy('tmp/history122/final/history-repeat.png','images/history-repeat.png');
for(const phase of ['before','final'])for(const name of ['timeline.json','verification.json'])copy('tmp/history122/'+phase+'/'+name,'evidence/'+phase+'-'+name);
for(const name of ['analysis.json','stable-difference.json','build-receipt.json'])copy('tmp/history122/'+name,'evidence/'+name,false,true);
copy('tmp/history122/native/verification.json','evidence/native-matrix.json');
for(const result of native.results){const v=result.variant;for(const suffix of ['.png','-tooltip.png'])copy('tmp/history122/native/'+v+suffix,'images/native/'+v+suffix);copy('tmp/history122/native/'+v+'-checks.json','evidence/native/'+v+'-checks.json');}
for(const filename of fs.readdirSync('screens/history-details').filter(name=>/^history-(?:selected-)?(?:en|th)-(?:dark|light)\.png$/.test(name)||name==='repeat-history-en-dark.png'))copy('screens/history-details/'+filename,'images/stable/'+filename);
for(const name of ['build','build-approved','build-final','build-fixed-overlay','build-delivery','after','final-capture','native','native-diagnosis','native-final','native-fixed-overlay','native-delivery','stable','stable-final','stable-rail','stable-current','stable-resize-diagnosis','stable-validated','stable-keyboard','stable-selection','stable-nonmodal','control-static'])copy('tmp/history122-'+name+'.log','evidence/logs/'+name+'.log.gz',true,true);
for(const file of ['capture-history122.mts','prepare-history122.cjs','check-history122-native.mts','prepare-history122-native.cjs','analyze-history122.py','analyze-history122-stable.py','history122-control-static.mts','rebuild-history122.ps1','migrate-history122-gate.cjs','package-history122.cjs'])copy('tmp/'+file,'evidence/reproducer/'+file+'.gz',true);
for(const file of ['history122-native-first-attempt.mts','history122-timeline-first-attempt.mjs','history122-timeline-diagnosis.mjs','history122-stable-first-attempt.mts','history122-native-pre-metadata.mts'])copy('tmp/'+file,'evidence/diagnoses/'+file+'.gz',true);
copy('tmp/history122/after/history.png','images/diagnoses/relative-panel.png');copy('tmp/history122/control-static/history.png','images/diagnoses/static-intervention.png');
for(const phase of ['after','control-static'])for(const name of ['verification.json','timeline.json'])copy('tmp/history122/'+phase+'/'+name,'evidence/diagnoses/'+phase+'-'+name);
copy('tmp/history122/native-metadata-before.json','evidence/diagnoses/native-before-metadata-correction.json');
const checks=['packages/web/src/redesign/history-timeline.tsx','packages/web/src/redesign/history.css','packages/web/src/i18n/en.ts','packages/web/src/i18n/th.ts','scripts/check-history-timeline.mjs','scripts/check-stable-captures.mts','scripts/browser-fixed-date.mjs'];
fs.writeFileSync(root+'/source-fingerprints.json',JSON.stringify(checks.map(p=>({path:p,lfSha256:sha(Buffer.from(fs.readFileSync(p,'utf8').replace(/\r\n/g,'\n')))})),null,2)+'\n');
fs.writeFileSync(root+'/review-manifest.json',JSON.stringify({checkpoint:'v1.85.122',status:'partially validated; original repeatability gate RED',productionIndexSha256:index,browser:native.browser,nativeChromeCases:8,scopesPerCase:2,canonicalChangedPixels:2745,canonicalOutsideAxisPixels:0,functionalFirstPasses:firstPasses,repeatFailure:{changedPixels:132,maxChannelDelta:7,bounds:difference.bounds,chartPixels:0,masks:false},reference:'../redesign-v1.85.69/refs/history.png',before:'images/before.png',after:'images/history.png',desktopBundleUpdated:false,scope:'History dates and API-backed inspection; no whole-design approval'},null,2)+'\n');
const hashes={};function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else if(e.name!=='artifact-hashes.json')hashes[path.relative(root,p).replaceAll('\\','/')]=sha(fs.readFileSync(p));}}walk(root);fs.writeFileSync(root+'/artifact-hashes.json',JSON.stringify(hashes,null,2)+'\n');
console.log(JSON.stringify({artifacts:Object.keys(hashes).length,index,firstPasses,nativeCases:8,canonicalChangedPixels:2745,stableGate:'RED132 header pixels/max7'}));
