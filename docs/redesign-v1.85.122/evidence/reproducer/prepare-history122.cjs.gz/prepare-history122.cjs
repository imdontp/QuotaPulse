const fs=require('node:fs');let s=fs.readFileSync('tmp/capture-matrix114.mts','utf8');
s=s.replace("'tmp/matrix114/'+(process.env.QUOTAPULSE_MATRIX_PHASE??'after')","'tmp/history122/'+(process.env.QUOTAPULSE_HISTORY_PHASE??'after')");
s=s.replace("if(process.env.QUOTAPULSE_MATRIX_PHASE==='before'&&routeName!=='live')continue;","if(routeName!=='history')continue;");
s=s.replace("    const first = await page.screenshot",`    if(routeName==='history'){
      const chart=await page.locator('.qp-history-timeline>svg').evaluate(element=>({label:element.getAttribute('aria-label'),rect:element.getBoundingClientRect().toJSON(),viewBox:element.getAttribute('viewBox'),points:Array.from(element.querySelectorAll('circle')).map(point=>({cx:point.getAttribute('cx'),cy:point.getAttribute('cy'),fill:point.getAttribute('fill')})),lines:Array.from(element.querySelectorAll('polyline,polygon')).map(line=>line.getAttribute('points')),dates:Array.from(element.querySelectorAll('text')).map(text=>({text:text.textContent,at:text.getAttribute('data-axis-at'),x:text.getAttribute('x')}))}));
      writeFileSync(resolve(output,'timeline.json'),JSON.stringify(chart,null,2));
    }
    const first = await page.screenshot`);
fs.writeFileSync('tmp/capture-history122.mts',s);
