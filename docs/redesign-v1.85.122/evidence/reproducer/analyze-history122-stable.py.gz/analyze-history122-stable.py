import json
from pathlib import Path
from collections import Counter
from PIL import Image, ImageChops
root=Path('screens/history-details')
a=Image.open(root/'history-en-dark.png').convert('RGB')
b=Image.open(root/'repeat-history-en-dark.png').convert('RGB')
changes=[]
for y in range(a.height):
    for x in range(a.width):
        old,new=a.getpixel((x,y)),b.getpixel((x,y))
        if old!=new: changes.append(dict(x=x,y=y,before=old,after=new,delta=max(abs(o-n) for o,n in zip(old,new))))
report=dict(changedPixels=len(changes), maxChannelDelta=max(p['delta'] for p in changes),
    bounds=ImageChops.difference(a,b).getbbox(),
    chartPixels=sum(251<=p['x']<1351 and 271<=p['y']<439 for p in changes),
    pixelRows=Counter(p['y'] for p in changes), pixels=changes,
    verdict='RED: existing 0.00005 changed fraction exceeded; no mask or threshold change')
Path('tmp/history122/stable-difference.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['pixels','pixelRows']}))
