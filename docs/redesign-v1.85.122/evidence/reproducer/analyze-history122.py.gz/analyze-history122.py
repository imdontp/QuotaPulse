import json
from pathlib import Path
from PIL import Image, ImageChops
root = Path('tmp/history122')
before = json.loads((root/'before/timeline.json').read_text(encoding='utf-8'))
after = json.loads((root/'final/timeline.json').read_text(encoding='utf-8'))
for key in ['label', 'rect', 'viewBox', 'points', 'lines']:
    assert before[key] == after[key], key
a = Image.open(root/'before/history.png').convert('RGB')
b = Image.open(root/'final/history.png').convert('RGB')
assert a.size == b.size
delta = ImageChops.difference(a,b)
channels = delta.split()
d = ImageChops.lighter(ImageChops.lighter(channels[0],channels[1]),channels[2])
hist = d.histogram()
outside = []
inside = 0
for y in range(a.height):
    for x in range(a.width):
        if a.getpixel((x,y)) != b.getpixel((x,y)):
            if 290 <= x <= 1351 and 418 <= y <= 440:
                inside += 1
            else:
                outside.append(dict(x=x,y=y,before=a.getpixel((x,y)),after=b.getpixel((x,y))))
report = dict(preserved=['chart label/totals','chart bounds','viewBox','all 60 base circle coordinates/colors','all polygon/polyline points'],
    basePoints=len(after['points']), dateTicksBefore=len(before['dates'])-5, dateTicksAfter=len(after['dates'])-5,
    changedPixels=sum(hist[1:]), axisPixels=inside, outsideAxisPixels=len(outside), unplannedPixels=outside,
    bounds=d.getbbox(), maxChannelDelta=max(i for i,n in enumerate(hist) if n),
    scope='Canonical before/after only; real API with synthetic data, not a concept fidelity score')
(root/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k != 'unplannedPixels'}))
