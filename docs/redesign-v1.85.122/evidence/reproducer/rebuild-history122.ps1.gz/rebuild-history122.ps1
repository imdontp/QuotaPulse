$ErrorActionPreference='Stop'
$expected='2ea9a898618f9351162122cc9f74358efaf84937a7d0d1d6e0430bcd568aa346'
$ErrorActionPreference='Continue'
npm run build -w @quotapulse/web *> tmp/history122-build-delivery.log
$buildExit=$LASTEXITCODE
$ErrorActionPreference='Stop'
if ($buildExit -ne 0) { throw 'Final build failed' }
$actual=(Get-FileHash -LiteralPath packages/web/dist/index.html -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actual -ne $expected) { throw "Source/build differs from tested index: $actual" }
@{status='passed';productionIndexSha256=$actual;matchesTestedBuild=$true} | ConvertTo-Json | Set-Content -LiteralPath tmp/history122/build-receipt.json -Encoding UTF8
