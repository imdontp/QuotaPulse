import { readFileSync, writeFileSync } from 'node:fs';
import { chromium } from 'playwright';
const browser = await chromium.launch({ channel: 'chrome', headless: true });
const results = [];
try {
 const page = await browser.newPage();
 for (const route of ['cost', 'providers']) for (const version of ['reference', 'current']) {
  const path = version === 'reference' ? `C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/${route}.png` : `tmp/reference101/${route}.png`;
  const result = await page.evaluate(async base64 => {
   const image = new Image(); image.src = 'data:image/png;base64,' + base64; await image.decode();
   const canvas = document.createElement('canvas'); canvas.width=image.width;canvas.height=image.height;
   const context = canvas.getContext('2d')!; context.drawImage(image,0,0);
   const pixels=context.getImageData(0,0,image.width,image.height).data;
   const iconRows = [], rimRows = [];
   for(let y=80;y<435;y++) {
    let iconPixels=0,rimPixels=0;
    for(let x=25;x<54;x++){const i=(y*image.width+x)*4;if(pixels[i+1]>=65&&pixels[i+2]>=110)iconPixels++;}
    for(let x=10;x<23;x++){const i=(y*image.width+x)*4;if(pixels[i+1]>80&&pixels[i+2]>110&&pixels[i]<100&&pixels[i+1]>pixels[i]*1.25)rimPixels++;}
    iconRows.push({y,count:iconPixels});rimRows.push({y,count:rimPixels});
   }
   const iconGroups: Array<{top:number;bottom:number;pixels:number}> = [];
   for(const row of iconRows.filter(row=>row.count>0)) {
    const last=iconGroups.at(-1); if(last&&row.y-last.bottom<=4){last.bottom=row.y;last.pixels+=row.count;}else iconGroups.push({top:row.y,bottom:row.y,pixels:row.count});
   }
   const rimGroups: Array<{top:number;bottom:number;pixels:number}> = [];
   for(const row of rimRows.filter(row=>row.count>0)) {
    const last=rimGroups.at(-1); if(last&&row.y-last.bottom<=3){last.bottom=row.y;last.pixels+=row.count;}else rimGroups.push({top:row.y,bottom:row.y,pixels:row.count});
   }
   return {iconGroups:iconGroups.filter(group=>group.pixels>25).map(group=>({...group,center:(group.top+group.bottom)/2})),rimGroups:rimGroups.filter(group=>group.pixels>20),thresholds:'icons x25..53 g>=65 b>=110; rims x10..22 g>80 b>110 r<100 g>r*1.25; group gaps<=4/3; raster estimate, not DOM/source geometry'};
  }, readFileSync(path).toString('base64'));
  results.push({route,version,...result});
 }
 writeFileSync('tmp/reference101/sidebar-raster-measurements.json',JSON.stringify(results,null,2)); console.log(JSON.stringify(results,null,2));
} finally { await browser.close(); }
