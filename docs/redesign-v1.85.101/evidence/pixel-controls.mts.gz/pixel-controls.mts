import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { chromium } from 'playwright';
const before = JSON.parse(readFileSync('tmp/reference101-before/verification.json', 'utf8'));
const after = JSON.parse(readFileSync('tmp/reference101/verification.json', 'utf8'));
const browser = await chromium.launch({ channel: 'chrome', headless: true });
const results=[];
try {
 const page=await browser.newPage();
 for(const entry of after.results) {
  const route=entry.route;
  const result=await page.evaluate(async ({a,b,sidebarRight})=>{
   const decoded=await Promise.all([a,b].map(async base64=>{
    const image=new Image();image.src='data:image/png;base64,'+base64;await image.decode();
    const canvas=document.createElement('canvas');canvas.width=image.width;canvas.height=image.height;
    const context=canvas.getContext('2d')!;context.drawImage(image,0,0);
    return {width:image.width,height:image.height,data:context.getImageData(0,0,image.width,image.height).data};
   }));
   const [prior,current]=decoded;
   if(prior.width!==current.width||prior.height!==current.height)throw new Error('Dimension mismatch');
   let changedPixels=0,outsideSidebar=0,maxChannelDelta=0,minX=prior.width,minY=prior.height,maxX=-1,maxY=-1;
   const outsidePixels=[];
   for(let y=0;y<prior.height;y++)for(let x=0;x<prior.width;x++){
    const i=(y*prior.width+x)*4;let changed=false;
    for(let c=0;c<4;c++){const delta=Math.abs(prior.data[i+c]-current.data[i+c]);maxChannelDelta=Math.max(maxChannelDelta,delta);if(delta)changed=true;}
    if(changed){changedPixels++;if(x>=sidebarRight||y<60){outsideSidebar++;if(outsidePixels.length<200)outsidePixels.push({x,y,before:[...prior.data.slice(i,i+4)],after:[...current.data.slice(i,i+4)]});}minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);}
   }
   return {changedPixels,outsideSidebar,outsidePixels,maxChannelDelta,boundingBox:changedPixels?[minX,minY,maxX,maxY]:null,sidebarRight};
  }, {a:readFileSync(`tmp/reference101-before/${route}.png`).toString('base64'),b:readFileSync(`tmp/reference101/${route}.png`).toString('base64'),sidebarRight:Math.ceil(entry.geometry.sidebar.right)});
  results.push({route,...result}); console.log(`${route}: ${result.changedPixels} changed pixels, outside sidebar=${result.outsideSidebar}`);
 }
 writeFileSync('tmp/reference101/controls.json',JSON.stringify({masks:false,beforeIndexSha256:before.productionIndexSha256,afterIndexSha256:after.productionIndexSha256,scope:'Intermediate before plate/icons/spacing repair versus final build on the same synthetic fixture; original-reference scores are separate. No changed pixels are excluded from counts.',results},null,2));
 for(const result of results)assert.equal(result.outsideSidebar,0,`${result.route}: unexplained changes outside the edited sidebar`);
} finally {await browser.close();}
