const fs=require('fs'),assert=require('assert/strict');
const swap=s=>s.replaceAll('redesign-validation-v1.85.130','redesign-validation-v1.85.131').replaceAll('release131','release132').replaceAll('review131','review132').replaceAll('v1.85.130-review132','v1.85.131-review132').replaceAll('ea66edfce5c1e665a7a5ecfd592e6eab12bd0545','a47ad1354eb402b51a08c86d53cfa325adde0905').replaceAll('35c6f598ea7ea32f55faef8be725ec73c6ccda602aaf52d7f447b14eb47a91f7','0f6ed0dbbfb677a873e562f3343bf02c21f839e8b099c81eb726eb11be7bd520');
for(const name of ['build-review131.ps1','prepare-review131.cjs','archive-review131.ps1','extract-review131.ps1','check-bundle131.mts','check-native-review131.mts','audit-review131.cjs']){
 let s=swap(fs.readFileSync('tmp/'+name,'utf8'));
 if(name==='check-native-review131.mts'){
  const old='return{unknown:unknown.textContent,value:value.textContent,';assert.ok(s.includes(old));
  s=s.replace(old,`const values=[...document.querySelectorAll('.qp-model-summary article>strong')].map(strong=>{const node=strong.querySelector('.qp-cost-value>span:first-child')??strong;const range=document.createRange();range.selectNodeContents(node);return{text:node.textContent,lineTops:[...new Set([...range.getClientRects()].filter(r=>r.width>0).map(r=>r.top))]}});
   return{values,unknown:unknown.textContent,value:value.textContent,`);
  s=s.replace('if(summaryLayout){assert.equal(',"if(summaryLayout){for(const value of summaryLayout.values)assert.equal(value.lineTops.length,1,'Native summary value wraps: '+value.text);assert.equal(");
 }
 if(name==='audit-review131.cjs')s=s.replace("assert.equal(capture.summaryLayout.valueLineTops.length,1);", "assert.equal(capture.summaryLayout.valueLineTops.length,1);assert.equal(capture.summaryLayout.values.length,4);for(const value of capture.summaryLayout.values)assert.equal(value.lineTops.length,1);");
 fs.writeFileSync('tmp/'+name.replace('131','132'),s);
}
let p=swap(fs.readFileSync('tmp/package131.py','utf8')).replaceAll('docs/redesign-v1.85.131','docs/redesign-v1.85.132').replaceAll('package131.py','package132.py').replaceAll('check-viewer131.mjs','check-viewer132.mjs').replaceAll('check-bundle131.mts','check-bundle132.mts').replaceAll('source130','source131').replaceAll('v1.85.130','v1.85.131');
p=p.replace('Both native Models frames explicitly verify the unknown qualifier and partial monetary value remain single-line after the real restart','Both native Models frames explicitly verify all four values, the unknown qualifier and partial monetary value remain single-line after the real restart');
p=p.replace('130 also retains a separate16-case browser matrix for EN/TH, dark/light,390/1688 and USD/THB.','131 also retains a separate32-case browser matrix for EN/TH, dark/light,390/1280/1355/1688 and USD/THB.');
p=p.replace('- Native-discovered fixes for the unknown-provider qualifier and partial-value line wrapping, including narrow full-width values (130). The earlier source129/archive130 candidate was withheld after visual inspection; this ZIP uses the corrected source131.','- Native-discovered summary fixes: unknown-provider qualifier and partial-value wrapping (130), then intrinsic value columns and medium-width currency layout (131). Both earlier source129/archive130 and source130/archive131 candidates were withheld after visual review; this ZIP uses corrected source131.');
fs.writeFileSync('tmp/package132.py',p);
fs.writeFileSync('tmp/check-viewer132.mjs',fs.readFileSync('tmp/check-viewer131.mjs','utf8').replaceAll('v1.85.131','v1.85.132'));
fs.mkdirSync('tmp/release132',{recursive:true});console.log('Prepared source131 replacement ZIP132.');
