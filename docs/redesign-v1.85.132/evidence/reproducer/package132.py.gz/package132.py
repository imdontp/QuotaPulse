from pathlib import Path
import json,hashlib,gzip,subprocess
root=Path('docs/redesign-v1.85.132');root.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text(encoding='utf8').lstrip('\ufeff'))
def write(name,value):
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
def copy(src,name,zipped=False,raw=False):
 b=Path(src).read_bytes()
 if not raw and not str(src).endswith('.png'):b=b.decode('utf-16' if b[:2]==b'\xff\xfe' else 'utf8').lstrip('\ufeff').replace('\r\n','\n').encode()
 if zipped:b=gzip.compress(b,mtime=0)
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
summary=load('tmp/release132/summary.json');fixture=Path(summary['fixture']);report=load(fixture/'verification.json');archive=summary['archive'];input=load('tmp/release132/inputs.json')
assert report['sourceCommit']=='a47ad1354eb402b51a08c86d53cfa325adde0905' and report['productionIndexSha256']=='0f6ed0dbbfb677a873e562f3343bf02c21f839e8b099c81eb726eb11be7bd520'
assert summary['repositoryTests']==656 and summary['nativeCaptures']==16 and summary['standaloneSmokeChecks']==6
assert archive['allEntryBytesMatch'] and sha(Path(archive['archive']).read_bytes())==archive['sha256']
assert subprocess.check_output(['git','-C',input['checkout'],'status','--porcelain','--untracked-files=no'],text=True).strip()==''
for c in report['captures']:
 name=c['phase']+'-'+c['route']+'.png';assert sha((fixture/name).read_bytes())==c['sha256'];copy(fixture/name,'images/'+name)
for name in ['verification.json','settings.json']:copy(fixture/name,'evidence/native/'+name)
for name in ['summary.json','inputs.json','archive.json']:copy('tmp/release132/'+name,'evidence/'+name)
copy('tmp/release132/standalone-smoke/bundle-verification.json','evidence/standalone-smoke.json')
for p in Path('tmp/release132/build').iterdir():
 if p.suffix in ['.json','.log']:copy(p,'evidence/build/'+p.name+('.gz'if p.suffix=='.log'else''),p.suffix=='.log')
copy('tmp/release132/build/build.json','evidence/build/build-raw.json.gz',True,True)
for name in ['prepare-release132.cjs','build-review132.ps1','prepare-review132.cjs','archive-review132.ps1','extract-review132.ps1','check-bundle132.mts','check-native-review132.mts','audit-review132.cjs','package132.py','check-viewer132.mjs']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True,True)
for name in ['release132-build-runner.log','review132-native.log','review132-archive.log','review132-zip-smoke.log']:copy('tmp/'+name,'evidence/logs/'+name+'.gz',True)
write('review-manifest.json',{'sourceCommit':report['sourceCommit'],'index':report['productionIndexSha256'],'captures':report['captures']})
(root/'README.md').write_text(f'''# Fixed-source native review delivery v1.85.131

Product source: v1.85.131, commit `{report['sourceCommit']}`. This checkpoint delivers an updated runnable review ZIP. Full redesign and99–100% reference acceptance remain incomplete.

## Try the app

[Open the local ZIP]({archive['archive'].replace(chr(92),'/')}). Extract it into a new dedicated folder, then run from PowerShell in that folder:

```powershell
.\\scripts\\start-review.ps1
```

Open http://127.0.0.1:7807/#overview, or use the review tray icon to open the native dashboard. Stop only this review instance with:

```powershell
.\\scripts\\stop-review.ps1
```

Requires Windows x64 and an installed Node runtime with ABI127; this build/test used Node22.13.1. Node is not bundled. Occupied ports are rejected; start-review accepts a different `-Port` when needed. Existing application profiles are untouched.

This review launcher starts a separate empty profile with readers/account probes and Pet animation disabled. It does not collect real usage. No customer data, credentials or synthetic fixture database is packaged. The populated screenshots below are owned synthetic QA data used with the real production daemon/main/preload/web, not fake data built into the UI. Real-reader/customer acceptance remains open.

Archive SHA256: `{archive['sha256']}`

{archive['bytes']} bytes; {archive['entries']} entries. Every ZIP entry matches the unused source bundle. The actual archive was extracted outside repository dependencies and passed the six launch/stop/restart checks.

## What is included

- Live nine-column recorded session composition and actual input/output/provider/model facts (126).
- Cost nearest-bucket pointer/keyboard inspection and readable narrow tables (127).
- Reference-specific dashboard harness and OpenCode Go subscription artwork (128).
- Models actual provider counts, input/output summary and separate Anthropic provider/company artwork (129).
- Native-discovered summary fixes: unknown-provider qualifier and partial-value wrapping (130), then intrinsic value columns and medium-width currency layout (131). Both earlier source129/archive130 and source130/archive131 candidates were withheld after visual review; this ZIP uses corrected source131.

[Native screenshots](review.html) · [Reference/current browser comparison129](../redesign-v1.85.129/review.html) · [130 defect and fix evidence](../redesign-v1.85.131/README.md). The129 viewer precedes the130 wrapping fix and is not labelled as this ZIP's native paint.

## Validation

- Fresh daemon/web/tray builds and656 repository tests passed:123 daemon,335 web,198 tray; zero failures/skips/cancellations.
- Actual compiled production Electron main with its sandboxed preload: two launch cycles and16 captures across eight routes. EN/dark first, then TH/light with THB37.25 and window1371×887 restored through Settings/preload/main. Preload source, context isolation, sandbox and disabled Node integration are verified. All served web asset bytes are checked against the bundle.
- Both native Models frames explicitly verify all four values, the unknown qualifier and partial monetary value remain single-line after the real restart; these are the defects found in the rejected candidate.131 also retains a separate32-case browser matrix for EN/TH, dark/light,390/1280/1355/1688 and USD/THB.
- The owned QA database retained221 stored tokens and native/computed/unknown cost provenance; integrity passed. The unused source bundle remained byte unchanged throughout native QA. Frozen source tracked files remain clean.
- The actual ZIP passed dependency isolation, start/stop WhatIf behavior, scoped shutdown, database preservation and restart checks outside repository dependencies. All owned QA processes were stopped.

## Limits and remaining work

Native capture windows were offscreen, with test-only anti-occlusion/background-throttling and reduced-motion overrides. Actual first viewport: `{json.dumps(summary['firstViewport'])}`; first native image: `{json.dumps(summary['firstNativeImageSize'])}`. These are not reference-sized pixel acceptance or physical monitor/tray-click/performance proof. Only two native language/theme combinations were exercised here.

The full blueprint trace and accepted v1.1 gap ledger remain authoritative. Remaining visual materials, rings, typography, controls, full distinct-document repeat stability (including128 header differences), real-reader/customer flows, physical desktop behavior, performance and human acceptance remain open. Current versioned installation/upgrade/rollback and signing are not certified by these portable ZIP checks. Main is unchanged; branch/tag/worktree isolation is retained.
''',encoding='utf8',newline='\n')
captures=report['captures'];phases=list(dict.fromkeys(c['phase']for c in captures));routes=list(dict.fromkeys(c['route']for c in captures))
(root/'review.html').write_text('''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>QuotaPulse review132 native captures</title><style>body{background:#08111e;color:#deecff;font:15px system-ui;margin:20px}a{color:#38c9ff}select{padding:8px;margin:5px}img{width:100%;height:auto;display:block;margin:12px 0;border:1px solid #234}</style><h1>QuotaPulse review132</h1><p>Actual production Electron source131. Owned QA data; not concept parity approval. <a href="README.md">Run instructions and limits</a></p><label>Page <select id="route">'''+''.join('<option>'+r+'</option>'for r in routes)+'''</select></label><label>Native cycle <select id="phase">'''+''.join('<option>'+p+'</option>'for p in phases)+'''</select></label><p id="caption"></p><img id="image" alt="Selected native dashboard frame"><script>const data='''+json.dumps(captures)+''',route=document.getElementById('route'),phase=document.getElementById('phase'),frame=document.getElementById('image');function render(){const row=data.find(r=>r.route===route.value&&r.phase===phase.value);frame.src='images/'+row.phase+'-'+row.route+'.png';document.getElementById('caption').textContent=row.route+' / '+row.phase+' / '+row.nativeImageSize.width+'x'+row.nativeImageSize.height}route.onchange=phase.onchange=render;render();</script></html>''',encoding='utf8',newline='\n')
write('artifact-hashes.json',{str(p.relative_to(root)).replace('\\','/'):sha(p.read_bytes())for p in sorted(root.rglob('*'))if p.is_file()and p.name!='artifact-hashes.json'})
print(json.dumps({'artifacts':len(load(root/'artifact-hashes.json')),'source':report['sourceCommit'],'archive':archive['archive'],'sha256':archive['sha256']}))
