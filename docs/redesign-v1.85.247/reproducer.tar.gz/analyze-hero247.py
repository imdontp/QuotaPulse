from pathlib import Path
from PIL import Image
import hashlib, json, numpy as np, shutil

root = Path(__file__).resolve().parents[1]
out = root / 'docs/redesign-v1.85.247'
assert not out.exists()
before_dir, after_dir = (root / 'tmp/fidelity235' / name for name in ('hero247-before', 'hero247-after'))
before = json.loads((before_dir / 'verification.json').read_text(encoding='utf-8'))
after = json.loads((after_dir / 'verification.json').read_text(encoding='utf-8'))
stable = json.loads((root / 'tmp/overview247-stable/verification.json').read_text(encoding='utf-8'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
index = digest(root / 'packages/web/dist/index.html')
assert after['productionIndexSha256'] == stable['productionIndexSha256'] == index
assert stable['captureMatrix']['complete'] and len(stable['cases']) == 4
reference = root / 'docs/redesign-v1.85.156/refs/overview.png'
old_image, new_image = before_dir / 'overview.png', after_dir / 'overview.png'
for report, image in [(before, old_image), (after, new_image)]:
    assert len(report['results']) == 1
    row = report['results'][0]
    assert row['route'] == 'overview' and row['repeatIdentical'] and not row['errors'] and not row['forbidden']
    assert digest(image) == row['sha256'] == row['repeatSha256'] and digest(reference) == row['referenceSha256']
assert digest(old_image) == digest(root / 'docs/redesign-v1.85.245/overview.png')
imgs = {name: Image.open(path).convert('RGB') for name, path in [('reference', reference), ('before', old_image), ('after', new_image)]}
assert all(image.size == (1586, 992) for image in imgs.values())
diff = np.any(np.asarray(imgs['before']) != np.asarray(imgs['after']), axis=2)
y, x = np.where(diff)
assert len(x) and x.min() >= 650 and x.max() < 825 and y.min() >= 170 and y.max() < 275
out.mkdir()
for name, image in imgs.items(): image.crop((650, 170, 825, 275)).save(out / f'{name}-detail.png')
shutil.copyfile(new_image, out / 'after.png')
for source, name in [(before_dir / 'verification.json', 'before-verification.json'), (after_dir / 'verification.json', 'after-verification.json'), (root / 'tmp/overview247-stable/verification.json', 'stable-verification.json')]: shutil.copyfile(source, out / name)
record = {'productionIndexSha256': index, 'beforeMatchesGallery245': True, 'unmaskedChangedPixels': int(diff.sum()),
          'changedBounds': [int(x.min()), int(y.min()), int(x.max()) + 1, int(y.max()) + 1],
          'scope': 'fixed synthetic English/dark reference-viewport captures, not a whole-page likeness score'}
(out / 'analysis.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(record, indent=2))
