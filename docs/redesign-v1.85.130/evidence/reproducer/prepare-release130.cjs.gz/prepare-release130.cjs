const fs=require('fs'),assert=require('assert/strict');
const oldCommit='97bb1da57e6328b3d5c74e86955f3dafe8b9b3d8',commit='1913d86e5a015d0b5870d6a0223cc05883ad828f';
const oldIndex='f07fd15bfef89b60e59dcca679d930f0957c54be64e10333fc63650ab53fcb43',index='874c835e16f96e1ff9982480775fc2bd28edaa1ae296c99b941d2125a78fa1e4';
for(const name of ['build-review125.ps1','prepare-review125.cjs','archive-review125.ps1','extract-review125.ps1','check-bundle125.mts','check-native-review125.mts']){
 let s=fs.readFileSync('tmp/'+name,'utf8').replaceAll('redesign-validation-v1.85.124','redesign-validation-v1.85.129').replaceAll('release125','release130').replaceAll('review125','review130').replaceAll('v1.85.124-review130','v1.85.129-review130').replaceAll(oldCommit,commit).replaceAll(oldIndex,index);
 s=s.replace("mkdtempSync(join(tmpdir(),'qpdash-'))", "mkdtempSync(join(realpathSync.native(tmpdir()),'qpdash-'))");
 assert.ok(!s.includes(oldCommit)&&!s.includes(oldIndex)&&!s.includes('redesign-validation-v1.85.124'));
 fs.writeFileSync('tmp/'+name.replace('125','130'),s);
}
fs.mkdirSync('tmp/release130',{recursive:true});console.log({commit,index,output:'tmp/release130'});
