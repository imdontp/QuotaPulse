from pathlib import Path
import json,hashlib,gzip,subprocess
root=Path('docs/redesign-v1.85.130');root.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text(encoding='utf8').lstrip('\ufeff'))
def write(name,value):
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
def copy(src,name,zipped=False,raw=False):
 b=Path(src).read_bytes()
 if str(src).endswith('.log'):b=b.decode('utf-16' if b[:2]==b'\xff\xfe' else 'utf8').lstrip('\ufeff').replace('\r\n','\n').encode()
 if str(src).endswith('.json') and not raw:b=b.decode('utf8').lstrip('\ufeff').replace('\r\n','\n').encode()
 if zipped:b=gzip.compress(b,mtime=0)
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
index=sha(Path('packages/web/dist/index.html').read_bytes());before=load('tmp/wrap130/before/verification.json');after=load('tmp/wrap130/after/verification.json')
assert before['index']=='874c835e16f96e1ff9982480775fc2bd28edaa1ae296c99b941d2125a78fa1e4' and after['index']==index
assert before['status']==after['status']=='passed' and len(after['results'])==16
assert before['results'][0]['unknownLines']==before['results'][0]['valueLines']==2
assert all(r['unknownLines']==r['valueLines']==1 for r in after['results'])
for phase,report in [('before',before),('after',after)]:
 for name in ['en-dark-1688-USD','th-light-390-THB']:
  row=next((r for r in report['results'] if r['name']==name),None)
  if row:
   p=Path('tmp/wrap130')/phase/(name+'.png');assert sha(p.read_bytes())==row['sha256'];copy(p,'images/'+phase+'/'+name+'.png')
for phase in ['before','after']:copy('tmp/wrap130/'+phase+'/verification.json','evidence/'+phase+'.json.gz',True)
native='tmp/review130/native-27b875be-b948-4539-b761-8cd3901374b6';report=load(native+'/verification.json');assert report['sourceCommit']=='1913d86e5a015d0b5870d6a0223cc05883ad828f' and report['status']=='passed' and len(report['captures'])==16
copy(native+'/initial-models.png','images/native129-before-models.png');copy(native+'/verification.json','evidence/native129-candidate.json.gz',True)
copy('tmp/release130/archive.json','evidence/source129-candidate-archive.json');copy('tmp/release130/build/build.json','evidence/source129-candidate-build.json')
copy('tmp/release130/build/build.json','evidence/source129-candidate-build-raw.json.gz',True,True)
for name in ['wrap130-before.log','wrap130-before-final.log','wrap130-before-api.log','wrap130-after.log','wrap130-after-final.log','build130-wrap-web-final.log','review130-native.log','review130-archive.log']:copy('tmp/'+name,'evidence/logs/'+name+'.gz',True)
for name in ['prepare-wrap130.cjs','wrap130-body.txt','check-wrap130.mts','fix-wrap130.cjs','package-wrap130.py','prepare-release130.cjs']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
paths=subprocess.check_output(['git','diff','HEAD','--name-only','--','packages/web/src'],text=True).splitlines();assert len(paths)==4
write('source-fingerprints.json',[{'path':p,'rawSha256':sha(Path(p).read_bytes()),'lfSha256':sha(Path(p).read_bytes().replace(b'\r\n',b'\n'))}for p in paths])
write('summary.json',{'checkpoint':'v1.85.130','parent':'1913d86e5a015d0b5870d6a0223cc05883ad828f','index':index,'beforeIndex':before['index'],'browserCases':16,'knownDefectsBefore':{'unknownQualifierLines':2,'partialValueLines':2},'afterAllCases':{'unknownQualifierLines':1,'partialValueLines':1},'source129Candidate':'Functional native checks passed, but ZIP withheld after visual review identified wrapping defects; not the final review delivery','fullRedesignComplete':False})
(root/'README.md').write_text('''# Native-discovered Models summary wrapping v1.85.130

The source129 review candidate built successfully, passed656 repository tests and its real Electron two-cycle/16-capture machinery checks, and produced a byte-verified ZIP. Visual inspection then identified two wrapping defects in its small, partially priced dataset. That candidate is NOT the updated delivery. Its archive receipt is retained as candidate evidence; the delivery must be rebuilt from this fixed source.

## Observed defects and minimal correction

The actual source129 Electron Models frame showed the unknown-provider qualifier split across lines and the partial value$0.01+ split before its +. The same three-event owned dataset (221 stored tokens; native/computed/unknown cost provenance) reproduced both two-line fragments in the compiled browser at1688px.

The provider summary now uses the shorter localized "Across {count} providers" form with its existing true count and separate unknown-pair disclosure. The +? abbreviation is an indivisible inline unit. The money card selects its existing wide layout at six characters rather than seven, fixing$0.01+. Narrow wide-value cards use a full-width row beneath their icon/header, keeping that value readable. Values, cost coverage, API data, scope, and unknown-state semantics are unchanged. Long factual content still has intrinsic wrapping; nothing is clipped or hidden to fit the reference.

## Validation

- Final TypeScript/production web build passed.
- Original causal reproduction: both fragments occupy two text-line positions before the fix.16 final browser cases (EN/TH, dark/light,390/1688, USD/THB at37.25) show each fragment on one line, retain summary child bounds and have no page overflow, browser errors or forbidden writes. Each case independently reads the exact Models API query used by its UI; all preserve221 tokens and three model/route groups.
- The first test harness attempted a named nested page.evaluate function and failed because its transpiler helper was absent in the browser. It was replaced with direct DOM Range measurements. A subsequently constructed unsupported API query returned400; the harness now uses the actual UI request URL. Both failed logs are retained; these were harness corrections, not product fixes.
- An initial product candidate still wrapped the value at390px because the existing narrow rule overrode the wide layout. The final targeted narrow CSS rule corrected that observed case. The failed log is retained.
- The656 repository tests and native16 captures here belong to the source129 candidate, NOT to a fresh source130 release. Full fixed-source rebuild/repository/native/ZIP validation follows in the next delivery checkpoint. No customer database or fixture is shipped. The source129 candidate used a separate synthetic QA profile, readers off and offscreen windows; it is not physical desktop or real-reader acceptance.

Overall redesign is incomplete.99–100% visual acceptance and the earlier all-page repeat issues remain unresolved. The latest accepted downloadable review ZIP remains125/source124 until the fixed-source replacement is verified. Main is unchanged.
''',encoding='utf8',newline='\n')
write('artifact-hashes.json',{str(p.relative_to(root)).replace('\\','/'):sha(p.read_bytes())for p in sorted(root.rglob('*'))if p.is_file()and p.name!='artifact-hashes.json'})
print(json.dumps({'index':index,'cases':16,'artifacts':len(load(root/'artifact-hashes.json'))}))
