const fs=require('fs'),assert=require('assert/strict');
let s=fs.readFileSync('tmp/check-summary129-native.mts','utf8');
const native=fs.readFileSync('tmp/check-native-review130.mts','utf8');
const a=native.indexOf('db.transaction(()=>{'),b=native.indexOf('const factsBefore=',a);assert.ok(a>0&&b>a);
const seed=native.slice(a,b).replace(/\bnow\b/g,'fixedNow');
const start=s.indexOf("const db = openDb(':memory:');"),end=s.indexOf('const scheduler',start);assert.ok(start>0&&end>start);
s=s.slice(0,start)+"const db = openDb(':memory:');\n"+seed+s.slice(end);
s=s.slice(0,s.indexOf('const results:unknown[]=[];')).replace('tmp/fidelity129/native',"tmp/wrap130/"+(process.env.QP_WRAP_PHASE??'before'));
s+=fs.readFileSync('tmp/wrap130-body.txt','utf8');fs.writeFileSync('tmp/check-wrap130.mts',s);
