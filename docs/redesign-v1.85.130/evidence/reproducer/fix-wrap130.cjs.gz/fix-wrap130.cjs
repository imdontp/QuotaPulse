const fs=require('fs'),assert=require('assert/strict');
function edit(p,from,to){const s=fs.readFileSync(p,'utf8');assert.equal(s.split(from).length,2,p);fs.writeFileSync(p,s.replace(from,to));}
edit('packages/web/src/redesign/models.tsx',"{t('redesign.providersUsed')}: {number(recordedProviders.size)}","{t('redesign.modelsAcrossProviders').replace('{count}', number(recordedProviders.size))}");
edit('packages/web/src/redesign/models.tsx',"data!.totals.estimated_calls < data!.totals.calls ? 1 : 0) > 6}","data!.totals.estimated_calls < data!.totals.calls ? 1 : 0) > 5}");
for(const [lang,text]of [['en','Across {count} providers'],['th','จากผู้ให้บริการ {count} ราย']])edit('packages/web/src/i18n/'+lang+'.ts',"  'redesign.modelsInput':",`  'redesign.modelsAcrossProviders': '${text}',\n  'redesign.modelsInput':`);
fs.appendFileSync('packages/web/src/redesign/models.css','\n/* Keep the unknown-provider qualifier together when the summary wraps. */\n.qp-model-summary [data-testid=models-provider-count] abbr { display:inline-block; white-space:nowrap; }\n');
