/** Static canonical reference capture. Isolated synthetic DB, compiled application, no user data. */
import assert from 'node:assert/strict';
import { en } from '../packages/web/src/i18n/en.js';
import { th } from '../packages/web/src/i18n/th.js';
import { installBrowserFixedDate } from '../scripts/browser-fixed-date.mjs';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium, type Page, type Request } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import { recordQuotaAlerts } from '../packages/daemon/src/api/queries.js';
const root = fileURLToPath(new URL('..', import.meta.url));
const output = resolve(root, 'tmp/wrap130/after'); 
const referenceRoot = 'C:/Users/TH12367283/Downloads/quotapulse_build_blueprint';
const priorTimezone = process.env.TZ;
process.env.TZ = 'Asia/Bangkok';
mkdirSync(output, { recursive: true });

const fixedNow = Date.parse('2025-05-17T13:42:00.000Z');
// Freeze Date only, keeping real timers/performance for HTTP, browser and cleanup.
// This applies to internal query helpers too, without changing production clocks.
const realDate = globalThis.Date;
globalThis.Date = new Proxy(realDate, {
  construct(target, args) { return Reflect.construct(target, args.length ? args : [fixedNow]); },
  apply() { return new realDate(fixedNow).toString(); },
  get(target, property, receiver) { return property === 'now' ? () => fixedNow : Reflect.get(target, property, receiver); },
});
const db = openDb(':memory:');
db.transaction(()=>{
 db.prepare(`INSERT INTO source(id,harness,profile,root_path,display_name,enabled,detected_at,account_key,account_provider,account_display_name,account_state,account_last_success_at) VALUES(?,?,?,?,?,0,?,?,?,?,?,?)`).run(1,'codex','native-review','/synthetic/nonexistent','Native review source A',fixedNow,'review:openai','openai','Native review OpenAI','active',fixedNow);
 db.prepare(`INSERT INTO source(id,harness,profile,root_path,display_name,enabled,detected_at,account_key,account_provider,account_display_name,account_state,account_last_success_at) VALUES(?,?,?,?,?,0,?,?,?,?,?,?)`).run(2,'claude-code','native-review','/synthetic/nonexistent','Native review source B',fixedNow,'review:anthropic','anthropic','Native review Anthropic','active',fixedNow);
 db.prepare('INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES(1,1,?,?,?)').run('native-review-a','Native review project',fixedNow);
 db.prepare('INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES(2,2,?,?,?)').run('native-review-b','Native review second project',fixedNow);
 const event=db.prepare(`INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source,cost_input_usd,cost_cached_input_usd,cost_output_usd,cost_cache_saving_usd,price_provider) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
 event.run(1,1,'native-review-1',fixedNow-30000,'Native Model A','openai',100,0,50,150,1,.25,'native',null,null,null,null,null);
 event.run(2,2,'native-review-2',fixedNow-60000,'Native Model B','anthropic',40,10,20,70,2,.0123,'computed',.004,.0003,.008,.0007,'anthropic');
 event.run(1,1,'native-review-3',fixedNow-90000,null,null,1,0,0,1,1,null,'unknown',null,null,null,null,null);
 const quota=db.prepare('INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin) VALUES(?,?,?,?,?,?,?,?)');
 quota.run(1,'5h',83,fixedNow+7200000,fixedNow,fixedNow,fixedNow,'native-review');quota.run(2,'monthly',62,fixedNow+86400000,fixedNow,fixedNow,fixedNow,'native-review');
 db.exec(`INSERT OR REPLACE INTO app_setting(id,pet_enabled,tray_animation_enabled,hidden_subscriptions,updated_at) VALUES(1,0,0,'[]',0);INSERT OR REPLACE INTO notification_setting(id,enabled,snooze_until,quiet_start,quiet_end,updated_at) VALUES(1,0,4102444800000,1320,420,0);`);
})();
const scheduler = new Scheduler(db, [], { pollMs: 1_000_000, detectMs: 1_000_000 });
const daemon = buildServer(db, scheduler, { token: 'stable-capture-test', port: 7816, webRoot: resolve(root, 'packages/web/dist') });

let browser:Awaited<ReturnType<typeof chromium.launch>>|undefined;
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const indexPath=resolve(root,'packages/web/dist/index.html'),index=sha(readFileSync(indexPath));
const results:any[]=[];
try{
 await daemon.listen({host:'127.0.0.1',port:7816});browser=await chromium.launch({channel:'chrome',headless:true});
 const cases=process.env.QP_WRAP_PHASE==='after'?['en','th'].flatMap(lang=>['dark','light'].flatMap(theme=>[390,1688].flatMap(width=>['USD','THB'].map(currency=>({lang,theme,width,currency}))))):[{lang:'en',theme:'dark',width:1688,currency:'USD'}];
 for(const {lang,theme,width,currency}of cases){
  const name=[lang,theme,width,currency].join('-'),context=await browser.newContext({viewport:{width,height:980},deviceScaleFactor:1,reducedMotion:'reduce',timezoneId:'Asia/Bangkok'}),page=await context.newPage(),errors:string[]=[],forbidden:string[]=[];
  page.on('pageerror',e=>errors.push(e.message));await page.route('**/*',route=>{const r=route.request(),u=new URL(r.url());if(u.origin!=='http://127.0.0.1:7816'||r.method()!=='GET'&&!(r.method()==='POST'&&u.pathname==='/api/model-row-trends')){forbidden.push(r.method()+' '+u.pathname);return route.abort()}return route.continue()});
  await page.addInitScript(({lang,theme,currency})=>{(window as any).__QUOTAPULSE_TOKEN__='stable-capture-test';localStorage.setItem('quotapulse-prefs',JSON.stringify({lang,currency,rate:37.25,hiddenSubscriptions:[]}));localStorage.setItem('quotapulse-theme',theme)},{lang,theme,currency});await installBrowserFixedDate(page,fixedNow);
  const summaryResponse=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/models'&&r.status()===200);
  await page.goto('http://127.0.0.1:7816/#models',{waitUntil:'domcontentloaded'});const summaryUrl=new URL((await summaryResponse).url());await page.locator('.qp-model-summary article[data-tone=orange]').first().waitFor();await page.locator('.qp-model-trend').waitFor();await page.evaluate(()=>document.fonts.ready);
  const facts=await page.evaluate(()=>{
   const count=document.querySelector('[data-testid=models-provider-count]')!,unknown=count.querySelector('abbr')!,value=document.querySelector('.qp-model-summary article:last-child>strong .qp-cost-value>span:first-child')!;
   const unknownRange=document.createRange(),valueRange=document.createRange();unknownRange.selectNodeContents(unknown);valueRange.selectNodeContents(value);
   return{providerText:count.textContent,unknownText:unknown.textContent,unknownRects:[...unknownRange.getClientRects()].filter(r=>r.width>0&&r.height>0).map(r=>r.toJSON()),value:value.textContent,valueRects:[...valueRange.getClientRects()].filter(r=>r.width>0&&r.height>0).map(r=>r.toJSON()),wide:value.closest('article')!.getAttribute('data-wide'),cards:[...document.querySelectorAll('.qp-model-summary article')].map(card=>({rect:card.getBoundingClientRect().toJSON(),children:[...card.querySelectorAll(':scope>small,:scope>strong')].map(node=>({text:node.textContent,rect:node.getBoundingClientRect().toJSON()}))})),overflow:document.documentElement.scrollWidth>innerWidth};
  });
  const response=await daemon.inject({url:summaryUrl.pathname+summaryUrl.search,headers:{'x-quotapulse-token':'stable-capture-test'}});assert.equal(response.statusCode,200);const data=response.json();assert.equal(data.totals.tokens,221);assert.equal(data.groups.length,3);
  assert.equal(facts.overflow,false);assert.deepEqual(errors,[]);assert.deepEqual(forbidden,[]);
  const unknownLines=new Set(facts.unknownRects.map(r=>r.top)).size,valueLines=new Set(facts.valueRects.map(r=>r.top)).size;
  if(process.env.QP_WRAP_PHASE==='after'){
   assert.equal(unknownLines,1,'Unknown-provider qualifier must remain one readable unit');assert.equal(valueLines,1,'Partial monetary amount must remain on one line in the tested card');
   for(const card of facts.cards)for(const child of card.children)assert.ok(child.rect.left>=card.rect.left-.5&&child.rect.right<=card.rect.right+.5&&child.rect.bottom<=card.rect.bottom+.5,JSON.stringify(child));
  }else{assert.equal(unknownLines,2);assert.equal(valueLines,2)}
  const frame=await page.screenshot({path:resolve(output,name+'.png'),animations:'disabled'});results.push({name,lang,theme,width,currency,facts,unknownLines,valueLines,api:{tokens:data.totals.tokens,calls:data.totals.calls,apiValue:data.totals.api_value_usd,computedCalls:data.totals.computed_calls,unknownCalls:data.totals.unknown_calls},sha256:sha(frame)});console.log('Recorded '+name+' lines '+unknownLines+'/'+valueLines);await context.close();
 }
 writeFileSync(resolve(output,'verification.json'),JSON.stringify({status:'passed',phase:process.env.QP_WRAP_PHASE??'before',index,browser:browser.version(),results},null,2));
}finally{await browser?.close();await daemon.close();db.close();globalThis.Date=realDate;process.env.TZ=priorTimezone}
