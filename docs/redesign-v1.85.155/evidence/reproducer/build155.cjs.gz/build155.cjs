const {spawnSync}=require('node:child_process'),fs=require('node:fs');
const result=spawnSync(process.env.ComSpec||'cmd.exe',['/d','/c','npm.cmd run build -w @quotapulse/web'],{encoding:'utf8',maxBuffer:20000000});
fs.writeFileSync('tmp/alerts155-build.log',result.stdout+'\n'+result.stderr);fs.writeFileSync('tmp/alerts155-build-result.json',JSON.stringify({status:result.status,signal:result.signal,error:result.error?.message},null,2)+'\n');console.log(JSON.stringify({status:result.status,signal:result.signal}));process.exitCode=result.status??1;
