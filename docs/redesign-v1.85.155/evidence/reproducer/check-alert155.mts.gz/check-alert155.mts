/** Real HTTP + in-memory SQLite E2E. Never opens the user's usage database. */
import assert from 'node:assert/strict';
import { mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer } from 'vite';
import { closeAbortedSseProxy } from '../packages/web/vite-sse-proxy.js';
import { chromium } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { recordQuotaAlerts } from '../packages/daemon/src/api/queries.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import { en as englishMessages } from '../packages/web/src/i18n/en.ts';
import { th as thaiMessages } from '../packages/web/src/i18n/th.ts';
import { checkAlertsLayout } from './check-alerts-diagnostic155.mts';
import type { Overview } from '../packages/web/src/api.ts';

const root = fileURLToPath(new URL('..', import.meta.url));
const output = resolve(root, 'tmp/alerts155');
mkdirSync(output, { recursive: true });
for (const manifest of ['verification.json', 'cost-route-compatibility.json']) rmSync(resolve(output, manifest), { force: true });
const db = openDb(':memory:');
const now = Date.now();
db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at) VALUES
  (1,'codex','test','/synthetic/nonexistent','Codex test',0), (2,'hermes','test','/synthetic/nonexistent','Hermes test',0);
  INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (1,1,'synthetic-session','alpha_100%',${now - 1000}), (2,2,'aggregate-session',NULL,NULL);`);
db.prepare(`UPDATE source SET account_key='openai:subscription', account_provider='openai',
  account_display_name='OpenAI Test Subscription', account_state='active', account_last_success_at=? WHERE id=1`).run(now - 15000);
db.prepare(`INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin)
  VALUES (1,'5h',38,?,?,?,?,?)`).run(now + 7200000, now - 15000, now - 15000, now - 15000, 'live-synthetic');
for (const [used, observed, reset] of [[80, now - 10800000, now - 7200000], [10, now - 2400000, now + 7200000], [20, now - 1200000, now + 7200000]]) {
  db.prepare(`INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin)
    VALUES (1,'5h',?,?,?,?,?,?)`).run(used, reset, observed, observed, observed, 'live-synthetic');
}
db.prepare(`INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin)
  VALUES (1,'5h',92,?,?,?,?,?)`).run(now + 7200000, now - 7200000, now - 7200000, now - 7200000, 'old-fallback');
const insert = db.prepare(`INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,total_tokens,call_count,cost_usd,cost_source)
  VALUES (?,?,?,?,?,?,?,1,0.2,'computed')`);
db.transaction(() => {
  for (let i = 0; i < 52; i++) insert.run(1, 1, `test-${i}`, now - 1000 - i, 'gpt-test', 'openrouter', 100 + i);
  insert.run(2, 2, 'aggregate', now - 2000, 'claude-test', 'anthropic', 999);
})();
db.prepare(`UPDATE usage_event SET input_tokens=40,cached_input_tokens=20,
  output_tokens=total_tokens-60,cost_cache_saving_usd=0.03 WHERE source_id=1`).run();
db.prepare(`UPDATE usage_event SET cache_write_tokens=7,duration_ms=1234,service_tier='test-tier',price_provider='anthropic' WHERE id=53`).run();
db.prepare(`UPDATE session SET is_subagent=1 WHERE id=2`).run();
const scheduler = new Scheduler(db, [], { pollMs: 1000000, detectMs: 1000000 });
const daemon = buildServer(db, scheduler, { token: 'history-test', port: 7800, webRoot: resolve(root, 'packages/web/dist') });
const vite = await createServer({ root: resolve(root, 'packages/web'), server: { host: '127.0.0.1', port: 7801, strictPort: true, proxy: { '/api': { target: 'http://127.0.0.1:7800', changeOrigin: true, configure: closeAbortedSseProxy } } } });
let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;
try{await daemon.listen({host:'127.0.0.1',port:7800});await vite.listen();browser=await chromium.launch({channel:'chrome',headless:true});await checkAlertsLayout(browser,db,output,[],scheduler);console.log('PASS focused Alerts layout');}
finally{await browser?.close();await vite.close();await daemon.close();db.close();}
