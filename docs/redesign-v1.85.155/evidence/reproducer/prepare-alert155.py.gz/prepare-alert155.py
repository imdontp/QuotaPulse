from pathlib import Path
s=Path('scripts/check-history.mts').read_text(encoding='utf-8')
s=s[:s.index('let browser:')]
s=s.replace("from './check-alerts-layout.mts'","from './check-alerts-diagnostic155.mts'")
s=s.replace("const output = resolve(root, 'screens/history');","const output = resolve(root, 'tmp/alerts155');")
s+='''let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;
try{await daemon.listen({host:'127.0.0.1',port:7800});await vite.listen();browser=await chromium.launch({channel:'chrome',headless:true});await checkAlertsLayout(browser,db,output,[],scheduler);console.log('PASS focused Alerts layout');}
finally{await browser?.close();await vite.close();await daemon.close();db.close();}
'''
Path('tmp/check-alert155.mts').write_bytes(s.encode())
s=Path('scripts/check-alerts-layout.mts').read_text(encoding='utf-8')
needle="        assert.ok(Math.abs(chart.width - chart.viewWidth) <= 1, 'Quota chart uses stretched coordinates');"
assert s.count(needle)==1
s=s.replace(needle,'''        const frames=[chart];
        for(let i=0;i<5;i++){await page.evaluate(()=>new Promise(requestAnimationFrame));frames.push(await screen.locator('.qp-alert-segments').evaluate(node=>({width:node.getBoundingClientRect().width,viewWidth:Number(node.getAttribute('viewBox')!.split(' ')[2]),points:Array.from(node.querySelectorAll('circle')).map(point=>({x:+point.getAttribute('cx')!,y:+point.getAttribute('cy')!}))})));}
        writeFileSync(resolve(output,`geometry-${lang}-${theme}.json`),JSON.stringify(frames,null,2)+'\\n');
        assert.ok(Math.abs(chart.width - chart.viewWidth) <= 1, 'Quota chart uses stretched coordinates: '+JSON.stringify({lang,theme,frames}));''')
Path('tmp/check-alerts-diagnostic155.mts').write_bytes(s.encode())
