from pathlib import Path
import gzip,hashlib,json
out=Path('docs/redesign-v1.85.155');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,compressed=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not compressed and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0) if compressed else b)
def log(path):
 b=Path(path).read_bytes();return b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
before=load('tmp/alerts155/geometry-before-en-dark.json');assert before[0]['viewWidth']==600 and abs(before[0]['width']-600)>300 and abs(before[1]['width']-before[1]['viewWidth'])<1
assert load('tmp/alerts155-build-result.json')['status']==0
assert 'Quota chart uses stretched coordinates' in log('tmp/alerts155-before.log') and 'PASS focused Alerts layout' in log('tmp/alerts155-after.log')
assert '# pass 353' in log('tmp/alerts155-web-tests.log') and '# fail 0' in log('tmp/alerts155-web-tests.log')
assert 'History/Overview/Projects/Live/Providers/Models/Cost/Alerts E2E passed' in log('tmp/alerts155-integration.log') and 'History teardown: database closed' in log('tmp/alerts155-integration.log')
matrix=load('screens/history/responsive-matrix.json');assert len(matrix['cases'])==144 and all(row['streams']<=1 for row in matrix['cases'])
current=load('tmp/fidelity155/final/verification.json');prior=load('tmp/fidelity153/final/verification.json');diffs=load('tmp/fidelity155/analysis.json')
index=sha(Path('packages/web/dist/index.html').read_bytes());assert current['productionIndexSha256']==index
assert prior['productionIndexSha256']==load('docs/redesign-v1.85.153/delivery.json')['productionIndexSha256']
assert len(current['results'])==8 and all(row['repeatIdentical'] and row['errors']==[] and row['forbidden']==[] for row in current['results'])
assert next(row for row in diffs if row['route']=='alerts')['changedPixels']==0
assert len([row for row in diffs if row['changedPixels']==0])==7 and next(row for row in diffs if row['route']=='models')['changedPixels']==3
copy('tmp/alerts155/geometry-before-en-dark.json','evidence/geometry-before-en-dark.json')
for lang in ['en','th']:
 for theme in ['dark','light']:
  name=lang+'-'+theme;frames=load('tmp/alerts155/geometry-'+name+'.json');assert len(frames)==6 and all(abs(row['width']-row['viewWidth'])<=1 and row['points'][0]['y']==104 for row in frames)
  copy('tmp/alerts155/geometry-'+name+'.json','evidence/geometry-after-'+name+'.json')
  copy('tmp/alerts155/alerts-occupied-'+name+'.png','images/alerts-'+name+'.png')
for src,dst in [('tmp/alerts155/alerts-occupied-layout.json','focused-layout.json'),('screens/history/alerts-occupied-layout.json','integration-alerts-layout.json'),('screens/history/verification.json','integration.json'),('screens/history/responsive-matrix.json','integration-matrix.json'),('tmp/alerts155-build-result.json','build-result.json'),('tmp/fidelity153/final/verification.json','canonical-before.json'),('tmp/fidelity155/final/verification.json','canonical-current.json'),('tmp/fidelity155/analysis.json','comparison.json')]:copy(src,'evidence/'+dst)
copy('tmp/fidelity155/final/models.png','evidence/models-current.png')
for src,dst in [('tmp/alerts155-before.log','before-reproduction'),('tmp/alerts155-after.log','after-reproduction'),('tmp/alerts155-build.log','build'),('tmp/alerts155-web-tests.log','web-tests'),('tmp/alerts155-integration.log','integration'),('tmp/fidelity155-final.log','canonical-current')]:copy(src,'evidence/logs/'+dst+'.log.gz',True)
for name in ['check-alert155.mts','check-alerts-diagnostic155.mts','prepare-alert155.py','capture-fidelity155.mts','diff155.py','build155.cjs','package155.py']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
sources={}
for name in ['packages/web/src/redesign/quota-chart.tsx','scripts/check-alerts-layout.mts']:
 b=Path(name).read_bytes();sources[name]={'rawSha256':sha(b),'lfSha256':sha(b.replace(b'\r\n',b'\n'))}
write('source-hashes.json',sources)
write('delivery.json',{'parentCommit':'7d4e9aee2bc322043d4fe9805e63b0a314e3bd39','productionIndexSha256':index,'webTests':353,'focusedLanguageThemeCases':4,'geometryFramesPerCase':6,'fullIntegrationPassed':True,'responsiveCases':144,'canonicalRepeatPairs':8,'settledAlertsPixelsChanged':0,'unchangedCanonicalFrames':7,'modelsUnexplainedPixels':3,'nativeRevalidated':False,'newArchiveCreated':False,'historicalSseIntermittenceResolved':False,'fullGoalComplete':False})
(out/'README.md').write_bytes('''# Quota chart initial coordinates / source155

The Alerts quota chart could briefly show stretched coordinates on first mount. A focused run of the original assertion measured its actual width932.9375px with viewBox600 and x positions34/407.333/594. One animation frame later the same chart used viewBox933 and positions34/629.333/927. It was not a stale quota value or incorrect percentage calculation: the hardcoded600 fallback remained visible until the first ResizeObserver delivery. The original full integration failure in source154 omitted the measured values; the focused frame trace now establishes this causal timing mechanism.

QuotaChart now measures its mounted client width in useLayoutEffect before paint, then retains ResizeObserver for later size changes. Existing minimum width, percentage/time calculations, unknown sample breaks, reset boundaries, zero baseline, text and accessible sample table are unchanged. The same component serves Alerts and the Overview history disclosure, where it mounts only after the disclosure opens. No API or data changes were needed. The maintained assertion now includes language/theme/geometry in its failure message; its tolerance and timing are unchanged.

## Validation

The identical focused diagnostic asserts the first measured frame, not a later settled frame. Before the change it fails with600 versus932.9375; after the change it reads933 immediately and passes all four EN/TH dark/light layouts. Six measurements per case retain the same correct coordinate width. All zero points remain at y104. The existing focused Alerts flow also checks the unknown sample break, four source owners, sample table keyboard controls, same-owner SSE counter drop, unknown-only owner, sidebar risk count, Quick Stats and390/900/1280 layout. No assertion or numeric tolerance was loosened and no sleep was added to the maintained check to hide the initial state.

Production build exits0 and353 web tests pass without failures/skips/cancellations. The complete maintained dashboard integration, including the Alerts assertion that failed in source154, passes. Its144 responsive cases retain at most one SSE server listener. This does not prove the separate historical SSE intermittence fixed; the dev proxy cause fixed in source154 remains a narrower, independently validated conclusion.

All eight current canonical screenshot pairs are byte-identical within their context. The historical baseline is the verified source153 renderer, not a fresh run relabeled as before. Settled Alerts is byte-identical to that baseline, as are six other pages: this correction changes the transient initial layout rather than the approved settled design. Models still differs by3 unexplained edge pixels at x246,y353–414, maximum channel delta23, and its whole current frame is retained. No mask/tolerance closes that gate. The earlier105 Providers header variance also remains unexplained even though the current Providers frame matches source153.

```powershell
npm.cmd run build -w @quotapulse/web
npm.cmd run test -w @quotapulse/web
node --import tsx scripts/check-history.mts
```

The four images are actual occupied Alerts captures after validation; no initial-before screenshot was captured, and no synthetic before image was reconstructed. The before/after frame geometry is the evidence for the transient correction. Compressed exact logs and isolated-fixture reproducers accompany source/index hashes. Reproducers run from tmp/ after decompression; the focused diagnostic copy retains its pre-fix first-frame assertion. No new native, ZIP or performance/migration acceptance is claimed. The most recent runnable ZIP is still review150 and lacks source151–155. Original reference99–100% approval, remaining visual/control/motion, native/customer/provider, tray/monitor, performance and migration/rollback gates remain open. Main and unrelated work remain preserved.
'''.encode())
write('artifact-hashes.json',{p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='artifact-hashes.json'})
print('Sealed',len(load(out/'artifact-hashes.json')),'artifacts')
