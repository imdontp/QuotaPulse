from pathlib import Path
from PIL import Image
import hashlib, json, numpy as np, shutil

root = Path(__file__).resolve().parents[1]
dest = root / 'docs/redesign-v1.85.246'
assert not dest.exists()
dest.mkdir()
paths = {
    'reference': root / 'docs/redesign-v1.85.156/refs/models.png',
    'before': root / 'docs/redesign-v1.85.245/models.png',
    'after': root / 'tmp/fidelity235/ring246/models.png',
}
report = json.loads((root / 'tmp/fidelity235/ring246/verification.json').read_text(encoding='utf-8'))
stable = json.loads((root / 'tmp/models246-stable/verification.json').read_text(encoding='utf-8'))
index = hashlib.sha256((root / 'packages/web/dist/index.html').read_bytes()).hexdigest()
assert report['productionIndexSha256'] == stable['productionIndexSha256'] == index
result = report['results'][0]
assert result['route'] == 'models' and result['repeatIdentical'] and not result['errors'] and not result['forbidden']
assert hashlib.sha256(paths['after'].read_bytes()).hexdigest() == result['sha256']
assert hashlib.sha256(paths['reference'].read_bytes()).hexdigest() == result['referenceSha256']
assert stable['captureMatrix']['complete'] and len(stable['cases']) == 4
images = {name: Image.open(path).convert('RGB') for name, path in paths.items()}
assert all(image.size == (1672, 941) for image in images.values())
for name, image in images.items():
    image.crop((1500, 380, 1650, 520)).save(dest / f'{name}-ring.png')
shutil.copyfile(paths['after'], dest / 'after.png')
change = np.any(np.asarray(images['before']) != np.asarray(images['after']), axis=2)
region = np.zeros(change.shape, bool)
region[375:530, 1485:1655] = True
y, x = np.where(change)
points = {'upper_right': (1609, 418), 'lower_left': (1536, 486)}
samples = {}
for name, image in images.items():
    pixels = np.asarray(image)
    samples[name] = {label: np.median(pixels[py-1:py+2, px-1:px+2], axis=(0, 1)).astype(int).tolist() for label, (px, py) in points.items()}
record = {'scope': 'unmasked before/after full frames; sample colors are 3x3 medians and are not a likeness score',
          'productionIndexSha256': index, 'changedPixels': int(change.sum()), 'changedInsideRingRegion': int((change & region).sum()),
          'changedOutsideRingRegion': int((change & ~region).sum()), 'changedBounds': [int(x.min()), int(y.min()), int(x.max()) + 1, int(y.max()) + 1],
          'ringRegion': [1485, 375, 1655, 530], 'sampleCoordinates': points, 'samplesRgb': samples}
(dest / 'analysis.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
shutil.copyfile(root / 'tmp/fidelity235/ring246/verification.json', dest / 'capture-verification.json')
shutil.copyfile(root / 'tmp/models246-stable/verification.json', dest / 'stable-verification.json')
print(json.dumps(record, indent=2))
