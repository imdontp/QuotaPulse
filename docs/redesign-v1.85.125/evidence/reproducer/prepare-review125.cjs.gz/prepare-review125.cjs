const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),crypto=require('node:crypto');
const checkout='C:/Users/TH12367283/Projects/QuotaPulse/tmp/worktrees/redesign-validation-v1.85.124';
const built=JSON.parse(fs.readFileSync(path.join(checkout,'screens/tray-recovery/bundle-build.json')));
const receipt='tmp/release125/build/build.json';const record=JSON.parse(fs.readFileSync(receipt));
assert.equal(record.sourceCommit,'97bb1da57e6328b3d5c74e86955f3dafe8b9b3d8');assert.equal(record.steps.length,6);assert.ok(record.steps.every(step=>step.exitCode===0));
const hash=crypto.createHash('sha256').update(fs.readFileSync(path.join(built.bundle,'packages/web/dist/index.html'))).digest('hex');assert.equal(hash,'f07fd15bfef89b60e59dcca679d930f0957c54be64e10333fc63650ab53fcb43');
fs.writeFileSync('tmp/release125/inputs.json',JSON.stringify({checkout,bundle:built.bundle,sourceCommit:record.sourceCommit,buildReceipt:path.resolve(receipt),webIndexSha256:hash},null,2)+'\n');
console.log(JSON.stringify({bundle:built.bundle,sourceCommit:record.sourceCommit,index:hash}));
