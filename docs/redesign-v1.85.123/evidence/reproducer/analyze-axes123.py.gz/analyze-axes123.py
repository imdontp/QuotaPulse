import json, math
from pathlib import Path
from PIL import Image,ImageChops
before=Path('tmp/fidelity123');after=Path('tmp/axes123/after')
old=json.loads((before/'verification.json').read_text(encoding='utf-8'));new=json.loads((after/'verification.json').read_text(encoding='utf-8'))
assert old['rendererArgs']==new['rendererArgs']==[]
def diff(a,b):
    c=ImageChops.difference(a,b).split();d=ImageChops.lighter(ImageChops.lighter(c[0],c[1]),c[2]);h=d.histogram()
    return dict(changedPixels=sum(h[1:]),maxChannelDelta=max((i for i,n in enumerate(h) if n),default=0),bounds=d.getbbox())
rows=[]
for prior,current in zip(old['results'],new['results']):
    route=current['route'];assert route==prior['route'];assert prior['viewport']==current['viewport'];assert prior['referenceSha256']==current['referenceSha256'];assert current['repeatIdentical']
    a=Image.open(before/(route+'.png')).convert('RGB');b=Image.open(after/(route+'.png')).convert('RGB');assert a.size==b.size
    plots=json.loads((after/(route+'-plots.json')).read_text(encoding='utf-8'))
    plot_diffs=[]
    for plot in plots:
        r=plot['rect'];box=(math.floor(r['x']),math.floor(r['y']),math.ceil(r['right']),math.ceil(r['bottom']))
        plot_diffs.append(dict(rect=r,points=len(plot['points']),**diff(a.crop(box),b.crop(box))))
    rows.append(dict(route=route,viewport=current['viewport'],allPageGeometryIdentical=prior['geometry']==current['geometry'],plots=plot_diffs,**diff(a,b)))
report=dict(beforeIndex=old['productionIndexSha256'],afterIndex=new['productionIndexSha256'],rendererArgs=[],routes=rows,allPageGeometryIdentical=all(r['allPageGeometryIdentical'] for r in rows),allInteractivePlotsExact=all(p['changedPixels']==0 for r in rows for p in r['plots']),scope='Inactive before/after app states at original dimensions; pixel changes retained, not a concept parity score')
Path('tmp/axes123/analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
