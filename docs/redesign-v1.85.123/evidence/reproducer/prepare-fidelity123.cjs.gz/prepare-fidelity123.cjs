const fs=require('node:fs');
let s=fs.readFileSync('tmp/capture-matrix114.mts','utf8');
s=s.replace("'tmp/matrix114/'+(process.env.QUOTAPULSE_MATRIX_PHASE??'after')","'tmp/fidelity123'");
s=s.replace("if(process.env.QUOTAPULSE_MATRIX_PHASE==='before'&&routeName!=='live')continue;",'');
s=s.replace("const rendererArgs = ['--disable-gpu', '--deterministic-mode', '--disable-skia-runtime-opts', '--force-color-profile=srgb'];",'const rendererArgs: string[] = [];');
fs.writeFileSync('tmp/capture-fidelity123.mts',s);
