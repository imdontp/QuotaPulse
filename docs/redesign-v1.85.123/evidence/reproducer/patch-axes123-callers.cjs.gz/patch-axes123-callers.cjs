const fs=require('node:fs'),assert=require('node:assert/strict');
for(const [file,old,next] of [
 ['packages/web/src/redesign/projects.tsx','<ObservedTrendAxes className="qp-project-trend"','<ObservedTrendAxes valueLabel={t(\'redesign.tokens\')} className="qp-project-trend"'],
 ['packages/web/src/redesign/models.tsx','<ObservedTrendAxes className="qp-model-trend"','<ObservedTrendAxes valueLabel={t(route.metric === \'calls\' ? \'redesign.modelsCalls\' : \'redesign.modelsTokens\')} className="qp-model-trend"'],
]) {const original=fs.readFileSync(file,'utf8');assert.equal(original.split(old).length,2,file);fs.writeFileSync(file,original.replace(old,next));}
