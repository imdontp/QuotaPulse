const fs=require('node:fs');
const canonical=fs.readFileSync('tmp/capture-fidelity123.mts','utf8');
let prefix=canonical.slice(0,canonical.indexOf('let browser:'));
prefix=prefix.replace("'tmp/fidelity123'","'tmp/axes123/native'");
prefix=prefix.replace("import assert from 'node:assert/strict';", "import assert from 'node:assert/strict';\nimport { checkTrendInspection } from '../scripts/check-trend-inspection.mjs';\nimport { en } from '../packages/web/src/i18n/en.js';\nimport { th } from '../packages/web/src/i18n/th.js';");
const body=`
let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const indexPath=resolve(root,'packages/web/dist/index.html'),index=sha(readFileSync(indexPath));
const results:unknown[]=[];
try {
  await daemon.listen({host:'127.0.0.1',port:7816});
  browser=await chromium.launch({channel:'chrome',headless:true});
  for(const routeName of ['projects','models']) for(const lang of ['en','th']) for(const theme of ['dark','light']) for(const width of [390,1672]) {
    const name=[routeName,lang,theme,width].join('-');
    if(process.env.QP_TREND_CASE && process.env.QP_TREND_CASE!==name)continue;
    const context=await browser.newContext({viewport:{width,height:941},reducedMotion:'reduce',deviceScaleFactor:1,timezoneId:'Asia/Bangkok',colorScheme:theme as 'dark'|'light'});
    const page=await context.newPage();page.setDefaultTimeout(15000);
    const errors:string[]=[],forbidden:string[]=[],pending=new Set<Request>(),reads:Array<Promise<{url:string;body:any}>>=[];
    page.on('pageerror',error=>errors.push(error.message));
    page.on('response',response=>{const url=new URL(response.url());if(url.pathname==='/api/'+(routeName==='models'?'model':'project')+'-detail'&&response.status()===200)reads.push(response.json().then(body=>({url:url.pathname+url.search,body})));});
    page.on('request',request=>{if(new URL(request.url()).pathname.startsWith('/api/')&&!request.url().includes('/events/stream'))pending.add(request)});
    page.on('requestfinished',request=>pending.delete(request));page.on('requestfailed',request=>pending.delete(request));
    await page.route('**/*',route=>{const request=route.request(),url=new URL(request.url());const readPost=request.method()==='POST'&&url.pathname==='/api/model-row-trends';if(url.origin!=='http://127.0.0.1:7816'||url.pathname.startsWith('/api/')&&request.method()!=='GET'&&!readPost){forbidden.push(request.method()+' '+url.pathname);return route.abort()}return route.continue()});
    await page.addInitScript(({lang,theme})=>{(window as unknown as {__QUOTAPULSE_TOKEN__:string}).__QUOTAPULSE_TOKEN__='stable-capture-test';localStorage.setItem('quotapulse-prefs',JSON.stringify({lang,currency:'USD',rate:1,hiddenSubscriptions:[]}));localStorage.setItem('quotapulse-theme',theme)},{lang,theme});
    await installBrowserFixedDate(page,fixedNow);
    const settle=async()=>{let idle=0;const end=performance.now()+30000;while(idle<8){assert.ok(performance.now()<end);await page.waitForTimeout(40);idle=pending.size===0?idle+1:0}await Promise.all(reads)};
    await page.goto('http://127.0.0.1:7816/#'+routeName,{waitUntil:'domcontentloaded'});
    await page.locator('.qp-observed-trend-axes').waitFor();await page.evaluate(()=>document.fonts.ready);await settle();
    const inspectApi=async(metric:string)=>{
      const read=(await Promise.all(reads)).at(-1);assert.ok(read);
      const response=await daemon.inject({method:'GET',url:read.url,headers:{'x-quotapulse-token':'stable-capture-test'}});assert.equal(response.statusCode,200);const data=response.json();assert.deepEqual(data,read.body);
      const expected=Array.from({length:Math.ceil((data.scope.to-data.scope.from)/data.bucketMs)},(_,index)=>{const at=data.scope.from+index*data.bucketMs;return{at,value:data.points.find((point:any)=>point.start===at)?.[metric]??0}});
      const copy=lang==='th'?th:en;
      const unit=routeName==='projects'?copy['redesign.tokens']:copy[metric==='calls'?'redesign.modelsCalls':'redesign.modelsTokens'];
      return {api:read.url,metric,...await checkTrendInspection(page,expected,unit)};
    };
    const checks=[await inspectApi('tokens')];
    if(routeName==='models'){
      const svg=page.locator('.qp-observed-trend-axes>svg');await svg.focus();await page.keyboard.press('Home');
      const old=await page.locator('.qp-observed-trend-axes').getAttribute('data-trend-scope');
      await page.locator('.qp-model-toolbar select').last().selectOption('calls');await settle();await page.locator('.qp-observed-trend-axes').waitFor();
      assert.notEqual(await page.locator('.qp-observed-trend-axes').getAttribute('data-trend-scope'),old);
      assert.equal(await page.locator('.qp-trend-inspection-tooltip').count(),0,'Metric changes dismiss old token quantity');
      checks.push(await inspectApi('calls'));
    }
    await page.locator('.qp-observed-trend-axes>svg').focus();await page.keyboard.press('End');
    await page.screenshot({path:resolve(output,name+'-tooltip.png'),animations:'disabled'});
    assert.deepEqual(errors,[]);assert.deepEqual(forbidden,[]);
    const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);assert.equal(overflow,false);
    results.push({name,route:routeName,lang,theme,viewport:{width,height:941},checks,errors,forbidden,overflow});
    console.log('Passed '+name+' '+checks.length+' scoped checks');await context.close();
  }
  assert.equal(sha(readFileSync(indexPath)),index);
  writeFileSync(resolve(output,'verification.json'),JSON.stringify({status:'passed',index,browser:browser.version(),rendererArgs:[],results},null,2));
}finally{await browser?.close();await daemon.close();db.close();globalThis.Date=realDate;process.env.TZ=priorTimezone}
`;
fs.writeFileSync('tmp/check-axes123.mts',prefix+body);
let capture=canonical.replace("'tmp/fidelity123'","'tmp/axes123/after'");
capture=capture.replace('  for (const [routeName, readySelector] of Object.entries(targets)) {',`  for (const [routeName, readySelector] of Object.entries(targets)) {`);
capture=capture.replace('    const first = await page.screenshot',`    const plots=await page.locator('.qp-observed-trend-axes>svg').evaluateAll(nodes=>nodes.map(node=>({rect:node.getBoundingClientRect().toJSON(),label:node.getAttribute('aria-label'),points:Array.from(node.querySelectorAll('circle[data-at]')).map(point=>({at:point.getAttribute('data-at'),value:point.getAttribute('data-value'),cx:point.getAttribute('cx'),cy:point.getAttribute('cy')})),lines:Array.from(node.querySelectorAll('polygon,polyline')).map(line=>line.getAttribute('points'))})));
    writeFileSync(resolve(output,routeName+'-plots.json'),JSON.stringify(plots,null,2));
    const first = await page.screenshot`);
fs.writeFileSync('tmp/capture-axes123.mts',capture);
