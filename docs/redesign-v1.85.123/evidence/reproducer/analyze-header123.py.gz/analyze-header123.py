import json
from pathlib import Path
from PIL import Image,ImageChops
root=Path('tmp/header123')
manifest=json.loads((root/'reports.json').read_text(encoding='utf-8'))
def delta(a,b):
    a=Image.open(root/(a+'.png')).convert('RGB');b=Image.open(root/(b+'.png')).convert('RGB')
    c=ImageChops.difference(a,b).split();d=ImageChops.lighter(ImageChops.lighter(c[0],c[1]),c[2]);h=d.histogram()
    header=d.crop((0,0,a.width,60));hh=header.histogram()
    return dict(changedPixels=sum(h[1:]),headerPixels=sum(hh[1:]),maxChannelDelta=max((i for i,n in enumerate(h) if n),default=0),bounds=d.getbbox())
results=[]
for condition in ['control','layer']:
    for first,second in [(0,1),(0,2),(1,2)]:results.append(dict(pair=[f'{condition}-{first}',f'{condition}-{second}'],**delta(f'{condition}-{first}',f'{condition}-{second}')))
results.append(dict(pair=['control-0','layer-0'],**delta('control-0','layer-0')))
geometry=True;paint=True;transforms=[]
base=manifest['reports'][0]['paint']
for report in manifest['reports'][1:]:
    assert len(base)==len(report['paint'])
    for old,new in zip(base,report['paint']):
        geometry &= old['rect']==new['rect']
        if old['transform']!=new['transform']:transforms.append(dict(name=report['name'],classes=new['classes'],before=old['transform'],after=new['transform']))
        paint &= {k:v for k,v in old.items() if k!='transform'}=={k:v for k,v in new.items() if k!='transform'}
result=dict(pairs=results,allHeaderGeometryIdentical=geometry,allNonTransformPaintFactsIdentical=paint,transformChanges=transforms,immediateExact=[r['exact'] for r in manifest['reports']],index=manifest['index'])
(root/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
