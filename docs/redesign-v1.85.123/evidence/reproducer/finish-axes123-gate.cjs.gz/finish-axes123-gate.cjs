const fs=require('node:fs'),assert=require('node:assert/strict');
const p='scripts/check-stable-captures.mts',s=fs.readFileSync(p,'utf8');
const target='modelCostChecks, quotaChecks';assert.equal(s.split(target).length,2);
fs.writeFileSync(p,s.replace(target,'modelCostChecks, trendInspectionChecks, quotaChecks'));
