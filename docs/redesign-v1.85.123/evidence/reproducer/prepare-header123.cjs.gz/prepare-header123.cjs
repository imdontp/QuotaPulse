const fs=require('node:fs');
const capture=fs.readFileSync('tmp/capture-history122.mts','utf8');
let prefix=capture.slice(0,capture.indexOf('let browser:'));
prefix=prefix.replace("'tmp/history122/'+(process.env.QUOTAPULSE_HISTORY_PHASE??'after')", "'tmp/header123'");
const body=`
let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;
const sha = (bytes:Buffer) => createHash('sha256').update(bytes).digest('hex');
const indexPath=resolve(root,'packages/web/dist/index.html');
const index=sha(readFileSync(indexPath));
const rendererArgs=['--disable-gpu','--deterministic-mode','--disable-skia-runtime-opts','--force-color-profile=srgb'];
const reports:unknown[]=[];
try {
  await daemon.listen({host:'127.0.0.1',port:7816});
  for(const condition of ['control','layer'])for(const pass of [0,1,2]) {
    browser=await chromium.launch({channel:'chrome',headless:true,args:rendererArgs});
    const page=await browser.newPage({viewport:{width:1672,height:941},reducedMotion:'reduce',deviceScaleFactor:1,timezoneId:'Asia/Bangkok'});
    const errors:string[]=[],forbidden:string[]=[],pending=new Set<Request>();
    page.on('pageerror',error=>errors.push(error.message));
    page.on('request',request=>{if(new URL(request.url()).pathname.startsWith('/api/')&&!request.url().includes('/events/stream'))pending.add(request)});
    page.on('requestfinished',request=>pending.delete(request)); page.on('requestfailed',request=>pending.delete(request));
    await page.route('**/*',route=>{const request=route.request(),url=new URL(request.url());if(url.origin!=='http://127.0.0.1:7816'||url.pathname.startsWith('/api/')&&request.method()!=='GET'){forbidden.push(request.method()+' '+url.pathname);return route.abort()}return route.continue()});
    await page.addInitScript(()=>{
      (window as unknown as {__QUOTAPULSE_TOKEN__:string}).__QUOTAPULSE_TOKEN__='stable-capture-test';
      localStorage.setItem('quotapulse-prefs',JSON.stringify({lang:'en',currency:'USD',rate:1,hiddenSubscriptions:[]}));localStorage.setItem('quotapulse-theme','dark');
    });
    await installBrowserFixedDate(page,fixedNow);
    await page.goto('http://127.0.0.1:7816/#history',{waitUntil:'domcontentloaded'});
    await page.locator('[data-history-detail-rail]').waitFor();await page.evaluate(()=>document.fonts.ready);
    let idle=0;const deadline=performance.now()+30000;
    while(idle<12){assert.ok(performance.now()<deadline);await page.waitForTimeout(40);idle=pending.size===0?idle+1:0}
    if(condition==='layer')await page.addStyleTag({content:'.qp-daemon-badge{transform:translateZ(0)} .qp-topbar-actions>button[aria-haspopup=dialog]{transform:translateY(-.5px) translateZ(0)}'});
    await page.mouse.move(0,0);await page.waitForTimeout(150);
    const paint=await page.locator('.qp-topbar *').evaluateAll(nodes=>nodes.map(node=>{const c=getComputedStyle(node);return{tag:node.tagName,classes:node.getAttribute('class'),text:node.children.length?null:node.textContent,rect:node.getBoundingClientRect().toJSON(),color:c.color,font:c.font,background:c.background,border:c.border,shadow:c.boxShadow,filter:c.filter,transform:c.transform,opacity:c.opacity}}));
    const name=condition+'-'+pass;
    const first=await page.screenshot({path:resolve(output,name+'.png'),animations:'disabled'});
    await page.waitForTimeout(150);
    const repeat=await page.screenshot({path:resolve(output,name+'-repeat.png'),animations:'disabled'});
    assert.deepEqual(errors,[]);assert.deepEqual(forbidden,[]);
    reports.push({name,condition,pass,index,browser:browser.version(),paint,sha:sha(first),repeatSha:sha(repeat),exact:first.equals(repeat),errors,forbidden});
    console.log(name+' immediate exact='+first.equals(repeat));
    await page.close();await browser.close();browser=undefined;
  }
  assert.equal(sha(readFileSync(indexPath)),index);
  writeFileSync(resolve(output,'reports.json'),JSON.stringify({index,rendererArgs,reports},null,2));
}finally{await browser?.close();await daemon.close();db.close();globalThis.Date=realDate;process.env.TZ=priorTimezone}
`;
fs.writeFileSync('tmp/check-header123.mts',prefix+body);
