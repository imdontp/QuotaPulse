# 03 - Design, Interaction and Motion

## Visual foundation

Measure shell, gutters, panel grids, fonts, row/control heights, radii, borders, chart
padding and glow from each original PNG. Record a common shell measurement sheet at both
canonical widths; do not hardcode a different navigation per image. Keep navy/cyan/blue/
violet treatment. Use bundled Geist/Geist Mono and local existing icon assets. Both light
and dark themes use semantic tokens. Use tabular numerals and reserve width for live data.

Reuse `lib/motion.ts`, `index.css`, existing primitives, quota/pricing utilities and the
refresh controller. Extend their tokens instead of building a second motion vocabulary.
The globe-like core and graph require real SVG/canvas/DOM, not a screenshot overlay.
No new rendering library is assumed; prove the existing stack in the pilot.

## Shared actions

Every visible control has hover, focus-visible, pressed, selected, disabled-with-reason,
loading and recoverable-error behavior where applicable. Native buttons/links retain
keyboard semantics; drawers restore focus. Row selection and sort keys are stable.
Global search opens the command palette. Refresh calls one existing incremental ingest
pass, never a new full scan. Workspace and avatar are display-only, without fake menus.
Existing theme/language/currency settings remain available. Unknown controls are not
implemented speculatively; use the explicit overrides and screen action tables.

## Motion contract

| Element | Trigger and motion | Stop/fallback |
|---|---|---|
| Pulse Core | Selected quota is fresh/recent and page visible; 6s orbital loop; arc settles over 420ms | Stop when stale/idle/hidden/offscreen; reduced motion static arc and immediate readable value |
| Runtime Map | New observed call on a known edge; one 700ms particle/highlight | No idle particles; aggregate update uses one node highlight, not invented flow; reduced motion static highlight |
| Minute chart | New snapshot; update changed points over 180ms, stable axes | No whole-history replay; pause freezes snapshot; reduced motion immediate update |
| Runway | Valid new forecast; marker settles over 420ms | Reset replaces period, never backwards interpolation; stale freezes with label |
| Tables/detail | New record/selection; 180ms transition, 700ms one-shot emphasis | Stable identity; no loop; reduced motion no movement |
| Alerts | Newly derived risk or history record; one 180ms entrance | No endless warning flash; static labelled severity in reduced motion |

Use existing entrance/exit easing tokens. Durations above are milliseconds; adapt to the
animation library's actual units. Visibility and intersection checks stop nonessential
draw/timer work. Removing a section removes its listeners; SSE remains page-wide.

## Responsive and locale

Canonical parity is dark English at the manifest viewports, DPR 1. At 1200-1440 reduce
gutters and stack rails as necessary; below 1200 use the existing sidebar collapse pattern;
below 900 allow stacked content and horizontally scrolling tables inside their region.
No document-level horizontal overflow at 390/900/1280/1440. Preserve keyboard access and
readability in Thai and light theme. No raster concept asserts a Thai/light pixel target.
