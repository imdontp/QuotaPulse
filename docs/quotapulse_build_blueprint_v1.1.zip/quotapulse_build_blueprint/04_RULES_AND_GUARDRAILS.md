# 04 - Rules and Guardrails

- Use all eight original concepts plus the enumerated overrides. Preserve composition
  outside those regions; a revised baseline is not permission to redesign arbitrarily.
- Never hardcode production metrics, infer token quotas, average categorical effort,
  claim confirmed running/failed sessions from usage recency, or infer provider latency
  from collector timings. Call-grain and aggregate-grain records remain distinguishable.
- Store/display metadata only. No prompts, responses, code, arbitrary source JSON or
  credential values. Copy/export uses an allowlist. Foreign SQLite files stay read-only.
- Keep existing localhost binding and token authentication, including all new read APIs.
  Bound page/range inputs and parameterize filters. Do not make writes available via GET.
- Provider helpers alone own credentials; web forms never request provider API keys.
  No new external request on normal UI load; fonts/icons remain bundled. Existing
  explicitly invoked refresh-price behavior keeps its separate meaning.
- Daemon owns collection and persisted settings. Closing browser/tray does not stop it.
  Shared SSE and the existing coalescing/visibility/fallback controller stay authoritative.
- Advisory-only actions navigate to local detail/diagnostics. No workload pause, routing,
  provider switch, email, Slack or Discord delivery is introduced by this redesign.
- Keep `?mode=popup` and desktop pet settings compatible. No blanket deletion of PetPopup
  imports/styles/contracts under the assumption that all web code is dashboard-only.
- No new schema, dependency, framework or runtime instrumentation is needed by this
  specified v1 scope. Escalate a concrete contradiction with evidence rather than inventing
  a capability. Do not execute unrelated cleanup or change the existing live database.
- Read the field contract before static implementation. Only production-valid replacement
  fields appear in fixtures. Empty/stale/error/reduced-motion states belong in every slice.
- Accepted design decisions can proceed without requesting them again. New deviations
  require a concrete gap record and review; never silently downgrade a visual target.
