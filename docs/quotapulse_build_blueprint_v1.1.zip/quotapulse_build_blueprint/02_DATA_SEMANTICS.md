# 02 - Data Semantics

## Trust and grain

Separate harness, harness vendor, model vendor, routed provider, subscription owner and
pricing provider. A harness linked to an account does not prove every call used that
account. Runtime graph edges represent observed project/source/provider/model metadata;
subscription ownership is a separate labelled relation, never a fabricated routing hop.

Use `grain=call` for immutable per-call sources and `grain=session_aggregate` for the
existing Hermes running totals. Hermes totals overwrite stable rows and move their
last-observed timestamp. They cannot reconstruct individual call times or token delivery.
Their period totals mean aggregates last observed in the period, not all tokens generated
inside that period. Surface that caveat in every affected total/detail/export.
Unknown future adapters get `grain=unknown` until their temporal contract is established.

Charts below one hour use only call-grain events and say `Recorded tokens/min`.
Even these timestamps represent source record times, not token-by-token generation.
Show excluded aggregate/unknown source counts and observed amounts separately. Zero is
valid only inside a reporting scope; disconnected/unknown coverage is unavailable, not zero.

## Counts and activity

Calls = SUM(call_count), records = COUNT(event id), sessions = COUNT(DISTINCT session id).
Never add distinct session counts across model rows: a session may use several models.
Session activity is `last_seen_at` within the preceding 5 minutes, evaluated against server
`now`; future timestamps are unknown, not active. Label `Recent activity`, not `Running`.
Older observed sessions say `Last activity ...`; no timestamp says `Unknown activity`.
No queued/failed/completed runtime state is synthesized from silence or reader errors.

## Quota

Selected identity = subscription owner + window kind; apply existing reader selection,
freshness and two-second reset jitter rules. Show provider percentage/reset only where
published. Tokens consumed locally do not give the account's token cap.
Safe pace = max(0, 100 - used_percent) / hours_until_reset, in percentage points/hour.
It is unavailable for stale/expired/unknown readings or missing/nonfuture resets.
Current pace uses the same owner's/window's percentage-point forecast. Forecast needs
the existing minimum three samples spanning 15 minutes within one reset period.
Insufficient, flat, reset, stale and unknown are explicit; do not mix windows or origins.
Do not display a precise exhaustion time for a stale sample. Token/day is not quota/day.

## Monetary basis

Existing cost_usd can contain native, computed, estimated and unknown rows. Do not relabel
that mixed sum as wholly API-equivalent or billed spend. Preserve the legacy total for
compatibility, but new money panels expose separate `reported_native_usd` and
`api_value_usd` (computed + estimated), with calls/coverage by cost_source.
If a combined amount is shown, label `Recorded usage value (mixed basis)` and explain it.
Native means the harness reported it, not that an invoice verified it. Native rows lack
calculated price components/cache savings in the current sink; do not manufacture them.
Estimated-provider pricing stays estimated and names its reference pricing provider.
No calls => zero; all relevant calls unpriced => unavailable; partial => known value plus
coverage/`+`; truly priced zero => zero. Weight coverage by calls, not records.
Keep native and API-value chart series separate. Projected monthly API value extrapolates
only a complete, fresh, call-grain calendar-month-to-date API-value series with at least
one full elapsed local day. Otherwise show unavailable with the reason, not a forecast of
billed spend. Do not offer quantified hypothetical model-switch savings or quality claims.

## Other metrics

Canonical tokens = fresh input + cached input + cache creation + output. Reasoning is a
subset of output and is never added twice. Cache read proportion uses cached input divided
by all input components; no input means unavailable. Cache monetary savings need priced
cache components and disclose coverage. Effort is categorical, never an invented 1-5 score.
Context capacity uses an exact provider/model catalog value with provenance; observed
request context windows are separately labelled. Missing context/speed/latency is unknown.
Source reader health is not provider service availability or latency.

All range reads use `[from,to)` in epoch milliseconds and one resolved scope. Existing
timezone behavior is retained; charts, totals and exports cannot silently choose different
boundaries. Null project is a distinct unassigned bucket, not the literal project name
`(none)`. Unknown provider/model remain distinct from genuine strings with those labels.

See [API contract](12_API_AND_FIELD_CONTRACTS.md) for availability and additive work.
