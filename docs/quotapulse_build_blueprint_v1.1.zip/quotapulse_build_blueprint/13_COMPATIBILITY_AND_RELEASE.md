# 13 - Compatibility and Release

## Hash migration

| Incoming hash | Destination |
|---|---|
| Empty/unknown | #overview |
| #usage (summary/default) | #overview |
| #usage?view=cost/projects/models | #cost / #projects / #models |
| #sessions | #history |
| #sources | #providers |
| #limits | #providers?section=quotas |
| #health | #settings?section=diagnostics |
| #today | #overview?range=today |
| #trend | #overview?range=month |
| #live, #alerts, #settings | unchanged |
| #projects, #models, #cost | canonical new routes; retain prior default range when absent (month/month/all) |

Preserve valid range/from/to/bucket/source parameters and selected entity keys. `source`
is the existing URL key; translate to source_id only at API binding. For legacy aliases,
explicit valid query values override alias defaults. Consume legacy view, preserve other
supported filters and use replaceState on canonicalization to avoid back-button loops.
Update existing callers and command palette. Diagnostics and quotas remain directly
reachable even though their old top-level navigation moves.

## Electron and preferences

`?mode=popup` selects the existing compact PetPopup before hash routing. Keep its styles,
preload/IPC expectations, hidden-subscription behavior and settings endpoints. Electron
dashboard #live remains functional; browser default can be Overview independently.
No desktop pet retirement or deletion of pet_enabled/tray_animation_enabled is included.
Retain language, theme, currency/rate, window size, notification/snooze/quiet-hour and
hidden-subscription settings. Static preview fixtures do not update persisted settings.
Keep English/Thai and light/dark functionality, including date/number formatting.

## Deployment/recovery

This release uses additive reads and no schema migration. Keep existing endpoint defaults
for the old web/tray. A previous application checkout plus its matching built assets is
the rollback unit; do not delete/reprice/reset the user's database. Build in the isolated
worktree before any separately authorized launch/task change. Document the exact app
commit/artifacts being installed; blueprint tags are never deployment targets.
Use fixture databases for tests; no scheduled-task replacement, daemon restart, provider
account probe or real-data migration is part of blueprint/foundation work.

## Release evidence

Record original image hashes, blueprint/fixture version, approved implementation baseline
paths, capture browser/OS/DPR/locale/timezone, commands, screenshots and open execution
gaps. Current package baseline tests are historical evidence from 2026-09-29 at c2b622e,
not a certification of future code. Baseline build emitted a >500kB chunk warning; profile
new work and consider page-level splitting based on measurements. No performance target
or visual parity score has been measured for the proposed redesign yet.
