# 08 - Definition of Done

## Blueprint release

- All original documents are reconciled; referenced overrides and API requirements agree.
- All eight original PNGs preserve hashes/dimensions; manifest distinguishes concepts from
  not-yet-created implementation baselines.
- Relative links resolve in the ZIP; JSON and arithmetic fixture validate.
- Source baseline and prior test evidence are dated; new implementation remains PLANNED.
- Final ZIP is reopened, checked and delivered with a SHA-256 and change summary.

## Application screen (future implementation)

- Its exact concept and overrides are identified; common shell and measured geometry match.
- Every visible value/action has a source, scope, transform, state fallback and phase.
- No fixture data remains in production; unknowns, aggregate grain, partial pricing and
  reported native amounts are honestly labelled; totals reconcile for the same scope.
- Every visible control follows the explicit action table; no placebo menus or switches.
- Auth, privacy allowlist and local-network boundaries are preserved.
- Keyboard/focus, both themes/languages, narrow viewports, hidden tab and reduced motion pass.
- Existing refresh/SSE/popup/route compatibility is preserved and tested.
- The initial real screenshot is reviewed against concept + overrides before becoming a
  baseline. Subsequent SSIM/regional regressions pass; no unexplained baseline replacement.
- Relevant build/unit/API/browser/visual checks pass, and performance evidence is recorded.
- Gap ledger includes execution evidence; ACCEPTED decisions alone are not completion.

## Application RC

All v1 screens and NEW_READ work verified; prior-client behavior, desktop popup and rollback
tested; future items remain visibly outside release scope. Reference, fixture, environment,
commit, tests and artifact hashes accompany the checkpoint. A blueprint tag or green old
baseline never certifies an application RC or production readiness.
