# QuotaPulse Build Blueprint v1.1

Status: revised build specification; application implementation has not started in this package.
Document release: `1.1.0`. Contract version: `2`. Application baseline: `0.1.0` at
`c2b622e4a16398680fe4a5d1fca60063f1331cd1`. A blueprint tag is not an application release.

This revision implements the repository review and the user's decision to retain all eight
original PNG concepts with explicit production overrides. It does not regenerate images.
Their SHA-256 hashes and dimensions are unchanged. No production screenshot baseline or
measured parity score exists yet. Do not report a new screen as built from this document.

## Read before building

1. [Master contract](00_MASTER_BUILD_CONTRACT.md)
2. [Reference overrides](11_REFERENCE_OVERRIDES.md)
3. [Data semantics](02_DATA_SEMANTICS.md) and [API/field contracts](12_API_AND_FIELD_CONTRACTS.md)
4. [Phases](01_IMPLEMENTATION_PHASES.md)
5. [Design and motion](03_DESIGN_SYSTEM_AND_MOTION.md)
6. The relevant `screens/*.md` contract
7. [Tests](05_TEST_AND_VISUAL_PARITY.md) and [compatibility/release](13_COMPATIBILITY_AND_RELEASE.md)
8. [Guardrails](04_RULES_AND_GUARDRAILS.md), [agent prompts](06_AGENT_PROMPTS.md),
   [gap ledger](07_GAP_LEDGER.md), [feature matrix](09_FEATURE_MATRIX.md),
   [workflow](10_BUILD_WORKFLOW.md), [Definition of Done](08_DEFINITION_OF_DONE.md)

## Authority

Data truth, privacy and local security come first. The revised screen/API contracts and
enumerated overrides determine production content and actions. Original images determine
composition and visual treatment outside those overrides. Once reviewed against both,
implementation screenshots become regression baselines; they do not replace the design
contract or excuse design drift. Motion and accessibility remain explicit requirements.

## Reference set

| Screen | Concept | CSS viewport, DPR 1 |
|---|---|---|
| Overview | [overview](refs/overview.png) | 1586 x 992 |
| Live | [live](refs/live.png) | 1672 x 941 |
| Projects | [projects](refs/projects.png) | 1672 x 941 |
| Providers | [providers](refs/providers.png) | 1672 x 941 |
| Models | [models](refs/models.png) | 1672 x 941 |
| Cost | [cost](refs/cost.png) | 1672 x 941 |
| History | [history](refs/history.png) | 1672 x 941 |
| Alerts | [alerts](refs/alerts.png) | 1672 x 941 |

## Scope

Build a local monitoring and advisory dashboard with React/TypeScript/Tailwind/Radix/Motion/
Recharts, consuming the existing Fastify/SQLite daemon and shared SSE. Preserve desktop
popup compatibility, both languages and themes. Add bounded read APIs where required.
Budgets, manual project creation, custom alert rules, quality benchmarks, external
notification channels, runtime instrumentation and workload control are future work.

READY means the required fields and scope already exist in an API. DERIVE means a specified
calculation over available data. NEW_READ means additive read API/query work over stored
facts. FUTURE means excluded from the first redesign release. A decision marked ACCEPTED
is not an implemented or tested feature.

See [changes](CHANGELOG.md), [verification](VALIDATION.md),
[evidence](evidence/verification.json), and the arithmetic [fixture](fixtures/redesign-fixture.json).
The fixture is seed data for implementation tests, not a mock production API or a claim
that providers expose the illustrative quota readings.
