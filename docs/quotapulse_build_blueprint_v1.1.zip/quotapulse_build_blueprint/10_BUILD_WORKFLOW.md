# 10 - Build Workflow

## Git isolation

Baseline commit: `c2b622e4a16398680fe4a5d1fca60063f1331cd1`.
Documentation branch: `design/blueprint-v1.1` in a dedicated worktree.
Documentation tag: `blueprint-v1.1.0` on the validated documentation commit.
Use the existing QuotaPulse origin as the user selected; publish only this branch and
explicit new tags. Never change origin, force-push, push all refs, merge the old branch,
or alter unrelated working-tree files. Worktrees share Git objects/remotes/tags; isolation
means separate checkout/index/branch, not a physically independent origin repository.

Future implementation uses phase branches from this documentation checkpoint. Keep
documentation-version tags distinct from application release versions. No application
version bump is included in this package. Phase branches/checkpoints follow the phases
table; merge/deploy remains a separate explicit action.

## Per-slice loop

1. Read contracts and the real source; confirm all data dependencies before layout.
2. Inspect original concept and matching overrides; measure affected regions.
3. Extend shared primitives and a deterministic fixture adapter.
4. Build/capture the static slice and fix regional geometry/type/color differences.
5. Review the concrete image against concept + overrides; record first baseline.
6. Bind tested real reads, actions, state variants and shared refresh.
7. Add bounded motion and keyboard behavior from the shared contract.
8. Run relevant semantic/API/browser/visual checks and compatibility checks.
9. Inspect diff, record actual evidence and update execution statuses.

## Review gates

Gate A: measured pilot/static screenshot with concrete overrides visible.
Gate B: reconciliation, grain, money, quota and privacy demonstrated on fixture data.
Gate C: actual interactions, motion, reduced motion and compatibility demonstrated.
Gate D: full RC evidence and recovery procedure. Do not request reapproval of already
accepted semantic substitutions; present only genuinely new deviations for a decision.

## Fixture and artifact policy

Use the included arithmetic fixture to seed the implementation fixture adapter; complete
loading/error/long-name/inactive variants in Phase 1. These records never enter the live
database. Freeze the clock and scope for captures; concept sample values are not facts.
The original concepts stay immutable. Keep implementation baseline paths and approvals
separate in the manifest. Store actual/diff images, measurements and capture environment
with each phase, outside production bundles.

Each checkpoint records application commit, blueprint version, original reference hashes,
fixture version, actual commands/results, screenshot approval/diff and remaining execution
gaps. Example statuses must not masquerade as a real parity score or completed test run.
