# Blueprint 1.1.0 Change Log - 2026-09-29

- Kept original eight PNGs byte-for-byte; contract version 2 separates concept references
  from future approved implementation baselines and replaces contradictory whole-PNG gates.
- Added 23 explicit reference overrides, a common nine-destination navigation and consistent
  arithmetic fixtures; no duplicated false concept totals or fabricated product features.
- Added source-backed API/field contracts, grain/coverage handling, bounded minute reads,
  metadata event paging/filters/export, distinct counts, provider identity and quota history.
- Corrected native/computed/estimated money semantics and missing native cache components.
- Locked monitoring/advisory v1 scope. Future budgets, custom rules, benchmarks, runtime
  instrumentation, remote notifications and mitigation are explicitly deferred.
- Preserved Electron popup, hash/filter migrations, settings, languages/themes and narrow UI.
- Moved semantic checks before static layout and accessibility/reduced motion to foundation;
  added the Shell/Pulse Core/Runtime Map pilot before broad screen implementation.
- Rewrote all original documents and prompts consistently. Separated accepted decisions
  from implementation/test status; no application feature is marked complete by this ZIP.
- Recorded previous baseline tests and new archive checks separately. No app version bump,
  daemon restart, live database access, dependency install or original-branch edit.
