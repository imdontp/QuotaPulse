# 12 - API and Field Contracts

Baseline inspection: c2b622e. This document specifies future additive reads; none of these
extensions is implemented by publishing the blueprint. Existing endpoints retain defaults.

## Availability verified in source

| Contract | Existing fact | Required extension |
|---|---|---|
| overview/limits | Account ownership, windows, percentages, freshness, forecast, source status | Reuse reader-selection and freshness logic |
| trend | Hour/day/week/month buckets; one grouping and optional source | Minute for call grain; shared filters and exclusion coverage |
| projects | Project/source/vendor/model usage totals | Distinct scoped session counts, nullable project identity, routed provider |
| models | Model/harness/effort/vendor totals | Provider-aware detailed grouping, distinct counts and context provenance |
| sessions | Range/source/vendor filtering, limit/offset | Project/model/harness/provider/search filters and activity counts |
| session detail | First 2000 events, no complete event pagination | Use new usage-events read for paginated records |
| export/usage | Allowlisted CSV, range/source filter | Same shared filters/grain and ordering semantics as History |
| alerts | Threshold history, fixed 50/80/95, delivery timestamp | Reuse; current advisory risks derived separately |
| health | Collector/readers, coverage, errors | Label reader diagnostics, not provider service latency |
| settings/notifications | Shared persisted settings and notification control | Reuse unchanged |
| events/stream | Invalidation signal with counts/time, not usage payload | Reuse one page-wide stream unchanged |

Source anchors: `packages/daemon/src/api/server.ts` (trend 339, sessions 426, stream 474),
`api/queries.ts` (models 1241, projects 1377, detail 1494, forecast 1532),
`adapters/hermes.ts` (124), `ingest/sink.ts` (267), `db/schema.ts` (context_window),
`pricing/loader.ts` (catalog context). Lines refer to the baseline, not future edits.

## Shared query scope

Use from/to epoch ms with `[from,to)`, source_id, project (exact metadata value),
project_missing=1, harness, provider, vendor, model, q (metadata substring), and grain
(all/call/session_aggregate/unknown). Missing-project selection is exclusive with project.
Use parameterized SQL; literal q does not interpret SQL wildcards. Match q against project,
model, native session id and source display name. Provider is the recorded route; vendor
is the model maker. Keep their filters separate. New filters are optional and old calls
keep their meaning. Metadata displays use source strings as text, never executable HTML.
Validate integer ranges, limits and enum values; unknown/malformed supplied values return
400. Reads retain the existing token authentication and local-only boundaries.

## New GET /api/usage-events

Query: shared scope, limit default 50/max 500, offset default 0; sort is ts DESC, id DESC.
Return rows, total record count, limit, offset, resolved scope and server now. Each row
uses the existing export allowlist: event_id, timestamp_ms, call_count, source identity,
project/session key, harness, provider/vendor/model, effort/service tier, token components,
cost_source/cost_usd/price_provider and duration_ms, plus grain. No prompt/response/raw JSON,
credential paths or external URLs are included. Identifier and grain are stable on refresh.
Hermes (existing aggregate adapter) is session_aggregate; current immutable call adapters
are call. New adapters are unknown until explicitly declared. No schema migration is needed.
Use a single DB read snapshot for count/rows; offset pages reflect the current dataset,
not a promised immutable historical snapshot. Pause keeps the currently rendered snapshot;
resume refreshes page zero. A changed aggregate replaces its row, not a new event arrival.

## Trend and quota history

Extend UsageBucket with minute in the trend API/client type. Minute ranges are at most 24h,
default Live range 30min, epoch-aligned 60s buckets. Query only call-grain events; return
coverage listing excluded sources, record/call counts and aggregate amounts last observed
in the requested range. Do not silently exclude them from page totals. Existing larger
buckets retain aggregate semantics with their explicit temporal caveat. Minute chart
labels state Recorded tokens/min; API records are not token transport instrumentation.

New GET /api/quota-history takes subscription_key, window_kind, from/to (max 90 days).
Return selected-reader identity/origin, ordered timestamp/used_percent/reset samples and
freshness/forecast status. Apply the same authoritative reader selection as current limits.
Do not concatenate multiple readers into fake burn. Keep reset periods as discontinuous
segments; no line across rollover. Historical samples mean observed provider values, not
interpolated daily/project token quota. Unknown selection returns an empty unavailable
result. Multiple subscription windows are never averaged into a global risk percentage.

## Additive aggregates and pricing

Projects/models: add an opt-in detailed mode so old row cardinality remains unchanged.
Detailed results retain source/provider/model identity and return separate distinct
session counts at project/model/page scope. Count distinct session ids in SQL, not sums
of already-grouped counts. Same model through two providers remains distinguishable.
Project identity is its stored full metadata string plus explicit null, not basename alone.

Expose monetary summary for each requested scope with reported_native_usd, api_value_usd,
native_calls, computed_calls, estimated_calls, unknown_calls and cache_saving_known_calls.
Existing cost_usd remains compatible. Null sums are converted to display zero only under
the rules in Data Semantics. Cache saving coverage excludes native rows without calculated
components. Use exact provider/model catalog context with origin/date; expose observed
context_window separately, never guess a match from a model name alone.

## UI mapping

| UI field/action | Source and transform | Freshness/fallback | Phase |
|---|---|---|---|
| Core/rings/countdowns | limits + selected owner/window | Existing freshness; unavailable after expiry | 2 |
| Safe pace/runway | same selected limit/forecast; specified percent formula | Insufficient/stale/reset explicit | 2,8 |
| Period tokens/value | usage plus monetary summary, same range | Coverage and aggregate caveats | 1A,2,6 |
| Model share | detailed model tokens / scoped total tokens | No usage -> empty; unknown retained | 2,6 |
| Runtime edges | detailed project/source/provider/model rows | Last observed, not executing route | 1A,2 |
| Recent sessions | distinct sessions with valid last_seen within five minutes | Future/null -> unknown | 1A,3 |
| Reporting/stale/error cards | enabled sourceStatus telemetry and health errors; count source once per card | Categories may overlap, label clearly | 3 |
| Live chart/matrix | call-only minute trend by observed provider/model | Explicit excluded/unknown coverage | 1A,3 |
| Activity/history | usage-events rows; distinguish record count/calls | Aggregate updates replace stable row | 1A,3,7 |
| Project cards/detail | projects detailed, scoped counts, trend group_by=project | Unassigned bucket explicit | 1A,4 |
| Provider cards/Manage | subscriptions/limits; navigate settings diagnostics | No quota published != zero | 5 |
| Model details | detailed models, coverage, exact catalog/observed context | Missing context unknown; effort categorical | 1A,6 |
| Cost charts/breakdowns | basis-split summaries/trend under same filters | No invoice or quality equivalence claim | 1A,6 |
| History export/copy | export endpoint with identical filter set; allowlist | Whole matching range, not loaded page | 1A,7 |
| Risk history | quota-history for selected owner/window | Discontinuity at reset; freshness explicit | 1A,8 |
| Alerts/rules | current limit/source risks; separate retained alerts | No custom persistence/lifecycle engine | 8 |
| Notification switch | existing notification-settings PUT | Loading/disabled/retry; no collection change | 8 |
| Refresh/Pause | existing refresh; local snapshot freeze | Daemon/SSE remain running; resume latest | all |

Current advisory classification: fresh quota >=95% critical, >=80% warning; valid forecast
before reset critical; stale/unknown source informational. Deduplicate by risk kind,
owner/window (source for reader risks) and current reset period. Current cards disappear
when facts recover; recorded threshold history does not. Do not treat pending delivery as
an unresolved risk. Deterministic insights also expose cache proportion and model
concentration as descriptive metrics, without invented business value or quality advice.
