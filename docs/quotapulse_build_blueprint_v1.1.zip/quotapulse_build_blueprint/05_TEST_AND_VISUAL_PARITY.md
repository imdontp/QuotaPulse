# 05 - Test and Visual Parity

## Blueprint validation (this release)

Verify ZIP readability, required documents, valid JSON, relative document links, original
PNG hashes/dimensions, override coverage, feature-to-phase mapping, and arithmetic fixture
invariants. Reopen the final artifact. The validation report distinguishes prior baseline
tests from artifact checks run now. This does not run or claim tests for unimplemented APIs.

## Implementation acceptance

| Area | Required scenarios |
|---|---|
| Quota | Multiple readers for one owner; percent-only windows; missing reset; flat/insufficient; >=3 samples over >=15min; stale; rollover; 2000ms jitter boundary; selected-owner/window consistency |
| Grain | Hermes totals replace without duplication; moved timestamps; mixed call/aggregate data; unknown adapter; minute series excludes aggregates and reports exclusions; no claim of token streaming |
| Counts | Calls vs rows vs distinct sessions; one session across models/providers; null/unassigned project; no usage; missing last_seen; future clock skew; five-minute boundary |
| Money | Native-only with no calculated components; computed; estimated provider; wholly/partially unpriced; zero-cost priced row; no usage; call-weighted coverage; no mixed-basis forecast |
| Queries | Shared filters across lists/counts/totals/export; >2000 events; stable ordering for equal timestamps; max page/range validation; provider vs vendor; SQL metacharacters treated literally |
| Export/privacy | Allowlisted metadata only; CSV quoting/newlines/formula-leading text; no prompt/response/raw credentials; filtered export includes all matching rows, not just visible page |
| Alerts | Current risk clears after reset/recovery; history retained; fixed 50/80/95 threshold dedup; snooze/quiet hours suppress delivery not collection; no external action |
| Live/UI | One SSE connection; coalesced updates; reconnect; hidden tab; pause holds display while collection continues; resume fetches current snapshot without fake replay; cleanup on navigation |
| Compatibility | Old hash/view/source/range links, browser back/forward, Electron #live and ?mode=popup, hidden subscriptions, language/theme/currency and notifications |

Keep pure semantic calculations in unit tests and use isolated fixture DBs for query/API
tests. Preserve current tests unless a documented UI selector genuinely changes; retain
the behavior assertion when replacing selectors. Do not test the live provider accounts.

## Visual procedure

Use English, dark theme, DPR 1, exact viewport, fixed fixture clock/timezone and recorded
Chrome version. Wait for local fonts and stable layout. Capture the viewport, not an
arbitrarily tall full-page image; capture scroll content separately. Freeze ambient motion
at the documented static frame; test real motion separately. Use one measured common shell.
First compare visually and by measured regions against concepts + overrides. Review the
concrete result before saving the initial implementation baseline. Then enforce SSIM >=
0.985 against that baseline, plus region geometry and text/typography checks. Only named
truly dynamic values may be masked; do not mask charts/labels/cards to hide mismatches.
Baseline updates include reason, diff, reference/fixture version, reviewer and commit.
No score is supplied by this blueprint before such captures exist.

Run functional/overflow checks at 390/900/1280/1440 for en/th and light/dark, plus canonical
desktop screenshots for all eight screens. Verify visible focus, headings, semantics,
contrast, drawer focus restoration and reduced motion. Track both valid and error states.

## Performance and commands

Profile the pilot before adding all pages: initial render, query count, chart commits,
real animation paints and hidden/offscreen work. Hidden/offscreen nonessential canvas
paints must stop; navigation must not accumulate timers/SSE streams. Use query plans and
large fixture histories to identify actual indexing/virtualization needs. Record measured
CPU/render results; no unsupported numerical performance claim or arbitrary new library.

For each UI slice run `npm run build -w @quotapulse/web`, web unit tests and `npm run test:ui`.
Run daemon tests when changing read contracts and `npm test` at integration/RC checkpoints.
Add `npm run test:visual` during Phase 1; it does not exist in the baseline. Store
reference/actual/diff artifacts and capture environment alongside each phase result.
