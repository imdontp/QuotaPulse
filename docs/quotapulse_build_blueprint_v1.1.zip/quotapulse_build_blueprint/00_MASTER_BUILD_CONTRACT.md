# 00 - Master Build Contract

## Outcome

Deliver all eight concept compositions using real components, truthful data and functional
controls. Preserve the visual ambition of the concepts: dense navy panels, cyan/blue/violet
light, prominent quota core, diagrams, charts, tables and contextual detail rails.

Architecture stays:
`harness files/provider helpers -> collector -> SQLite -> Fastify REST + SSE -> React + Electron`.
The daemon owns state and collection. The dashboard never owns credentials or collection.

## Authority and measurable acceptance

1. Data truth, metadata-only privacy and local security.
2. [API/field contracts](12_API_AND_FIELD_CONTRACTS.md), screen contracts and the explicit
   [reference overrides](11_REFERENCE_OVERRIDES.md).
3. Original concept geometry, hierarchy and styling outside overridden regions.
4. Shared interaction/motion/accessibility contract.
5. Implementation convenience.

The original 99-100% ambition is a visual design objective, not a measured completion score.
Do not require whole-image SSIM against an original PNG whose contents this contract changes.
Measure unchanged major region geometry within 2 CSS px and repeated primitives within
1-2 CSS px of the Phase 1 measurement sheet. Revised regions use their approved measurements.
Original typography is visual guidance; Phase 1 locks concrete bundled font tokens.
SSIM >= 0.985 applies only to deterministic captures versus approved implementation
baselines, with regional geometry/text checks. Never silently replace a failing baseline.

## Navigation

Use hash navigation: `#overview`, `#live`, `#projects`, `#providers`, `#models`, `#cost`,
`#history`, `#alerts`, `#settings`. The same nine destinations appear on every page.
Overview is the browser default. Existing `#live` and Electron popup URLs remain supported.
Global search opens the existing command palette. Workspace is the noninteractive label
`This machine`; no account/team/workspace-switching backend is implied.

## Release scope

Deliver monitoring and deterministic advisory insight. Providers represent detected and
catalogued supported subscriptions/sources, not every logo in the concept. Keep inactive
supported subscriptions visible according to existing hidden-subscription preferences.
Keep desktop `?mode=popup`; remove pet-specific decoration only from the redesigned
dashboard. Keep diagnostics accessible through Settings and Providers.

No new database schema is required for this release. NEW_READ capabilities are additive
queries over existing facts; extend API types compatibly and preserve existing defaults.
No runtime execution, budget authoring, benchmark import, provider credential entry,
custom rule engine or external notification delivery belongs in this release.

## Build order inside a slice

Confirm data availability and overrides before static layout. Then use deterministic
fixtures to lock layout, review the concrete screenshot, bind APIs, implement actions,
cover data states, add motion and verify accessibility/performance. Prove Shell + Pulse
Core + Runtime Map before scaling the composition to eight pages. Reuse existing refresh,
pricing, quota, translation and motion utilities; do not create parallel systems.

Every data block reserves space for loading, fresh/recent, stale, expired, unavailable,
empty, partial pricing, estimated pricing and errors where applicable. Retain last good
data during transient errors with an explicit age/error label, never a live badge.
