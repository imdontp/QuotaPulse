# 11 - Reference Overrides

These accepted substitutions preserve the eight original PNGs. They supersede their
affected labels/data/actions and are mandatory in fixtures and production. Regions not
listed retain the original composition. Phase 1 measures the resulting shared layout.

| ID | Region | Production replacement and action |
|---|---|---|
| OVR-001 | Global sidebar | Same nine destinations on all screens; Settings below primary eight; no screen-specific disappearance of Providers or Cost |
| OVR-002 | Global workspace/search/avatar | Static This machine scope; search opens command palette; avatar/brand are display-only; keep theme/language/settings controls |
| OVR-003 | Global live/quick stats | Connection and source freshness labelled separately; counts derived from selected scope; no constant All systems operational |
| OVR-004 | Overview core/quota fractions | One selected owner/window, percentage and reset; no fake token cap; left tokens are separately labelled period usage |
| OVR-005 | Overview Value Created | Cache savings plus cache-read proportion and pricing coverage; no productive hours or ROI |
| OVR-006 | Overview map/insights | Observed project -> harness -> routed provider -> model edges; unknown provider remains unknown; rule-based insights, not AI-powered claims |
| OVR-007 | Overview/Alerts runway | Percentage-points/hour, valid forecast and reset; insufficient/stale fallback; no global quota or token-denominator inference |
| OVR-008 | Live metric cards | Recent sessions, Reporting sources, Stale sources, Reader errors (counts may overlap and are not a partition); no queued/failed session cards |
| OVR-009 | Live token charts/status matrix | Recorded call-grain tokens/min with exclusions; matrix is observed provider/model activity, not service health/latency |
| OVR-010 | Live activity/status | Usage records and aggregate updates; recent/last-observed labels; no fabricated start/queue/completion/error lifecycle events |
| OVR-011 | Projects header/tabs/cards | Refresh replaces New Project; All projects/Recent activity/Unassigned tabs and harness filter replace team/archive tabs; progress shows usage share, not budget |
| OVR-012 | Project detail | Metadata path replaces authored description; last observed replaces active duration; Settings tab becomes Details; no pin/archive/edit menus |
| OVR-013 | Providers actions/cards | Refresh status and Diagnostics; render supported detected/catalogued subscriptions only; original extra logos do not request new integrations |
| OVR-014 | Providers plan/health | Origin/freshness replaces unverified plan price/renewal; reader health/observed age replaces provider response latency; no daily window invented |
| OVR-015 | Models speed/quality/context | Calls replaces Avg Speed; Pricing coverage replaces Quality; sourced context or unavailable; contextual observed window stays distinct from capacity |
| OVR-016 | Models performance/description | Categorical effort distribution replaces benchmark bars; identity/provenance metadata replaces marketing capability claims |
| OVR-017 | Cost metric panels | Reported native cost and API value shown separately; combined amount explicitly Mixed basis; no invoice claim; historical known cache savings, no hypothetical dollar saving promises |
| OVR-018 | History detail | Event Summary, Token Breakdown, Pricing Source, Runtime Metadata and Related Session; safe metadata copy only; no Prompt/Response/raw source JSON |
| OVR-019 | History metrics/filter/status | Categorical effort distribution replaces numeric average; call/aggregate record kind replaces completed/failed; metadata search; CSV exports all matching records; no unsupported bulk action |
| OVR-020 | Alerts header/rules/actions | Notifications toggle controls existing settings; fixed 50/80/95 rules read-only; Add Rule absent; recommendations open local detail/diagnostics; no Switch/Apply/Enable/Pause execution |
| OVR-021 | Alerts counts/history/channels | Current risks distinct from retained threshold history; unavailable monitor data stays unknown; desktop notification channel only, requires running tray |
| OVR-022 | Data consistency | Fixture facts determine every total/count/share, replacing conflicting concept numbers; no effort score or time-series curve copied as factual data |
| OVR-023 | Desktop/themes | Dashboard pet decorations removed; Electron popup preserved; light/Thai/narrow states retain functionality with equivalent semantic tokens |

## Fixed unavailable behavior

Preserve a metric slot with `Unavailable` and a short reason when its valid source is
missing. Never populate it with zero, fabricated speed, benchmark, subscription denominator
or cost estimate. Remove excluded feature action controls as specified above; do not offer
a disabled fake product workflow. Existing refresh/settings remain actionable.

## Known concept inconsistencies

Models shows 721M overall while its 12 visible model rows sum to 797M. Projects shows an
All Projects count of five with six visible cards. Navigation varies by screenshot.
These are source-art inconsistencies, not regression targets. No mask is used to conceal
them; the production-valid fixture and common navigation explicitly replace them.

Every first implementation baseline records which overrides were applied. Later changes
need an updated override/version and concrete diff; a screenshot alone is not a contract.
