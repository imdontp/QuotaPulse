# 09 - Feature Matrix

| Feature | Screen | Availability at baseline | Delivery phase |
|---|---|---|---|
| Common shell/command palette/themes/i18n | all | READY primitives; new layout | 1 |
| Static capture and measured visual baseline | all | NEW harness | 1 |
| Selected quota, freshness, forecast | Overview/Providers/Alerts | READY + DERIVE gating | 2,5,8 |
| Safe pace | Overview/Alerts | DERIVE specified formula | 2,8 |
| Runtime metadata graph | Overview | DERIVE; provider refinement NEW_READ | 1A,2 |
| Cache savings with coverage | Overview/Cost | READY amounts; NEW_READ coverage | 1A,2,6 |
| Recent session/source metrics | Live | DERIVE; efficient scoped counts NEW_READ | 1A,3 |
| Recorded minute chart | Live | NEW_READ; excludes aggregates | 1A,3 |
| Usage record feed/table/search/export | Live/History | NEW_READ; existing export reused | 1A,3,7 |
| Project totals/model mix | Projects | READY; distinct counts/filter NEW_READ | 1A,4 |
| Subscription windows/reader diagnostics | Providers | READY; new layout | 5 |
| Model totals/effort | Models | READY; route identity/counts NEW_READ | 1A,6 |
| Catalog/observed context provenance | Models | Stored facts; NEW_READ exposure | 1A,6 |
| Monetary basis splits | Cost/all money | Stored cost_source; NEW_READ totals | 1A,6 |
| Threshold history/notifications | Alerts | READY fixed thresholds/settings | 8 |
| Current advisory risk list | Alerts | DERIVE deterministic rules | 8 |
| Quota sample history | Alerts | Stored samples; NEW_READ | 1A,8 |
| Legacy routes/Electron popup | compatibility | READY behavior to preserve | 1,9 |
| Reduced motion/accessibility | all | READY foundations to extend | 1 through 10 |
| Budgets/project authoring/workspace teams | future | FUTURE | excluded |
| Benchmarks/quality/runtime speed and lifecycle instrumentation | future | FUTURE | excluded |
| Custom alert rules/external notification channels/mitigation | future | FUTURE | excluded |

Availability describes current inputs, not whether the redesigned feature exists. No
NEW_READ feature becomes READY until its endpoint/type/query tests pass. UI-only
derivation is used only when inputs are complete for the requested scope; never fetch all
pages or perform one request per session merely to simulate an aggregate endpoint.
