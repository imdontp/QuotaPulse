# 06 - Agent Prompts

## Reference analysis

Read the master, reference overrides, data/API contracts, manifest and relevant screen.
Inspect the exact original PNG. Produce measured regions/tokens and an element mapping:
visual slot -> override ID -> meaning -> source -> transformation -> fallback -> action.
Use current source files to verify READY claims. Do not claim minute streaming, call-level
Hermes timestamps or runtime lifecycle states. No application changes in this step.

## Static slice

Implement <SCREEN> from its concept plus all assigned overrides. Bind deterministic
production-valid fixture semantics from the outset. Preserve unaffected geometry and
shared shell. Build real components using existing dependencies. Do not reproduce false
concept totals, provider caps, ROI, credentials forms or prompt panels. Capture exact
viewport after fonts settle, inspect regional differences and present the concrete pilot
or screen for baseline review. Do not claim a measured score against an original concept.

## Read API slice

Implement the named NEW_READ work in the API contract with isolated test DBs. Keep old
endpoints/default behavior compatible. Reuse normalized usage facts and the export
allowlist. Include grain, call_count, scope, coverage and identity information where
required. Test nulls, filtering, paging beyond 2000 records, duplicate timestamps,
aggregate replacement, native pricing and authentication. Do not add collector
instrumentation, a schema migration or a generic remote event bus.

## Data and interaction integration

Replace fixtures with real API bindings without changing approved geometry. Reuse shared
refresh/SSE. Every control must follow the screen action table, including pause/resume,
metadata-only search, filtered CSV export and diagnostics navigation. Display stale,
unavailable, partial and estimated states; no fabricated fills. Totals and detail use the
same resolved scope. Keep desktop popup and legacy routes operational.

## Motion

Use the existing shared tokens and the element motion table. Specify trigger, duration,
easing, cleanup, visibility/intersection and reduced-motion fallback. Animate only observed
events; an aggregate refresh does not imply a stream of calls. Verify actual frame counts
and stable chart axes, not merely requestAnimationFrame scheduling.

## Review and handoff

Run the relevant checks and report actual commands/results. Compare to concepts + overrides
for intent and to implementation baselines for regression. Update decision and execution
statuses independently in the gap ledger. Record commit, blueprint/reference/fixture
versions and artifacts. Preserve prior user work. Do not push to unrelated branches,
merge, deploy, delete a worktree or access a live DB as part of a documentation task.
Never mark future features implemented or count a prior baseline test as a new feature test.
