# 01 - Implementation Phases

Blueprint version 1.1.0 is independent of application version 0.1.0. Phases are checkpoints,
not automatic package-version bumps or deployment authorizations.

| Phase | Work and dependencies | Exit evidence |
|---|---|---|
| 0 Baseline | Isolated branch/worktree, original hashes, baseline tests, old route/settings inventory | Recorded commit, tests and recovery point |
| 0A Contracts | Apply all overrides; field mapping, grain, filters, money and quota scope | No unresolved v1 semantic choice; future items excluded |
| 1 Foundation/pilot | Measure all references, common shell, tokens, fixture adapter, screenshot harness; prove Pulse Core and Runtime Map | Concrete pilot screenshots and measurements; named visual review; profile at canonical and narrow viewports |
| 1A Read API foundation | Shared filters, usage-events, additive aggregates, minute trend and quota-history; authenticate/validate all reads | API tests for paging, scopes, aggregates, privacy and old-client defaults |
| 2 Overview | Selected quota core/runway, truthful metrics, observed usage graph, insights and recent records | Scope consistency and no fabricated quota denominator; screenshot baseline |
| 3 Live | Recent activity states, per-call minute chart, recorded metadata feed, source status; UI pause | Aggregate-source exclusion coverage; shared SSE, reconnect and resume tests |
| 4 Projects | Discovered project cards, query filters, distinct session counts, trend/detail | Totals reconcile across null projects, multiharness and multimodel sessions |
| 5 Providers | Existing subscriptions, supported windows, freshness, reader diagnostics | Correct shared-account ownership, inactive/hidden and no-quota cases |
| 6 Models/Cost | Provider-scoped model usage, context provenance, effort, separated monetary bases | Cross-provider and native/computed/estimated/unknown tests |
| 7 History | Paginated safe records, metadata drawer, filter-consistent CSV | >2000 records, aggregate updates, unknowns, escaping and filter/export parity |
| 8 Alerts | Current advisory risks, historical threshold events, notification settings and read-only thresholds | Current vs historical separation, rollover/jitter, suppression and popup compatibility |
| 9 Hardening | All themes/languages, responsive states, keyboard, motion/CPU, compatibility | Complete browser matrix and bounded update work |
| 10 RC | Final screenshot diffs, privacy/network, complete existing tests/build and rollback rehearsal | All v1 requirements implemented/tested; exceptions explicitly recorded |

Accessibility and reduced motion start in Phase 1; Phase 9 consolidates rather than
introducing them. NEW_READ for a slice must pass before that slice claims real-data
completion. No slice waits for a future rule engine, project budget or external integration.

The pilot reviews the hardest visual regions before broad implementation. Capture timings,
actual draw/frame counters and hidden-tab behavior. If fidelity or rendering cost requires
a change, document the concrete alternative and review it before extending other screens.
Do not lower the target or change assets silently to make a test pass.
