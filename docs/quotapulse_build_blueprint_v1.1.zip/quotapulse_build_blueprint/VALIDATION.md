# Validation Evidence

Documentation baseline: `c2b622e4a16398680fe4a5d1fca60063f1331cd1`, reviewed 2026-09-29.
Original ZIP SHA-256: `f907f9aea7d15fba63ccf7317609f8080472c2c9da89df555a7e0903d3e9d309`.

## Previous repository baseline (not rerun for this documentation release)

`npm test`, `npm run build -w @quotapulse/web`, and `npm run test:ui` passed in the preceding
review. Initial sandbox process-spawn failures were resolved by rerunning with the
required execution permissions. The web build had a large-chunk warning. These results
do not validate any proposed new API, screen, motion effect or screenshot parity.

## Archive validation at generation

The generation validator checks all 20 original Markdown documents are
reconciled, all required new documents exist, JSON parses, relative Markdown links resolve,
eight PNG dimensions and SHA-256 match the original manifest, baseline entries remain
not_created, and fixture tokens/calls/session counts/monetary bases reconcile. It reopens
the completed ZIP and verifies CRC/readability and original archive immutability.
See the outside release note for the final ZIP SHA-256 (not embedded recursively).

## Remaining implementation gates

All redesigned screens and additive APIs are PLANNED, not implemented by this package.
No production visual baseline, SSIM score or redesign performance result exists yet.
Run the documented slice tests, pilot capture/review and compatibility gates when building.
This document certifies package consistency only, not application production readiness.
