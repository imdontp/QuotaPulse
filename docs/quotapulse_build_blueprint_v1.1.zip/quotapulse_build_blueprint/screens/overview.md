# Screen Contract - Overview / Mission Control

Concept: [original image](../refs/overview.png), 1586 x 992, DPR 1.
Overrides: OVR-001..007, OVR-022..023; see [exact replacements](../11_REFERENCE_OVERRIDES.md).
Sources/field mappings: [API contract](../12_API_AND_FIELD_CONTRACTS.md).

## Composition, meaning and actions

Keep topbar/sidebar, central Pulse Core with left telemetry/top models, subscription rail,
Runtime Map, Runway, Insights and activity strip. Core selection is one owner/window.
Click quota selects that identity in core/runway; model click opens Models with model and
period; graph node opens scoped project/model detail; activity opens History by session.
Token totals use the selected usage range, independently labelled from quota window.
Native/API value are separate; cache savings disclose missing native components.
Runtime edges show observed usage. Animate only genuine new call records, not every edge
or every Hermes aggregate update. Display insufficient forecast, unknown project/provider,
no quota and stale cases in the same panel geometry. No selection defaults to a stale
or arbitrary quota: choose an available fresh quota by greatest used percentage, then
stable owner/window key; if none is fresh, show explicitly unavailable core state.

## Shared acceptance

Use [data semantics](../02_DATA_SEMANTICS.md), [motion](../03_DESIGN_SYSTEM_AND_MOTION.md)
and [tests](../05_TEST_AND_VISUAL_PARITY.md). Preserve scope in drill-down URLs.
Support loading, empty, stale, unavailable, partial/estimated pricing and retry without
unexpected layout shifts. All visible controls have keyboard/focus and error behavior.
No fixture values enter production. Static preview alone is not implementation completion.
Record a measured screenshot baseline only after reviewing concept + overrides together.
