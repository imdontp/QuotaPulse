# Screen Contract - History & Logs

Concept: [original image](../refs/history.png), 1672 x 941, DPR 1.
Overrides: OVR-001..003, OVR-018..019, OVR-022..023; see [exact replacements](../11_REFERENCE_OVERRIDES.md).
Sources/field mappings: [API contract](../12_API_AND_FIELD_CONTRACTS.md).

## Composition, meaning and actions

Keep timeline/summary, metadata search and filters, paginated usage-record table and
selected detail rail. Use usage-events for complete history; sessionDetail's first 2000
rows is not a history endpoint. Label records versus SUM(call_count), including aggregates.
Filters: range/project/harness/provider/vendor/model/record kind and metadata search.
Record selection uses stable event_id. Status column becomes record kind; effort is
source category. Detail contains summary, token breakdown, price provenance, runtime
metadata and related session. Copy uses only the record allowlist, never arbitrary JSON.
Export CSV includes all matching records under the same filters, not only the page;
there is no unsupported bulk-selection action. Do not advertise prompt search.
Handle >2000 rows, equal timestamps, changing aggregate rows, missing durations and
unknown project/provider/model. No label claims aggregate timestamps are individual calls.

## Shared acceptance

Use [data semantics](../02_DATA_SEMANTICS.md), [motion](../03_DESIGN_SYSTEM_AND_MOTION.md)
and [tests](../05_TEST_AND_VISUAL_PARITY.md). Preserve scope in drill-down URLs.
Support loading, empty, stale, unavailable, partial/estimated pricing and retry without
unexpected layout shifts. All visible controls have keyboard/focus and error behavior.
No fixture values enter production. Static preview alone is not implementation completion.
Record a measured screenshot baseline only after reviewing concept + overrides together.
