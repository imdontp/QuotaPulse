# Screen Contract - Alerts & Quota Guard

Concept: [original image](../refs/alerts.png), 1672 x 941, DPR 1.
Overrides: OVR-001..003, OVR-007, OVR-020..023; see [exact replacements](../11_REFERENCE_OVERRIDES.md).
Sources/field mappings: [API contract](../12_API_AND_FIELD_CONTRACTS.md).

## Composition, meaning and actions

Keep summary metrics, risk chart, current risk list, read-only threshold table, forecast
rail, recommended actions and historical notifications. Header toggle is Notifications
and uses existing settings; it never pauses collection or turns on automatic protection.
Metrics show current risks, monitored owner/windows, fixed thresholds and fresh-reading
coverage. Coverage denominator includes known monitored windows; unknown coverage stays
unknown and excludes hidden subscriptions consistently with the selected view.
Risk chart selects one owner/window and reads real quota history with reset breaks.
Project filters cannot imply attribution of account-wide quota to one project.
Rules list 50/80/95 as read-only; no Add Rule or per-rule toggle. Current risk derives
from fresh percent/forecast/source status per API contract and clears on recovery;
threshold history retains facts independently of current risk or delivery state.
Recommendations open local project/model/provider detail or explain waiting for reset.
No Switch/Apply/Enable/Pause external execution. Recent notification history names only
existing desktop delivery and explains that the tray must run for delivery. Keep snooze,
quiet hours and duplicate suppression; no email/Slack/Discord icons or new channels.

## Shared acceptance

Use [data semantics](../02_DATA_SEMANTICS.md), [motion](../03_DESIGN_SYSTEM_AND_MOTION.md)
and [tests](../05_TEST_AND_VISUAL_PARITY.md). Preserve scope in drill-down URLs.
Support loading, empty, stale, unavailable, partial/estimated pricing and retry without
unexpected layout shifts. All visible controls have keyboard/focus and error behavior.
No fixture values enter production. Static preview alone is not implementation completion.
Record a measured screenshot baseline only after reviewing concept + overrides together.
