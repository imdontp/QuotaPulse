# Screen Contract - Projects

Concept: [original image](../refs/projects.png), 1672 x 941, DPR 1.
Overrides: OVR-001..003, OVR-011..012, OVR-022..023; see [exact replacements](../11_REFERENCE_OVERRIDES.md).
Sources/field mappings: [API contract](../12_API_AND_FIELD_CONTRACTS.md).

## Composition, meaning and actions

Keep card grid, selected detail rail/trend, breakdown and top-consuming list. Refresh
calls existing incremental refresh. Tabs: All projects, Recent activity (five minutes)
and Unassigned, with a harness filter. Search metadata and sort by last observed/tokens/
API value via complete scoped results, not only the currently visible page.
Card progress is project tokens / all scoped project tokens, labelled Share of usage.
No budget cap is implied. Use full project metadata identity; basename is display-only.
Description shows safe cwd/project metadata. Counts distinguish calls and distinct sessions.
Details tabs are Overview, Sessions, Usage and Details (read-only metadata). Card click
selects detail; sessions are server-filtered by project; trend uses identical scope.
Null project gets its explicit bucket. No new-project, budget, archive, pin or team editor.

## Shared acceptance

Use [data semantics](../02_DATA_SEMANTICS.md), [motion](../03_DESIGN_SYSTEM_AND_MOTION.md)
and [tests](../05_TEST_AND_VISUAL_PARITY.md). Preserve scope in drill-down URLs.
Support loading, empty, stale, unavailable, partial/estimated pricing and retry without
unexpected layout shifts. All visible controls have keyboard/focus and error behavior.
No fixture values enter production. Static preview alone is not implementation completion.
Record a measured screenshot baseline only after reviewing concept + overrides together.
