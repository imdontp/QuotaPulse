# Screen Contract - Live Monitoring

Concept: [original image](../refs/live.png), 1672 x 941, DPR 1.
Overrides: OVR-001..003, OVR-008..010, OVR-022..023; see [exact replacements](../11_REFERENCE_OVERRIDES.md).
Sources/field mappings: [API contract](../12_API_AND_FIELD_CONTRACTS.md).

## Composition, meaning and actions

Keep four metrics, session table, minute chart, usage-record feed, advisory rail and
provider/model activity matrix. Cards are Recent sessions, Reporting sources, Stale
sources and Reader errors, not a session-state partition. The recent threshold is five
minutes, based on source timestamps; null/future timestamps are unknown. Session filter
is recent/all observed, plus metadata filters; no queued/failed runtime state.
Default chart/feed range is the last 30 minutes. Per-call trend supplies Recorded
tokens/min; aggregate/unknown exclusions are visible, including a distinct aggregate
summary. Pausing freezes this page's displayed snapshot and counters, not daemon/SSE.
Resume reloads the latest snapshot/page zero without replaying imagined missed events.
Session row opens metadata detail; matrix cell filters provider/model; alert opens its
local owner/window or diagnostics. No error-rate, TPM-cap or latency assertion without
a trusted source. Bound rows through server paging; never one detail fetch per row.

## Shared acceptance

Use [data semantics](../02_DATA_SEMANTICS.md), [motion](../03_DESIGN_SYSTEM_AND_MOTION.md)
and [tests](../05_TEST_AND_VISUAL_PARITY.md). Preserve scope in drill-down URLs.
Support loading, empty, stale, unavailable, partial/estimated pricing and retry without
unexpected layout shifts. All visible controls have keyboard/focus and error behavior.
No fixture values enter production. Static preview alone is not implementation completion.
Record a measured screenshot baseline only after reviewing concept + overrides together.
