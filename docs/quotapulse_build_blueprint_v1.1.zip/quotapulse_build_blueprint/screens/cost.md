# Screen Contract - Cost Analysis

Concept: [original image](../refs/cost.png), 1672 x 941, DPR 1.
Overrides: OVR-001..003, OVR-017, OVR-022..023; see [exact replacements](../11_REFERENCE_OVERRIDES.md).
Sources/field mappings: [API contract](../12_API_AND_FIELD_CONTRACTS.md).

## Composition, meaning and actions

Keep summary tiles, provider breakdown, trend, model/project tables, expensive sessions
and insight rail. Monetary basis selector is API value or Reported native cost. The
default is API value; every panel and per-token denominator follows the selected basis.
All usage token totals may be shown separately, clearly scoped. Basis coverage explains
excluded unknown and other-basis calls. Never label the mixed legacy sum as API spend.
Native-only calls have no computed breakdown/cache savings; show missing coverage.
Projected monthly API value uses the constrained Data Semantics rule, otherwise unavailable;
native mode has no billed-spend projection. Insight rail shows known historical cache
savings, model cost concentration and unpriced coverage. Do not promise equivalent
quality or hypothetical dollar savings from a model switch. Insight links open local
explanations/detail. Expensive sessions need server-scoped sorting, not sorting one page.

## Shared acceptance

Use [data semantics](../02_DATA_SEMANTICS.md), [motion](../03_DESIGN_SYSTEM_AND_MOTION.md)
and [tests](../05_TEST_AND_VISUAL_PARITY.md). Preserve scope in drill-down URLs.
Support loading, empty, stale, unavailable, partial/estimated pricing and retry without
unexpected layout shifts. All visible controls have keyboard/focus and error behavior.
No fixture values enter production. Static preview alone is not implementation completion.
Record a measured screenshot baseline only after reviewing concept + overrides together.
