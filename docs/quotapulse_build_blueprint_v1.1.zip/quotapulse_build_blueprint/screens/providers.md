# Screen Contract - Providers & Subscriptions

Concept: [original image](../refs/providers.png), 1672 x 941, DPR 1.
Overrides: OVR-001..003, OVR-013..014, OVR-022..023; see [exact replacements](../11_REFERENCE_OVERRIDES.md).
Sources/field mappings: [API contract](../12_API_AND_FIELD_CONTRACTS.md).

## Composition, meaning and actions

Keep subscription card grid, window bars, comparison chart and reader-health table.
Cards represent supported known accounts/sources, including inactive ones per existing
preferences, not all brands drawn in the concept. Preserve shared-owner deduplication
and linked harness labels without implying per-call account routing.
Refresh status uses global existing refresh; Manage opens Settings diagnostics for the
source/owner; card opens local details; hover shows origin, observed age and reset.
Comparison selects one actual window kind, excludes unavailable values with a visible
count, and never averages daily/weekly/monthly percentages. Original plan/renewal slots
show source origin and freshness. Health lists reader state and last observed age, not
provider latency. No account credentials or new integration setup workflow.

## Shared acceptance

Use [data semantics](../02_DATA_SEMANTICS.md), [motion](../03_DESIGN_SYSTEM_AND_MOTION.md)
and [tests](../05_TEST_AND_VISUAL_PARITY.md). Preserve scope in drill-down URLs.
Support loading, empty, stale, unavailable, partial/estimated pricing and retry without
unexpected layout shifts. All visible controls have keyboard/focus and error behavior.
No fixture values enter production. Static preview alone is not implementation completion.
Record a measured screenshot baseline only after reviewing concept + overrides together.
