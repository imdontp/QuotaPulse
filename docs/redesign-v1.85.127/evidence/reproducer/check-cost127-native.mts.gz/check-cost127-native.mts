import { checkCostInspection } from '../scripts/check-cost-inspection.mjs';
/** Static canonical reference capture. Isolated synthetic DB, compiled application, no user data. */
import assert from 'node:assert/strict';
import { en } from '../packages/web/src/i18n/en.js';
import { th } from '../packages/web/src/i18n/th.js';
import { installBrowserFixedDate } from '../scripts/browser-fixed-date.mjs';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium, type Page, type Request } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import { recordQuotaAlerts } from '../packages/daemon/src/api/queries.js';
const root = fileURLToPath(new URL('..', import.meta.url));
const output = resolve(root, process.env.QP127_SCENARIOS ? 'tmp/fidelity127/scenarios' : 'tmp/fidelity127/native'); 
const referenceRoot = 'C:/Users/TH12367283/Downloads/quotapulse_build_blueprint';
const priorTimezone = process.env.TZ;
process.env.TZ = 'Asia/Bangkok';
mkdirSync(output, { recursive: true });

const fixedNow = Date.parse('2025-05-17T13:42:00.000Z');
// Freeze Date only, keeping real timers/performance for HTTP, browser and cleanup.
// This applies to internal query helpers too, without changing production clocks.
const realDate = globalThis.Date;
globalThis.Date = new Proxy(realDate, {
  construct(target, args) { return Reflect.construct(target, args.length ? args : [fixedNow]); },
  apply() { return new realDate(fixedNow).toString(); },
  get(target, property, receiver) { return property === 'now' ? () => fixedNow : Reflect.get(target, property, receiver); },
});
const db = openDb(':memory:');
db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at,account_key,account_provider,account_display_name,account_state,account_last_success_at)
  VALUES (1,'codex','fixed','/synthetic/nonexistent','Codex fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow}),
    (2,'hermes','fixed','/synthetic/nonexistent','Hermes fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (3,'claude-code','fixed','/synthetic/nonexistent','Claude Code fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (4,'opencode','fixed','/synthetic/nonexistent','OpenCode fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow});`);
const referenceProjects = ['QuotaPulse', 'Agent Platform', 'Edge Services', 'Developer Tools', 'Research Lab'];
const referenceModels = [
  { name: 'DeepSeek V4.1', provider: 'deepseek', share: 38 },
  { name: 'GPT-5.x', provider: 'openai', share: 24 },
  { name: 'Claude 3.7', provider: 'anthropic', share: 18 },
  { name: 'Claude 3.5', provider: 'anthropic', share: 11 },
  { name: 'Others', provider: 'openrouter', share: 9 },
  { name: 'GPT-4.1 mini', provider: 'openai', share: 0 },
];
const session = db.prepare('INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (?,?,?,?,?)');
const usage = db.prepare('INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source,cost_input_usd,cost_cached_input_usd,cost_cache_write_usd,cost_output_usd,cost_cache_saving_usd,price_provider) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
// Synthetic catalogue rates for the in-memory visual fixture only. The saved
// amount is derived from the same fresh/cached input components the UI reports.
const fixtureInputUsdPerMillion = 0.0593846153846154, fixtureCachedInputUsdPerMillion = 0.004, fixtureOutputUsdPerMillion = 0.004;
for (let index = 0; index < 12; index++) {
  // Keep the reference map's 4 Codex, 2 Claude Code, 6 Hermes, 0 OpenCode
  // recent-session distribution while preserving the same 12 sessions.
  const source = [1, 1, 1, 1, 3, 3, 2, 2, 2, 2, 2, 2][index]!;
  session.run(index + 1, source, `fixture-session-${index}`, referenceProjects[0], fixedNow - 10_000);
  const model = referenceModels[index % referenceModels.length]!;
  const totalTokens = model.share === 0 ? 1 : model.share * 721_000_000 / 600;
  for (let call = 0; call < 3; call++) {
    const inputShare = [.6, .65, .7][(index + call) % 3]!;
    const inputTokens = totalTokens * inputShare * .58, cachedInputTokens = totalTokens * inputShare * .42;
    const outputTokens = totalTokens * (1 - inputShare);
    const costSource = index === 0 ? 'native' : 'computed';
    const inputUsd = inputTokens / 1_000_000 * fixtureInputUsdPerMillion;
    const cachedInputUsd = cachedInputTokens / 1_000_000 * fixtureCachedInputUsdPerMillion;
    const outputUsd = outputTokens / 1_000_000 * fixtureOutputUsdPerMillion;
    const cacheSavingUsd = cachedInputTokens / 1_000_000 * (fixtureInputUsdPerMillion - fixtureCachedInputUsdPerMillion);
    // Keep each session's latest record within four minutes, then spread older calls across the visible 30-minute interval.
    const ageMs = call === 0 ? 15_000 + index * 20_000 : source === 2
      ? 300_000 + index * 120_000 + (call === 2 ? 30_000 : 0)
      : 300_000 + index * 240_000 + (call === 2 ? 90_000 : 0);
    const recordedAt = fixedNow - ageMs;
    usage.run(source, index + 1, `fixed-${index}-${call}`, recordedAt, model.name, model.provider,
      inputTokens, cachedInputTokens, outputTokens, totalTokens, call + 1,
      costSource === 'native' ? (index + 1) / 100 : inputUsd + cachedInputUsd + outputUsd, costSource,
      costSource === 'native' ? null : inputUsd, costSource === 'native' ? null : cachedInputUsd,
      costSource === 'native' ? null : 0, costSource === 'native' ? null : outputUsd,
      costSource === 'native' ? null : cacheSavingUsd, costSource === 'native' ? null : model.provider);
  }
}
// A stale recorded OpenCode route keeps the concept's zero-active-session edge
// visible without manufacturing a provider relationship or changing live counts.
const openCodeAt = fixedNow - 10 * 60_000;
session.run(13, 4, 'fixture-opencode-quota-pulse', referenceProjects[0], openCodeAt);
usage.run(4, 13, 'fixed-opencode-route', openCodeAt, 'DeepSeek V4.1', 'deepseek', 1, 0, 0, 1, 1,
  null, 'unknown', null, null, null, null, null, null);
// The monthly concept is focused on QuotaPulse while the machine-wide quick
// stats still report all five named projects. Keep four small monthly records
// for the other projects, outside the recent-session window.
for (let index = 1; index < referenceProjects.length; index++) {
  const id = 100 + index, source = [1, 3, 4, 2][index - 1]!;
  const model = referenceModels[index - 1]!;
  const at = fixedNow - 10 * 60_000;
  session.run(id, source, `fixture-project-${index}`, referenceProjects[index], at);
  const inputUsd = fixtureInputUsdPerMillion / 1_000_000;
  usage.run(source, id, `fixture-project-usage-${index}`, at, model.name, model.provider, 1, 0, 0, 1, 1,
    inputUsd, 'computed', inputUsd, 0, 0, 0, 0, model.provider);
}
// Values below the old visual minimum catch inflated nonzero bars in both charts.
const tinyUsage = db.prepare("INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source) VALUES (1,1,?,?,'DeepSeek V4.1','deepseek',1,0,0,1,1,0,'computed')");
tinyUsage.run('fixed-tiny-minute', fixedNow - 15 * 60_000);
tinyUsage.run('fixed-tiny-day', fixedNow - 3 * 86_400_000);
const quota = db.prepare('INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin) VALUES (?,?,?,?,?,?,?,?)');
const addQuotaSample = (sourceId: number, window: string, percent: number | null, resetAt: number | null, observedAt: number) => quota.run(sourceId, window, percent, resetAt, observedAt, observedAt, observedAt, 'fixed-fixture');
// Complete history must include older reset periods, nulls and more than eight
// readings per period, without changing the latest live quota/default selection.
for (let segment = 0; segment < 4; segment++) for (let index = 0; index < 12; index++) {
  const at = fixedNow - (5 - segment) * 3_600_000 + index * 60_000;
  addQuotaSample(1, '5h', index === 4 ? null : index === 1 ? 0.5 : index * 8, segment === 0 ? null : fixedNow - (4 - segment) * 3_600_000, at);
}
addQuotaSample(1, '5h', 38, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 5 * 60_000);
addQuotaSample(1, '5h', 83, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 30_000);
addQuotaSample(1, 'weekly', 62, fixedNow + (3 * 24 + 5) * 3_600_000, fixedNow - 30_000);
const monthlyReset = fixedNow + (6 * 24 + 2) * 3_600_000;
addQuotaSample(1, 'monthly', 59, monthlyReset, fixedNow - 48 * 3_600_000);
addQuotaSample(1, 'monthly', 65.5, monthlyReset, fixedNow - 24 * 3_600_000);
addQuotaSample(1, 'monthly', 72, monthlyReset, fixedNow - 30_000);
addQuotaSample(2, 'monthly', 58, fixedNow + (12 * 24 + 6) * 3_600_000, fixedNow - 30_000);
addQuotaSample(2, 'daily', 34, fixedNow + (7 * 60 + 18) * 60_000, fixedNow - 30_000);
recordQuotaAlerts(db, fixedNow);
const scheduler = new Scheduler(db, [], { pollMs: 1_000_000, detectMs: 1_000_000 });
const daemon = buildServer(db, scheduler, { token: 'stable-capture-test', port: 7816, webRoot: resolve(root, 'packages/web/dist') });

let browser:Awaited<ReturnType<typeof chromium.launch>>|undefined;
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const indexPath=resolve(root,'packages/web/dist/index.html'),index=sha(readFileSync(indexPath));
const results:unknown[]=[];
try{
 await daemon.listen({host:'127.0.0.1',port:7816});browser=await chromium.launch({channel:'chrome',headless:true});
 for(const lang of ['en','th'])for(const theme of ['dark','light'])for(const width of [390,1280,1536,1672])for(const basis of ['api','native']){
  if(process.env.QP127_SCENARIOS && !(lang==='en'&&theme==='dark'&&basis==='api'&&[390,1672].includes(width)))continue;
  const currency=width===390||width===1536?'THB':'USD',rate=37.25,name=[lang,theme,width,basis,currency].join('-'),copy=lang==='th'?th:en;
  const context=await browser.newContext({viewport:{width,height:941},reducedMotion:'reduce',deviceScaleFactor:1,timezoneId:'Asia/Bangkok'});
  const page=await context.newPage();page.setDefaultTimeout(15000);const errors:string[]=[],forbidden:string[]=[];const pending=new Set<Request>();
  page.on('pageerror',error=>errors.push(error.message));page.on('response',response=>{if(response.status()>=400)errors.push(response.status()+' '+response.url())});
  page.on('request',request=>{if(new URL(request.url()).pathname.startsWith('/api/')&&!request.url().includes('/events/stream'))pending.add(request)});
  page.on('requestfinished',r=>pending.delete(r));page.on('requestfailed',r=>pending.delete(r));
  await page.route('**/*',route=>{const r=route.request(),u=new URL(r.url());if(u.origin!=='http://127.0.0.1:7816'||r.method()!=='GET'){forbidden.push(r.method()+' '+u.pathname);return route.abort()}return route.continue()});
  await page.addInitScript(({lang,theme,currency,rate})=>{(window as any).__QUOTAPULSE_TOKEN__='stable-capture-test';localStorage.setItem('quotapulse-prefs',JSON.stringify({lang,currency,rate,hiddenSubscriptions:[]}));localStorage.setItem('quotapulse-theme',theme)},{lang,theme,currency,rate});await installBrowserFixedDate(page,fixedNow);
  const settle=async()=>{let idle=0;const end=performance.now()+30000;while(idle<8){assert.ok(performance.now()<end);await page.waitForTimeout(40);idle=pending.size===0?idle+1:0}};
  const response=page.waitForResponse(response=>response.url().includes('/api/cost-analysis?')&&response.status()===200);
  await page.goto('http://127.0.0.1:7816/#cost?range=month&basis='+basis,{waitUntil:'domcontentloaded'});
  const request=new URL((await response).url());const independent=await daemon.inject({url:request.pathname+request.search,headers:{'x-quotapulse-token':'stable-capture-test'}});assert.equal(independent.statusCode,200);const data=independent.json();assert.equal(data.basis,basis);
  await page.locator('.qp-cost-chart').waitFor();await page.evaluate(()=>document.fonts.ready);await settle();
  await page.evaluate(()=>{(window as any).__costEvents=[];for(const kind of ['scroll','focusin','focusout','resize','pointerleave'])window.addEventListener(kind,event=>{const rows=(window as any).__costEvents;rows.push({kind,at:performance.now(),target:(event.target as HTMLElement)?.className,y:scrollY,focus:document.activeElement?.className,tip:document.querySelector('.qp-cost-inspection-tooltip')?.getAttribute('data-at')});if(rows.length>100)rows.shift()},true)});
  let result:any;
  try{result=await checkCostInspection(page,data,{locale:lang==='th'?'th-TH':'en-US',currency,rate,basisLabel:copy[basis==='api'?'redesign.costApiBasis':'redesign.costNativeBasis'],unknown:copy['redesign.unknownValue']});}
  catch(error){writeFileSync(resolve(output,name+'-failure.json'),JSON.stringify(await page.evaluate(()=>({events:(window as any).__costEvents,plot:document.querySelector('.qp-cost-chart')?.getBoundingClientRect().toJSON(),tip:document.querySelector('.qp-cost-inspection-tooltip')?.outerHTML,focus:document.activeElement?.outerHTML.slice(0,500),y:scrollY})),null,2));await page.screenshot({path:resolve(output,name+'-failure.png')});throw error}
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
  if(width===390){const tables=[];for(const section of ['models','projects','sessions']){const region=page.locator('.qp-cost-'+section+' .qp-cost-table');const bounds=await region.evaluate(node=>({clientWidth:node.clientWidth,scrollWidth:node.scrollWidth,tableWidth:node.querySelector('table')!.getBoundingClientRect().width}));assert.ok(bounds.scrollWidth>bounds.clientWidth&&bounds.tableWidth>=(section==='projects'?460:640),'Narrow Cost facts retain readable table columns');await region.focus();await page.keyboard.press('ArrowRight');await page.waitForFunction(selector=>document.querySelector(selector)!.scrollLeft>0,'.qp-cost-'+section+' .qp-cost-table');tables.push({section,...bounds,keyboardScroll:true});await region.evaluate(node=>{node.scrollLeft=0;(node as HTMLElement).blur()})}result.narrowTables=tables;}
  await page.evaluate(()=>scrollTo(0,0));await page.screenshot({path:resolve(output,name+'.png'),animations:'disabled'});
  if(lang==='en'&&theme==='dark'&&width===1672&&basis==='api'){
   const plot=page.locator('.qp-cost-chart');await plot.focus();await page.keyboard.press('End');await page.locator('.qp-cost-inspection-tooltip').waitFor();
   const next=page.waitForResponse(r=>r.url().includes('/api/cost-analysis?')&&new URL(r.url()).searchParams.get('basis')==='native');
   await page.evaluate(()=>{location.hash='#cost?range=month&basis=native&bucket=week'});await page.locator('.qp-cost-inspection-tooltip').waitFor({state:'hidden'});assert.equal((await next).status(),200);await settle();assert.equal(await page.locator('.qp-cost-inspection-tooltip').count(),0);
   await plot.focus();await page.keyboard.press('Home');await page.locator('.qp-cost-inspection-tooltip').waitFor();assert.equal(await page.locator('.qp-cost-inspection-tooltip dt').first().textContent(),copy['redesign.costNativeBasis']);await page.keyboard.press('Escape');result.scopeInvalidation=true;
  }
  if(process.env.QP127_SCENARIOS){
   const plot=page.locator('.qp-cost-chart');await plot.evaluate(node=>node.blur());await plot.focus();try{await page.locator('.qp-cost-inspection-tooltip').waitFor();}catch(error){writeFileSync(resolve(output,name+'-refocus-failure.json'),JSON.stringify(await page.evaluate(()=>({events:(window as any).__costEvents,plot:document.querySelector('.qp-cost-chart')?.getBoundingClientRect().toJSON(),y:scrollY,focus:document.activeElement?.className})),null,2));throw error}await page.keyboard.press('End');
   const frame=await page.screenshot({path:resolve(output,name+'-inspection.png'),animations:'disabled'});result.inspectionFrame={file:name+'-inspection.png',sha256:sha(frame),hash:await page.evaluate(()=>location.hash),at:await page.locator('.qp-cost-inspection-tooltip').getAttribute('data-at')};
   if(width===390){const at=await page.evaluate(()=>{const node=document.querySelector('.qp-cost-models .qp-cost-table')!;const at=performance.now();node.scrollLeft=node.scrollWidth-node.clientWidth;return at});await page.waitForFunction(at=>(window as any).__costEvents.some((row:any)=>row.at>=at&&row.kind==='scroll'&&row.target==='qp-cost-table'),at);assert.equal(await page.locator('.qp-cost-inspection-tooltip').isVisible(),true,'Unrelated table scrolling preserves the selected Cost bucket');result.unrelatedScrollPreserved=true;const beforeScroll=await page.evaluate(()=>({y:scrollY,max:document.documentElement.scrollHeight-innerHeight}));assert.ok(beforeScroll.max>0);await page.evaluate(y=>scrollTo(0,y>0?y-1:1),beforeScroll.y);await page.locator('.qp-cost-inspection-tooltip').waitFor({state:'hidden'});result.scrollInvalidation=true;}
   if(width===1672){
    const from=fixedNow-30_000,to=fixedNow+1,hash='#cost?range=custom&from='+from+'&to='+to+'&basis=native&bucket=hour&source=1';
    const next=page.waitForResponse(r=>r.url().includes('/api/cost-analysis?')&&new URL(r.url()).searchParams.get('from')===String(from));await page.evaluate(hash=>{location.hash=hash},hash);
    const req=new URL((await next).url());const single=await daemon.inject({url:req.pathname+req.search,headers:{'x-quotapulse-token':'stable-capture-test'}});assert.equal(single.statusCode,200);const one=single.json();await settle();assert.equal(one.points.length,1);
    result.singleBucket=await checkCostInspection(page,one,{locale:'en-US',currency:'USD',rate:1,basisLabel:copy['redesign.costNativeBasis'],unknown:copy['redesign.unknownValue']});
    await plot.focus();await page.locator('.qp-cost-inspection-tooltip').waitFor();const noPrice=page.waitForResponse(r=>r.url().includes('/api/cost-analysis?')&&new URL(r.url()).searchParams.get('source_id')==='4');
    await page.evaluate(()=>{location.hash='#cost?range=month&basis=native&source=4'});await page.locator('.qp-cost-inspection-tooltip').waitFor({state:'hidden'});
    const emptyResponse=await noPrice;assert.equal(emptyResponse.status(),200);assert.equal((await emptyResponse.json()).totals.pricedCalls,0);await settle();assert.equal(await plot.count(),0);assert.equal(await page.locator('.qp-cost-inspection-tooltip').count(),0);result.unpricedScope=true;
   }
  }
  assert.deepEqual(errors,[]);assert.deepEqual(forbidden,[]);results.push({name,lang,theme,width,basis,currency,index,apiScope:data.scope,result,errors,forbidden});console.log('Passed '+name);await context.close();
 }
 assert.equal(sha(readFileSync(indexPath)),index);writeFileSync(resolve(output,'verification.json'),JSON.stringify({status:'passed',index,browser:browser.version(),results},null,2));
}finally{await browser?.close();await daemon.close();db.close();globalThis.Date=realDate;process.env.TZ=priorTimezone}
