import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { chromium } from 'playwright';
const root=resolve('docs/redesign-v1.85.127'),manifest=JSON.parse(readFileSync(resolve(root,'review-manifest.json')));
const browser=await chromium.launch({channel:'chrome',headless:true});
try{
 const page=await browser.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(pathToFileURL(resolve(root,'review.html')).href);
 const loaded=async(path,width)=>page.waitForFunction(({path,width})=>{const image=document.getElementById('image');return image.complete&&image.naturalWidth===width&&image.currentSrc.endsWith(path)},{path,width});
 await loaded('images/final/overview.png',1586);await page.locator('#route').selectOption('cost');await loaded('images/final/cost.png',1672);
 await page.locator('#phase').selectOption('original');await loaded('redesign-v1.85.69/refs/cost.png',1672);await page.locator('#phase').selectOption('before');await loaded('images/before/cost.png',1672);
 for(const [index,entry] of manifest.active.entries()){await page.locator('#active').selectOption(String(index));await loaded(entry.path,index===0?390:1672);assert.ok((await page.locator('#caption').textContent()).includes(entry.hash));}
 assert.deepEqual(errors,[]);writeFileSync(resolve(root,'evidence/viewer-verification.json'),JSON.stringify({status:'passed',browser:browser.version(),pageSelection:true,original:true,before:true,current:true,activeRoutes:manifest.active.map(r=>r.hash),errors},null,2)+'\n');
}finally{await browser.close()}
