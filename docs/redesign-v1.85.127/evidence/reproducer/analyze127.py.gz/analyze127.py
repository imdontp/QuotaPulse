import json
from pathlib import Path
import numpy as np
from PIL import Image
root=Path('tmp/fidelity127')
before=json.loads((root/'before/verification.json').read_text(encoding='utf8'))
after=json.loads((root/'final/verification.json').read_text(encoding='utf8'))
results=[]
for entry in after['results']:
    name=entry['route'];prior=next(r for r in before['results'] if r['route']==name)
    a=np.array(Image.open(root/'before'/f'{name}.png').convert('RGB')).astype(int)
    b=np.array(Image.open(root/'final'/f'{name}.png').convert('RGB')).astype(int)
    d=np.abs(a-b);changed=d.max(axis=2)>0;yy,xx=np.where(changed)
    results.append({'route':name,'changedPixels':int(changed.sum()),'maxChannelDelta':int(d.max()),'bbox':None if not changed.any() else [int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())], 'mainGeometryEqual':prior['geometry']['mainRegions']==entry['geometry']['mainRegions'],'beforeRepeatExact':prior['repeatIdentical'],'afterRepeatExact':entry['repeatIdentical'],'referenceSha256':entry['referenceSha256']})
summary={'scope':'All-eight inactive native Chrome frame comparisons; not an original-concept similarity percentage','beforeIndex':before['productionIndexSha256'],'afterIndex':after['productionIndexSha256'],'results':results}
(root/'analysis.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps(summary))
