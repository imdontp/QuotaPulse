const fs=require('fs'),crypto=require('crypto'),assert=require('assert/strict');
const data=JSON.parse(fs.readFileSync('tmp/fidelity128/traced-marks.json'));
for(const record of Object.values(data)){const bytes=fs.readFileSync('docs/redesign-v1.85.69/refs/'+record.reference);assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),record.referenceSha256);}
const paths=Object.fromEntries(Object.entries(data).filter(([key])=>key!=='opencode').map(([key,record])=>[key,record.path]));
fs.writeFileSync('packages/web/src/redesign/dashboard-mark-glyphs.ts','/** App glyph contours from the user-supplied blueprint refs. See redesign128 provenance. */\nexport const dashboardGlyphs = '+JSON.stringify(paths,null,2)+' as const;\n');
