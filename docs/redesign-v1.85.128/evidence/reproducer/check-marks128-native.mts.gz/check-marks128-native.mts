/** Static canonical reference capture. Isolated synthetic DB, compiled application, no user data. */
import assert from 'node:assert/strict';
import { en } from '../packages/web/src/i18n/en.js';
import { th } from '../packages/web/src/i18n/th.js';
import { installBrowserFixedDate } from '../scripts/browser-fixed-date.mjs';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium, type Page, type Request } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import { recordQuotaAlerts } from '../packages/daemon/src/api/queries.js';
const root = fileURLToPath(new URL('..', import.meta.url));
const output = resolve(root, 'tmp/fidelity128/native'); 
const referenceRoot = 'C:/Users/TH12367283/Downloads/quotapulse_build_blueprint';
const priorTimezone = process.env.TZ;
process.env.TZ = 'Asia/Bangkok';
mkdirSync(output, { recursive: true });

const fixedNow = Date.parse('2025-05-17T13:42:00.000Z');
// Freeze Date only, keeping real timers/performance for HTTP, browser and cleanup.
// This applies to internal query helpers too, without changing production clocks.
const realDate = globalThis.Date;
globalThis.Date = new Proxy(realDate, {
  construct(target, args) { return Reflect.construct(target, args.length ? args : [fixedNow]); },
  apply() { return new realDate(fixedNow).toString(); },
  get(target, property, receiver) { return property === 'now' ? () => fixedNow : Reflect.get(target, property, receiver); },
});
const db = openDb(':memory:');
db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at,account_key,account_provider,account_display_name,account_state,account_last_success_at)
  VALUES (1,'codex','fixed','/synthetic/nonexistent','Codex fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow}),
    (2,'hermes','fixed','/synthetic/nonexistent','Hermes fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (3,'claude-code','fixed','/synthetic/nonexistent','Claude Code fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (4,'opencode','fixed','/synthetic/nonexistent','OpenCode fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow});`);
const referenceProjects = ['QuotaPulse', 'Agent Platform', 'Edge Services', 'Developer Tools', 'Research Lab'];
const referenceModels = [
  { name: 'DeepSeek V4.1', provider: 'deepseek', share: 38 },
  { name: 'GPT-5.x', provider: 'openai', share: 24 },
  { name: 'Claude 3.7', provider: 'anthropic', share: 18 },
  { name: 'Claude 3.5', provider: 'anthropic', share: 11 },
  { name: 'Others', provider: 'openrouter', share: 9 },
  { name: 'GPT-4.1 mini', provider: 'openai', share: 0 },
];
const session = db.prepare('INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (?,?,?,?,?)');
const usage = db.prepare('INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source,cost_input_usd,cost_cached_input_usd,cost_cache_write_usd,cost_output_usd,cost_cache_saving_usd,price_provider) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
// Synthetic catalogue rates for the in-memory visual fixture only. The saved
// amount is derived from the same fresh/cached input components the UI reports.
const fixtureInputUsdPerMillion = 0.0593846153846154, fixtureCachedInputUsdPerMillion = 0.004, fixtureOutputUsdPerMillion = 0.004;
for (let index = 0; index < 12; index++) {
  // Keep the reference map's 4 Codex, 2 Claude Code, 6 Hermes, 0 OpenCode
  // recent-session distribution while preserving the same 12 sessions.
  const source = [1, 1, 1, 1, 3, 3, 2, 2, 2, 2, 2, 2][index]!;
  session.run(index + 1, source, `fixture-session-${index}`, referenceProjects[0], fixedNow - 10_000);
  const model = referenceModels[index % referenceModels.length]!;
  const totalTokens = model.share === 0 ? 1 : model.share * 721_000_000 / 600;
  for (let call = 0; call < 3; call++) {
    const inputShare = [.6, .65, .7][(index + call) % 3]!;
    const inputTokens = totalTokens * inputShare * .58, cachedInputTokens = totalTokens * inputShare * .42;
    const outputTokens = totalTokens * (1 - inputShare);
    const costSource = index === 0 ? 'native' : 'computed';
    const inputUsd = inputTokens / 1_000_000 * fixtureInputUsdPerMillion;
    const cachedInputUsd = cachedInputTokens / 1_000_000 * fixtureCachedInputUsdPerMillion;
    const outputUsd = outputTokens / 1_000_000 * fixtureOutputUsdPerMillion;
    const cacheSavingUsd = cachedInputTokens / 1_000_000 * (fixtureInputUsdPerMillion - fixtureCachedInputUsdPerMillion);
    // Keep each session's latest record within four minutes, then spread older calls across the visible 30-minute interval.
    const ageMs = call === 0 ? 15_000 + index * 20_000 : source === 2
      ? 300_000 + index * 120_000 + (call === 2 ? 30_000 : 0)
      : 300_000 + index * 240_000 + (call === 2 ? 90_000 : 0);
    const recordedAt = fixedNow - ageMs;
    usage.run(source, index + 1, `fixed-${index}-${call}`, recordedAt, model.name, model.provider,
      inputTokens, cachedInputTokens, outputTokens, totalTokens, call + 1,
      costSource === 'native' ? (index + 1) / 100 : inputUsd + cachedInputUsd + outputUsd, costSource,
      costSource === 'native' ? null : inputUsd, costSource === 'native' ? null : cachedInputUsd,
      costSource === 'native' ? null : 0, costSource === 'native' ? null : outputUsd,
      costSource === 'native' ? null : cacheSavingUsd, costSource === 'native' ? null : model.provider);
  }
}
// A stale recorded OpenCode route keeps the concept's zero-active-session edge
// visible without manufacturing a provider relationship or changing live counts.
const openCodeAt = fixedNow - 10 * 60_000;
session.run(13, 4, 'fixture-opencode-quota-pulse', referenceProjects[0], openCodeAt);
usage.run(4, 13, 'fixed-opencode-route', openCodeAt, 'DeepSeek V4.1', 'deepseek', 1, 0, 0, 1, 1,
  null, 'unknown', null, null, null, null, null, null);
// The monthly concept is focused on QuotaPulse while the machine-wide quick
// stats still report all five named projects. Keep four small monthly records
// for the other projects, outside the recent-session window.
for (let index = 1; index < referenceProjects.length; index++) {
  const id = 100 + index, source = [1, 3, 4, 2][index - 1]!;
  const model = referenceModels[index - 1]!;
  const at = fixedNow - 10 * 60_000;
  session.run(id, source, `fixture-project-${index}`, referenceProjects[index], at);
  const inputUsd = fixtureInputUsdPerMillion / 1_000_000;
  usage.run(source, id, `fixture-project-usage-${index}`, at, model.name, model.provider, 1, 0, 0, 1, 1,
    inputUsd, 'computed', inputUsd, 0, 0, 0, 0, model.provider);
}
// Values below the old visual minimum catch inflated nonzero bars in both charts.
const tinyUsage = db.prepare("INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source) VALUES (1,1,?,?,'DeepSeek V4.1','deepseek',1,0,0,1,1,0,'computed')");
tinyUsage.run('fixed-tiny-minute', fixedNow - 15 * 60_000);
tinyUsage.run('fixed-tiny-day', fixedNow - 3 * 86_400_000);
const quota = db.prepare('INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin) VALUES (?,?,?,?,?,?,?,?)');
const addQuotaSample = (sourceId: number, window: string, percent: number | null, resetAt: number | null, observedAt: number) => quota.run(sourceId, window, percent, resetAt, observedAt, observedAt, observedAt, 'fixed-fixture');
// Complete history must include older reset periods, nulls and more than eight
// readings per period, without changing the latest live quota/default selection.
for (let segment = 0; segment < 4; segment++) for (let index = 0; index < 12; index++) {
  const at = fixedNow - (5 - segment) * 3_600_000 + index * 60_000;
  addQuotaSample(1, '5h', index === 4 ? null : index === 1 ? 0.5 : index * 8, segment === 0 ? null : fixedNow - (4 - segment) * 3_600_000, at);
}
addQuotaSample(1, '5h', 38, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 5 * 60_000);
addQuotaSample(1, '5h', 83, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 30_000);
addQuotaSample(1, 'weekly', 62, fixedNow + (3 * 24 + 5) * 3_600_000, fixedNow - 30_000);
const monthlyReset = fixedNow + (6 * 24 + 2) * 3_600_000;
addQuotaSample(1, 'monthly', 59, monthlyReset, fixedNow - 48 * 3_600_000);
addQuotaSample(1, 'monthly', 65.5, monthlyReset, fixedNow - 24 * 3_600_000);
addQuotaSample(1, 'monthly', 72, monthlyReset, fixedNow - 30_000);
addQuotaSample(2, 'monthly', 58, fixedNow + (12 * 24 + 6) * 3_600_000, fixedNow - 30_000);
addQuotaSample(2, 'daily', 34, fixedNow + (7 * 60 + 18) * 60_000, fixedNow - 30_000);
recordQuotaAlerts(db, fixedNow);
const scheduler = new Scheduler(db, [], { pollMs: 1_000_000, detectMs: 1_000_000 });
const daemon = buildServer(db, scheduler, { token: 'stable-capture-test', port: 7816, webRoot: resolve(root, 'packages/web/dist') });

let browser:Awaited<ReturnType<typeof chromium.launch>>|undefined;
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const indexPath=resolve(root,'packages/web/dist/index.html'),index=sha(readFileSync(indexPath));
const results:unknown[]=[];
const targets={overview:'.qp-map-node[data-dimension=harness]',live:'.qp-live-table tbody tr',projects:'.qp-project-trend',history:'.qp-history-harness',providers:'.qp-provider-health tbody tr',alerts:'.qp-alert-risk>ul>li[data-level]'};
try{
 await daemon.listen({host:'127.0.0.1',port:7816});browser=await chromium.launch({channel:'chrome',headless:true});
 for(const [routeName,ready] of Object.entries(targets))for(const lang of ['en','th'])for(const theme of ['dark','light'])for(const width of [390,1672]){
  const name=[routeName,lang,theme,width].join('-'),context=await browser.newContext({viewport:{width,height:941},reducedMotion:'reduce',deviceScaleFactor:1,timezoneId:'Asia/Bangkok'});
  const page=await context.newPage();page.setDefaultTimeout(15000);const errors:string[]=[],forbidden:string[]=[];const pending=new Set<Request>();
  page.on('pageerror',error=>errors.push(error.message));page.on('response',response=>{if(response.status()>=400)errors.push(response.status()+' '+response.url())});
  page.on('request',request=>{if(new URL(request.url()).pathname.startsWith('/api/')&&!request.url().includes('/events/stream'))pending.add(request)});page.on('requestfinished',r=>pending.delete(r));page.on('requestfailed',r=>pending.delete(r));
  await page.route('**/*',route=>{const r=route.request(),u=new URL(r.url());if(u.origin!=='http://127.0.0.1:7816'||r.method()!=='GET'){forbidden.push(r.method()+' '+u.pathname);return route.abort()}return route.continue()});
  await page.addInitScript(({lang,theme})=>{(window as any).__QUOTAPULSE_TOKEN__='stable-capture-test';localStorage.setItem('quotapulse-prefs',JSON.stringify({lang,currency:'USD',rate:1,hiddenSubscriptions:[]}));localStorage.setItem('quotapulse-theme',theme)},{lang,theme});await installBrowserFixedDate(page,fixedNow);
  const dataResponse=routeName==='history'?page.waitForResponse(r=>r.url().includes('/api/usage-events?')&&r.status()===200):null;
  await page.goto('http://127.0.0.1:7816/#'+routeName,{waitUntil:'domcontentloaded'});await page.locator(ready).first().waitFor();await page.evaluate(()=>document.fonts.ready);
  let idle=0;const end=performance.now()+30000;while(idle<8){assert.ok(performance.now()<end);await page.waitForTimeout(40);idle=pending.size===0?idle+1:0}
  const marks=await page.locator('svg[data-dashboard-harness],svg[data-subscription-mark]').evaluateAll(nodes=>nodes.map(node=>({harness:node.getAttribute('data-dashboard-harness'),owner:node.getAttribute('data-subscription-mark'),hidden:node.getAttribute('aria-hidden'),focusable:node.getAttribute('focusable'),rect:node.getBoundingClientRect().toJSON(),ids:Array.from(node.querySelectorAll('defs [id]')).map(def=>def.id),fills:Array.from(node.querySelectorAll('[fill]')).map(child=>child.getAttribute('fill')).filter(fill=>fill?.startsWith('url(#')),parentHarness:node.closest('[data-harness]')?.getAttribute('data-harness')})));
  assert.ok(marks.length>0);const ids=marks.flatMap(mark=>mark.ids);assert.equal(new Set(ids).size,ids.length);
  for(const mark of marks){assert.equal(mark.hidden,'true');assert.equal(mark.focusable,'false');assert.ok(mark.rect.width>0&&mark.rect.height>0);if(mark.harness){assert.ok(['hermes','codex','claude-code','opencode'].includes(mark.harness));if(mark.parentHarness)assert.equal(mark.harness,mark.parentHarness)}else assert.equal(mark.owner,'opencode');for(const fill of mark.fills)assert.ok(mark.ids.includes(fill!.slice(5,-1)),'Gradient stays within its own glyph instance')}
  let apiFacts:any=null;
  if(routeName==='live'){
   const response=await daemon.inject({url:'/api/live-sessions?from='+(fixedNow-30*60_000)+'&to='+(fixedNow+1)+'&mode=recent&limit=10&offset=0',headers:{'x-quotapulse-token':'stable-capture-test'}});assert.equal(response.statusCode,200);const data=response.json();
   const rows=page.locator('.qp-live-table tbody tr');assert.equal(await rows.count(),data.rows.length);for(const [i,row] of data.rows.entries()){assert.equal(await rows.nth(i).locator('svg[data-dashboard-harness]').getAttribute('data-dashboard-harness'),row.harness);assert.equal(await rows.nth(i).locator('td').nth(6).locator('abbr').getAttribute('aria-label'),new Intl.NumberFormat(lang==='th'?'th-TH':'en-US').format(row.tokens))}apiFacts={rows:data.rows.length,recordedHarnessAndTokens:true};
  }
  if(routeName==='history'){
   const url=new URL((await dataResponse!).url()),response=await daemon.inject({url:url.pathname+url.search,headers:{'x-quotapulse-token':'stable-capture-test'}});assert.equal(response.statusCode,200);const rows=response.json().rows,icons=page.locator('.qp-history-harness');assert.equal(await icons.count(),rows.length);for(const [i,row]of rows.entries())assert.equal(await icons.nth(i).locator('svg[data-dashboard-harness]').getAttribute('data-dashboard-harness'),row.harness);apiFacts={rows:rows.length,recordedHarness:true};
  }
  if(routeName==='providers'){
   const response=await daemon.inject({url:'/api/overview',headers:{'x-quotapulse-token':'stable-capture-test'}});const data=response.json(),rows=page.locator('.qp-provider-health tbody tr');assert.equal(await rows.count(),data.sourceStatus.length);for(const [i,source]of data.sourceStatus.entries())assert.equal(await rows.nth(i).locator('svg[data-dashboard-harness]').getAttribute('data-dashboard-harness'),source.harness);apiFacts={readers:data.sourceStatus.length,recordedHarness:true};
  }
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);assert.deepEqual(errors,[]);assert.deepEqual(forbidden,[]);const frame=await page.screenshot({path:resolve(output,name+'.png'),animations:'disabled'});
  results.push({name,route:routeName,lang,theme,width,marks,apiFacts,sha256:sha(frame),errors,forbidden});console.log('Passed '+name);await context.close();
 }
 assert.equal(sha(readFileSync(indexPath)),index);writeFileSync(resolve(output,'verification.json'),JSON.stringify({status:'passed',index,browser:browser.version(),results},null,2));
}finally{await browser?.close();await daemon.close();db.close();globalThis.Date=realDate;process.env.TZ=priorTimezone}
