import { createRoot } from 'react-dom/client';
import { DashboardHarnessIcon, SubscriptionMark } from '../packages/web/src/redesign/dashboard-marks';
import { HarnessIcon } from '../packages/web/src/components/harness-icon';
import { VendorIcon } from '../packages/web/src/components/vendor-icon';

const harnesses=['hermes','codex','claude-code','opencode'],sizes=[8,14,16,24,32,44];
const fallback=[{harness:'future-tool',vendor:'anthropic',label:'Future Tool'},{harness:'codex-next',vendor:'openai',label:'Codex Next'},{harness:'opencode:beta',vendor:'opencode',label:'OpenCode beta'}];
createRoot(document.getElementById('root')!).render(<>
 {(['dark','light'] as const).map(theme=><section key={theme} className="qp-redesign" data-theme={theme} style={{background:theme==='dark'?'#08111e':'#f4f7fb',color:theme==='dark'?'#e3eeff':'#12304c',padding:16}}><h2>{theme}</h2><div className="samples">
  {harnesses.flatMap(harness=>sizes.map(size=><div key={harness+size} className="sample" style={{fontSize:size}}><DashboardHarnessIcon harness={harness}/><small>{harness} {size}</small></div>))}
  {sizes.flatMap(size=>[false,true].map(framed=><div key={size+String(framed)} className="sample" style={{fontSize:size}}><span style={{display:'inline-flex',background:framed?'transparent':'#6130c5',borderRadius:'.2em'}}><SubscriptionMark vendor="opencode" framed={framed}/></span><small>owner {size} {String(framed)}</small></div>))}
 </div></section>)}
 <section id="fallback">{fallback.map((props,index)=><div data-case={index} key={index}><div data-version="current"><DashboardHarnessIcon {...props} className="fixture-mark"/></div><div data-version="legacy"><HarnessIcon {...props} className="fixture-mark"/></div></div>)}
  {['openai','anthropic','future-provider'].map(vendor=><div data-owner-case={vendor} key={vendor}><div data-version="current"><SubscriptionMark vendor={vendor} className="fixture-mark"/></div><div data-version="legacy"><VendorIcon vendor={vendor} className="fixture-mark"/></div></div>)}
 </section>
</>);
