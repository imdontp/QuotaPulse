const fs=require('fs'),esbuild=require('esbuild');
(async()=>{
 const bundle=await esbuild.build({stdin:{contents:`import {renderToStaticMarkup} from 'react-dom/server';import {createElement} from 'react';import {HarnessIcon} from './packages/web/src/components/harness-icon';window.legacyHarness=(harness)=>renderToStaticMarkup(createElement(HarnessIcon,{harness,vendor:harness==='hermes'?'nous':harness==='claude-code'?'anthropic':harness==='codex'?'openai':'opencode'}));`,resolveDir:process.cwd(),loader:'tsx'},tsconfig:'packages/web/tsconfig.json',platform:'browser',format:'iife',bundle:true,write:false,jsx:'automatic'});
 fs.writeFileSync('tmp/legacy-marks128.js',bundle.outputFiles[0].text);
 let s=fs.readFileSync('tmp/capture-fidelity128.mts','utf8');
 s=s.replace("for (const [routeName, readySelector] of Object.entries(targets)) {","for (const [routeName, readySelector] of Object.entries(targets).filter(([name])=>name==='providers')) {");
 const point="    const geometry = await page.evaluate(() => {";
 const injection=`    await page.addScriptTag({path:resolve(root,'tmp/legacy-marks128.js')});
    const layout=()=>page.locator('.qp-provider-health tbody tr').evaluateAll(rows=>rows.map(row=>({text:row.textContent,rect:row.getBoundingClientRect().toJSON(),cells:[...row.children].map(cell=>cell.getBoundingClientRect().toJSON()),identity:row.querySelector('.qp-provider-reader-identity')!.getBoundingClientRect().toJSON()})));
    const current=await layout();
    await page.locator('.qp-provider-health svg[data-dashboard-harness]').evaluateAll(nodes=>nodes.forEach(node=>{node.outerHTML=(window as any).legacyHarness(node.getAttribute('data-dashboard-harness'));}));
    const legacy=await layout();
    writeFileSync(resolve(output,'table-layout-control.json'),JSON.stringify({index:productionIndexSha256,scope:'Same document and data, only four reader glyph DOMs replaced with original HarnessIcon output; no production code change',current,legacy},null,2));
    await page.screenshot({path:resolve(output,'legacy-reader-control.png'),animations:'disabled'});
`;
 if(!s.includes(point))throw Error('injection anchor missing');s=s.replace(point,injection+point);fs.writeFileSync('tmp/diagnose128-layout.mts',s);
})();
