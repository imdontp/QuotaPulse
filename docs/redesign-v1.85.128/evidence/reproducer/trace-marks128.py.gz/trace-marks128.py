from PIL import Image
import numpy as np
import hashlib,json
import math
from pathlib import Path

# Vector contours of the user-supplied small glyphs, not a new bitmap asset.
root=Path('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs')
out=Path('tmp/fidelity128');out.mkdir(parents=True,exist_ok=True)
def simplify_open(points,epsilon=.75):
    if len(points)<3:return points
    ax,ay=points[0];bx,by=points[-1];dx,dy=bx-ax,by-ay
    def distance(p):
        t=max(0,min(1,((p[0]-ax)*dx+(p[1]-ay)*dy)/(dx*dx+dy*dy))) if dx*dx+dy*dy else 0
        return math.hypot(p[0]-ax-t*dx,p[1]-ay-t*dy)
    distances=[distance(p) for p in points[1:-1]]
    index=1+int(np.argmax(distances))
    return simplify_open(points[:index+1],epsilon)[:-1]+simplify_open(points[index:],epsilon) if max(distances)>epsilon else [points[0],points[-1]]
def smooth_path(points):
    split=max(range(len(points)),key=lambda i:math.dist(points[0],points[i]))
    simple=simplify_open(points[:split+1])[:-1]+simplify_open(points[split:]+[points[0]])[:-1]
    if len(simple)<3:simple=points
    corners=[]
    for i,p in enumerate(simple):
        prev,nxt=simple[i-1],simple[(i+1)%len(simple)]
        radius=min(.18,math.dist(p,prev)/3,math.dist(p,nxt)/3)
        before=tuple(p[j]+(prev[j]-p[j])*radius/math.dist(p,prev) for j in [0,1])
        after=tuple(p[j]+(nxt[j]-p[j])*radius/math.dist(p,nxt) for j in [0,1])
        corners.append((before,p,after))
    xy=lambda p:f'{p[0]:.3f},{p[1]:.3f}'
    return 'M'+xy(corners[0][0])+''.join(('' if i==0 else 'L'+xy(a))+'Q'+xy(p)+' '+xy(b) for i,(a,p,b) in enumerate(corners))+'Z'
def outline(mask):
    edges=set()
    for y,x in zip(*np.where(mask)):
        x,y=int(x),int(y)
        for a,b in [((x,y),(x+1,y)),((x+1,y),(x+1,y+1)),((x+1,y+1),(x,y+1)),((x,y+1),(x,y))]:
            if (b,a) in edges:edges.remove((b,a))
            else:edges.add((a,b))
    paths=[]
    while edges:
        first=next(iter(edges));start,current=first;edges.remove(first);points=[start]
        while current!=start:
            points.append(current)
            options=[e for e in edges if e[0]==current]
            if not options:raise RuntimeError('Open contour')
            edge=options[0];edges.remove(edge);current=edge[1]
        # Merge collinear grid edges. The SVG renderer supplies antialiasing.
        simple=[]
        for i,p in enumerate(points):
            prev,nxt=points[i-1],points[(i+1)%len(points)]
            if (p[0]-prev[0])*(nxt[1]-p[1]) != (p[1]-prev[1])*(nxt[0]-p[0]):simple.append(p)
        if len(simple)>=3:paths.append(smooth_path(simple))
    return ''.join(paths)
specs=[('subscription','providers',(623,175,655,207),'white',None),('hermes','overview',(643,531,669,557),'dark-green',(5,5,20,20)),('codex','overview',(643,575,669,601),'white',(3,3,23,23)),('claude-code','overview',(643,619,669,645),'dark-orange',(4,4,22,22)),('opencode','overview',(643,663,669,689),'cyan',(4,4,22,22))]
result={}
for key,file,box,kind,inner in specs:
    data=(root/(file+'.png')).read_bytes();a=np.asarray(Image.open(root/(file+'.png')).convert('RGB')).astype(int);x,y,r,b=box;a=a[y:b,x:r]
    red,green,blue=a[:,:,0],a[:,:,1],a[:,:,2]
    if kind=='white':mask=(a.min(axis=2)>155)&(a.max(axis=2)-a.min(axis=2)<80)
    elif kind=='dark-green':mask=(red<55)&(green<145)&(blue<110)
    elif kind=='dark-orange':mask=(red<130)&(green<110)&(blue<105)
    else:mask=(green>145)&(blue>180)
    if inner:
        left,top,right,bottom=inner;region=np.zeros(mask.shape,dtype=bool);region[top:bottom,left:right]=True;mask&=region
    if key=='codex':
        mask=(a.min(axis=2)>115)&(a.max(axis=2)-a.min(axis=2)<150)&region
    if key=='claude-code':
        remaining=set(zip(*np.where(mask)))
        while remaining:
            first=remaining.pop();component={first};stack=[first]
            while stack:
                py,px=stack.pop()
                for point in [(py-1,px),(py+1,px),(py,px-1),(py,px+1)]:
                    if point in remaining:remaining.remove(point);component.add(point);stack.append(point)
            if len(component)<=3:
                for py,px in component:mask[py,px]=False
    result[key]={'reference':file+'.png','referenceSha256':hashlib.sha256(data).hexdigest(),'bounds':list(box),'inner':inner,'threshold':kind,'viewBox':[0,0,box[2]-box[0],box[3]-box[1]],'foregroundPixels':int(mask.sum()),'path':outline(mask),'samples':{f'{px},{py}':a[py,px].tolist() for px,py in [(2,2),(5,3),(21,3),(3,21),(21,21)] if px<a.shape[1] and py<a.shape[0]}}
    print(key,'pixels',mask.sum(),'path chars',len(result[key]['path']))
    for row in mask:print(''.join('#' if p else '.' for p in row))
(out/'traced-marks.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
