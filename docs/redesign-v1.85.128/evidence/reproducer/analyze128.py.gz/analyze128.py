from pathlib import Path
from PIL import Image
import numpy as np,json,math
root=Path('tmp/fidelity128')
load=lambda p:json.loads(p.read_text(encoding='utf8'))
before=load(root/'before/verification.json');after=load(root/'final/verification.json');rows=[]
for entry in after['results']:
    route=entry['route'];old=next(r for r in before['results'] if r['route']==route)
    a=np.asarray(Image.open(root/'before'/f'{route}.png').convert('RGB')).astype(int);b=np.asarray(Image.open(root/'final'/f'{route}.png').convert('RGB')).astype(int)
    d=np.abs(a-b);changed=d.max(axis=2)>0;yy,xx=np.where(changed);slots=np.zeros(changed.shape,dtype=bool);marks=load(root/'final'/f'{route}-marks.json')
    for mark in marks:
        r=mark['slot'];x0=max(0,math.floor(r['left'])-2);y0=max(0,math.floor(r['top'])-2);x1=min(changed.shape[1],math.ceil(r['right'])+2);y1=min(changed.shape[0],math.ceil(r['bottom'])+2);slots[y0:y1,x0:x1]=True
    outside=changed&~slots;oy,ox=np.where(outside)
    rows.append({'route':route,'changedPixels':int(changed.sum()),'maxChannelDelta':int(d.max()),'bbox':None if not len(xx) else [int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())],'mainGeometryEqual':old['geometry']['mainRegions']==entry['geometry']['mainRegions'],'beforeRepeatExact':old['repeatIdentical'],'afterRepeatExact':entry['repeatIdentical'],'glyphs':len(marks),'outsideNewGlyphSlotsPixels':int(outside.sum()),'outsideBounds':None if not len(ox) else [int(ox.min()),int(oy.min()),int(ox.max()),int(oy.max())]})
summary={'scope':'Whole before/after frames; slot localization is diagnostic only and is not a screenshot gate mask or similarity percentage','beforeIndex':before['productionIndexSha256'],'afterIndex':after['productionIndexSha256'],'rows':rows}
(root/'analysis.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode());print(json.dumps(summary))
