from pathlib import Path
from PIL import Image
import json,hashlib,gzip,subprocess,re,shutil
import numpy as np
root=Path('docs/redesign-v1.85.128');base=Path('tmp/fidelity128');root.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf8').lstrip('\ufeff'))
def write(p,value):
 p=root/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
def copy(src,dest,zipped=False):
 b=Path(src).read_bytes()
 if str(src).endswith('.log'):b=b.decode('utf-16' if b[:2] in [b'\xff\xfe',b'\xfe\xff'] else 'utf8').lstrip('\ufeff').replace('\r\n','\n').encode()
 if zipped:b=gzip.compress(b,mtime=0)
 p=root/dest;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
index=sha(Path('packages/web/dist/index.html').read_bytes());final=load(base/'final/verification.json');before=load(base/'before/verification.json');native=load(base/'native/verification.json');component=load(base/'component/verification.json');analysis=load(base/'analysis.json')
assert index==final['productionIndexSha256']==native['index']==analysis['afterIndex']
assert len(native['results'])==48 and native['status']=='passed' and component['status']=='passed'
assert len(final['results'])==8 and all(x['repeatIdentical'] for x in final['results'])
routes=[]
for r in final['results']:
 name=r['route'];original=Path('docs/redesign-v1.85.69/refs')/(name+'.png');assert sha(original.read_bytes())==r['referenceSha256']
 for phase,report in [('before',before),('final',final)]:
  source=base/phase/(name+'.png');assert sha(source.read_bytes())==next(x for x in report['results'] if x['route']==name)['sha256'];copy(source,'images/'+phase+'/'+name+'.png')
 routes.append({'route':name,'original':'../redesign-v1.85.69/refs/'+name+'.png','before':'images/before/'+name+'.png','final':'images/final/'+name+'.png','referenceSha256':r['referenceSha256']})
for folder in ['before','final','native','component']:copy(base/folder/'verification.json','evidence/'+folder+'.json.gz',True)
copy(base/'analysis.json','evidence/analysis.json')
copy(base/'component/gallery.png','images/gallery.png');copy(base/'component/gallery-grid-candidate.png','images/rejected-grid-gallery.png')
for name in ['traced-marks.json','layout-diagnosis/table-layout-control.json'] :copy(base/name,'evidence/'+Path(name).name)
copy(base/'layout-diagnosis/legacy-reader-control.png','images/providers-legacy-reader-control.png')
for p in ['trace-marks128.py','generate-marks128.cjs','capture-fidelity128.mts','check-marks128-native.mts','check-marks128.mjs','marks128-entry.tsx','analyze128.py','diagnose128-layout.cjs','diagnose128-layout.mts','check-viewer128.mjs','package128.py']:
 copy(Path('tmp')/p,'evidence/reproducer/'+p+'.gz',True)
for p in ['build128-web-final.log','test128-web-final.log','fidelity128-native-final.log','fidelity128-final.log','fidelity128-layout.log','stable128-all.log','stable128-providers.log','stable128-history.log']:copy(Path('tmp')/p,'evidence/logs/'+p+'.gz',True)
# Retain actual failed pairs, without inventing success manifests from stale files.
repeat=[]
for scope,folder,file in [('providers','providers-comparison','providers-th-dark.png'),('history','history-details','history-en-dark.png')]:
 a=Path('screens')/folder/file;b=a.with_name('repeat-'+file)
 assert a.exists() and b.exists()
 aa=np.asarray(Image.open(a).convert('RGB')).astype(int);bb=np.asarray(Image.open(b).convert('RGB')).astype(int);d=np.abs(aa-bb);m=d.max(2)>0;y,x=np.where(m)
 record={'scope':scope,'status':'failed','changedPixels':int(m.sum()),'maxChannelDelta':int(d.max()),'bbox':[int(x.min()),int(y.min()),int(x.max()),int(y.max())],'headerPixels':int(m[:60].sum()),'belowHeaderPixels':int(m[60:].sum()),'outsideSidebarHeaderPixels':int(m[60:,227:].sum()),'firstSha256':sha(a.read_bytes()),'repeatSha256':sha(b.read_bytes()),'index':index}
 repeat.append(record);copy(a,'images/repeat-failures/'+scope+'-first.png');copy(b,'images/repeat-failures/'+scope+'-repeat.png')
write('evidence/scoped-repeat-failures.json',repeat)
copy(base/'broad-grid/verification.json','evidence/earlier-broad-grid.json')
for name in ['providers-en-dark.png','repeat-providers-en-dark.png']:copy(base/'broad-grid'/name,'images/repeat-failures/earlier-'+name)
# Quantify diagnostic regions; these are not masks in any screenshot gate.
a=np.asarray(Image.open(base/'before/providers.png').convert('RGB')).astype(int);b=np.asarray(Image.open(base/'final/providers.png').convert('RGB')).astype(int);m=np.abs(a-b).max(2)>0
regions=[]
for name,x0,y0,x1,y1 in [('ownerPlate',580,130,690,245),('readerHealth',968,638,1650,790),('comparisonMark',680,750,720,785)]:regions.append({'name':name,'bounds':[x0,y0,x1,y1],'changedPixels':int(m[y0:y1,x0:x1].sum())});m[y0:y1,x0:x1]=False
assert not m.any()
control=load(base/'layout-diagnosis/table-layout-control.json');assert control['index']==index
a=np.asarray(Image.open(base/'before/providers.png').convert('RGB'));b=np.asarray(Image.open(base/'layout-diagnosis/legacy-reader-control.png').convert('RGB'));assert np.array_equal(a[638:790,968:1650],b[638:790,968:1650])
write('evidence/providers-diagnosis.json',{'scope':'Diagnostic localization, never used to relax or mask capture gates','regions':regions,'outsideRegionsPixels':0,'legacyReaderControlMatchesPriorHealthRegionExactly':True,'firstRowHeightCurrent':control['current'][0]['rect']['height'],'firstRowHeightLegacy':control['legacy'][0]['rect']['height'],'laterRowsShiftPx':control['current'][1]['rect']['y']-control['legacy'][1]['rect']['y']})
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+['packages/web/src/redesign/dashboard-mark-glyphs.ts','packages/web/src/redesign/dashboard-marks.tsx']
assert len(paths)==15 and all(p.startswith(('packages/web/src/','scripts/check-stable-captures.mts')) for p in paths)
sources=[{'path':p,'rawSha256':sha(Path(p).read_bytes()),'lfSha256':sha(Path(p).read_bytes().replace(b'\r\n',b'\n'))} for p in paths];write('source-fingerprints.json',sources)
protected=[]
for p in ['packages/web/src/components/harness-icon.tsx','packages/web/src/components/vendor-icon.tsx']:
 original=subprocess.check_output(['git','show','HEAD:'+p]);current=Path(p).read_bytes();assert original.replace(b'\r\n',b'\n')==current.replace(b'\r\n',b'\n');protected.append({'path':p,'headSha256':sha(original),'workingSha256':sha(current),'normalizedEqual':True})
write('evidence/protected-components.json',protected)
test=Path('tmp/test128-web-final.log').read_bytes();test=test.decode('utf-16' if test[:2]==b'\xff\xfe' else 'utf8');assert re.search(r'^# pass 335\r?$',test,re.M) and re.search(r'^# fail 0\r?$',test,re.M)
write('summary.json',{'checkpoint':'v1.85.128','parent':'7eebaeec81446c103f688345cb09ef47a8e3a4d7','index':index,'validation':'Partially validated: functional checks pass; distinct-document repeat gates remain red','webTests':335,'nativeBrowserCases':48,'componentGlyphs':72,'fallbackCases':6,'withinContextExactRepeats':8,'scopedRepeatFailures':repeat,'fullRedesignComplete':False,'currentRunnableZipSource':'v1.85.124 (review125), excludes126-128'})
write('review-manifest.json',{'checkpoint':'v1.85.128','index':index,'captures':routes})
(root/'README.md').write_text('''# Dashboard reference artwork v1.85.128

**Partially validated. Overall redesign and 99–100% reference fidelity are not achieved.**

[Open original / before / current comparison](review.html). Source build and evidence identifiers are in [summary.json](summary.json).

## Implementation

The dashboard now uses the reference-specific green Hermes, purple Codex, orange Claude Code and blue OpenCode badges, plus the white OpenCode Go subscription character on a purple plate. These are dashboard artwork reconstructed from the supplied concept, not a claim that they are official vendor logos. Original vendor/model marks and legacy fallback components are unchanged.

The four known harness IDs map exactly; unknown IDs retain the original fallback, without guessing from name prefixes. Subscription artwork selects the recorded OpenCode subscription identity. Existing names, source IDs, amounts, unknown/partial values and links remain real. The Pet and backend are unchanged. Six dashboard routes use the new marks; Models and Cost remain pixel identical in this canonical fixture. History integration is within its redesign branch.

SVG paths for Hermes, Codex, Claude Code and the subscription character come from thresholded contours of the supplied reference crops. Closed contour simplification uses 0.75 source-pixel tolerance and 0.18-pixel rounded corners. The blue OpenCode roundel is reconstructed with native SVG geometry; its diagnostic traced mask is not used in production. Initial pixel-grid contours were rejected after rendering the gallery. This remains an approximation requiring visual review, not measured 99% fidelity.

## Validation and remaining failures

- Production build, 335/335 web tests, 48 actual Chrome cases across six routes, EN/TH, dark/light and 390/1672 widths passed. Browser cases verify raw API harness identity, real values, unique gradients, decorative accessibility, no new focus stops, no page overflow and no forbidden writes. They use an isolated in-memory fixture, not customer data.
- Component gallery: 72 glyph instances at 8–44 px; six legacy fallback comparisons; 60 unique gradient IDs; no focus stops or browser errors.
- Eight source-sized pages repeat byte exactly within their own browser contexts. This is not the broader distinct-document repeat gate.
- The earlier full gate completed 36 first-pass page/language/theme captures, then failed on Providers (233 pixels, max channel delta20). The failure has 209 header and24 sidebar pixels, zero outside those regions. Its manifest excludes32 stale files. Only its failed pair is published here; the capture manifest records the40 fresh images, not72 purported fresh captures.
- Final scoped Providers and History repeat gates also FAILED: each125 pixels, max channel delta7. See scoped-repeat-failures.json for measured bounds and header/sidebar counts. No success manifest is claimed. No tolerance, screenshot mask, renderer flag or product workaround was added to force these gates green. Cause of the repeat variation is unresolved.

## Providers layout diagnosis

The20,356 changed pixels are confined to the subscription plate/glow (5,725), comparison artwork (285), and reader table (14,346). These regions are diagnostic only. In a same-document intervention, replacing just the four reader glyph DOMs with the original HarnessIcon output makes the health region pixel identical to the prior image. The new Hermes badge gives a16px identity line instead of14.84375px, increasing the first row from30.640625 to31.796875px and shifting subsequent rows1.15625px. The table remains readable; this is an explained layout consequence, not a claim that only glyph pixels changed. Main region geometry is unchanged across all eight pages. See the raw control measurements and retained control frame.

## Delivery limits

The latest runnable ZIP remains review125 built from source124; it does not include126–128. This checkpoint contains source and review evidence, not an updated application ZIP. Full visual parity, updated delivery, and the unresolved repeat gates remain work. Main is unchanged; this work is isolated on design/redesign-foundation.
''',encoding='utf8',newline='\n')
manifest=json.dumps({'captures':routes})
(root/'review.html').write_text('''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>QuotaPulse128 review</title><style>body{background:#08111e;color:#deecff;font:15px system-ui;margin:20px}a{color:#38c9ff}select{padding:8px;margin:5px}img{width:100%;height:auto;display:block;margin:12px 0;border:1px solid #234}</style><h1>QuotaPulse128</h1><p>Reference artwork review. Overall redesign incomplete; distinct-document repeat gates remain red. <a href="README.md">Evidence and limits</a></p><label>Page <select id="route">'''+''.join('<option>'+r['route']+'</option>' for r in routes)+'''</select></label><label>Frame <select id="phase"><option value="final">Current128</option><option value="original">Original concept</option><option value="before">Before127</option></select></label><p id="caption"></p><img id="image" alt="Selected dashboard frame"><h2>Current glyph gallery</h2><img src="images/gallery.png" alt="Glyphs at multiple sizes on dark and light surfaces"><script>const data='''+manifest+''',route=document.getElementById('route'),phase=document.getElementById('phase'),frame=document.getElementById('image');function render(){const row=data.captures.find(r=>r.route===route.value);frame.src=row[phase.value];document.getElementById('caption').textContent=route.value+' / '+phase.value}route.onchange=phase.onchange=render;render();</script></html>''',encoding='utf8',newline='\n')
def hash_artifacts():write('artifact-hashes.json',{str(p.relative_to(root)).replace('\\','/'):sha(p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file() and p.name!='artifact-hashes.json'})
hash_artifacts();print(json.dumps({'index':index,'sourceFiles':len(paths),'artifacts':len(load(root/'artifact-hashes.json')),'repeatFailures':repeat}))
