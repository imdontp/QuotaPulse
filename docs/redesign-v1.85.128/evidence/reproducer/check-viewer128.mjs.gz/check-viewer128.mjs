import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {chromium} from 'playwright';
const root=resolve('docs/redesign-v1.85.128');
const manifest=JSON.parse(readFileSync(resolve(root,'review-manifest.json')));
const browser=await chromium.launch({channel:'chrome',headless:true});
try {
 const page=await browser.newPage(),errors=[],cases=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(pathToFileURL(resolve(root,'review.html')).href);
 for(const row of manifest.captures)for(const phase of ['final','original','before']){
  await page.locator('#route').selectOption(row.route);await page.locator('#phase').selectOption(phase);
  await page.waitForFunction(({path,width})=>{const img=document.getElementById('image');return img.complete&&img.naturalWidth===width&&decodeURI(img.currentSrc).endsWith(path)},{path:row[phase].replace('../',''),width:row.route==='overview'?1586:1672});
  assert.equal(await page.locator('#caption').textContent(),row.route+' / '+phase);cases.push({route:row.route,phase});
 }
 assert.equal(await page.locator('img').last().evaluate(img=>img.complete&&img.naturalWidth>0),true);
 assert.deepEqual(errors,[]);writeFileSync(resolve(root,'evidence/viewer-verification.json'),JSON.stringify({status:'passed',browser:browser.version(),cases,galleryLoaded:true,errors},null,2)+'\n');
}finally{await browser.close()}
