import assert from 'node:assert/strict';
import { build } from 'esbuild';
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { chromium } from 'playwright';
const output=resolve('tmp/fidelity128/component');mkdirSync(output,{recursive:true});
const bundle=await build({entryPoints:[resolve('tmp/marks128-entry.tsx')],tsconfig:resolve('packages/web/tsconfig.json'),bundle:true,write:false,platform:'browser',format:'iife',jsx:'automatic'});
const browser=await chromium.launch({channel:'chrome',headless:true});
try{
 const page=await browser.newPage({viewport:{width:1100,height:1100},reducedMotion:'reduce'}),errors=[];page.on('pageerror',error=>errors.push(error.message));
 await page.setContent('<!doctype html><style>body{margin:0;font:14px system-ui}.samples{display:flex;flex-wrap:wrap;gap:12px}.sample{width:95px;min-height:70px;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:5px}.sample small{font-size:10px}.fixture-mark{width:20px;height:20px}.inline-block{display:inline-block}#fallback{padding:16px;background:#fafafa}</style><div id="root"></div>');await page.addScriptTag({content:bundle.outputFiles[0].text});
 await page.waitForFunction(()=>document.querySelectorAll('[data-dashboard-harness]').length===48);
 assert.equal(await page.locator('[data-subscription-mark]').count(),24);
 for(const selector of ['[data-case]','[data-owner-case]'])for(const row of await page.locator(selector).all())assert.equal(await row.locator('[data-version=current]').innerHTML(),await row.locator('[data-version=legacy]').innerHTML(),'Unknown harness and non-OpenCode subscriptions retain the legacy fallback exactly');
 const glyphs=page.locator('[data-dashboard-harness],[data-subscription-mark]');assert.equal(await glyphs.count(),72);
 for(const glyph of await glyphs.all()) {assert.equal(await glyph.getAttribute('aria-hidden'),'true');assert.equal(await glyph.getAttribute('focusable'),'false');const bounds=await glyph.boundingBox();assert.ok([8,14,16,24,32,44].includes(bounds.width)&&bounds.width===bounds.height);assert.ok(await glyph.locator('path,circle,rect').count()>0);}
 const ids=await glyphs.locator('defs linearGradient').evaluateAll(nodes=>nodes.map(node=>node.id));assert.equal(ids.length,new Set(ids).size,'Every gradient instance has a unique namespace');
 assert.equal(await page.locator('a,button,input,[tabindex]').count(),0,'Decorative glyphs add no focus stops');assert.deepEqual(errors,[]);
 await page.screenshot({path:resolve(output,'gallery.png'),fullPage:true});writeFileSync(resolve(output,'verification.json'),JSON.stringify({status:'passed',browser:browser.version(),harnessInstances:48,subscriptionInstances:24,smallestPixels:8,largestPixels:44,fallbackCases:6,gradientIds:ids.length,uniqueIds:true,noFocusStops:true,errors},null,2)+'\n');
}finally{await browser.close()}
