from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib,gzip,shutil,re
base=Path('tmp/fidelity134');out=Path('docs/redesign-v1.85.134');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,zipped=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if zipped:b=gzip.compress(b,mtime=0)
 p.write_bytes(b)
before=load('tmp/fidelity133/final/verification.json');after=load(base/'final/verification.json');matrix=load(base/'controls/verification.json');stable=load('screens/models-comparison/verification.json')
index=sha(Path('packages/web/dist/index.html').read_bytes())
assert before['productionIndexSha256']=='fb552adb920de673a9ae10c008adbe428269d5b07dffd3894fbe0a3870012926'
assert after['productionIndexSha256']==matrix['productionIndexSha256']==stable['productionIndexSha256']==index
assert matrix['status']=='passed'and len(matrix['results'])==16
assert len(stable['cases'])==4 and all(c['sha256']==c['repeatSha256']for c in stable['cases'])
rows=[];captures=[]
for entry in after['results']:
 route=entry['route'];prior=next(e for e in before['results']if e['route']==route)
 old=Path('tmp/fidelity133/final')/(route+'.png');new=base/'final'/(route+'.png')
 assert sha(old.read_bytes())==prior['sha256'];assert sha(new.read_bytes())==entry['sha256']
 a=np.asarray(Image.open(old).convert('RGB')).astype(int);b=np.asarray(Image.open(new).convert('RGB')).astype(int);delta=np.abs(a-b);mask=delta.max(2)>0;yy,xx=np.where(mask)
 rows.append({'route':route,'changedPixels':int(mask.sum()),'maxChannelDelta':int(delta.max()),'bounds':None if not len(xx)else[int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())],'mainGeometryEqual':prior['geometry']['mainRegions']==entry['geometry']['mainRegions'],'repeatExact':entry['repeatIdentical']})
 # The previous committed evidence is the hash-bound before image.
 manifest=load('docs/redesign-v1.85.133/review-manifest.json');oldpath=next(c for c in manifest['captures']if c['route']==route)['final']
 priorlink='../redesign-v1.85.133/'+oldpath;assert sha((out/priorlink).read_bytes())==prior['sha256']
 current=priorlink
 if entry['sha256']!=prior['sha256']:
  current='images/'+route+'.png';copy(new,current)
 original='../redesign-v1.85.69/refs/'+route+'.png';assert sha((out/original).read_bytes())==entry['referenceSha256']
 captures.append({'route':route,'original':original,'before':priorlink,'current':current})
assert all(r['changedPixels']==0 for r in rows if r['route']not in ['models','cost','providers'])
provider=next(r for r in rows if r['route']=='providers')
assert provider['bounds'] is None or provider['bounds'][3]<60
assert all(r['repeatExact']for r in rows)
write('analysis.json',{'scope':'Unmasked whole-frame source133/source134 differences, not a reference similarity score.','beforeIndex':before['productionIndexSha256'],'index':index,'rows':rows})
for name in ['en-dark-390','th-light-390','en-dark-1280','th-light-1355']:
 copy(base/'controls'/(name+'.png'),'images/controls/'+name+'.png')
copy(base/'token-wrap-before.png','images/token-wrap-before.png')
copy(base/'controls/verification.json','evidence/controls.json.gz',True);copy(base/'final/verification.json','evidence/all-eight.json.gz',True);copy('screens/models-comparison/verification.json','evidence/stable-models.json.gz',True)
for name in ['build134-final.log','test134-web-final.log','check-controls134-final.log','stable134-models-final.log','fidelity134-final.log','build134-controls.log','test134-web.log','stable134-models.log','stable134-models-copy-expectation.log','check-controls134-hidden-description.log']:
 copy('tmp/'+name,'evidence/logs/'+name+'.gz',True)
for name in ['check-controls134.mts','capture-fidelity134.mts','check-viewer134.mjs','package134.py']:
 copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
viewer=Path('tmp/viewer134.log').read_bytes();viewer=viewer.decode('utf-16'if viewer[:2]==b'\xff\xfe'else'utf-8').lstrip('\ufeff').strip();assert json.loads(viewer)=={'checked':24,'errors':[]};write('evidence/viewer.json',json.loads(viewer))
sources=['packages/web/src/redesign/models.tsx','packages/web/src/redesign/models.css','packages/web/src/redesign/model-ranking.ts','packages/web/test/model-ranking.test.ts','packages/web/src/i18n/en.ts','packages/web/src/i18n/th.ts','scripts/check-section-marks.mts','scripts/check-stable-captures.mts']
write('source-fingerprints.json',[{'path':p,'rawSha256':sha(Path(p).read_bytes()),'lfSha256':sha(Path(p).read_bytes().replace(b'\r\n',b'\n'))}for p in sources])
log=Path('tmp/test134-web-final.log').read_bytes();log=log.decode('utf-16'if log[:2]==b'\xff\xfe'else'utf-8');assert re.search(r'^# pass 344\r?$',log,re.M)and re.search(r'^# fail 0\r?$',log,re.M)
write('summary.json',{'checkpoint':'v1.85.134','parent':'9de690479cbea8487892c20abe93b173414b002e','index':index,'webTests':344,'browserCases':16,'stableExactPairs':4,'withinContextEightRepeatsExact':True,'distinctDocumentHeaderRepeatGate':'open: Providers 105 header pixels, cause unestablished','fullRedesignComplete':False,'latestRunnableZip':'review132/source131; excludes source133 and source134'})
write('review-manifest.json',{'index':index,'captures':captures})
(out/'README.md').write_text('''# Models reference controls v1.85.134

[Compare original, source133 and current](review.html). This is a validated bounded change; full redesign and 99–100% visual acceptance remain unproven.

The approved Models contract retains the original composition and requires period/metric filters plus stable sorting. The period selector now sits in the page header, beside an accessible refresh action. Search, provider, maker, metric and a working sort toggle occupy the comparison toolbar. Wide search placement and control widths follow the supplied reference; smaller windows retain intrinsic controls and visible labels. Shorter English/Thai headings follow the reference while preserving model/provider pair, distinct session, API value and native cost meanings. Pricing Coverage has an explanatory title. Maker remains distinct from recorded provider.

The toggle switches ascending/descending ranking for the selected metric, supports keyboard activation, and persists in the route URL. Default ranking remains descending. Missing API prices stay last in both directions; zero-call/known-zero values remain numeric zero; partial known amounts keep their partial annotation. Stable pair tie-breaks preserve null and empty identities. Ranking does not mutate response groups or change the summary request scope. Pagination/selection motion contexts include direction.

Human inspection found the large token summary splitting 721.0M across two lines at 390px. Long token values now use a full card row on narrow windows; desktop composition is unchanged. The before frame is retained. All four visible metric values are checked for a single glyph line in every browser case. The first new glyph check included the intentionally hidden cost coverage description; the harness was corrected to measure the visible cost span while keeping the accessible description intact, and its failed log is retained.

Validation: web build and 344 tests passed. Sixteen Chrome cases cover EN/TH, dark/light and widths 390/1280/1355/1672. An additional isolated unpriced pair verifies API ranking in both directions; each case checks keyboard toggle, URL reload, restored order, header range control, control containment and no page overflow/errors. The maintained Models gate passes four exact capture/repeat pairs, including its existing data/geometry/responsive assertions. Only explicit heading expectations changed after the first gate correctly rejected stale copy. Initial sandbox spawn EPERM logs and that failed gate are retained. No dependency or customer data was added.

Canonical whole-frame comparison uses the same synthetic fixture and clock as committed source133; five unrelated pages are byte-identical. Models and Cost are inspected in analysis.json; Cost intentionally inherits the shorter shared Provider header. Providers retains a 105-pixel difference confined to the global header (bounds 955,12–1362,46), consistent in location with the previously unresolved distinct-document repeat finding; its cause is not established. Main region geometry is unchanged on all eight routes. Within-context repeats are exact on all eight pages; this does not close the retained distinct-document header repeat finding, and no whole-page repeat acceptance is claimed.

The real application queries its existing daemon; synthetic data is restricted to QA. Native Electron, real-reader acceptance, performance/physical-window checks and donut interpolation are not newly verified here. Latest runnable ZIP remains review132/source131 and excludes source133/source134. The original gap ledger and full requirement trace remain open and authoritative. Main is unchanged.
''',encoding='utf-8',newline='\n')
html='''<!doctype html><meta charset="utf-8"><title>QuotaPulse Models controls review134</title><style>body{font:14px system-ui;background:#071020;color:#def;margin:20px}select{padding:8px}img{display:block;max-width:100%;margin:16px 0;border:1px solid #456}a{color:#5cf}</style><h1>Original / source133 / source134</h1><p>Real-data application UI; screenshots use isolated QA data. This comparison does not assert 99–100% fidelity.</p><a href="README.md">Validation and limitations</a><p><select id="route"></select><select id="phase"><option value="original">Original reference</option><option value="before">Source133</option><option value="current" selected>Source134</option></select></p><img id="frame" alt="Selected dashboard comparison"><script>const rows=DATA;const route=document.getElementById('route'),phase=document.getElementById('phase'),frame=document.getElementById('frame');for(const row of rows){const o=document.createElement('option');o.value=row.route;o.textContent=row.route;route.append(o)}route.value='models';function show(){frame.src=rows.find(row=>row.route===route.value)[phase.value]}route.onchange=phase.onchange=show;show()</script>'''.replace('DATA',json.dumps(captures))
(out/'review.html').write_text(html,encoding='utf-8',newline='\n')
write('artifact-hashes.json',{str(p.relative_to(out)).replace('\\','/'):sha(p.read_bytes())for p in sorted(out.rglob('*'))if p.is_file()and p.name!='artifact-hashes.json'})
print(json.dumps({'index':index,'rows':rows,'artifacts':len(load(out/'artifact-hashes.json'))}))
