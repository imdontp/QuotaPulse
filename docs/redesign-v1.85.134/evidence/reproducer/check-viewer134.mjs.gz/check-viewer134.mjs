import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const browser=await chromium.launch({channel:'chrome',headless:true});
try {
 const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(pathToFileURL(resolve('docs/redesign-v1.85.134/review.html')).href);
 const routes=await page.locator('#route option').evaluateAll(nodes=>nodes.map(n=>n.value));
 let checked=0;
 for(const route of routes)for(const phase of ['original','before','current']){
  await page.locator('#route').selectOption(route);await page.locator('#phase').selectOption(phase);
  await page.waitForFunction(()=>{const img=document.querySelector('#frame');return img.complete&&img.naturalWidth>0});checked++;
 }
 assert.equal(checked,24);assert.deepEqual(errors,[]);console.log(JSON.stringify({checked,errors}));
}finally{await browser.close()}
