from pathlib import Path
import gzip,hashlib,json,sys
out=Path('docs/redesign-v1.85.161');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,compressed=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not compressed and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0) if compressed else b)
def log(path):
 b=Path(path).read_bytes();return b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
before=load('tmp/fidelity160/final/verification.json');after=load('tmp/fidelity161/final/verification.json');focused=load('screens/cost-summary-trends/verification.json');diffs=load('tmp/fidelity161/analysis.json')
index=sha(Path('packages/web/dist/index.html').read_bytes())
assert before['productionIndexSha256']=='eae05bfd21d49a867f00080b36f87e94f661350d9bc0bdc60d453d8ba1cc0b0a'
assert after['productionIndexSha256']==focused['productionIndexSha256']==index and load('tmp/cost161-build-result.json')['status']==0
assert len(focused['cases'])==16 and len(focused['futureCases'])==len(focused['emptyCases'])==4 and focused['errors']==focused['external']==[]
assert '# pass 363' in log('tmp/cost161-web-tests.log') and '# fail 0' in log('tmp/cost161-web-tests.log')
assert 'complete elapsed reporting period with no calls' in log('tmp/cost161-web-tests.log')
assert 'History/Overview/Projects/Live/Providers/Models/Cost/Alerts E2E passed' in log('tmp/cost161-integration.log') and 'History teardown: database closed' in log('tmp/cost161-integration.log')
assert 'hmr update' not in log('tmp/cost161-integration.log') and 'page reload' not in log('tmp/cost161-integration.log')
assert 'PASS empty, unavailable, recovery; no page errors.' in log('tmp/cost161-ui.log')
matrix=load('screens/history/responsive-matrix.json');assert len(matrix['cases'])==144 and all(row['streams']<=1 for row in matrix['cases'])
assert len(after['results'])==8 and all(row['repeatIdentical'] and row['errors']==[] and row['forbidden']==[] for row in after['results'])
assert len([r for r in diffs if r['changedPixels']==0])==5
assert all(next(r for r in diffs if r['route']==name)['changedPixels']==105 for name in ['history','providers'])
assert next(r for r in diffs if r['route']=='cost')['bounds']==[502,236,1171,294]
ref=Path('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/cost.png');assert sha(ref.read_bytes())==next(r for r in after['results']if r['route']=='cost')['referenceSha256'];copy(ref,'refs/cost.png')
for phase,report,folder in [('before',before,'tmp/fidelity160/final'),('after',after,'tmp/fidelity161/final')]:
 p=Path(folder)/'cost.png';assert sha(p.read_bytes())==next(r for r in report['results']if r['route']=='cost')['sha256'];copy(p,phase+'/cost.png')
for name in ['history','providers']:copy('tmp/fidelity161/final/'+name+'.png','images/'+name+'-current.png')
for name in ['en-dark-1672-api','en-dark-1672-native','th-light-390-api','th-light-390-native']:copy('screens/cost-summary-trends/'+name+'.png','images/'+name+'.png')
copy('tmp/cost161-first-failure.png','images/first-unpriced-zero-failure.png')
for src,dst in [('tmp/fidelity160/final/verification.json','canonical-before.json'),('tmp/fidelity161/final/verification.json','canonical-current.json'),('tmp/fidelity161/analysis.json','comparison.json'),('screens/cost-summary-trends/verification.json','summaries.json'),('screens/history/verification.json','integration.json'),('screens/history/responsive-matrix.json','integration-matrix.json'),('tmp/cost161-build-result.json','build-result.json'),('tmp/cost161-first-failure.json','initial-failure.json'),('tmp/cost161-reference-colors.json','reference-colors.json'),('tmp/cost161-range-risk.json','open-range-risk.json'),('tmp/fidelity161/canonical-before-future.json','historical/canonical-before-future.json'),('tmp/fidelity161/comparison-before-future.json','historical/comparison-before-future.json'),('tmp/fidelity161/canonical-before-empty.json','historical/canonical-before-empty.json'),('tmp/fidelity161/comparison-before-empty.json','historical/comparison-before-empty.json')]:copy(src,'evidence/'+dst)
for src,dst in [('tmp/cost161-build.log','build'),('tmp/cost161-before.log','initial-unpriced-zero'),('tmp/cost161-summary.log','summaries'),('tmp/cost161-web-tests.log','web-tests'),('tmp/cost161-integration.log','integration'),('tmp/cost161-ui.log','legacy-ui'),('tmp/cost161-integration-hmr.log','development-provider-errors'),('tmp/cost161-ui-initial-load-timeout.log','initial-legacy-load-timeout'),('tmp/fidelity161-final.log','canonical-current')]:copy(src,'evidence/logs/'+dst+'.log.gz',True)
for name in ['capture-fidelity161.mts','diff161.py','build161.cjs','edit-cost161.py','refine-cost161.py','sample-cost161.py','package161.py','check-viewer161.mjs']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
sources={}
for name in ['packages/web/src/redesign/cost-summary-trends.ts','packages/web/test/cost-summary-trends.test.ts','packages/web/src/redesign/cost.tsx','packages/web/src/redesign/cost.css','packages/web/src/redesign/observed-trend.tsx','packages/web/src/i18n/en.ts','packages/web/src/i18n/th.ts','scripts/check-cost-summary-trends.mts']:
 b=Path(name).read_bytes();sources[name]={'rawSha256':sha(b),'lfSha256':sha(b.replace(b'\r\n',b'\n'))}
write('source-hashes.json',sources)
verified=(out/'evidence/viewer.json').exists()
if verified:
 viewer=load(out/'evidence/viewer.json');assert viewer['status']=='passed' and viewer['productionIndexSha256']==index and len(viewer['cases'])==2 and viewer['errors']==[]
else:assert '--draft'in sys.argv
write('delivery.json',{'parentCommit':'d970887e25fdd0850d89dc4d47c40348e17d5376','productionIndexSha256':index,'webTests':363,'newCalculationTests':10,'focusedCases':24,'fullIntegrationPassed':True,'responsiveCases':144,'legacyUiPassed':True,'canonicalRepeatPairs':8,'unchangedOtherFrames':5,'unexplainedHistoryPixels':105,'unexplainedProvidersPixels':105,'reviewPageVerified':verified,'nativeRevalidated':False,'newArchiveCreated':False,'largeRangeGuardImplemented':False,'fullGoalComplete':False})
write('gap-execution.json',{'authorityZipSha256':'28bc63571ddf7ecda1e12e8821c6184378ccfe6c3a599d6ccec29bf17fedb054','scope':'targeted Cost slice; not a whole-blueprint completion audit','gaps':[{'id':'GAP-006','execution':'IN_PROGRESS','thisSliceVerified':'selected-basis cumulative/interval monetary charts; unknown/zero/partial/future/empty distinctions'},{'id':'GAP-018','execution':'IN_PROGRESS','thisSliceVerified':'canonical fixture unchanged; separate explicitly named monetary boundary fixture reconciles1100tokens/15calls'},{'id':'GAP-020','execution':'IN_PROGRESS','thisSliceVerified':'EN/TH dark/light four widths, accessible numeric descriptions, existing responsive/legacy checks'}],'remaining':['named concept+override visual acceptance and approved implementation baseline','remaining screen art/typography/control/motion inventory','bounded Cost bin materialization for very long explicit intervals','current native artifact and broad desktop/performance/customer-provider acceptance','current full RC suite and two-version rollback']})
(out/'README.md').write_bytes('''# Actual Cost summary charts / source161

[Original / source160 / current gallery](review.html) · [Current Cost](after/cost.png) · [Native-basis fixture](images/en-dark-1672-native.png) · [Thai mobile fixture](images/th-light-390-api.png) · [Targeted blueprint audit](audit.md) · [Latest native ZIP review156](../redesign-v1.85.156/README.md)

Cost now has three real summary sparklines: known value by recorded interval, cumulative known value per elapsed24h, and cumulative known value per1K priced tokens. The latter two fill the reference's blue/cyan chart slots using actual selected-basis facts. They are explicitly labelled cumulative. The projected-month card remains Unknown with its existing reason; no missing forecast or concept curve is fabricated. Reference color sampling records the representative blue/cyan accents and nearest original pixels rather than asserting an exact match to every glow pixel.

An interval containing calls with no price is now a gap in the amount sparkline. A truly priced zero and a reporting interval with no calls remain zero. Cumulative monetary averages retain known-value lower bounds and call-weighted coverage. Per1K uses only the cumulative priced-token denominator, not all tokens or a mean of bucket ratios; its priced-subset quotient has no misleading+ suffix. Native/API facts stay separate. The final interval ends at the exact selected exclusive bound. Partial periods shorter than24h have no daily average. Ranges extending beyond the API snapshot have no elapsed average and explain why. A complete elapsed range with no calls has a zero average; no priced-token denominator stays Unknown.

Point titles use the current currency, exact covered-call counts and localized dates. Their numeric descriptions are also bound to the SVG's aria-describedby. The existing ObservedTrend defaults and other callers retain their formatting. No new request, dependency, schema, reader, credential, execution control, pet or popup behavior is added.

## Validation

Validated: production build;363 web tests including10 new calculation tests;24 compiled monetary cases; full existing dashboard integration including144 responsive cases; and the existing legacy/UI suite, including popup/hidden-subscription compatibility. Final integration ran with frozen source and no HMR updates. The focused cases cover EN/TH, dark/light,390/900/1280/1672 widths, USD/THB at37.25, API/native values, a partial final interval, unknown versus priced-zero samples, separate bases, exact cumulative denominators, accessible descriptions, four future and four empty-range checks. They use owned in-memory SQLite and real local HTTP, with no external request or customer data.

The controlled fixture has1100 tokens and15 weighted calls: API values2+6+0 with500 priced tokens and6 priced calls; native value4 with400 priced tokens and4 priced calls; five unpriced calls. API cumulative daily values are2,1,8/3,8/3.5 and per1K values20,20,20,16. The native amount has one known point, cumulative daily4/3 then4/3.5, and per1K10 then10. Future-selected time does not dilute an elapsed average. Zero-usage periods do not turn into missing-price periods.

The original compiled source160 reproduces the unpriced-interval defect as actual[2,0,6,0] versus expected[2,6,0]; its failed log and full frame are retained. A developmental integration run with live module reloads recorded useI18n provider errors. A separate legacy/UI attempt timed out on its initial10-second page load. Both failures remain in evidence; the same unrelaxed assertions pass in the final frozen runs. No production causal fix is claimed for those development/startup failures.

All eight current canonical within-context pairs are byte-identical. Cost changes are confined to502,236–1171,294 in the new summary charts. Five other full frames are byte-identical to source160. History and Providers each retain105 unexplained global-search-header pixels with maximum channel delta4; those full frames and differences remain unmasked. Earlier candidate reports are historical, not replacement baselines. No99–100% approval or whole-image similarity percentage is claimed.

```powershell
npm.cmd run build -w @quotapulse/web
npm.cmd run test -w @quotapulse/web
node --import tsx scripts/check-cost-summary-trends.mts
node --import tsx scripts/check-history.mts
npm.cmd run test:ui
```

Review156 remains the latest runnable native ZIP, containing source155 and excluding source157–161 changes. No native packaging, physical tray/monitor, broad performance/customer-provider or two-version migration/rollback acceptance was rerun here. Main and unrelated work are preserved; the full project remains open.
'''.encode())
(out/'audit.md').write_bytes('''# Targeted Cost audit and next unresolved work

Authority: blueprint v1.1 ZIP SHA25628bc63571ddf7ecda1e12e8821c6184378ccfe6c3a599d6ccec29bf17fedb054 was reopened and its Markdown/JSON read for this slice. This is a targeted audit, not a completed review of every numbered obligation.

| Rule | Current evidence | Position |
|---|---|---|
|00: real components, truthful data, functional controls; visual convenience ranks last | Existing summary slots use actual response points, cumulative arithmetic and the same resolved basis/scope; no concept curve | Verified for this slice |
|02: no calls means zero; all relevant calls unpriced means unavailable; priced zero is real zero; coverage is call-weighted | Original compiled failure plus10 unit and24 real-HTTP cases distinguish these states | Verified for new summaries |
|02: native and API amounts stay separate; only eligible complete/fresh call-grain month-to-date series may project | Native/API fixture values never mix; monthly projection remains explicitly unavailable | Safe unavailable branch retained; eligible projection capability unverified |
|03 and OVR017/022: preserve visual ambition without invented facts | Two previously empty nonforecast chart slots now use actual cumulative blue/cyan series; fixed original reference and full before/after frames retained | Improved, not approved whole-screen parity |
|03/05: responsive locales, keyboard/semantics and existing compatibility | New SVG descriptions,16 primary combinations and8 boundary cases; final144 matrix and legacy/UI suite | Bounded current evidence |
|05: max page/range validation and bounded render work | The Cost path still fills one slot per selected interval; scope parser only checks valid integer/date bounds | Open next implementation item |
|08/09: all screens and NEW_READ verified, named initial visual review, performance evidence and RC provenance | This slice changes eight web/test files; current build and reports are bound to hashes, but baseline acceptance/native/performance/rollback remain open | Whole application RC not established |
|13: preserve main, isolated app work, prior-client behavior and matching-artifact recovery | Existing branch/worktree/origin preserved; current legacy checks pass; review156/source155 remains the latest native package | Current native build and two-version rollback still required |

Cost's current response has11 top-level fields: now, scope, basis, totals, providers, models, projects, sessions, bucket, bucketMs and points. Neither its declared web interface nor returned object supplies an ingestion-completeness/source-freshness proof for the whole selected series. A successful request alone is not that proof. Keeping the monthly projection unavailable avoids inventing eligibility; this audit does not certify the eligible branch.

The next concrete performance item is supported by source/arithmetic inspection: selectedScope preserves explicit custom bounds; parseUsageScope accepts integer bounds through8640000000000000; Cost materializes ceil((to-from)/bucketMs) slots. At the fixed May17,2025 reference time, epoch-to-now hourly scope has485414 slots; the maximum accepted bound has2400000000 hourly slots. No enormous allocation or deliberate UI freeze was run, so no measured crash/CPU claim is made. Bound display/query work while retaining scope, requested-interval meaning, monetary bases and all facts; do not silently sample away money or label coarser bins hourly.

GAP006/018/020 remain IN_PROGRESS at project scope with this slice's evidence recorded separately. Earlier green builds, exact repeat pairs and the newer native ZIP do not substitute for all remaining art/typography/control/motion review, approved implementation baselines, current performance tests, customer/provider checks and two-version rollback. The user's full objective remains active.
'''.encode())
(out/'review.html').write_bytes('''<!doctype html><meta charset="utf-8"><title>Cost actual summary charts / source161</title><style>body{font:14px system-ui;margin:20px;background:#071020;color:#def}a{color:#5cf}select{padding:8px;margin:6px}section{display:grid;grid-template-columns:1fr 1fr;gap:12px}img{width:100%;border:1px solid #456}figure{margin:0}figcaption{margin:8px 0}@media(max-width:900px){section{grid-template-columns:1fr}}</style><h1>Cost / original, source160, source161</h1><p>Original concept and actual QA values differ. New blue/cyan charts use actual cumulative values; no missing projection is fabricated. <a href="README.md">Changes, evidence and limits</a></p><select id="left-source"><option value="refs">Original concept</option><option value="before">Before / source160</option></select><section><figure><figcaption id="left-label"></figcaption><img id="left" alt="Original or previous Cost frame"></figure><figure><figcaption>Current / source161</figcaption><img id="right" src="after/cost.png" alt="Current compiled Cost frame"></figure></section><script>const source=document.getElementById('left-source');function show(){document.getElementById('left-label').textContent=source.options[source.selectedIndex].text;document.getElementById('left').src=source.value+'/cost.png'}source.onchange=show;show()</script>'''.encode())
write('artifact-hashes.json',{p.relative_to(out).as_posix():sha(p.read_bytes())for p in sorted(out.rglob('*'))if p.is_file()and p.name!='artifact-hashes.json'})
print('Sealed',len(load(out/'artifact-hashes.json')),'artifacts; viewer verified:',verified)
