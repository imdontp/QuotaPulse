from pathlib import Path
p=Path('packages/web/src/redesign/cost.tsx');b=p.read_bytes()
def replace(old,new):
 global b
 old=old.encode();assert b.count(old)==1,old;b=b.replace(old,new.encode())
replace('costSummaryTrends(trend, data.scope, data.bucketMs)', 'costSummaryTrends(trend, data.scope, data.bucketMs, data.now)')
replace('  const pointDescription =', '  const averageValue = summaryTrends?.average.at(-1)?.value ?? null;\n  const futureRange = !!data && data.scope.to > data.now + 1;\n  const pointDescription =')
replace('fullDays > 0 && total!.pricedCalls > 0 ? <CostValue amount={total!.amount / elapsedDays}', 'averageValue !== null && total!.pricedCalls > 0 ? <CostValue amount={averageValue}')
replace("<small>{fullDays} {t('redesign.costDays')}</small>{fullDays > 0 && total!.pricedCalls > 0 && summaryChart('average', t('redesign.costDailyTrend'))}", "<small>{futureRange ? t('redesign.costFutureAverage') : <>{fullDays} {t('redesign.costDays')}</>}</small>{averageValue !== null && total!.pricedCalls > 0 && summaryChart('average', t('redesign.costDailyTrend'))}")
p.write_bytes(b)
for lang,value in {'en':'Selected range includes time after this snapshot','th':'ช่วงที่เลือกมีเวลาหลังข้อมูลชุดนี้'}.items():
 p=Path(f'packages/web/src/i18n/{lang}.ts');b=p.read_bytes();needle=b"  'redesign.costProjection':";assert b.count(needle)==1;p.write_bytes(b.replace(needle,f"  'redesign.costFutureAverage': '{value}',\n".encode()+needle))
p=Path('packages/web/test/cost-summary-trends.test.ts');s=p.read_text().replace("import { costSummaryTrends }", "import { costSummaryTrends as actualTrends }")
anchor='const day = 86_400_000, scope = { from: 0, to: 3.5 * day };'
extra="\nconst costSummaryTrends = (points: Parameters<typeof actualTrends>[0], range: Parameters<typeof actualTrends>[1], bucketMs: number) => actualTrends(points, range, bucketMs, range.to);"
assert s.count(anchor)==1;s=s.replace(anchor,anchor+extra)
s+='''
test('a future range cannot claim an elapsed daily average, while the inclusive-now1ms boundary stays valid', () => {
  const future = actualTrends(fixture, scope, day, 3 * day);
  assert.ok(future.average.every(p => p.value === null));
  assert.equal(future.perThousand.at(-1)!.value, 16);
  const boundary = actualTrends(fixture, scope, day, scope.to - 1);
  assert.equal(boundary.average.at(-1)!.value, 8 / 3.5);
});
''';p.write_text(s)
