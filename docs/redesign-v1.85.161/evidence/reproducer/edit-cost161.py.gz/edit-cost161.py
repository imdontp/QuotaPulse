from pathlib import Path
p=Path('packages/web/src/redesign/cost.tsx');b=p.read_bytes()
def replace(old,new):
 global b
 old=old.encode();assert b.count(old)==1,old[:80];b=b.replace(old,new.encode())
replace("import { CostValue, costValue } from './cost-value';","import { CostValue, costValue } from './cost-value';\nimport { costSummaryTrends, type CostSummaryPoint } from './cost-summary-trends';")
replace('  const pointDescription = (point: (typeof trend)[number]) =>', '  const summaryTrends = data ? costSummaryTrends(trend, data.scope, data.bucketMs) : null;\n  const pointDescription = (point: (typeof trend)[number]) =>')
needle="  const date = (at: number) => new Date(at).toLocaleString(lang === 'th' ? 'th-TH' : 'en-US', { dateStyle: 'short', timeStyle: 'short' });"
extra='''
  const summaryChart = (kind: 'amount' | 'average' | 'perThousand', label: string) => {
    const points: CostSummaryPoint[] = summaryTrends?.[kind] ?? [];
    return <ObservedTrend className="qp-cost-summary-trend" points={points.map(point => ({ ...point, value: point.value === null ? null : currency === 'THB' ? point.value * rate : point.value }))}
      language={lang} label={`${label} (${currency})`} pointTitle={({ at, index }) => {
        const point = points[index]!;
        const value = kind === 'perThousand' ? unitMoney(point.value!) : costValue(point.value!, point.pricedCalls, point.allCalls, money, t('redesign.unknownValue'));
        return `${date(at)} · ${value} · ${t('redesign.costCoverage')}: ${number(point.pricedCalls)} / ${number(point.allCalls)}`;
      }}/>;
  };'''
replace(needle,needle+extra)
replace('''{total!.pricedCalls > 0 && <ObservedTrend className="qp-cost-summary-trend" points={trend.map(point => ({ at: point.start, value: currency === 'THB' ? point.amount * rate : point.amount }))} language={lang} label={`${t('redesign.costTotal')} (${currency})`}/>}''', "{total!.pricedCalls > 0 && summaryChart('amount', t('redesign.costAmountTrend'))}")
replace("<small>{fullDays} {t('redesign.costDays')}</small></article>","<small>{fullDays} {t('redesign.costDays')}</small>{fullDays > 0 && total!.pricedCalls > 0 && summaryChart('average', t('redesign.costDailyTrend'))}</article>")
replace("<small>{t('redesign.costAllTokens')}: {f.tokens(total!.allTokens)}</small></article>","<small>{t('redesign.costAllTokens')}: {f.tokens(total!.allTokens)}</small>{total!.pricedTokens > 0 && summaryChart('perThousand', t('redesign.costUnitTrend'))}</article>")
p.write_bytes(b)
for lang,labels in {'en':{'costAmountTrend':'Known value by recorded interval','costDailyTrend':'Cumulative known value per elapsed 24h','costUnitTrend':'Cumulative known value per 1K priced tokens'},'th':{'costAmountTrend':'มูลค่าที่ทราบตามช่วงเวลาที่บันทึก','costDailyTrend':'มูลค่าที่ทราบสะสมเฉลี่ยต่อเวลาที่ผ่านไป 24 ชั่วโมง','costUnitTrend':'มูลค่าที่ทราบสะสมต่อโทเค็นที่มีราคา 1,000 โทเค็น'}}.items():
 p=Path(f'packages/web/src/i18n/{lang}.ts');b=p.read_bytes();needle=b"  'redesign.costProjection':";assert b.count(needle)==1
 added=''.join(f"  'redesign.{key}': '{value}',\n"for key,value in labels.items()).encode();p.write_bytes(b.replace(needle,added+needle))
