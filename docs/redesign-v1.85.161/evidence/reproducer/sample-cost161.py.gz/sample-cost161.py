from pathlib import Path
from PIL import Image
import json,hashlib,math
p=Path('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/cost.png');im=Image.open(p).convert('RGB');rows=[]
for name,box,color in [('average',(498,238,697,303),(0,157,255)),('unit',(974,238,1173,303),(0,215,239))]:
 samples=[(sum((a-b)**2 for a,b in zip(im.getpixel((x,y)),color)),x,y,im.getpixel((x,y)))for y in range(box[1],box[3])for x in range(box[0],box[2])]
 distance,x,y,rgb=min(samples)
 rows.append({'kind':name,'referenceBox':box,'selectedRepresentativeRgb':color,'nearestReferencePixel':{'x':x,'y':y,'rgb':rgb},'squaredDistance':distance})
Path('tmp/cost161-reference-colors.json').write_text(json.dumps({'referenceSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scope':'representative blue/cyan series accents only; original glow and antialias vary by pixel','samples':rows},indent=2)+'\n')
Path('tmp/cost161-range-risk.json').write_text(json.dumps({'method':'arithmetic/source inspection only; no huge array allocated or UI deliberately frozen','fixedReferenceNow':'2025-05-17T13:42:00Z','hourlySlotsFromEpoch':math.ceil((1747489320000+1)/3600000),'maximumAcceptedTimeBound':8640000000000000,'hourlySlotsAtMaximumAcceptedBound':math.ceil(8640000000000000/3600000),'mechanism':['scope.ts preserves explicit custom from/to/bucket','usage-scope.ts validates integer/date bounds without a bucket-count limit','cost.tsx fills Math.ceil((scope.to-scope.from)/bucketMs) slots before drawing'],'status':'open; actual large-range runtime behavior not measured','nextAction':'bound Cost display work for long explicit intervals without changing scope, monetary bases or dropping facts'},indent=2)+'\n')
print(json.dumps(rows))
