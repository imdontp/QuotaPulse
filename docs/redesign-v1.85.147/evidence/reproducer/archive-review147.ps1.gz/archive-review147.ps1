$ErrorActionPreference='Stop'
$inputRecord=Get-Content -LiteralPath 'tmp/release147/inputs.json' -Raw | ConvertFrom-Json
$bundle=(Resolve-Path -LiteralPath $inputRecord.bundle).Path
. ./scripts/review-profile.ps1
Assert-ReviewPlainPath $bundle
if(Test-Path -LiteralPath (Join-Path $bundle 'review-data')){throw 'Source bundle must remain unused'}
$archive=Join-Path (Split-Path -Parent $bundle) 'QuotaPulse-v1.85.146-review147.zip'
Assert-ReviewPlainPath $archive
if(Test-Path -LiteralPath $archive){throw 'Refusing to overwrite a prior archive'}
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$writer=[IO.Compression.ZipFile]::Open($archive,[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in @(Get-ChildItem -LiteralPath $bundle -File -Recurse -Force)){
 if($file.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Linked entries are not allowed'}
 $relative=$file.FullName.Substring($bundle.Length+1).Replace('\','/')
 [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($writer,$file.FullName,$relative,[IO.Compression.CompressionLevel]::Optimal)|Out-Null
}}finally{$writer.Dispose()}
$reader=[IO.Compression.ZipFile]::OpenRead($archive);$verified=0
try{foreach($entry in $reader.Entries){
 if($entry.FullName.Contains('\')){throw 'Noncanonical archive separator'}
 $original=Join-Path $bundle $entry.FullName
 $stream=$entry.Open();$sha=[Security.Cryptography.SHA256]::Create()
 try{$actual=([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose();$stream.Dispose()}
 $expected=(Get-FileHash -LiteralPath $original -Algorithm SHA256).Hash.ToLowerInvariant()
 if($actual -ne $expected){throw "Archive entry mismatch: $($entry.FullName)"};$verified++
}}finally{$reader.Dispose()}
$result=@{archive=$archive;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant();entries=$verified;allEntryBytesMatch=$true;sourceCommit=$inputRecord.sourceCommit;productionIndexSha256=$inputRecord.webIndexSha256}
[IO.File]::WriteAllText((Join-Path (Get-Location) 'tmp/release147/archive.json'),($result|ConvertTo-Json -Depth 5)+"`n",[Text.UTF8Encoding]::new($false))
$result|ConvertTo-Json -Depth 5
