$ErrorActionPreference='Stop'
. ./scripts/review-profile.ps1
$archive='C:\Users\TH12367283\Projects\QuotaPulse\tmp\worktrees\redesign-validation-v1.85.146\tmp\review-bundles\QuotaPulse-v1.85.146-review147.zip'
$archiveSha='ec9acc148315e1a7f3cb4c362bf3c088bc91aceaf3a76475fbf6382b5b346d25'
Assert-ReviewPlainPath $archive
if((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $archiveSha){throw 'Restorable review archive hash mismatch'}
$tempRoot=(Resolve-Path -LiteralPath ([IO.Path]::GetTempPath())).Path.TrimEnd('\')
$checks=@()
foreach($recordFile in @('tmp/release147/standalone-smoke/bundle-verification.json','tmp/release147/reader-smoke.json')){
 $record=Get-Content -LiteralPath $recordFile -Raw | ConvertFrom-Json
 if($record.status -ne 'passed' -or $record.archiveSha256 -ne $archiveSha -or $record.archive -ne $archive){throw 'Owned QA receipt mismatch'}
 $cleanupTargetAbsolute=(Resolve-Path -LiteralPath $record.extracted).Path
 if((Split-Path -Parent $cleanupTargetAbsolute).TrimEnd('\') -ne $tempRoot -or (Split-Path -Leaf $cleanupTargetAbsolute) -notmatch '^QuotaPulse-review-[a-zA-Z0-9]+$'){throw 'Cleanup escaped the exact owned temporary extraction directory'}
 if($cleanupTargetAbsolute -notin @('C:\Users\TH12367283\AppData\Local\Temp\QuotaPulse-review-7vtVpd','C:\Users\TH12367283\AppData\Local\Temp\QuotaPulse-review-nnkFrV')){throw 'Unexpected QA directory'}
 Assert-ReviewPlainPath $cleanupTargetAbsolute
 if(@(Get-ChildItem -LiteralPath $cleanupTargetAbsolute -Recurse -Force -Attributes ReparsePoint).Count -ne 0){throw 'Linked entries are not eligible for cleanup'}
 if((Get-FileHash -LiteralPath (Join-Path $cleanupTargetAbsolute 'packages/web/dist/index.html') -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'bbc7208eeeb1c4f9e4c36fb6f639c7a138447ddb67a5867ebd267c91adc4f240'){throw 'Extracted build fingerprint mismatch'}
 $state=Get-Content -LiteralPath (Join-Path $cleanupTargetAbsolute 'review-data/review-processes.json') -Raw | ConvertFrom-Json
 foreach($role in @('daemon','tray')){if(Get-Process -Id $state.$role.pid -ErrorAction SilentlyContinue){throw 'Recorded QA process is still alive; refusing cleanup'}}
 $bytes=(Get-ChildItem -LiteralPath $cleanupTargetAbsolute -Recurse -File -Force | Measure-Object Length -Sum).Sum
 $checks+=@{path=$cleanupTargetAbsolute;bytes=$bytes;receipt=$recordFile;recordedProcessesStopped=$true;archiveSha256=$archiveSha}
}
$freeBefore=([IO.DriveInfo]::new('C:\')).AvailableFreeSpace
foreach($check in $checks){Remove-Item -LiteralPath $check.path -Recurse -Force}
New-Item -ItemType Directory -Path tmp/release147 -Force | Out-Null
$result=@{kind='only two owned stopped QA extractions removed; source and review ZIP retained';checks=$checks;freeBefore=$freeBefore;freeAfter=([IO.DriveInfo]::new('C:\')).AvailableFreeSpace}
[IO.File]::WriteAllText((Join-Path (Get-Location) 'tmp/release147/cleanup147.json'),($result|ConvertTo-Json -Depth 6)+"`n",[Text.UTF8Encoding]::new($false))
$result|ConvertTo-Json -Depth 6
