from pathlib import Path
mapping={'release146':'release147','review146':'review147','v1.85.145':'v1.85.146',
 'cba8566897f1f34b723417a23f46ead4bf20a86a':'2fd5353173d5820fbf6407f8548ac76d689e0c6d',
 '5512414cbc49b60cd0e11cfec3da1ed99c30c4c6d923f4a9a2b3392c40b0189c':'bbc7208eeeb1c4f9e4c36fb6f639c7a138447ddb67a5867ebd267c91adc4f240'}
for name in ['build-review146.ps1','prepare-review146.cjs','archive-review146.ps1','extract-review146.ps1',
 'check-bundle146.mts','check-native-review146.mts','check-reader-archive146.mts','audit-review146.cjs']:
    source=Path('tmp',name).read_text(encoding='utf-8-sig')
    for before, after in mapping.items(): source=source.replace(before,after)
    if name=='check-native-review146.mts':
        source=source.replace("const plot=timeline.locator('svg[role=group]');", "assert.equal(await timeline.locator('svg[role=group]>polygon').count(),0,'Native single bucket must retain points without extrapolated areas');assert.equal(await timeline.locator('g[data-bucket-at]>circle').count(),2);const plot=timeline.locator('svg[role=group]');")
        source=source.replace('observedExtent:true,queryStartsAtEpoch:true', 'singleBucketPointsOnly:true,observedExtent:true,queryStartsAtEpoch:true')
    if name=='audit-review146.cjs':
        source=source.replace('assert.equal(row.observedExtent,true);', 'assert.equal(row.singleBucketPointsOnly,true);assert.equal(row.observedExtent,true);')
    Path('tmp',name.replace('146','147')).write_text(source,encoding='utf-8',newline='\n')
