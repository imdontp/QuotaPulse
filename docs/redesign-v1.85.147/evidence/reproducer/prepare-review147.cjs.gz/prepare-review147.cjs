const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),crypto=require('node:crypto');
const checkout='C:/Users/TH12367283/Projects/QuotaPulse/tmp/worktrees/redesign-validation-v1.85.146';
const built=JSON.parse(fs.readFileSync(path.join(checkout,'screens/tray-recovery/bundle-build.json')));
const receipt='tmp/release147/build/build.json';const record=JSON.parse(fs.readFileSync(receipt));
assert.equal(record.sourceCommit,'2fd5353173d5820fbf6407f8548ac76d689e0c6d');assert.equal(record.steps.length,6);assert.ok(record.steps.every(step=>step.exitCode===0));
const hash=crypto.createHash('sha256').update(fs.readFileSync(path.join(built.bundle,'packages/web/dist/index.html'))).digest('hex');assert.equal(hash,'bbc7208eeeb1c4f9e4c36fb6f639c7a138447ddb67a5867ebd267c91adc4f240');
fs.writeFileSync('tmp/release147/inputs.json',JSON.stringify({checkout,bundle:built.bundle,sourceCommit:record.sourceCommit,buildReceipt:path.resolve(receipt),webIndexSha256:hash},null,2)+'\n');
console.log(JSON.stringify({bundle:built.bundle,sourceCommit:record.sourceCommit,index:hash}));
