/** Probe a remaining limitation using owned synthetic transcript files only. */
import assert from 'node:assert/strict';
import { readFileSync, statSync, utimesSync, writeFileSync, writeFileSync as save } from 'node:fs';
import { join, resolve } from 'node:path';
import { openDb, upsertSource } from '../packages/daemon/src/db/index.js';
import { codexAdapter } from '../packages/daemon/src/adapters/codex.js';
import { claudeCodeAdapter } from '../packages/daemon/src/adapters/claude-code.js';
import { runPass } from '../packages/daemon/src/ingest/runner.js';
import { health } from '../packages/daemon/src/api/queries.js';
import { tmpRoot, writeCodexProfile, writeClaudeProfile } from '../packages/daemon/test/fixtures.js';

const results = [];
for (const [harness, adapter, create] of [
  ['codex', codexAdapter, writeCodexProfile], ['claude-code', claudeCodeAdapter, writeClaudeProfile],
] as const) {
  const root = join(tmpRoot('qp-same-mtime-'), 'profile'), file = create(root);
  const stamp = new Date('2025-01-01T00:00:00Z');
  utimesSync(file, stamp, stamp);
  const profile = { profile:'fixture', rootPath:root, displayName:`Fixture ${harness}` };
  const db = openDb(':memory:');
  try {
    const sourceId = upsertSource(db, { harness, ...profile });
    const source = { adapter, profile, sourceId };
    await runPass(db, [source]);
    const original = readFileSync(file, 'utf8');
    const changed = harness === 'codex' ? original.replace('"input_tokens":10000', '"input_tokens":90000') : original.replace('"input_tokens":12', '"input_tokens":92');
    assert.notEqual(changed, original); assert.equal(Buffer.byteLength(changed), Buffer.byteLength(original));
    const before = statSync(file);
    await new Promise(resolve => setTimeout(resolve, 30));
    writeFileSync(file, changed, 'utf8'); utimesSync(file, stamp, stamp);
    const after = statSync(file);
    assert.equal(after.size, before.size); assert.equal(after.mtimeMs, before.mtimeMs);
    await runPass(db, [source]);
    const warnings = health(db).transcriptParseWarnings as Array<{unverifiedFiles:number}>;
    results.push({ harness, contentChanged:true, sameSize:true, sameMtime:true, sameCtime:after.ctimeMs===before.ctimeMs, ctimeDeltaMs:after.ctimeMs-before.ctimeMs, sameFileId:after.ino===before.ino && after.dev===before.dev, unverifiedWarnings:warnings.length });
  } finally { db.close(); }
}
save(resolve('tmp/integrity253/ctime-probe-final.json'), JSON.stringify({fixture:'synthetic; owned temporary files', results}, null, 2)+'\n');
console.log(JSON.stringify(results));
