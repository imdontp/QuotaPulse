/** One-time metadata baseline benchmark, synthetic local SQLite only. */
import { join, resolve } from 'node:path';
import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { performance } from 'node:perf_hooks';
import { openDb, upsertSource } from '../packages/daemon/src/db/index.js';
import { DbCursorStore } from '../packages/daemon/src/ingest/cursor.js';
import { tmpRoot } from '../packages/daemon/test/fixtures.js';

const count=5000, root=tmpRoot('qp-ctime-bench-'), db=openDb(join(root,'bench.db'));
try {
  const source=upsertSource(db,{harness:'codex',profile:'fixture',rootPath:'/synthetic',displayName:'Fixture'});
  const insert=db.prepare("INSERT INTO ingest_state (source_id,target_key,kind,byte_offset,file_size,file_mtime,meta,last_ok_at) VALUES (?,?, 'file',100,100,10,'{}',1)");
  db.transaction(()=>{for(let i=0;i<count;i++) insert.run(source,`/synthetic/${i}.jsonl`)})();
  const cursor=new DbCursorStore(db,source), start=performance.now();
  for(let i=0;i<count;i++){const key=`/synthetic/${i}.jsonl`;assert.equal(cursor.updateMeta(key,{jsonlObservedCtimeMs:10}),true);}
  const durationMs=performance.now()-start;
  const verified = db.prepare("SELECT COUNT(*) AS count FROM ingest_state WHERE source_id=? AND meta LIKE '%jsonlObservedCtimeMs%'").get(source) as {count:number};
  assert.equal(verified.count,count);
  const result={fixture:'synthetic local SQLite WAL; no filesystem scan',count,durationMs,perSecond:count/durationMs*1000};
  writeFileSync(resolve('tmp/integrity253/ctime-benchmark-verified.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result));
} finally { db.close(); }
