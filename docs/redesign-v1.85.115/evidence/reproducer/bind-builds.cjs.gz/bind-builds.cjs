const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto'),zlib=require('node:zlib'),{execFileSync}=require('node:child_process');
const {inventory}=require('../scripts/check-release-rollback.cjs');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const git='C:/Users/TH12367283/AppData/Local/Programs/Git/cmd/git.exe';
const roots={previous:'C:/Users/TH12367283/Projects/QuotaPulse/tmp/worktrees/redesign-rollback-v1.80',current:'C:/Users/TH12367283/Projects/QuotaPulse/tmp/worktrees/redesign-validation-v1.85.114'};
const commits={previous:'6f5759344e16756c41cf2e6e335e65b89ab5b777',current:'00bf157f0f6c7ed95746b56b35dba9f134e1676d'};
const bound={gitExecutable:git};
for(const role of ['previous','current']){
 const checkout=roots[role],out='tmp/rollback115/'+role;
 const receipt=JSON.parse(fs.readFileSync(out+'/build.json','utf8'));
 const expectedSteps=role==='previous'?['daemon-build','web-build','tray-build','tray-package-with-tests','review-bundle']:['daemon-build','web-build','tray-build','repository-tests','approved-runtime-assets','review-bundle'];
 assert.deepEqual(receipt.steps.map(step=>step.name),expectedSteps);assert.ok(receipt.steps.every(step=>step.exitCode===0));
 const head=execFileSync(git,['-C',checkout,'rev-parse','HEAD'],{encoding:'utf8'}).trim();assert.equal(head,commits[role]);
 const built=JSON.parse(fs.readFileSync(checkout+'/screens/tray-recovery/bundle-build.json'));
 const runtime=inventory(built.bundle);
 for(const [file,expected] of Object.entries(runtime))assert.equal(sha(fs.readFileSync(path.join(checkout,file))),expected,file);
 const full={};let petFiles=0;
 function walk(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){const file=path.join(dir,entry.name);assert.equal(fs.lstatSync(file).isSymbolicLink(),false);if(entry.isDirectory())walk(file);else if(entry.isFile()){const relative=path.relative(built.bundle,file).replaceAll('\\','/');full[relative]=sha(fs.readFileSync(file));if(relative.startsWith('packages/tray/assets/pets/')){const source=path.join(checkout,'packages/tray/dist-package/pets',relative.slice('packages/tray/assets/pets/'.length));assert.equal(sha(fs.readFileSync(source)),full[relative],relative);petFiles++;}}}}
 walk(built.bundle);
 const sourceFiles=execFileSync(git,['-C',checkout,'ls-files','--','package.json','package-lock.json','tsconfig.base.json','packages/daemon','packages/web','packages/tray','scripts/build-review-bundle.mts','scripts/task-entry.cjs','scripts/start-review.ps1','scripts/stop-review.ps1','scripts/review-profile.ps1','scripts/install-review.ps1','scripts/uninstall-review.ps1'],{encoding:'utf8',maxBuffer:8*1024*1024}).trim().split('\n');
 const sourceHashes={};for(const file of sourceFiles)sourceHashes[file]=sha(fs.readFileSync(path.join(checkout,file)));
 fs.writeFileSync(out+'/full-bundle-sha256.json.gz',zlib.gzipSync(Buffer.from(JSON.stringify(full,null,2)+'\n')));
 fs.writeFileSync(out+'/checkout-files-sha256.json.gz',zlib.gzipSync(Buffer.from(JSON.stringify(sourceHashes,null,2)+'\n')));
 const provenance={sourceCommit:head,checkoutRoot:checkout,runtimeRawSha256:runtime,buildReceiptSha256:sha(fs.readFileSync(out+'/build.json')),fullBundleInventoryPath:path.resolve(out+'/full-bundle-sha256.json.gz'),fullBundleInventorySha256:sha(fs.readFileSync(out+'/full-bundle-sha256.json.gz')),checkoutInventorySha256:sha(fs.readFileSync(out+'/checkout-files-sha256.json.gz')),bundleFiles:Object.keys(full).length,runtimeFiles:Object.keys(runtime).length,approvedPetFilesCompared:petFiles,webIndexSha256:runtime['packages/web/dist/index.html']};
 fs.writeFileSync(out+'/provenance.json',JSON.stringify(provenance,null,2)+'\n');
 bound[role+'Bundle']=built.bundle;bound[role+'Provenance']=path.resolve(out+'/provenance.json');
 console.log(JSON.stringify({role,sourceCommit:head,runtimeFiles:provenance.runtimeFiles,bundleFiles:provenance.bundleFiles,approvedPetFiles:petFiles,webIndexSha256:provenance.webIndexSha256}));
}
fs.writeFileSync('tmp/rollback115/inputs.json',JSON.stringify(bound,null,2)+'\n');
const originals={};for(const file of ['scripts/check-review-version-rollback.ps1','scripts/check-review-version-rollback.cjs'])originals[file]=sha(fs.readFileSync(file));
fs.writeFileSync('tmp/rollback115/original-scaffold-hashes.json',JSON.stringify(originals,null,2)+'\n');
