const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root='C:/Users/TH12367283/Projects/QuotaPulse/tmp/worktrees/redesign-validation-v1.85.114/tmp/release-rollback/run-5729fe59cc63438bad23edcba1147717';
const json=file=>JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''));
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const report=json(root+'/verification.json');
assert.equal(report.status,'passed actual two-checkout rollback');assert.equal(report.stages.length,4);assert.equal(report.wholeGoalComplete,false);
assert.deepEqual(report.stages.map(stage=>stage.name),['previous-seeded','current-upgrade','previous-rollback','current-recovery']);
const baseline=fs.readFileSync(report.baseline),data=json(report.baseline),stages=[];
for(const [index,stage] of report.stages.entries()){
 assert.equal(stage.sourceCommit,index%2===0?report.identities.previous.sourceCommit:report.identities.current.sourceCommit);
 assert.equal(stage.durableSnapshotEqual,true);assert.equal(stage.ownedProcessesTerminal,true);assert.equal(stage.processes.length,2);
 assert.deepEqual(fs.readFileSync(stage.snapshot),baseline);
 const before=json(stage.installed),after=json(stage.afterStopInstalled),live=json(stage.live);
 assert.equal(before.fullPackageEqual,true);assert.equal(after.fullPackageEqual,true);assert.equal(before.fullFiles,index%2===0?3135:3155);
 assert.equal(live.usage.rows.length,3);assert.equal(live.readersDisabled,true);
 for(const process of stage.processes){assert.ok(process.commandLine.includes(process.expectedEntry));assert.ok(process.commandLine.includes(process.expectedData));assert.ok(process.commandLine.includes('--no-readers'));}
 stages.push({name:stage.name,sourceCommit:stage.sourceCommit,fullFiles:before.fullFiles,servedWebFiles:Object.keys(live.served).length,exactStoppedSnapshotSha256:sha(fs.readFileSync(stage.snapshot)),rootsTerminal:true});
}
for(const [file,expected] of Object.entries(json('tmp/rollback115/original-scaffold-hashes.json')))assert.equal(sha(fs.readFileSync(file)),expected,'Original untracked scaffold changed');
const summary={status:'passed actual four-stage cycle',productUi:'unchanged114',sourceCommits:{previous:report.identities.previous.sourceCommit,current:report.identities.current.sourceCommit},fixture:root,installationRoot:json(root+'/fixture.json').installationRoot,baselineSha256:sha(baseline),schema:data.schemaVersion.value,fixtureRows:{sources:data.sources.length,sessions:data.sessions.length,usage:data.usage.length,quotas:data.quotas.length,alerts:data.alerts.length,cursors:data.cursors.length,rollups:data.rollups.length},initialization:json(root+'/initialization.json'),stages,archives:report.archives,originalScaffoldsPreserved:true,limitations:report.limitations};
fs.writeFileSync('tmp/rollback115/summary.json',JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify(summary,null,2));
