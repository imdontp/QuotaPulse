$ErrorActionPreference='Stop'
$fixture='C:\Users\TH12367283\Projects\QuotaPulse\tmp\worktrees\redesign-validation-v1.85.114\tmp\release-rollback\run-6656250d363a4d06b8c0aab459468f7d'
$metadata=Get-Content -LiteralPath (Join-Path $fixture 'fixture.json') -Raw | ConvertFrom-Json
$target=$metadata.installationRoot
$result=@()
try{
  & (Join-Path $target 'start.ps1') -Port 7818
  $marker=Get-Content -LiteralPath (Join-Path $target 'installation.json') -Raw | ConvertFrom-Json
  $runtime=Join-Path (Join-Path $target 'releases') $marker.active
  $state=Get-Content -LiteralPath (Join-Path $target 'review-data\review-processes.json') -Raw | ConvertFrom-Json
  foreach($role in @('daemon','tray')){
    $record=$state.$role
    $proc=Get-CimInstance Win32_Process -Filter "ProcessId=$([int]$record.pid)"
    if(-not $proc){throw 'Owned probe process not live'}
    $entry=Join-Path $runtime 'scripts\task-entry.cjs'
    $data=Join-Path $target 'review-data'
    $normalizedCreated=if($record.created -is [DateTime]){$record.created.ToUniversalTime().ToString('O')}else{[DateTime]::Parse($record.created,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind).ToUniversalTime().ToString('O')}
    $result+=@{role=$role;pid=$record.pid;commandLine=$proc.CommandLine;executablePath=$proc.ExecutablePath;expectedEntry=$entry;normalizedExpectedEntry=[IO.Path]::GetFullPath($entry);expectedData=$data;normalizedExpectedData=[IO.Path]::GetFullPath($data);createdType=$record.created.GetType().FullName;createdString=[string]$record.created;normalizedCreated=$normalizedCreated;actualCreated=$proc.CreationDate.ToUniversalTime().ToString('O');entryContains=$proc.CommandLine.Contains($entry);dataContains=$proc.CommandLine.Contains($data);roleContains=$proc.CommandLine.Contains("--role $role");noReadersContains=$proc.CommandLine.Contains('--no-readers');normalizedCreationMatches=($proc.CreationDate.ToUniversalTime().ToString('O') -eq $normalizedCreated)}
  }
  [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'rollback115\process-identity-diagnosis.json'),($result|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
}finally{& (Join-Path $target 'stop.ps1')}
