import json
from pathlib import Path
from PIL import Image, ImageChops
root=Path('tmp/axes118')
def compare(a,b,box=None):
    left=Image.open(a).convert('RGB');right=Image.open(b).convert('RGB')
    if box:left=left.crop(box);right=right.crop(box)
    channels=ImageChops.difference(left,right).split();delta=ImageChops.lighter(ImageChops.lighter(channels[0],channels[1]),channels[2]);hist=delta.histogram()
    return dict(changedPixels=sum(hist[1:]),maxChannelDelta=max(i for i,n in enumerate(hist)if n),bounds=delta.getbbox())
report={}
for route in ['models','projects']:
    old=json.loads((root/f'before/{route}-trend.json').read_text());new=json.loads((root/f'after/{route}-trend.json').read_text())
    for key in ['label','points','lines']:assert old['plot'][key]==new['plot'][key],(route,key)
    if route=='projects':assert old==new,'Shared Projects axes and geometry changed'
    report[route]=dict(preservedPoints=len(new['plot']['points']),preservedNormalizedPlot=True,oldPlot=old['plot']['rect'],newPlot=new['plot']['rect'],axes=len(new['axes']),beforeAfter=compare(root/f'before/{route}.png',root/f'after/{route}.png'),repeat=compare(root/f'after/{route}.png',root/f'after/{route}-repeat.png'))
    if route=='models':
        report[route]['controls']={name:compare(root/'before/models.png',root/'after/models.png',box)for name,box in dict(header=(0,0,1672,60),sidebar=(0,60,226,941),primary=(226,60,1275,941),upperDetail=(1275,60,1672,528)).items()}
manifest=json.loads((root/'after/verification.json').read_text())
report['productionIndexSha256']=manifest['productionIndexSha256'];report['scope']='Recorded-value axes in Models; shared Projects preservation; not full visual acceptance'
(root/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
