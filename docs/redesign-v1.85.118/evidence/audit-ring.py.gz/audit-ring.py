import json
from pathlib import Path
from PIL import Image, ImageChops
base=Path('screens/models-comparison');out=Path('tmp/axes118');
a=Image.open(base/'models-en-dark.png').convert('RGB');b=Image.open(base/'repeat-models-en-dark.png').convert('RGB')
channels=ImageChops.difference(a,b).split();d=ImageChops.lighter(ImageChops.lighter(channels[0],channels[1]),channels[2]);h=d.histogram();total=sum(h[1:]);ring=0
for y in range(375,512):
    for x in range(1510,1650):
        if a.getpixel((x,y))!=b.getpixel((x,y)):ring+=1
old=json.loads((base/'models-en-dark.png.ring.json').read_text());new=json.loads((base/'repeat-models-en-dark.png.ring.json').read_text())
report=dict(changedPixels=total,ringPixels=ring,otherPixels=total-ring,maxChannelDelta=max(i for i,n in enumerate(h)if n),bounds=d.getbbox(),ringDomPaintInputsEqual=old==new,scope='Current original gate failure; ring changes exceed unchanged tolerance, cause unproven')
out.mkdir(exist_ok=True);(out/'ring-failure.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
