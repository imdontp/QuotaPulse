from pathlib import Path
import datetime, json, os, shutil, subprocess

root = Path(__file__).resolve().parents[1]
out = root / 'tmp/release236'
assert not out.exists()
out.mkdir()
git = lambda *args: subprocess.check_output(['git', *args], cwd=root, text=True).strip()
source = git('rev-parse', 'HEAD')
assert source.startswith('194cafb')
assert not git('status', '--porcelain', '--untracked-files=no', '--', 'packages', 'scripts', 'package.json', 'package-lock.json', 'tsconfig.base.json')
node = Path(shutil.which('node'))
npm = node.parent / 'node_modules/npm/bin/npm-cli.js'
assert npm.is_file()
runner = (root / 'tmp/run-repository162.cjs').read_text(encoding='utf-8').replace('cost162', 'review236')
(root / 'tmp/run-repository230.cjs').write_text(runner, encoding='utf-8', newline='\n')
commands = [
 ('daemon-build', [str(npm), 'run', 'build', '-w', '@quotapulse/daemon']),
 ('web-build', [str(npm), 'run', 'build', '-w', '@quotapulse/web']),
 ('tray-build', [str(npm), 'run', 'build', '-w', '@quotapulse/tray']),
 ('repository-tests', ['tmp/run-repository230.cjs']),
 ('approved-runtime-assets', ['--import', 'tsx', 'packages/tray/scripts/package-assets.ts']),
 ('review-bundle', ['--import', 'tsx', 'scripts/build-review-bundle.mts']),
]
steps = []
env = dict(os.environ, QUOTAPULSE_REVIEW_CHECKPOINT='v1.85.235-review236')
for name, args in commands:
    assert git('rev-parse', 'HEAD') == source
    assert not git('diff', 'HEAD', '--', 'packages', 'scripts', 'package.json', 'package-lock.json', 'tsconfig.base.json')
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    logpath = out / (name + '.log')
    with logpath.open('w', encoding='utf-8') as log:
        result = subprocess.run([str(node), *args], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    steps.append({'name': name, 'exitCode': result.returncode, 'reused': False, 'startedUtc': started, 'finishedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'log': str(logpath)})
    (out / 'build.json').write_text(json.dumps({'sourceCommit': source, 'checkout': str(root), 'steps': steps}, indent=2) + '\n', encoding='utf-8')
    assert result.returncode == 0, name
    print(name, 'passed', flush=True)
bundle = json.loads((root / 'screens/tray-recovery/bundle-build.json').read_text(encoding='utf-8'))['bundle']
record = {'checkout': str(root), 'bundle': bundle, 'sourceCommit': source, 'buildReceipt': str(out / 'build.json')}
(out / 'inputs.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record, indent=2), flush=True)
