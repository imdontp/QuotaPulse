from pathlib import Path
root = Path(__file__).resolve().parents[1]
for stem, ext in [('check-archive-rollback', 'ps1'), ('check-archive-rollback', 'cjs'), ('check-rollback-native', 'mts')]:
    src = (root / 'tmp' / f'{stem}231.{ext}').read_text(encoding='utf-8')
    src = src.replace('rollback231', 'rollback236').replace('native231', 'native236')
    if ext == 'cjs':
        assert '[3161,3163].includes(provenance.entries)' in src
        src = src.replace('[3161,3163].includes(provenance.entries)', '[3163,3165].includes(provenance.entries)')
    dest = root / 'tmp' / f'{stem}236.{ext}'
    assert not dest.exists()
    dest.write_text(src, encoding='utf-8', newline='\n')
src = (root / 'tmp/create-rollback231-provenance.py').read_text(encoding='utf-8')
src = (src.replace('tmp/rollback231', 'tmp/rollback236')
       .replace("('previous','docs/redesign-v1.85.224/archive.json','QuotaPulse-v1.85.223-review224.zip')", "('previous','docs/redesign-v1.85.230/archive.json','QuotaPulse-v1.85.229-review230.zip')")
       .replace("('current','docs/redesign-v1.85.230/archive.json','QuotaPulse-v1.85.229-review230.zip')", "('current','tmp/release236/archive.json','QuotaPulse-v1.85.235-review236.zip')")
       .replace("d['entries'] in (3161,3163)", "d['entries'] in (3163,3165)"))
assert "'tmp/release236/archive.json'" in src and "'docs/redesign-v1.85.230/archive.json'" in src
dest = root / 'tmp/create-rollback236-provenance.py'
assert not dest.exists()
dest.write_text(src, encoding='utf-8', newline='\n')
print('Prepared review230 to review236 rollback drivers')
