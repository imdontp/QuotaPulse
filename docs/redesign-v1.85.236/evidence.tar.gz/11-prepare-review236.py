from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[1]
old = '429877f92b9b6f5df275550fb57bb2a3573c82af'
new = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert new.startswith('194cafb')
names = ['build-review230.py', 'check-native-review230.mts', 'deliver-review230.ps1',
         'extract-review230.ps1', 'check-bundle230.mts', 'check-reader-archive230.mts',
         'check-install230.ps1', 'check-installed230.cjs', 'prepare-cleanup230.py', 'cleanup230.ps1']
for name in names:
    source = (root / 'tmp' / name).read_text(encoding='utf-8-sig')
    source = (source.replace(old, new).replace("startswith('429877f')", "startswith('194cafb')")
              .replace('review230', 'review236').replace('release230', 'release236')
              .replace('installed230', 'installed236').replace('cleanup230', 'cleanup236')
              .replace('v1.85.229', 'v1.85.235')
              .replace(r'v1\.85\.229', r'v1\.85\.235'))
    destination = root / 'tmp' / name.replace('230', '236')
    assert not destination.exists(), destination
    assert old not in source and 'release230' not in source and 'review230' not in source
    if name == 'check-native-review230.mts':
        assert "rgb(57, 224, 178)" in source
    destination.write_text(source, encoding='utf-8', newline='\n')
print('Prepared review236 drivers for', new)
