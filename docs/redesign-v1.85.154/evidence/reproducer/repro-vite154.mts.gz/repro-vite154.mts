import assert from 'node:assert/strict';
import {request} from 'node:http';
import {once} from 'node:events';
import {setTimeout as delay} from 'node:timers/promises';
import {writeFileSync} from 'node:fs';
import {createServer} from 'vite';
import {openDb} from '../packages/daemon/src/db/index.js';
import {buildServer} from '../packages/daemon/src/api/server.js';
import {Scheduler} from '../packages/daemon/src/ingest/scheduler.js';
function deferred(){let resolve!:()=>void;const promise=new Promise<void>(r=>resolve=r);return{promise,resolve}}
const results=[];
for(const early of [false,true]){
 const db=openDb(':memory:'),scheduler=new Scheduler(db,[]),app=buildServer(db,scheduler,{token:'owned-proxy-test',port:0});
 const entered=deferred(),release=deferred(),downClosed=deferred();let raw:any;
 app.addHook('preHandler',async(req,reply)=>{if(req.url.startsWith('/api/events/stream')){raw=reply.raw;entered.resolve();await release.promise}});
 await app.listen({host:'127.0.0.1',port:0});const address=app.server.address() as any;
 console.log('daemon listening',early,address.port);
 const vite=await createServer({configFile:false,root:'packages/web',optimizeDeps:{noDiscovery:true,entries:[]},server:{watch:null,host:'127.0.0.1',port:0,proxy:{'/api':{target:`http://127.0.0.1:${address.port}`,changeOrigin:true,configure:early?proxy=>{proxy.on('proxyReq',(upstream,req,res)=>{if(!req.url?.startsWith('/api/events/stream'))return;res.once('close',()=>upstream.destroy());if(res.destroyed)upstream.destroy()})}:undefined}}}});
 await vite.listen();const proxyAddress=vite.httpServer!.address() as any;console.log('proxy listening',early,proxyAddress.port);
 vite.httpServer!.once('request',(_req,res)=>res.once('close',downClosed.resolve));
 const client=request({host:'127.0.0.1',port:proxyAddress.port,path:'/api/events/stream',headers:{'x-quotapulse-token':'owned-proxy-test'}});client.on('error',()=>{});client.end();
 try{
  await Promise.race([entered.promise,delay(5000,undefined,{ref:false}).then(()=>{throw Error('handler not entered')})]);console.log('handler entered',early);client.destroy();await Promise.race([downClosed.promise,delay(5000,undefined,{ref:false}).then(()=>{throw Error('downstream not closed')})]);console.log('downstream closed',early);await delay(50);
  const upstreamClosedBeforeRelease=raw.destroyed;release.resolve();await delay(50);
  results.push({early,upstreamClosedBeforeRelease,data:scheduler.listenerCount('data'),settings:scheduler.listenerCount('settings')});console.log('measured',JSON.stringify(results.at(-1)));
 }finally{release.resolve();client.destroy();raw?.destroy();await vite.close();await app.close();db.close()}
}
writeFileSync('tmp/vite154-repro.json',JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results));assert.equal(results[0].data,1);assert.equal(results[1].data,0);
