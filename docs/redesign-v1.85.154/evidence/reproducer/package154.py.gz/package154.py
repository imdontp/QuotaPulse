from pathlib import Path
import gzip,hashlib,json
out=Path('docs/redesign-v1.85.154');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,compressed=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not compressed and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0) if compressed else b)
def log(path):
 b=Path(path).read_bytes();return b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
assert '# pass 1' in log('tmp/vite154-before-tests.log') and '# fail 1' in log('tmp/vite154-before-tests.log')
assert '# pass 2' in log('tmp/vite154-after-tests.log') and '# fail 0' in log('tmp/vite154-after-tests.log')
assert '# pass 353' in log('tmp/vite154-web-tests.log') and '# fail 0' in log('tmp/vite154-web-tests.log')
assert '# pass 3' in log('tmp/vite154-direct-sse.log') and '# fail 0' in log('tmp/vite154-direct-sse.log')
assert 'Quota chart uses stretched coordinates' in log('tmp/vite154-integration.log') and 'History teardown: database closed' in log('tmp/vite154-integration.log')
matrix=load('screens/history/responsive-matrix.json');assert len(matrix['cases'])==144 and all(row['streams']<=1 for row in matrix['cases'])
repro=load('tmp/vite154-repro.json');assert repro==[{'early':False,'upstreamClosedBeforeRelease':False,'data':1,'settings':1},{'early':True,'upstreamClosedBeforeRelease':True,'data':0,'settings':0}]
index=sha(Path('packages/web/dist/index.html').read_bytes());assert index==load('docs/redesign-v1.85.153/delivery.json')['productionIndexSha256']=='047c35f7e6bd34cf7eb86ec5c65419266968dada8e1ec566317371f3bbede3c1'
for src,dst in [('tmp/vite154-repro.json','reproduction.json'),('screens/history/responsive-matrix.json','integration-matrix.json')]:copy(src,'evidence/'+dst)
for src,dst in [('tmp/vite154-repro.log','reproduction'),('tmp/vite154-before-tests.log','before-regression'),('tmp/vite154-after-tests.log','after-regression'),('tmp/vite154-web-tests.log','web-tests'),('tmp/vite154-direct-sse.log','direct-sse'),('tmp/vite154-typecheck.log','config-typecheck'),('tmp/vite154-integration.log','integration')]:copy(src,'evidence/logs/'+dst+'.log.gz',True)
for name in ['repro-vite154.mts','package154.py']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
sources={}
for name in ['packages/web/vite.config.ts','packages/web/vite-sse-proxy.ts','packages/web/test/vite-sse-proxy.test.ts','scripts/check-history.mts']:
 b=Path(name).read_bytes();sources[name]={'rawSha256':sha(b),'lfSha256':sha(b.replace(b'\r\n',b'\n'))}
write('source-hashes.json',sources)
write('delivery.json',{'parentCommit':'4d3ab6cf560f1d982ef975ebe643b73655542771','productionIndexSha256':index,'webTests':353,'proxyRegressionTests':2,'earlyAbortCycles':8,'directDaemonSseTests':3,'fullIntegrationPassed':False,'fullIntegrationFailure':'Alerts: Quota chart uses stretched coordinates','responsiveCases':144,'configTypecheckExitCode':0,'productionRendererRebuilt':False,'nativeRevalidated':False,'newArchiveCreated':False,'devProxyBeforeHeadersDefectFixed':True,'historicalIntegrationIntermittenceFullyExplained':False,'fullGoalComplete':False})
(out/'README.md').write_bytes('''# Dev proxy canceled SSE cleanup / source154

The shipped Vite development proxy could retain a daemon SSE subscription when the browser disconnected before upstream response headers. The daemon is still waiting in an asynchronous hook, so it cannot know that the downstream browser has gone: the proxy leaves its own upstream socket alive. Once the hook resumes, the daemon correctly starts an SSE stream for that still-live socket, leaving one data and one settings listener with no browser consumer.

An isolated real HTTP reproduction holds the authenticated daemon preHandler, closes the downstream client, then releases the handler. With the previous dev proxy, the upstream is still open and listener counts become1/1. With early downstream-close forwarding, the upstream is already destroyed before release and counts remain0/0. The daemon's existing abort guard from source149 is unchanged and handles the forwarded abort correctly. This causal control distinguishes the proxy defect from a daemon listener cleanup failure.

The fix binds downstream response close during proxyReq, before headers can arrive, and destroys that upstream request. It also checks response.destroyed in case close has already occurred. It applies only to the exact /api/events/stream pathname and preserves token query parameters. Normal requests remain unchanged. A small typed helper is shared by the actual vite.config.ts and the existing full integration harness, which previously carried its own early-close callback. No new dependency, production transport, runtime API or data schema is introduced.

## Validation

The new regression loads the actual shipped dev proxy options. Before the fix, the canceled-before-headers case fails because the upstream close never arrives; the live-stream case passes. After the fix both pass. Eight controlled early-abort cycles leave both listener counts0. The second case confirms hello/data delivery, an independent successful health request without ending SSE, and actual upstream response close after normal client disconnect. Cleanup destroys owned response sockets only after assertions; it does not replay close events to satisfy them. All test resources terminate.

All353 web tests pass with0 failures/skips/cancellations, including these2 new tests. The3 direct daemon SSE abort/disconnect/shutdown regressions pass independently. The maintained full dashboard integration completes its144 responsive cases with at most one server listener after navigation, but later FAILS in checkAlertsLayout: Quota chart uses stretched coordinates. The complete suite therefore does not pass. That assertion's original width/viewBox values were not included in the old error message, so the exact geometry and root cause remain unproven. The chart initializes its coordinate width to600 and measures it in a ResizeObserver effect; a timing hypothesis must still be tested rather than assumed. Its assertions and cleanup budget are unchanged; only the duplicated proxy configure callback now references the shared helper. TypeScript checking of vite.config.ts and vite-sse-proxy.ts exited0 with no diagnostics. The proxy fix is validated in isolation; broader integration remains partially validated until the Alerts failure is resolved.

```powershell
node --import tsx --test packages/web/test/vite-sse-proxy.test.ts
npm.cmd run test -w @quotapulse/web
node --import tsx --test packages/daemon/test/sse-lifetime.test.ts
node --import tsx scripts/check-history.mts
node C:/Users/TH12367283/Projects/QuotaPulse/node_modules/typescript/bin/tsc --noEmit --skipLibCheck --target ES2022 --module ESNext --moduleResolution Bundler packages/web/vite-sse-proxy.ts packages/web/vite.config.ts
```

The current compiled renderer index remains exactly source153 047c35f7e6bd34cf7eb86ec5c65419266968dada8e1ec566317371f3bbede3c1, verified against its committed delivery manifest; no renderer rebuild, native run or new ZIP was needed for this dev-server change. The source153 visual gallery remains current. Review150 remains the previous runnable ZIP and does not include source151–154.

## Bounds of the conclusion

This fixes the demonstrated shipped-development-proxy defect. It does not establish the cause of every historical server2/client1 integration failure: source152's integration already installed an early-close callback, so that separate intermittent observation remains unexplained. The current144-case transport portion does not close that investigation. The newly observed Alerts coordinate assertion,105 Providers header pixels and3 Models edge pixels from source153, original reference99–100% approval, remaining visual/control/motion, native/customer/provider, tray/monitor, performance and migration/rollback acceptance remain open. Main and unrelated work are preserved. Evidence includes exact red/green logs, causal measurements, the full integration failure log and completed matrix, source hashes and reproducible owned-fixture code.
'''.encode())
write('artifact-hashes.json',{p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='artifact-hashes.json'})
print('Sealed',len(load(out/'artifact-hashes.json')),'artifacts')
