import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { chromium } from 'playwright';
const before=JSON.parse(readFileSync('tmp/reference103/verification.json','utf8'));
const after=JSON.parse(readFileSync('tmp/reference104/verification.json','utf8'));
const browser=await chromium.launch({channel:'chrome',headless:true});const results=[];
try{
 const page=await browser.newPage();
 for(const entry of after.results){
  const prior=before.results.find(item=>item.route===entry.route);
  assert.deepEqual(entry.geometry,prior.geometry,entry.route+': main/sidebar/headings/stats geometry changed');
  const pixels=await page.evaluate(async ({a,b})=>{
   const decoded=await Promise.all([a,b].map(async source=>{const img=new Image();img.src='data:image/png;base64,'+source;await img.decode();const canvas=document.createElement('canvas');canvas.width=img.width;canvas.height=img.height;const ctx=canvas.getContext('2d')!;ctx.drawImage(img,0,0);return {width:img.width,height:img.height,data:ctx.getImageData(0,0,img.width,img.height).data};}));
   const [aImage,bImage]=decoded;let changed=0,outsideHeader=0,maxChannelDelta=0,maxOutsideHeaderDelta=0;const samples=[];
   for(let y=0;y<aImage.height;y++)for(let x=0;x<aImage.width;x++){const i=(y*aImage.width+x)*4;let delta=0;for(let c=0;c<4;c++)delta=Math.max(delta,Math.abs(aImage.data[i+c]-bImage.data[i+c]));if(delta){changed++;maxChannelDelta=Math.max(maxChannelDelta,delta);if(y>=60){outsideHeader++;maxOutsideHeaderDelta=Math.max(maxOutsideHeaderDelta,delta);if(samples.length<100)samples.push({x,y,before:[...aImage.data.slice(i,i+4)],after:[...bImage.data.slice(i,i+4)]});}}}
   return {changed,outsideHeader,maxChannelDelta,maxOutsideHeaderDelta,outsideSamples:samples};
  },{a:readFileSync('tmp/reference103/'+entry.route+'.png').toString('base64'),b:readFileSync('tmp/reference104/'+entry.route+'.png').toString('base64')});
  results.push({route:entry.route,geometryIdentical:true,...pixels});console.log(entry.route+': '+pixels.changed+' total; '+pixels.outsideHeader+' outside edited header; max outside delta '+pixels.maxOutsideHeaderDelta);
 }
 const status=results.every(item=>item.outsideHeader===0)?'PASS':'RED';
 writeFileSync('tmp/workspace104-controls.json',JSON.stringify({status,masks:false,beforeIndexSha256:before.productionIndexSha256,afterIndexSha256:after.productionIndexSha256,scope:'Every pixel counted. y>=60 is separately checked as outside the intentionally edited header. Main/sidebar/headings/QuickStats DOM geometry must remain identical.',results},null,2));
 assert.equal(status,'PASS','Unexplained cross-build raster changes outside the edited header');
}finally{await browser.close();}
