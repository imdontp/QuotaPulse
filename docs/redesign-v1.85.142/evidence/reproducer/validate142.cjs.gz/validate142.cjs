const cp=require('child_process'),fs=require('fs'),assert=require('assert/strict');
for(const[script,log,env]of [['tmp/check-history142.mts','tmp/history142-matrix-final.log',{}],['tmp/capture-fidelity142.mts','tmp/fidelity142-final.log',{QP_FIDELITY_PHASE:'final',QP_FIDELITY_ONLY:''}]]){
 const fd=fs.openSync(log,'w'),r=cp.spawnSync(process.execPath,['--import','tsx',script],{env:{...process.env,...env},stdio:['ignore',fd,fd],windowsHide:true});fs.closeSync(fd);assert.equal(r.status,0,script);console.log('Passed '+script);
}
