import assert from 'node:assert/strict';
import {readFileSync,writeFileSync}from'node:fs';
import {resolve}from'node:path';
import {pathToFileURL}from'node:url';
import {chromium}from'playwright';
const root=resolve('docs/redesign-v1.85.142'),manifest=JSON.parse(readFileSync(resolve(root,'review-manifest.json'))),browser=await chromium.launch({channel:'chrome',headless:true});
try{const page=await browser.newPage(),cases=[],errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(pathToFileURL(resolve(root,'review.html')).href);for(const[route,phases]of Object.entries(manifest))for(const[phase,path]of Object.entries(phases)){await page.locator('#route').selectOption(route);await page.locator('#phase').selectOption(phase);await page.waitForFunction(url=>{const img=document.getElementById('image');return img.complete&&img.naturalWidth>0&&img.currentSrc===url},new URL(path,pathToFileURL(resolve(root,'review.html'))).href);cases.push(route+'/'+phase);}assert.equal(cases.length,24);assert.deepEqual(errors,[]);writeFileSync(resolve(root,'evidence/viewer.json'),JSON.stringify({status:'passed',browser:browser.version(),cases,errors},null,2)+'\n');console.log(JSON.stringify({checked:cases.length,errors}));}finally{await browser.close()}
