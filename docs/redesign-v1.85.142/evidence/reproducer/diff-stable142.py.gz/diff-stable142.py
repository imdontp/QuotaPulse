from pathlib import Path
from PIL import Image
import numpy as np,json
root=Path('screens/history-details');report=json.loads((root/'verification.json').read_text(encoding='utf-8'));rows=[]
for case in report['cases']:
 a=np.asarray(Image.open(root/case['filename']).convert('RGB')).astype(int);b=np.asarray(Image.open(root/('repeat-'+case['filename'])).convert('RGB')).astype(int)
 d=np.abs(a-b);yy,xx=np.where(d.max(2)>0)
 row={'page':case['page'],'lang':case['lang'],'theme':case['theme'],'changedPixels':len(xx),'maxChannelDelta':int(d.max()),'bounds':None if not len(xx)else[int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())]}
 assert row['changedPixels']==case['changedPixels'] and row['maxChannelDelta']==case['maxChannelDelta'];rows.append(row)
Path('tmp/fidelity142/maintained-analysis.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(rows))
