const cp=require('child_process'),fs=require('fs'),assert=require('assert/strict');
for(const[phase,web]of [['before','C:/Users/TH12367283/Projects/QuotaPulse/tmp/worktrees/redesign-validation-v1.85.140/packages/web/dist'],['final','C:/Users/TH12367283/Projects/QuotaPulse/tmp/worktrees/redesign-foundation/packages/web/dist']]){
 const fd=fs.openSync('tmp/fidelity142-'+phase+'.log','w');const result=cp.spawnSync(process.execPath,['--import','tsx','tmp/capture-fidelity142.mts'],{env:{...process.env,QP_FIDELITY_PHASE:phase,QP_FIDELITY_WEB_ROOT:web,QP_FIDELITY_ONLY:''},stdio:['ignore',fd,fd],windowsHide:true});fs.closeSync(fd);assert.equal(result.status,0,phase);console.log('Captured '+phase);
}
