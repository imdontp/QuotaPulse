/** Static canonical reference capture. Isolated synthetic DB, compiled application, no user data. */
import assert from 'node:assert/strict';
import { installBrowserFixedDate } from '../scripts/browser-fixed-date.mjs';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium, type Page, type Request } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import { recordQuotaAlerts } from '../packages/daemon/src/api/queries.js';
const root = fileURLToPath(new URL('..', import.meta.url));
const output = resolve(root, 'tmp/fidelity142/matrix'); 
const referenceRoot = 'C:/Users/TH12367283/Downloads/quotapulse_build_blueprint';
const priorTimezone = process.env.TZ;
process.env.TZ = 'Asia/Bangkok';
mkdirSync(output, { recursive: true });

const fixedNow = Date.parse('2025-05-17T13:42:00.000Z');
// Freeze Date only, keeping real timers/performance for HTTP, browser and cleanup.
// This applies to internal query helpers too, without changing production clocks.
const realDate = globalThis.Date;
globalThis.Date = new Proxy(realDate, {
  construct(target, args) { return Reflect.construct(target, args.length ? args : [fixedNow]); },
  apply() { return new realDate(fixedNow).toString(); },
  get(target, property, receiver) { return property === 'now' ? () => fixedNow : Reflect.get(target, property, receiver); },
});
const db = openDb(':memory:');
db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at,account_key,account_provider,account_display_name,account_state,account_last_success_at)
  VALUES (1,'codex','fixed','/synthetic/nonexistent','Codex fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow}),
    (2,'hermes','fixed','/synthetic/nonexistent','Hermes fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (3,'claude-code','fixed','/synthetic/nonexistent','Claude Code fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (4,'opencode','fixed','/synthetic/nonexistent','OpenCode fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow});`);
const referenceProjects = ['QuotaPulse', 'Agent Platform', 'Edge Services', 'Developer Tools', 'Research Lab'];
const referenceModels = [
  { name: 'DeepSeek V4.1', provider: 'deepseek', share: 38 },
  { name: 'GPT-5.x', provider: 'openai', share: 24 },
  { name: 'Claude 3.7', provider: 'anthropic', share: 18 },
  { name: 'Claude 3.5', provider: 'anthropic', share: 11 },
  { name: 'Others', provider: 'openrouter', share: 9 },
  { name: 'GPT-4.1 mini', provider: 'openai', share: 0 },
];
const session = db.prepare('INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (?,?,?,?,?)');
const usage = db.prepare('INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source,cost_input_usd,cost_cached_input_usd,cost_cache_write_usd,cost_output_usd,cost_cache_saving_usd,price_provider) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
// Synthetic catalogue rates for the in-memory visual fixture only. The saved
// amount is derived from the same fresh/cached input components the UI reports.
const fixtureInputUsdPerMillion = 0.0593846153846154, fixtureCachedInputUsdPerMillion = 0.004, fixtureOutputUsdPerMillion = 0.004;
for (let index = 0; index < 12; index++) {
  // Keep the reference map's 4 Codex, 2 Claude Code, 6 Hermes, 0 OpenCode
  // recent-session distribution while preserving the same 12 sessions.
  const source = [1, 1, 1, 1, 3, 3, 2, 2, 2, 2, 2, 2][index]!;
  session.run(index + 1, source, `fixture-session-${index}`, referenceProjects[0], fixedNow - 10_000);
  const model = referenceModels[index % referenceModels.length]!;
  const totalTokens = model.share === 0 ? 1 : model.share * 721_000_000 / 600;
  for (let call = 0; call < 3; call++) {
    const inputShare = [.6, .65, .7][(index + call) % 3]!;
    const inputTokens = totalTokens * inputShare * .58, cachedInputTokens = totalTokens * inputShare * .42;
    const outputTokens = totalTokens * (1 - inputShare);
    const costSource = index === 0 ? 'native' : 'computed';
    const inputUsd = inputTokens / 1_000_000 * fixtureInputUsdPerMillion;
    const cachedInputUsd = cachedInputTokens / 1_000_000 * fixtureCachedInputUsdPerMillion;
    const outputUsd = outputTokens / 1_000_000 * fixtureOutputUsdPerMillion;
    const cacheSavingUsd = cachedInputTokens / 1_000_000 * (fixtureInputUsdPerMillion - fixtureCachedInputUsdPerMillion);
    // Keep each session's latest record within four minutes, then spread older calls across the visible 30-minute interval.
    const ageMs = call === 0 ? 15_000 + index * 20_000 : source === 2
      ? 300_000 + index * 120_000 + (call === 2 ? 30_000 : 0)
      : 300_000 + index * 240_000 + (call === 2 ? 90_000 : 0);
    const recordedAt = fixedNow - ageMs;
    usage.run(source, index + 1, `fixed-${index}-${call}`, recordedAt, model.name, model.provider,
      inputTokens, cachedInputTokens, outputTokens, totalTokens, call + 1,
      costSource === 'native' ? (index + 1) / 100 : inputUsd + cachedInputUsd + outputUsd, costSource,
      costSource === 'native' ? null : inputUsd, costSource === 'native' ? null : cachedInputUsd,
      costSource === 'native' ? null : 0, costSource === 'native' ? null : outputUsd,
      costSource === 'native' ? null : cacheSavingUsd, costSource === 'native' ? null : model.provider);
  }
}
// A stale recorded OpenCode route keeps the concept's zero-active-session edge
// visible without manufacturing a provider relationship or changing live counts.
const openCodeAt = fixedNow - 10 * 60_000;
session.run(13, 4, 'fixture-opencode-quota-pulse', referenceProjects[0], openCodeAt);
usage.run(4, 13, 'fixed-opencode-route', openCodeAt, 'DeepSeek V4.1', 'deepseek', 1, 0, 0, 1, 1,
  null, 'unknown', null, null, null, null, null, null);
// The monthly concept is focused on QuotaPulse while the machine-wide quick
// stats still report all five named projects. Keep four small monthly records
// for the other projects, outside the recent-session window.
for (let index = 1; index < referenceProjects.length; index++) {
  const id = 100 + index, source = [1, 3, 4, 2][index - 1]!;
  const model = referenceModels[index - 1]!;
  const at = fixedNow - 10 * 60_000;
  session.run(id, source, `fixture-project-${index}`, referenceProjects[index], at);
  const inputUsd = fixtureInputUsdPerMillion / 1_000_000;
  usage.run(source, id, `fixture-project-usage-${index}`, at, model.name, model.provider, 1, 0, 0, 1, 1,
    inputUsd, 'computed', inputUsd, 0, 0, 0, 0, model.provider);
}
// Values below the old visual minimum catch inflated nonzero bars in both charts.
const tinyUsage = db.prepare("INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source) VALUES (1,1,?,?,'DeepSeek V4.1','deepseek',1,0,0,1,1,0,'computed')");
tinyUsage.run('fixed-tiny-minute', fixedNow - 15 * 60_000);
tinyUsage.run('fixed-tiny-day', fixedNow - 3 * 86_400_000);
const quota = db.prepare('INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin) VALUES (?,?,?,?,?,?,?,?)');
const addQuotaSample = (sourceId: number, window: string, percent: number | null, resetAt: number | null, observedAt: number) => quota.run(sourceId, window, percent, resetAt, observedAt, observedAt, observedAt, 'fixed-fixture');
// Complete history must include older reset periods, nulls and more than eight
// readings per period, without changing the latest live quota/default selection.
for (let segment = 0; segment < 4; segment++) for (let index = 0; index < 12; index++) {
  const at = fixedNow - (5 - segment) * 3_600_000 + index * 60_000;
  addQuotaSample(1, '5h', index === 4 ? null : index === 1 ? 0.5 : index * 8, segment === 0 ? null : fixedNow - (4 - segment) * 3_600_000, at);
}
addQuotaSample(1, '5h', 38, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 5 * 60_000);
addQuotaSample(1, '5h', 83, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 30_000);
addQuotaSample(1, 'weekly', 62, fixedNow + (3 * 24 + 5) * 3_600_000, fixedNow - 30_000);
const monthlyReset = fixedNow + (6 * 24 + 2) * 3_600_000;
addQuotaSample(1, 'monthly', 59, monthlyReset, fixedNow - 48 * 3_600_000);
addQuotaSample(1, 'monthly', 65.5, monthlyReset, fixedNow - 24 * 3_600_000);
addQuotaSample(1, 'monthly', 72, monthlyReset, fixedNow - 30_000);
addQuotaSample(2, 'monthly', 58, fixedNow + (12 * 24 + 6) * 3_600_000, fixedNow - 30_000);
addQuotaSample(2, 'daily', 34, fixedNow + (7 * 60 + 18) * 60_000, fixedNow - 30_000);
recordQuotaAlerts(db, fixedNow);
const scheduler = new Scheduler(db, [], { pollMs: 1_000_000, detectMs: 1_000_000 });
const webRoot = resolve(process.env.QP_FIDELITY_WEB_ROOT ?? resolve(root, 'packages/web/dist'));
const daemon = buildServer(db, scheduler, { token: 'stable-capture-test', port: 7816, webRoot });
let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;
const sha = (bytes: Buffer) => createHash('sha256').update(bytes).digest('hex');
const indexPath = resolve(webRoot, 'index.html');
const productionIndexSha256 = sha(readFileSync(indexPath));
const rendererArgs: string[] = [];
const referenceManifest = JSON.parse(readFileSync(resolve(referenceRoot, 'reference_manifest.json'), 'utf8'));
const results:any[]=[],errors:string[]=[];
try {
 await daemon.listen({host:'127.0.0.1',port:7816});
 browser=await chromium.launch({channel:'chrome',headless:true});
 for(const lang of ['en','th'])for(const theme of ['dark','light'])for(const width of [390,900,1280,1672]){
  const name=`${lang}-${theme}-${width}`,context=await browser.newContext({viewport:{width,height:941},reducedMotion:'reduce',timezoneId:'Asia/Bangkok'}),page=await context.newPage();
  page.on('pageerror',e=>errors.push(e.message));
  await page.route('**/*',route=>new URL(route.request().url()).origin==='http://127.0.0.1:7816'?route.continue():route.abort());
  await page.addInitScript(({lang,theme})=>{(window as any).__QUOTAPULSE_TOKEN__='stable-capture-test';localStorage.setItem('quotapulse-prefs',JSON.stringify({lang,currency:lang==='th'?'THB':'USD',rate:37.25,hiddenSubscriptions:[]}));localStorage.setItem('quotapulse-theme',theme)},{lang,theme});await installBrowserFixedDate(page,fixedNow);
  const from=fixedNow-7*86400000,baseHash=`#history?range=custom&from=${from}&to=${fixedNow}&source=1&session_id=1`;
  const ready=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/usage-events'&&r.status()===200);await page.goto('http://127.0.0.1:7816/'+baseHash);const initial=await(await ready).json();assert.ok(initial.total>0);
  const history=page.getByTestId('usage-history'),form=history.locator('.qp-history-filter-form');await history.locator('tbody tr').first().waitFor();await page.evaluate(()=>document.fonts.ready);
  const fields=form.locator('input:not([type=checkbox])');assert.equal(await fields.count(),6);
  // Use semantic labels read from each control instead of assuming Thai copy.
  for(const input of await fields.all())assert.ok(await input.evaluate(el=>(el as HTMLInputElement).labels?.[0]?.textContent?.trim()));
  const search=form.locator('.qp-history-filter-search input'),extra=form.locator('.qp-history-extra-filters'),summary=extra.locator('summary');
  await search.fill('no-match-draft');assert.equal(new URLSearchParams(new URL(page.url()).hash.split('?')[1]).has('q'),false);
  assert.equal(await history.locator('tbody tr').count(),initial.rows.length,'Unapplied draft must not replace rows');await search.fill('');
  const geometry=await form.evaluate(el=>{const parent=el.getBoundingClientRect();return{form:parent.toJSON(),fields:[...el.querySelector('fieldset')!.children].map(node=>node.getBoundingClientRect().toJSON())}});
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,name);
  for(const rect of geometry.fields)assert.ok(rect.left>=geometry.form.left-.5&&rect.right<=geometry.form.right+.5,name+' filter containment');
  if(width===1672){assert.equal(new Set(geometry.fields.map(rect=>rect.top)).size,1,'Reference desktop toolbar must use one row');assert.ok(geometry.fields[0].width>=geometry.fields[1].width*2,'Search needs reference prominence');}
  await page.mouse.move(0,0);await page.screenshot({path:resolve(output,name+'.png'),animations:'disabled'});
  await summary.focus();await page.keyboard.press('Enter');assert.equal(await extra.getAttribute('open'),'');
  const vendor=extra.locator('input[type=text]'),missing=extra.locator('input[type=checkbox]');await vendor.fill('deepseek');await missing.check();
  assert.equal(await form.locator('input[title]').nth(1).isDisabled(),true);
  assert.equal(await summary.getAttribute('data-active'),'true');assert.ok((await summary.getAttribute('aria-label'))!.endsWith('(2)'));
  const popover=await extra.locator('.qp-history-extra-fields').boundingBox();assert.ok(popover&&popover.x>=0&&popover.x+popover.width<=width,name+' extra filters containment');
  await page.screenshot({path:resolve(output,name+'-extra.png'),animations:'disabled'});
  await page.keyboard.press('Escape');assert.equal(await extra.getAttribute('open'),null);assert.equal(await summary.evaluate(el=>document.activeElement===el),true);
  await summary.click();await missing.uncheck();await form.locator('.qp-history-filter-field').filter({has:page.locator('input[title]')}).nth(1).locator('input').fill('QuotaPulse');
  const applied=page.waitForResponse(r=>{const u=new URL(r.url());return u.pathname==='/api/usage-events'&&u.searchParams.get('vendor')==='deepseek'&&r.status()===200});
  await vendor.press('Enter');const filtered=await(await applied).json();assert.ok(filtered.total>0);assert.ok(filtered.rows.every((row:any)=>row.vendor==='deepseek'&&row.project==='QuotaPulse'&&row.session_key===1));
  await page.waitForFunction(()=>new URLSearchParams(location.hash.split('?')[1]).get('vendor')==='deepseek');assert.equal(await extra.getAttribute('open'),null);
  assert.equal(await form.locator('.qp-history-filter-apply').evaluate(el=>document.activeElement===el),true,'Submitting advanced input must not strand focus in a hidden field');
  const cleared=page.waitForResponse(r=>{const u=new URL(r.url());return u.pathname==='/api/usage-events'&&!u.searchParams.has('vendor')&&!u.searchParams.has('project')&&r.status()===200});
  await form.locator('.qp-history-filter-clear').focus();await page.keyboard.press('Enter');const reset=await(await cleared).json();assert.equal(reset.total,initial.total);
  await page.waitForFunction(()=>!new URLSearchParams(location.hash.split('?')[1]).has('vendor'));
  const params=new URLSearchParams(new URL(page.url()).hash.split('?')[1]);assert.equal(params.get('range'),'custom');assert.equal(params.get('from'),String(from));assert.equal(params.get('to'),String(fixedNow));assert.equal(params.get('source'),'1');assert.equal(params.get('session_id'),'1');for(const key of ['q','project','vendor','harness','model','provider','project_missing','grain'])assert.equal(params.has(key),false,key);
  assert.equal(await search.evaluate(el=>document.activeElement===el),true);assert.equal(await vendor.inputValue(),'');assert.equal(await missing.isChecked(),false);assert.equal(await summary.getAttribute('data-active'),'false');
  const pause=history.locator('.qp-history-view-actions button').first();await pause.click();assert.equal(await form.getByRole('button').first().isDisabled(),true);await summary.dispatchEvent('click');assert.equal(await extra.getAttribute('open'),null,'Paused summary must not open');await pause.click();
  assert.deepEqual(errors,[]);results.push({name,geometry,unappliedDraft:true,keyboardExtraFilters:true,escapeFocus:true,exactVendorProjectApi:true,keyboardClearRetainsScope:true,pauseDisabled:true,noPageOverflow:true});console.log('Passed '+name);await context.close();
 }
 assert.equal(sha(readFileSync(indexPath)),productionIndexSha256);writeFileSync(resolve(output,'verification.json'),JSON.stringify({status:'passed',productionIndexSha256,browser:browser.version(),cases:results,errors,fixture:'owned in-memory canonical fixture; no customer data'},null,2)+'\n');
}finally{await browser?.close();await daemon.close();db.close();globalThis.Date=realDate;process.env.TZ=priorTimezone;}
