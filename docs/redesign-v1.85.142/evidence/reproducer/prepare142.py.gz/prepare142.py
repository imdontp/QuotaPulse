from pathlib import Path
s=Path('tmp/capture-fidelity140.mts').read_text(encoding='utf-8').replace('tmp/fidelity140/','tmp/fidelity142/')
Path('tmp/capture-fidelity142.mts').write_text(s,encoding='utf-8',newline='\n')
prefix=s.split('const allTargets =')[0].replace("'tmp/fidelity142/'+(process.env.QP_FIDELITY_PHASE??'before')","'tmp/fidelity142/matrix'")
Path('tmp/check-history142.mts').write_text(prefix+Path('tmp/history142-body.txt').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
