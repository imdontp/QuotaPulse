from pathlib import Path
from PIL import Image
import numpy as np,json
out=[]
for route in ['overview','live','projects','models','history','alerts','providers','cost']:
 a=np.asarray(Image.open(f'tmp/fidelity142/before/{route}.png').convert('RGB')).astype(int);b=np.asarray(Image.open(f'tmp/fidelity142/final/{route}.png').convert('RGB')).astype(int)
 d=np.abs(a-b);yy,xx=np.where(d.max(2)>0)
 out.append({'route':route,'changedPixels':len(xx),'maxChannelDelta':int(d.max()),'bounds':None if not len(xx)else[int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())]})
Path('tmp/fidelity142/analysis.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(out))
