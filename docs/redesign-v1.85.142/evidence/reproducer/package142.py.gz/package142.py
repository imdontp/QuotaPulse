from pathlib import Path
import json,gzip,hashlib,subprocess,sys
out=Path('docs/redesign-v1.85.142');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8').lstrip('\ufeff'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,zipped=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not zipped and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0) if zipped else b)
index=sha(Path('packages/web/dist/index.html').read_bytes());assert index=='22df4ba567d5aca1f58bfdf0e31f80409812103e6df587c7909b9c4a34a1389c'
matrix=load('tmp/fidelity142/matrix/verification.json');before=load('tmp/fidelity142/before/verification.json');final=load('tmp/fidelity142/final/verification.json');analysis=load('tmp/fidelity142/analysis.json')
assert matrix['status']=='passed' and len(matrix['cases'])==16 and matrix['errors']==[] and matrix['productionIndexSha256']==index
assert final['productionIndexSha256']==index and len(final['results'])==8 and len(before['results'])==8
assert before['productionIndexSha256']=='2bab6990b174526765b76cc512552e3daf1c97a2a9b07aa1157ffd33cdd9b732'
assert all(r['repeatIdentical'] and r['errors']==[] and r['forbidden']==[] for r in final['results']+before['results'])
assert all(row['changedPixels']==0 for row in analysis if row['route']!='history')
assert next(row for row in analysis if row['route']=='history')['bounds']==[238,472,1363,506]
test=Path('tmp/test142-web-final.log').read_bytes();text=test.decode('utf-16') if test[:2] in [b'\xff\xfe',b'\xfe\xff'] else test.decode('utf-8')
for value in ['# tests 351','# pass 351','# fail 0','# skipped 0','# cancelled 0']:assert value in text
files=['packages/web/src/redesign/history-filters.tsx','packages/web/src/redesign/history-filters.css','packages/web/src/sections/history.tsx','packages/web/src/i18n/en.ts','packages/web/src/i18n/th.ts','scripts/check-history.mts']
write('source-fingerprints.json',[{'path':name,'sha256':sha(Path(name).read_bytes()),'lfSha256':sha(Path(name).read_bytes().replace(b'\r\n',b'\n'))} for name in files])
approved=Path('docs/quotapulse_build_blueprint_v1.1.zip');assert sha(approved.read_bytes())=='28bc63571ddf7ecda1e12e8821c6184378ccfe6c3a599d6ccec29bf17fedb054'
write('authority.json',{'approvedArchive':str(approved),'sha256':sha(approved.read_bytes()),'gapLedger':{'path':'docs/redesign-v1.85.109/authority/07-GAP-LEDGER-v1.1.md','sha256':sha(Path('docs/redesign-v1.85.109/authority/07-GAP-LEDGER-v1.1.md').read_bytes())},'constraints':['GAP-001 metadata only; no prompt search/detail','GAP-013 full exact filters and matching export retained','GAP-019 categorical effort and real grain; no invented status options','GAP-020 Thai/light/narrow/keyboard behavior retained'],'reference':{'path':'refs/history.png','sha256':sha(Path('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/history.png').read_bytes())}})
for phase,report in [('before',before),('final',final)]:
 copy(f'tmp/fidelity142/{phase}/verification.json','evidence/'+phase+'.json')
 for row in report['results']:
  src=Path(f'tmp/fidelity142/{phase}/{row["route"]}.png');assert sha(src.read_bytes())==row['sha256']
  if phase=='before' or row['route']=='history':copy(src,f'images/{phase}/{row["route"]}.png')
copy('tmp/fidelity142/matrix/verification.json','evidence/matrix.json')
copy('tmp/fidelity142/analysis.json','analysis.json')
copy('tmp/fidelity142/maintained-analysis.json','maintained-analysis.json')
stable=load('screens/history-details/verification.json');assert stable['productionIndexSha256']==index and len(stable['cases'])==8
assert len(stable['historyChecks'])==4 and len(stable['historyRailChecks'])==4 and len(stable['historyDensityChecks'])==4
copy('screens/history-details/verification.json','evidence/maintained-history.json')
copy('tmp/stable142-history.log','evidence/logs/stable142-history.log.gz',True)
for row in stable['cases']:
 src=Path('screens/history-details')/row['filename'];repeat=src.with_name('repeat-'+src.name)
 assert sha(src.read_bytes())==row['sha256'] and sha(repeat.read_bytes())==row['repeatSha256']
 copy(src,'images/maintained/'+src.name)
 if row['sha256']!=row['repeatSha256']:copy(repeat,'images/maintained/'+repeat.name)
for name in ['en-dark-1672','en-dark-390','th-light-1672','th-light-390']:
 for suffix in ['', '-extra']:copy(f'tmp/fidelity142/matrix/{name}{suffix}.png',f'images/matrix/{name}{suffix}.png')
for name in ['build142-final.log','test142-web-final.log','history142-matrix-final.log','history142-integration.log','history142-integration-initial.log','history142-integration-rail-focus.log','history142-integration-auto-focus.log','history142-integration-project-heading.log','history142-integration-heading-copy.log','history142-matrix-initial.log','fidelity142-before.log','fidelity142-final.log']:copy('tmp/'+name,'evidence/logs/'+name+'.gz',True)
copy('tmp/history142-integration-model-link.log','evidence/logs/history142-integration-model-link.log.gz',True)
copy('tmp/history142-integration-model-destination.log','evidence/logs/history142-integration-model-destination.log.gz',True)
copy('tmp/history142-integration-chart-role.log','evidence/logs/history142-integration-chart-role.log.gz',True)
for name in ['prepare142.py','capture-fidelity142.mts','check-history142.mts','validate142.cjs','run-capture142.cjs','diff142.py','package142.py','check-viewer142.mjs']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
copy('tmp/diff-stable142.py','evidence/reproducer/diff-stable142.py.gz',True)
integration=load('tmp/integration142-status.json');write('evidence/integration-status.json',integration)
assert '--draft' in sys.argv or integration['status']!='running; unproven'
copy('tmp/history142-integration-matrix-rail.log','evidence/logs/history142-integration-matrix-rail.log.gz',True)
copy('tmp/history142-integration-model-value-column.log','evidence/logs/history142-integration-model-value-column.log.gz',True)
copy('tmp/history142-integration-occupied-project-heading.log','evidence/logs/history142-integration-occupied-project-heading.log.gz',True)
copy('tmp/commit142.log','evidence/logs/staging-line-ending-check.log.gz',True)
for name in ['responsive-matrix.json','cost-semantics.json','review-candidates.json']:copy('screens/history/'+name,'evidence/combined/'+name)
viewerVerified=(out/'evidence/viewer.json').exists()
if viewerVerified:
 viewer=load(out/'evidence/viewer.json');assert viewer['status']=='passed' and len(viewer['cases'])==24 and viewer['errors']==[]
else:assert '--draft' in sys.argv
write('summary.json',{'parent':'da6607c6435bf4cec5613aece81e91c0518c5f51','productionIndexSha256':index,'webTests':351,'browserCases':16,'canonicalStableExactPairs':8,'maintainedHistoryPairs':8,'maintainedHistoryExactPairs':4,'maintainedFullExactGate':False,'otherPagesByteIdentical':7,'changedBounds':[238,472,1363,506],'combinedIntegration':integration,'reviewPageVerified':viewerVerified,'fullGoalComplete':False,'latestRunnableZip':'review141/source140; excludes History142'})
(out/'README.md').write_text(f'''# History reference filter toolbar — source142

[Original / before / current review](review.html) · [Latest runnable package141 instructions](../redesign-v1.85.141/README.md)

Partially validated implementation on the isolated redesign branch. Parent: `da6607c6435bf4cec5613aece81e91c0518c5f51`. Production web index: `{index}`. This source is newer than ZIP141; that archive does not contain the new History toolbar.

The History metadata search now has reference prominence, a search icon and blue framed surface. Exact project/harness/provider/model fields, real record-kind selector, icon Apply and Clear share one desktop row. Vendor and unassigned-only controls remain available in a keyboard disclosure with a visible selected-draft count; no incomplete option lists or invented lifecycle statuses are introduced. Search remains metadata-only. Extra fields close on Apply, keyboard submission returns focus to Apply, Escape returns focus to the disclosure, and Clear returns focus to search. Clear resets only metadata/grain filters and pagination; date/source/session scope remains. Pause disables the controls. Legacy form behavior, API queries/export semantics and actual data remain unchanged.

## Verification

Web build and351 tests pass, zero failed/skipped/cancelled. Sixteen compiled-app cases cover EN/TH, dark/light and390/900/1280/1672 widths using an owned in-memory database. They verify pending drafts do not change rows, keyboard disclosure/Escape, actual vendor/project filtered API facts, Clear retaining custom from/to/source/session, paused controls, horizontal containment and one-row desktop search prominence. Final source/index fingerprints are retained.

All eight routes were captured before/after against the same clock/fixture and original reference dimensions; all eight final within-context pairs are byte-exact. Seven other routes remain byte-identical before/after. The39082 changed History pixels are confined to `[238,472,1363,506]`, its35px filter row; the rest of that canonical image is unchanged. Images are unmasked. This comparison proves bounded regression behavior, not original-concept100% acceptance.

Combined maintained History/all-eight integration status: `{integration['status']}`. {integration['detail']} Earlier failures and selector corrections are retained. The script now opens extra filters before unassigned checks, targets the existing nonmodal rail, focuses it before Escape, checks the established table fallback for automatic selection, disambiguates the Projects h1, uses current translated headings, and retains the exact model-pair count. These are test corrections; no product dialog/focus/heading behavior was changed to make the old suite pass.

## Limits

The separate maintained History gate exercises four language/theme combinations, metadata/keyboard/nonmodal rail, chart/axis/density and narrow layouts. Its eight independent-document pairs have four exact pairs; EN/dark and TH/light each retain differences in both initial/selected frames (57pixels/max3 and19pixels/max9 respectively). The unchanged gate accepts those within its recorded tolerance, but full exact raster acceptance remains OPEN and the cause is not established. Original/repeat frames and the raw report are retained; no mask or tolerance modification was introduced. This is distinct from the eight exact within-context canonical route pairs above.

Independent unmasked image analysis locates these differences in the global header: EN/dark bounds `[546,12,1016,20]`, TH/light `[283,12,966,22]`. History content below that header is exact in these pairs; the entire frames remain non-exact. This localization does not establish a rendering mechanism or close the full raster gate.

Original-reference final approval, complete native/physical/performance/all-state acceptance and the full blueprint remain open. The new toolbar uses exact text inputs rather than fabricated dropdown inventories. Browser fixture tests are not customer-data or all-provider acceptance. No native Electron run or new ZIP was made for source142. Current source does not alter main, dependencies, production data or prior archives. The approved v1.1 archive and gap ledger hashes are bound in [authority](authority.json); [full trace](../redesign-v1.85.109/REQUIREMENT-TRACE.md) remains the project-wide obligation list.
''',encoding='utf-8',newline='\n')
routes=[row['route'] for row in final['results']]
write('review-manifest.json',{route:{'original':f'../redesign-v1.85.69/refs/{route}.png','before':f'images/before/{route}.png','current':f'images/final/{route}.png' if route=='history' else f'images/before/{route}.png'}for route in routes})
html='''<!doctype html><meta charset="utf-8"><title>History142 reference comparison</title><style>body{font:14px system-ui;background:#071020;color:#def;margin:20px}select{padding:8px;margin:6px}img{display:block;max-width:100%;border:1px solid #456}a{color:#5cf}</style><h1>Source142 — History filters</h1><p>Real application, owned QA data. Reference approval remains open. <a href="README.md">Evidence and limits</a></p><select id="route">'''+''.join('<option'+(' selected' if route=='history' else '')+'>'+route+'</option>'for route in routes)+'''</select><select id="phase"><option>original</option><option>before</option><option selected>current</option></select><img id="image" alt="Selected reference or application screenshot"><script>const manifest='''+json.dumps(load(out/'review-manifest.json'))+''';const route=document.getElementById('route'),phase=document.getElementById('phase'),frame=document.getElementById('image');function show(){frame.src=manifest[route.value][phase.value]}route.onchange=phase.onchange=show;show()</script>'''
(out/'review.html').write_text(html,encoding='utf-8',newline='\n')
write('artifact-hashes.json',{str(p.relative_to(out)).replace('\\','/'):sha(p.read_bytes())for p in sorted(out.rglob('*'))if p.is_file()and p.name!='artifact-hashes.json'})
print(json.dumps({'artifacts':len(load(out/'artifact-hashes.json')),'index':index,'viewerVerified':viewerVerified,'integration':integration['status']}))
