const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),crypto=require('node:crypto');
const checkout='C:/Users/TH12367283/Projects/QuotaPulse/tmp/worktrees/redesign-validation-v1.85.155';
const built=JSON.parse(fs.readFileSync(path.join(checkout,'screens/tray-recovery/bundle-build.json')));
const receipt='tmp/release156/build/build.json';const record=JSON.parse(fs.readFileSync(receipt));
assert.equal(record.sourceCommit,'c452881ac8db8f9f513752379971f5efbce4b15d');assert.equal(record.steps.length,6);assert.ok(record.steps.every(step=>step.exitCode===0));
const hash=crypto.createHash('sha256').update(fs.readFileSync(path.join(built.bundle,'packages/web/dist/index.html'))).digest('hex');assert.equal(hash,'9a57fc2c0243d761bd576e1fed241ececd7ba154feec334b9f0349d26f5261ba');
fs.writeFileSync('tmp/release156/inputs.json',JSON.stringify({checkout,bundle:built.bundle,sourceCommit:record.sourceCommit,buildReceipt:path.resolve(receipt),webIndexSha256:hash},null,2)+'\n');
console.log(JSON.stringify({bundle:built.bundle,sourceCommit:record.sourceCommit,index:hash}));
