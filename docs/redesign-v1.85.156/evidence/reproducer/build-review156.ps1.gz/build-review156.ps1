$ErrorActionPreference='Stop'
$owner='C:\Users\TH12367283\Projects\QuotaPulse\tmp\worktrees\redesign-foundation'
$checkout='C:\Users\TH12367283\Projects\QuotaPulse\tmp\worktrees\redesign-validation-v1.85.155'
$checkout=(Resolve-Path -LiteralPath $checkout).Path
. (Join-Path $owner 'scripts\review-profile.ps1')
Assert-ReviewPlainPath $checkout
$commit=(& git -C $checkout rev-parse HEAD).Trim()
if($LASTEXITCODE -ne 0 -or $commit -ne 'c452881ac8db8f9f513752379971f5efbce4b15d'){throw 'Unexpected frozen source commit'}
$dirty=& git -C $checkout status --porcelain --untracked-files=no
if($LASTEXITCODE -ne 0 -or $dirty){throw 'Frozen tracked source is dirty'}
$targets=@('packages\daemon\dist','packages\web\dist','packages\tray\dist','packages\tray\dist-preload','packages\tray\dist-package') | ForEach-Object {
  $target=[IO.Path]::GetFullPath((Join-Path $checkout $_))
  if(-not $target.StartsWith($checkout+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Generated output escaped its checkout'}
  Assert-ReviewPlainPath $target
  $target
}
$output=Join-Path $owner 'tmp\release156\build'
New-Item -ItemType Directory -Path $output -Force | Out-Null
$steps=[Collections.Generic.List[object]]::new()
function Save-Receipt {
  [IO.File]::WriteAllText((Join-Path $output 'build.json'),(@{sourceCommit=$commit;checkout=$checkout;checkedGeneratedTargets=$targets;steps=@($steps)}|ConvertTo-Json -Depth 8)+"`n",[Text.UTF8Encoding]::new($false))
}
function Run-Step([string]$Name,[string]$Exe,[string[]]$Arguments){
  $log=Join-Path $output ($Name+'.log');$start=[DateTime]::UtcNow.ToString('O');$stepPreference=$ErrorActionPreference
  try{$ErrorActionPreference='Continue'; & $Exe @Arguments *> $log; $code=$LASTEXITCODE}finally{$ErrorActionPreference=$stepPreference}
  $steps.Add(@{name=$Name;executable=$Exe;arguments=$Arguments;startedUtc=$start;finishedUtc=[DateTime]::UtcNow.ToString('O');exitCode=$code;log=$log});Save-Receipt
  if($code -ne 0){throw "$Name failed with exit $code; see $log"}
  Write-Host "$Name passed."
}
Push-Location -LiteralPath $checkout
try{
  Run-Step 'daemon-build' 'npm' @('run','daemon:build')
  Run-Step 'web-build' 'npm' @('run','build','-w','@quotapulse/web')
  Run-Step 'tray-build' 'npm' @('run','build','-w','@quotapulse/tray')
  Run-Step 'repository-tests' 'npm' @('test')
  Run-Step 'approved-runtime-assets' 'node' @('--import','tsx','packages/tray/scripts/package-assets.ts')
  $env:QUOTAPULSE_REVIEW_CHECKPOINT='v1.85.155-review156'
  if([IO.DriveInfo]::new('C:\').AvailableFreeSpace -lt 950000000){throw 'Insufficient free space before creating the isolated runtime bundle'}
  Run-Step 'review-bundle' 'node' @('--import','tsx','scripts/build-review-bundle.mts')
}finally{Pop-Location}
