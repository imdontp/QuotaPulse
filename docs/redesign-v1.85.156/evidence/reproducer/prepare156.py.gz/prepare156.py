from pathlib import Path
mapping={'release150':'release156','review150':'review156','v1.85.149':'v1.85.155','5eb188edcfe8bddcf545ce952b13d36848daa066':'c452881ac8db8f9f513752379971f5efbce4b15d','f9df009691e9ccf99f7c674dfc560c4861cef60273cf327d0c5f46b41c253500':'9a57fc2c0243d761bd576e1fed241ececd7ba154feec334b9f0349d26f5261ba'}
for name in ['build-review150.ps1','prepare-review150.cjs','archive-review150.ps1','extract-review150.ps1','check-bundle150.mts','check-native-review150.mts','check-reader-archive150.mts','audit-review150.cjs','cleanup-owned150.ps1']:
 s=Path('tmp',name).read_text(encoding='utf-8-sig')
 for before,after in mapping.items():s=s.replace(before,after)
 if name=='audit-review150.cjs':s=s.replace('[129,351,198]','[129,353,198]').replace('repositoryTests:678','repositoryTests:680')
 if name=='build-review150.ps1':
  s=s.replace("Run-Step 'review-bundle'", "if([IO.DriveInfo]::new('C:\\').AvailableFreeSpace -lt 950000000){throw 'Insufficient free space before creating the isolated runtime bundle'}\n  Run-Step 'review-bundle'")
 if name=='check-native-review150.mts':
  marker='async function captureRoutes(page:Page,phase:string){'
  assert s.count(marker)==1
  s=s.replace(marker,'''async function referenceViewport(page:Page,route:string){
 const referenceRoot='C:/Users/TH12367283/Downloads/quotapulse_build_blueprint',manifest=json(join(referenceRoot,'reference_manifest.json'));
 const entry=manifest.references.find((row:any)=>row.file==='refs/'+route+'.png');assert.ok(entry);assert.equal(sha(readFileSync(join(referenceRoot,entry.file))),entry.sha256);
 const requested={width:entry.width,height:entry.height},measurements=[];
 for(let attempt=0;attempt<4;attempt++){
  const current=await page.evaluate(()=>({width:innerWidth,height:innerHeight}));measurements.push(current);if(current.width===requested.width&&current.height===requested.height)break;
  await desktop!.evaluate(({BrowserWindow},{current,requested})=>{const window=BrowserWindow.getAllWindows()[0],size=window.getSize();window.setSize(size[0]+requested.width-current.width,size[1]+requested.height-current.height,false)},{current,requested});await page.waitForTimeout(100);
 }
 const actual=await page.evaluate(()=>({width:innerWidth,height:innerHeight}));assert.deepEqual(actual,requested);writeFileSync(join(output,'viewport-initial-'+route+'.json'),JSON.stringify({requested,measurements,actual,referenceSha256:entry.sha256},null,2)+'\\n');
 return{...requested,referenceSha256:entry.sha256};
}
''' + marker)
  needle=" for(const [route,ready]of Object.entries(targets)){"
  assert s.count(needle)==1
  s=s.replace(needle,needle+"\n  const reference=phase==='initial'?await referenceViewport(page,route):undefined;")
  s=s.replace("captures.push({phase,route,summaryLayout,", "captures.push({phase,route,reference,summaryLayout,")
  needle=" const fields=page.getByTestId('usage-history').locator('input[type=date]')"
  assert s.count(needle)==1
  s=s.replace(needle,''' const picker=page.locator('.qp-history-range-picker'),summary=picker.locator('summary');
 if(await picker.getAttribute('open')===null){await summary.focus();await page.keyboard.press('Enter');}
 await page.locator('.qp-history-range-popover').waitFor();assert.equal(await summary.getAttribute('aria-expanded'),'true');
 const bounds=await page.locator('.qp-history-range-popover').boundingBox(),viewport=await page.evaluate(()=>innerWidth);assert.ok(bounds&&bounds.x>=0&&bounds.x+bounds.width<=viewport);
 const bars=await page.locator('.qp-history-token-comparison').evaluateAll(nodes=>nodes.map(node=>{const track=node.querySelector('.qp-history-token-bar')!,fill=track.firstElementChild as HTMLElement;return{count:Number(node.getAttribute('data-token-count')),max:Number(node.getAttribute('data-page-token-max')),ratio:Number(fill.getAttribute('data-token-ratio')),width:track.getBoundingClientRect().width,height:track.getBoundingClientRect().height}}));assert.deepEqual(bars.map(row=>row.count),[150,1]);for(const row of bars){assert.equal(row.max,150);assert.equal(row.ratio,row.count/150);assert.equal(row.width,50);assert.equal(row.height,6);}
''' + needle)
  s=s.replace(" calendarChecks.push({phase,from,to,actualDates,expectedDates,exactScope:true,tokens:151,clearedEndIgnored:true});", " await page.keyboard.press('Escape');assert.equal(await picker.getAttribute('open'),null);assert.equal(await summary.evaluate(node=>node===document.activeElement),true);\n calendarChecks.push({phase,from,to,actualDates,expectedDates,exactScope:true,tokens:151,clearedEndIgnored:true,pickerKeyboard:true,popoverContained:true,escapeRestoresFocus:true,bars});")
  needle=" await desktop!.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].setContentSize(1672,941));"
  assert s.count(needle)==1
  s=s.replace(needle,''' // Calibrate against actual renderer dimensions rather than assuming frame metrics.
 const viewportCalibration=[];
 for(let attempt=0;attempt<4;attempt++){
  const current=await page.evaluate(()=>({width:innerWidth,height:innerHeight}));viewportCalibration.push(current);if(current.width===1672&&current.height===941)break;
  await desktop!.evaluate(({BrowserWindow},current)=>{const window=BrowserWindow.getAllWindows()[0],size=window.getSize();window.setSize(size[0]+1672-current.width,size[1]+941-current.height,false)},current);await page.waitForTimeout(100);
 }
 const calibrated=await page.evaluate(()=>({width:innerWidth,height:innerHeight}));assert.deepEqual(calibrated,{width:1672,height:941});writeFileSync(join(output,'viewport-calibration.json'),JSON.stringify({requested:{width:1672,height:941},measurements:viewportCalibration,actual:calibrated},null,2)+'\\n');''')
 if name=='audit-review150.cjs':
  needle="assert.equal(row.clearedEndIgnored,true);"
  assert s.count(needle)==1
  s=s.replace(needle,needle+"assert.equal(row.pickerKeyboard,true);assert.equal(row.popoverContained,true);assert.equal(row.escapeRestoresFocus,true);assert.deepEqual(row.bars.map(bar=>bar.count),[150,1]);")
  s=s.replace("assert.equal(report.captures.length,16);","for(const capture of report.captures.filter(row=>row.phase==='initial')){assert.deepEqual(capture.viewport,{width:capture.route==='overview'?1586:1672,height:capture.route==='overview'?992:941,dpr:1});assert.equal(capture.reference.width,capture.viewport.width);assert.equal(capture.reference.height,capture.viewport.height);}\nassert.equal(report.captures.length,16);")
 Path('tmp',name.replace('150','156')).write_bytes(s.encode())
print('Prepared isolated source155 review156 build, native, ZIP and reader validation scripts')
