from pathlib import Path
import gzip,hashlib,json,sys,subprocess
out=Path('docs/redesign-v1.85.156');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,compressed=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not compressed and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0) if compressed else b)
summary=load('tmp/release156/summary.json');inputs=load('tmp/release156/inputs.json');fixture=Path(summary['fixture']);report=load(fixture/'verification.json');archive=summary['archive']
assert report['status']=='passed' and report['sourceCommit']=='c452881ac8db8f9f513752379971f5efbce4b15d' and report['productionIndexSha256']=='9a57fc2c0243d761bd576e1fed241ececd7ba154feec334b9f0349d26f5261ba'
assert summary['repositoryTests']==680 and len(report['captures'])==16 and report['daemonStopped'] and report['cleanup']==[] and report['errors']==[] and report['forbidden']==[]
assert archive['allEntryBytesMatch'] and sha(Path(archive['archive']).read_bytes())==archive['sha256']=='6ec9c91e7dd7586e5d776a270e1aa45dd3e86441ee23ea6392562bf55c9f61cb'
assert sha(Path(inputs['buildReceipt']).read_bytes())==report['buildReceiptSha256']
for row in report['calendarChecks']:
 assert row['tokens']==151 and row['actualDates']==row['expectedDates'] and row['clearedEndIgnored'] and row['pickerKeyboard'] and row['popoverContained'] and row['escapeRestoresFocus']
 assert [bar['count'] for bar in row['bars']]==[150,1]
referenceRoot=Path('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint');manifest=load(referenceRoot/'reference_manifest.json')
for entry in manifest['references']:
 route=Path(entry['file']).stem
 if route not in ['overview','live','projects','models','history','alerts','providers','cost']:continue
 p=referenceRoot/entry['file'];assert sha(p.read_bytes())==entry['sha256'];copy(p,'refs/'+route+'.png')
for row in report['captures']:
 name=row['phase']+'-'+row['route']+'.png';assert sha((fixture/name).read_bytes())==row['sha256'];copy(fixture/name,'images/'+name)
 if row['phase']=='initial':
  assert row['viewport']=={'width':row['reference']['width'],'height':row['reference']['height'],'dpr':1};copy(fixture/('viewport-initial-'+row['route']+'.json'),'evidence/native/viewport-'+row['route']+'.json')
 if not row['paintOraclePixelsExact']:
  p=fixture/(row['phase']+'-'+row['route']+'-native-attempt-1.png');assert sha(p.read_bytes())==row['nativeCaptureSha256'];copy(p,'images/native-api/'+name)
for phase in ['initial','restored-th-light']:
 for kind in ['palette-retained','history-observed','calendar-subday']:copy(fixture/(phase+'-'+kind+'.png'),'images/'+phase+'-'+kind+'.png')
for name in ['verification.json','settings.json','viewport-calibration.json']:copy(fixture/name,'evidence/native/'+name)
for name in ['summary.json','inputs.json','archive.json','reader-smoke.json','cleanup-standalone.json','cleanup-reader.json']:copy('tmp/release156/'+name,'evidence/'+name)
copy('tmp/release156/standalone-smoke/bundle-verification.json','evidence/standalone-smoke.json')
for name in ['reader-ingested.png','reader-incremental.png']:copy('screens/review-readers/'+name,'images/readers/'+name)
for p in Path('tmp/release156/build').iterdir():
 if p.suffix in ['.log','.json']:copy(p,'evidence/build/'+p.name+'.gz',True)
for name in ['prepare156.py','build-review156.ps1','prepare-review156.cjs','archive-review156.ps1','extract-review156.ps1','check-native-review156.mts','check-bundle156.mts','check-reader-archive156.mts','audit-review156.cjs','cleanup-owned156.ps1','package156.py','check-viewer156.mjs']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
for name in ['native','native-first','zip-smoke','reader']:copy('tmp/review156-'+name+'.log','evidence/logs/'+name+'.log.gz',True)
checkout=inputs['checkout'];run=lambda *args:subprocess.run(['git','-C',checkout,*args],capture_output=True,check=True).stdout.decode().strip()
assert run('rev-parse','HEAD')==report['sourceCommit'] and not run('status','--porcelain','--untracked-files=no')
visible=[line for line in run('ls-files','-t').splitlines() if not line.startswith('S ')]
write('source-provenance.json',{'checkout':checkout,'sourceCommit':report['sourceCommit'],'trackedSourceClean':True,'sparseVisibleTrackedFiles':len(visible),'productionIndexSha256':report['productionIndexSha256']})
verified=(out/'evidence/viewer.json').exists()
if verified:
 viewer=load(out/'evidence/viewer.json');assert viewer['sourceCommit']==report['sourceCommit'] and viewer['productionIndexSha256']==report['productionIndexSha256'] and viewer['status']=='passed' and len(viewer['cases'])==16 and viewer['errors']==[]
else:assert '--draft' in sys.argv
write('delivery.json',{'sourceCommit':report['sourceCommit'],'productionIndexSha256':report['productionIndexSha256'],'archive':archive,'repositoryTests':680,'nativeCaptures':16,'initialReferenceSizedPages':8,'nativeHistoryChecks':report['historyChecks'],'nativeCalendarChecks':report['calendarChecks'],'nativePaletteChecks':report['paletteChecks'],'standaloneSmokeChecks':6,'actualArchiveReaderChecks':6,'reviewPageVerified':verified,'physicalTrayMonitorValidated':False,'historicalSseIntermittenceResolved':False,'fullGoalComplete':False})
(out/'README.md').write_bytes(f'''# Review156 — runnable source155

[Review ZIP]({archive['archive'].replace(chr(92),'/')}) · [Original refs / actual Electron gallery](review.html) · [History date control](images/initial-calendar-subday.png)

Frozen source `{report['sourceCommit']}` includes the History reference table/token bars, compact date capsule and actions, Providers comparison graph, and initial quota-chart coordinate correction from source151–155. This is the latest portable review package; review150 remains preserved. The development-only SSE proxy correction is also in the frozen source and repository tests; the portable application connects directly to its daemon.

## Try it

Extract into a new dedicated folder and run PowerShell there:

```powershell
.\\scripts\\start-review.ps1 -EnableReaders
```

Open http://127.0.0.1:7807/#overview. Explicit -EnableReaders enables installed harness/configured quota readers into separate review-data, without importing the original application database. Initial scans may take several minutes. Without the switch the fresh profile starts empty with readers/account probes off. Stop with .\\scripts\\stop-review.ps1 before changing modes. Restart without the switch preserves collected review data but disables collection. The portable launcher exposes this switch; versioned installation wrappers do not. Pet stays disabled. No customer database, credentials or QA fixture database is packaged. Windows x64 and installed Node ABI127 are required (validated Node22.13.1); Node is external. -Port selects another port. No logon task is installed.

Archive: {archive['bytes']} bytes, {archive['entries']} entries. SHA256 `{archive['sha256']}`. Web index `{report['productionIndexSha256']}`.

## Validation

All six frozen application-only build/package stages passed. The clean sparse checkout contains{len(visible)} visible tracked files, and the full repository passes680 tests:129 daemon,353 web and198 tray, with no failures/skips/cancellations. Every ZIP entry matches the unchanged tested runtime folder. A fresh extraction outside repository dependencies passes6 portable start/stop/restart/profile-isolation checks. A second fresh extraction passes6 reader opt-in lifecycle checks using only an owned fake home and synthetic Codex logs:150→190 tokens, one session, deduplication, refresh, restart, default-off retention, prompt exclusion and unchanged original-profile/log sentinels.

Actual compiled Electron main and the exact sandboxed preload pass two cycles: EN/dark, then restart restoring TH/light, THB37.25 and1371×887 window settings. The final16 route captures are actual Electron page screenshots after DOM readiness. All8 initial frames use their own SHA-verified original reference dimensions: Overview1586×992, the other seven1672×941, DPR1. Renderer dimensions were measured and corrected through native window size feedback, without CSS zoom or screenshot resizing. The earlier first native QA run used1672×941 for every page; its log is retained as bounded evidence, while the final per-reference run is authoritative. The restored cycle intentionally shows its actual saved window size, not original-reference sizing.

The source151 token comparisons retain real150/1 counts,150 page maximum and exact ratios on50×6px tracks. The source152 date capsule opens with keyboard, fits the viewport and restores focus on Escape in both native phases. Two custom-date checks retain exact from/to/source/session scope and151 tokens, display the final included date and ignore a cleared end date. Native Projects facts/keyboard actions, metadata filters, observed/single-bucket History, cold palette query/focus handoff, Models180ms selection/reduced motion, preferences and window-size IPC also pass. All64 served web files match the tested distribution. All3159 bundle files remain unchanged. The owned native database retains3 records and221 tokens across native/computed/unknown monetary bases and passes integrity_check. All recorded QA daemons/tray processes stop.

The source bundle, both owned native profiles and ZIP remain retained. Only the two completed fresh ZIP QA extraction folders were removed, after exact archive/source/index/path/no-link/stopped-PID checks; separate cleanup receipts retain their identities and recovered bytes. Existing application data, prior ZIPs, main and unrelated work were preserved.

## Limits and remaining acceptance

The gallery compares original concept images with actual native QA data, not invented content. It does not claim99–100% approval. The16 current captures use an owned synthetic fixture; the delivered app displays collected actual data. Separate webContents.capturePage bitmap attempts are diagnostic and are not an exact parity pass. The native run uses offscreen/nonfocusable windows, anti-occlusion/background-throttling controls, and reduced motion except the explicit Models checks; this does not validate physical tray clicks, minimize/restore on real monitors, broad motion/performance or all customer/provider datasets. It is not installer/two-version migration/rollback acceptance.

The historical intermittent server2/client1 integration observation is still not fully explained. Source149 fixes a demonstrated daemon abort-before-handler defect, source154 fixes a demonstrated shipped-dev-proxy early-abort defect, and source155 fixes the reproduced initial quota-chart timing issue; these are bounded causal conclusions. Providers105 header pixels and Models3 edge pixels from previous browser comparisons remain unexplained, without masks or relaxed tolerances. Remaining visual/control/motion, customer/provider, native/monitor/performance and migration/rollback requirements still need the full blueprint audit. This portable delivery does not complete the overall goal.
'''.encode())
routes=['overview','live','projects','models','history','alerts','providers','cost']
(out/'review.html').write_bytes(('''<!doctype html><meta charset="utf-8"><title>Review156 / actual Electron and original refs</title><style>body{{font:14px system-ui;margin:20px;background:#071020;color:#def}}a{{color:#5cf}}select{{padding:8px;margin:6px}}section{{display:grid;grid-template-columns:1fr 1fr;gap:12px}}img{{width:100%;border:1px solid #456}}figure{{margin:0}}figcaption{{margin:8px 0}}@media(max-width:900px){{section{{grid-template-columns:1fr}}}}</style><h1>Review156 / original refs and actual Electron</h1><p>Initial native frames use original reference dimensions. Restored frames show the saved window size. Owned QA data differ from the concept. No similarity percentage or approval is claimed. <a href="README.md">Run instructions, evidence and limits</a></p><select id="route">{options}</select><select id="phase"><option value="initial">Initial / EN dark / reference dimensions</option><option value="restored-th-light">Restarted / TH light / saved window</option></select><section><figure><figcaption>Original concept / EN dark</figcaption><img id="reference" alt="Original concept reference"></figure><figure><figcaption id="caption"></figcaption><img id="image" alt="Actual compiled Electron app"></figure></section><script>const route=document.getElementById('route'),phase=document.getElementById('phase');function show(){{document.getElementById('reference').src='refs/'+route.value+'.png';document.getElementById('image').src='images/'+phase.value+'-'+route.value+'.png';document.getElementById('caption').textContent=phase.options[phase.selectedIndex].text}}route.onchange=phase.onchange=show;show()</script>''').format(options=''.join('<option>'+route+'</option>' for route in routes)).encode())
write('artifact-hashes.json',{p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='artifact-hashes.json'})
print('Sealed',len(load(out/'artifact-hashes.json')),'artifacts; viewer verified:',verified)
