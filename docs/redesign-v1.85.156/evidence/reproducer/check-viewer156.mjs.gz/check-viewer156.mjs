import assert from 'node:assert/strict';
import { readFileSync,writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { chromium } from 'playwright';
const root=resolve('docs/redesign-v1.85.156'),report=JSON.parse(readFileSync(resolve(root,'evidence/native/verification.json')));
assert.equal(report.sourceCommit,'c452881ac8db8f9f513752379971f5efbce4b15d');assert.equal(report.productionIndexSha256,'9a57fc2c0243d761bd576e1fed241ececd7ba154feec334b9f0349d26f5261ba');
const browser=await chromium.launch({channel:'chrome',headless:true});
try{
 const page=await browser.newPage(),errors=[],cases=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(pathToFileURL(resolve(root,'review.html')).href);
 for(const row of report.captures){
  await page.locator('#route').selectOption(row.route);await page.locator('#phase').selectOption(row.phase);
  const path='images/'+row.phase+'-'+row.route+'.png',reference='refs/'+row.route+'.png';
  await page.waitForFunction(({path,reference,width,height,refWidth,refHeight})=>{const img=document.getElementById('image'),ref=document.getElementById('reference');return img.complete&&img.naturalWidth===width&&img.naturalHeight===height&&decodeURI(img.currentSrc).endsWith(path)&&ref.complete&&ref.naturalWidth===refWidth&&ref.naturalHeight===refHeight&&decodeURI(ref.currentSrc).endsWith(reference)},{path,reference,width:row.nativeImageSize.width,height:row.nativeImageSize.height,refWidth:row.route==='overview'?1586:1672,refHeight:row.route==='overview'?992:941});cases.push(row.phase+'/'+row.route);
 }
 assert.equal(cases.length,16);assert.deepEqual(errors,[]);writeFileSync(resolve(root,'evidence/viewer.json'),JSON.stringify({status:'passed',sourceCommit:report.sourceCommit,productionIndexSha256:report.productionIndexSha256,browser:browser.version(),cases,errors},null,2)+'\n');console.log(JSON.stringify({checked:cases.length,errors}));
}finally{await browser.close()}
