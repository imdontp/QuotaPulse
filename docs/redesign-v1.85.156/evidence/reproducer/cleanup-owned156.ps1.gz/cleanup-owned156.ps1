param([Parameter(Mandatory=$true)][ValidateSet('standalone','reader')][string]$Stage,[Parameter(Mandatory=$true)][string]$ExpectedTarget)
$ErrorActionPreference='Stop'
. ./scripts/review-profile.ps1
$archiveRecord=Get-Content -LiteralPath tmp/release156/archive.json -Raw | ConvertFrom-Json
$expectedArchive='C:\Users\TH12367283\Projects\QuotaPulse\tmp\worktrees\redesign-validation-v1.85.155\tmp\review-bundles\QuotaPulse-v1.85.155-review156.zip'
if($archiveRecord.archive -ne $expectedArchive -or $archiveRecord.sourceCommit -ne 'c452881ac8db8f9f513752379971f5efbce4b15d'){throw 'Wrong archive provenance'}
Assert-ReviewPlainPath $expectedArchive
if((Get-FileHash -LiteralPath $expectedArchive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $archiveRecord.sha256){throw 'Archive changed'}
$receiptFile=if($Stage -eq 'standalone'){'tmp/release156/standalone-smoke/bundle-verification.json'}else{'tmp/release156/reader-smoke.json'}
$record=Get-Content -LiteralPath $receiptFile -Raw | ConvertFrom-Json
if($record.status -ne 'passed' -or $record.archive -ne $expectedArchive -or $record.archiveSha256 -ne $archiveRecord.sha256){throw 'Wrong owned QA receipt'}
$targetAbsolute=(Resolve-Path -LiteralPath $record.extracted).Path
$expectedAbsolute=[IO.Path]::GetFullPath($ExpectedTarget)
$tempRoot=(Resolve-Path -LiteralPath ([IO.Path]::GetTempPath())).Path.TrimEnd('\')
if($targetAbsolute -ne $expectedAbsolute -or (Split-Path -Parent $targetAbsolute).TrimEnd('\') -ne $tempRoot -or (Split-Path -Leaf $targetAbsolute) -notmatch '^QuotaPulse-review-[a-zA-Z0-9]+$'){throw 'Target is outside the exact owned temporary extraction'}
Assert-ReviewPlainPath $targetAbsolute
if(@(Get-ChildItem -LiteralPath $targetAbsolute -Recurse -Force -Attributes ReparsePoint).Count -ne 0){throw 'Linked entries are not eligible for cleanup'}
if((Get-FileHash -LiteralPath (Join-Path $targetAbsolute 'packages/web/dist/index.html') -Algorithm SHA256).Hash.ToLowerInvariant() -ne '9a57fc2c0243d761bd576e1fed241ececd7ba154feec334b9f0349d26f5261ba'){throw 'Wrong extracted web build'}
$state=Get-Content -LiteralPath (Join-Path $targetAbsolute 'review-data/review-processes.json') -Raw | ConvertFrom-Json
foreach($role in @('daemon','tray')){if(Get-Process -Id $state.$role.pid -ErrorAction SilentlyContinue){throw 'Owned QA process remains alive'}}
$bytes=(Get-ChildItem -LiteralPath $targetAbsolute -Recurse -File -Force | Measure-Object Length -Sum).Sum
$freeBefore=([IO.DriveInfo]::new('C:\')).AvailableFreeSpace
Remove-Item -LiteralPath $targetAbsolute -Recurse -Force
$receipt=@{stage=$Stage;path=$targetAbsolute;bytes=$bytes;recordedProcessesStopped=$true;sourceReceipt=$receiptFile;archive=$expectedArchive;archiveSha256=$archiveRecord.sha256;freeBefore=$freeBefore;freeAfter=([IO.DriveInfo]::new('C:\')).AvailableFreeSpace}
[IO.File]::WriteAllText((Join-Path (Get-Location) ('tmp/release156/cleanup-'+$Stage+'.json')),($receipt|ConvertTo-Json -Depth 6)+"`n",[Text.UTF8Encoding]::new($false))
$receipt|ConvertTo-Json -Depth 6
