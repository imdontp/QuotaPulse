from pathlib import Path
from zipfile import ZipFile
import hashlib, json, re, subprocess, tarfile

root = Path(__file__).resolve().parents[1]
project = root.parents[2]
out = root / 'tmp/rollback243'
assert not out.exists()
out.mkdir()
sha = lambda data: hashlib.sha256(data).hexdigest()
runtime_trees = ('packages/daemon/dist/', 'packages/tray/dist/', 'packages/tray/dist-preload/', 'packages/web/dist/')
runtime_files = {'scripts/task-entry.cjs', 'scripts/start-review.ps1', 'scripts/stop-review.ps1', 'scripts/review-profile.ps1', 'scripts/install-review.ps1', 'scripts/uninstall-review.ps1', 'packages/daemon/package.json', 'packages/tray/package.json', 'packages/tray/src/pet.html', 'packages/tray/src/gallery.html', 'packages/tray/src/gallery.css'}
specs = [
    ('previous', '236', 'QuotaPulse-v1.85.235-review236.zip', '00-archive.json', '3a711008ab2317f1fd170bcffe00af081cabfac24f1b2b7f8e6a5dd2001c3d48'),
    ('current', '243', 'QuotaPulse-v1.85.242-review243.zip', './archive.json', '05b737fcf86a81489e44a6122abc24ec2a475858305fdcd4f3fa3a52f1018e67'),
]
for label, version, filename, member, expected_index in specs:
    evidence = f'docs/redesign-v1.85.{version}/evidence.tar.gz'
    delivery = f'docs/redesign-v1.85.{version}/README.md'
    for file in (evidence, delivery):
        checked = subprocess.check_output(['git', 'show', f'HEAD:{file}'], cwd=root)
        assert checked == (root / file).read_bytes(), f'uncommitted evidence: {file}'
    with tarfile.open(root / evidence, 'r:gz') as data:
        receipt = json.loads(data.extractfile(member).read())
    archive = project / 'tmp/releases' / filename
    with archive.open('rb') as handle:
        digest = hashlib.file_digest(handle, 'sha256').hexdigest()
    assert digest == receipt['sha256'] and receipt['allEntryBytesMatch'] is True
    assert receipt.get('entries', receipt.get('fileCount')) == 3165
    assert digest in (root / delivery).read_text(encoding='utf-8')
    with ZipFile(archive) as z:
        names = [entry.filename for entry in z.infolist() if not entry.is_dir()]
        assert len(names) == len(set(names)) == 3165
        assert all(not n.startswith('/') and '\\' not in n and all(part not in ('', '.', '..') for part in n.split('/')) for n in names)
        runtime = {n: sha(z.read(n)) for n in names if n.startswith(runtime_trees) or n in runtime_files}
        assert runtime_files.issubset(runtime) and all(any(n.startswith(prefix) for n in runtime) for prefix in runtime_trees)
        assert runtime['packages/web/dist/index.html'] == expected_index
        manifest = json.loads(z.read('review-manifest.json'))
        assert (manifest['platform'], manifest['arch'], manifest['requiredNodeAbi']) == ('win32', 'x64', '127')
        daemon = z.read('packages/daemon/dist/index.js').decode()
        tray = z.read('packages/tray/dist/main.js').decode()
        profile = z.read('packages/tray/dist/instance-profile.js').decode()
        assert 'QUOTAPULSE_READERS' in daemon and re.search(r'readersEnabled\s*\?\s*ALL_ADAPTERS\s*:\s*\[\]', daemon)
        assert re.search(r'configureInstanceProfile\(app,\s*process\.env\.QUOTAPULSE_DATA_DIR\)', tray)
        assert "setPath('userData'" in profile and "setPath('sessionData'" in profile
    source = receipt['sourceCommit']
    assert source in (root / delivery).read_text(encoding='utf-8')
    record = {'archive': str(archive), 'archiveSha256': digest, 'sourceCommit': source, 'productionIndexSha256': expected_index,
              'delivery': delivery, 'deliverySha256': sha((root / delivery).read_bytes()), 'checkpoint': manifest['checkpoint'],
              'runtime': dict(sorted(runtime.items())), 'entries': len(names), 'isolatedEntryChecks': True}
    (out / f'{label}-provenance.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(label, source, manifest['checkpoint'], 'runtime files', len(runtime), flush=True)

for stem, ext in [('check-archive-rollback', 'ps1'), ('check-archive-rollback', 'cjs'), ('check-rollback-native', 'mts')]:
    source = (root / 'tmp' / f'{stem}236.{ext}').read_text(encoding='utf-8')
    source = source.replace('rollback236', 'rollback243').replace('native236', 'native243')
    target = root / 'tmp' / f'{stem}243.{ext}'
    assert not target.exists()
    target.write_text(source, encoding='utf-8', newline='\n')
