import collections,gzip,json
from pathlib import Path
standalone=json.loads(Path('tmp/frame171/standalone.json').read_text(encoding='utf-8'));summary=[]
for case in standalone['cases']:
 times=[s['at'] for s in case['samples']];gaps=[b-a for a,b in zip(times,times[1:])]
 summary.append(dict(context=case['contextNumber'],hidden=case['hidden'],frames=len(times),firstFrameMs=times[0],maximumFrameGapMs=max(gaps),nearEnd180=any(s['effects'][0]['state']=='running' and 120<=(s['effects'][0]['time'] or 0)<=180 for s in case['samples']),nearEnd700=any(s['effects'][1]['state']=='running' and 640<=(s['effects'][1]['time'] or 0)<=700 for s in case['samples']),finishes=case['finishes']))
result=dict(standalone=summary)
trace=Path('tmp/frame171/projects-trace.json.gz')
if trace.exists():
 data=json.loads(gzip.decompress(trace.read_bytes()));events=data['traceEvents'];counts=collections.Counter(e.get('name') for e in events)
 result['trace']={'events':len(events),'frequentEventNames':counts.most_common(24),'threadNames':[dict(pid=e['pid'],tid=e['tid'],name=e.get('args',{}).get('name')) for e in events if e.get('name')=='thread_name'],'longTimelineEvents':[dict(name=e['name'],ms=e['dur']/1000,pid=e['pid'],tid=e['tid'],at=e['ts']) for e in events if e.get('ph')=='X' and e.get('dur',0)>=50000 and e.get('name') in ['RunTask','Paint','Layout','UpdateLayoutTree','FunctionCall','FireAnimationFrame','CompositeLayers','Layerize','PrePaint']]}
Path('tmp/frame171/summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(result,indent=2))
