import json
from pathlib import Path
def summarize(path):
 data=json.loads(path.read_text(encoding='utf-8'));out=[]
 for c in data['cases']:
  samples=c['samples'];out.append(dict(context=c['contextNumber'],frames=len(samples),firstFrameMs=samples[0]['at'],maximumFrameGapMs=max(b['at']-a['at'] for a,b in zip(samples,samples[1:])),nearEnd180=any(s['effects'][0]['state']=='running' and 120<=(s['effects'][0]['time'] or 0)<=180 for s in samples),nearEnd700=any(s['effects'][1]['state']=='running' and 640<=(s['effects'][1]['time'] or 0)<=700 for s in samples),finishes=c['finishes']))
 return dict(browser=data['browser'],rendererArgs=data['rendererArgs'],cases=out)
result=dict(default=summarize(Path('tmp/frame171/standalone.json')),software=summarize(Path('tmp/frame171/software/standalone.json')))
Path('tmp/frame171/renderer-comparison.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result['software'],indent=2))
