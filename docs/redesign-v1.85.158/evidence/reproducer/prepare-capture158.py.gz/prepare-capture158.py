from pathlib import Path
s=Path('tmp/capture-fidelity157.mts').read_text(encoding='utf-8').replace('fidelity157/','fidelity158/')
needle='    const first = await page.screenshot('
assert s.count(needle)==1
s=s.replace(needle,'''    if(routeName==='models'){
      const table=await page.locator('.qp-model-table-wrap table').evaluate(node=>({width:node.getBoundingClientRect().width,scrollWidth:node.scrollWidth,wrapperWidth:node.parentElement!.clientWidth,rows:[...node.querySelectorAll('tbody tr')].map(row=>({rect:row.getBoundingClientRect().toJSON(),ratios:[...row.querySelectorAll('.qp-model-ratio')].map(ratio=>({kind:ratio.getAttribute('data-ratio-kind'),width:ratio.getBoundingClientRect().width,height:ratio.getBoundingClientRect().height,track:ratio.querySelector('.qp-bar')!.getBoundingClientRect().toJSON(),color:getComputedStyle(ratio.querySelector('.qp-bar>span')!).backgroundImage}))}))}));
      writeFileSync(resolve(output,'models-table.json'),JSON.stringify(table,null,2)+'\\n');
      assert.ok(table.width<=table.wrapperWidth+1,'Models reference-width columns must fit their viewport');assert.ok(table.rows.every(row=>row.rect.height===37),'Reference model rows must retain their37px density');
    }
''' + needle)
Path('tmp/capture-fidelity158.mts').write_bytes(s.encode())
