from pathlib import Path
from PIL import Image
import json
im=Image.open('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/models.png').convert('RGB')
rows=[]
for region,xs,ys in [('cache',range(858,892,5),range(408,419)),('coverage-slot',range(1082,1126,7),range(400,413))]:
 rows.append({'region':region,'rows':[{'y':y,'samples':[{'x':x,'rgb':im.getpixel((x,y))} for x in xs]} for y in ys]})
Path('tmp/model158-reference-samples.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
