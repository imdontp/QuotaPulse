from pathlib import Path
import gzip,hashlib,json,sys
out=Path('docs/redesign-v1.85.158');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,compressed=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not compressed and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0) if compressed else b)
def log(path):
 b=Path(path).read_bytes();return b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
before=load('tmp/fidelity157/final/verification.json');after=load('tmp/fidelity158/final/verification.json');focused=load('screens/model-ratio-bars/verification.json');diffs=load('tmp/fidelity158/analysis.json');density=load('tmp/fidelity158/final/models-table.json');priorDensity=load('tmp/fidelity158/before/models-table.json')
assert before['productionIndexSha256']=='dff79e4a60341cab38504dd5664ccbd8a69c6d3be35410b656c70609c98ad040'
assert after['productionIndexSha256']==focused['productionIndexSha256']==sha(Path('packages/web/dist/index.html').read_bytes())
assert load('tmp/models158-build-result.json')['status']==0 and len(focused['cases'])==16 and focused['errors']==[]
assert '# pass 353' in log('tmp/models158-web-tests.log') and '# fail 0' in log('tmp/models158-web-tests.log')
assert 'History/Overview/Projects/Live/Providers/Models/Cost/Alerts E2E passed' in log('tmp/models158-integration.log') and 'History teardown: database closed' in log('tmp/models158-integration.log')
matrix=load('screens/history/responsive-matrix.json');assert len(matrix['cases'])==144 and all(row['streams']<=1 for row in matrix['cases'])
assert len(after['results'])==8 and all(row['repeatIdentical'] and row['errors']==[] and row['forbidden']==[] for row in after['results'])
assert len([row for row in diffs if row['changedPixels']==0])==6 and next(row for row in diffs if row['route']=='providers')['changedPixels']==105
assert next(row for row in diffs if row['route']=='models')['bounds']==[842,394,1060,605]
assert len(density['rows'])==len(priorDensity['rows'])==6 and all(a['rect']['height']==b['rect']['height']==37 for a,b in zip(priorDensity['rows'],density['rows'])) and density['width']<=density['wrapperWidth']+1
ref=Path('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/models.png');assert sha(ref.read_bytes())==next(row for row in after['results'] if row['route']=='models')['referenceSha256'];copy(ref,'refs/models.png')
for phase,report,src in [('before',before,'tmp/fidelity157/final/models.png'),('after',after,'tmp/fidelity158/final/models.png')]:
 assert sha(Path(src).read_bytes())==next(row for row in report['results'] if row['route']=='models')['sha256'];copy(src,phase+'/models.png')
for src,dst in [('tmp/fidelity157/final/verification.json','canonical-before.json'),('tmp/fidelity158/final/verification.json','canonical-current.json'),('tmp/fidelity158/analysis.json','comparison.json'),('tmp/fidelity158/before/models-table.json','table-before.json'),('tmp/fidelity158/final/models-table.json','table-current.json'),('tmp/fidelity158/before/verification.json','measured-before.json'),('screens/model-ratio-bars/verification.json','ratios.json'),('screens/history/verification.json','integration.json'),('screens/history/responsive-matrix.json','integration-matrix.json'),('tmp/models158-build-result.json','build-result.json'),('tmp/model158-reference-samples.json','reference-samples.json')]:copy(src,'evidence/'+dst)
for name in ['en-dark-1672','th-light-390']:copy('screens/model-ratio-bars/'+name+'.png','images/'+name+'.png')
for src,dst in [('tmp/models158-build.log','build'),('tmp/models158-browser.log','focused'),('tmp/models158-web-tests.log','web-tests'),('tmp/models158-integration.log','integration'),('tmp/fidelity158-before.log','measured-before'),('tmp/fidelity158-final.log','canonical-current')]:copy(src,'evidence/logs/'+dst+'.log.gz',True)
for name in ['capture-fidelity158.mts','prepare-capture158.py','diff158.py','sample-model158.py','build158.cjs','package158.py','check-viewer158.mjs']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
sources={}
for name in ['packages/web/src/redesign/models.tsx','packages/web/src/redesign/models.css','scripts/check-model-ratio-bars.mts']:
 b=Path(name).read_bytes();sources[name]={'rawSha256':sha(b),'lfSha256':sha(b.replace(b'\r\n',b'\n'))}
write('source-hashes.json',sources)
verified=(out/'evidence/viewer.json').exists()
if verified:
 viewer=load(out/'evidence/viewer.json');assert viewer['status']=='passed' and viewer['productionIndexSha256']==after['productionIndexSha256'] and len(viewer['cases'])==2 and viewer['errors']==[]
else:assert '--draft' in sys.argv
write('delivery.json',{'parentCommit':'5e77b81c453d90032d9277edec78ccca19475c55','productionIndexSha256':after['productionIndexSha256'],'webTests':353,'focusedCases':16,'fullIntegrationPassed':True,'responsiveCases':144,'canonicalRepeatPairs':8,'unchangedOtherFrames':6,'providersUnexplainedPixels':105,'referenceTableFits':True,'modelRowHeight':37,'reviewPageVerified':verified,'nativeRevalidated':False,'newArchiveCreated':False,'fullGoalComplete':False})
(out/'README.md').write_bytes('''# Models reference ratio bars / source158

[Original / source157 / current gallery](review.html) · [Current Models](after/models.png) · [Tiny/zero/unknown fixture](images/en-dark-1672.png) · [Latest runnable ZIP review156](../redesign-v1.85.156/README.md)

At the original wide dark viewport, cache read share now uses an80×6px blue/violet track with the reference gradient direction and restrained edge/halo. Pricing Coverage uses an inline percentage with a50×6px green track in the accepted replacement for the concept's quality-score slot. Representative original cache/green pixels inform the paint, with full samples retained. The label and tooltip still describe recorded pricing coverage, not model quality. No benchmark, speed, lifecycle state or new data is invented. Light/narrow layouts keep their prior track dimensions and paint.

The original ratios are unchanged: cached input divided by fresh/cached/cache-write input, and native/computed/estimated priced calls divided by all recorded calls. Numeric data attributes retain exact raw percentages. Zero values have zero fill and no halo. Unknown denominators retain the existing dash with no track. Tiny positive values below1% now keep up to three significant digits in both table and selected details;1/1000000 renders0.0001% rather than a rounded zero. Common percentages retain the existing display format. The coverage grid allows its numeric label's natural width so precision does not overlap the track. No minimum fill is imposed.

## Verification

The production build passes. Sixteen compiled cases cover EN/TH, dark/light and390/900/1280/1672 widths using real HTTP and an owned in-memory DB. The Partial fixture has two records but10 weighted calls, of which4 are priced, so coverage is40%, not a record-based50%. Its fresh140/cached40/cache-write20 tokens produce20% cache share. Other groups cover0%,100%, unknown zero-call/input denominators and tiny0.0001% cache/coverage. Raw ratios and CSSOM serialization match exact independent expected values; geometric extents allow only the browser's1/64px quantization, while zero/full extents are exact. Tiny table and selected-detail labels agree. Keyboard selection, exact model/provider History links and page overflow also pass. No assertion or tolerance was relaxed after a failure.

All353 web tests and the full unchanged dashboard integration pass, including144 responsive cases and at most one SSE listener after navigation. Canonical before measurement recorded six37px model rows. All six remain37px and all reference-width columns fit without horizontal scrolling after the larger bars. The selected-model detail, chart, summaries, table structure and control behavior remain stable.

All eight current canonical within-context pairs are byte-identical. The historical source157 full baseline is indexdff79e4a60341cab38504dd5664ccbd8a69c6d3be35410b656c70609c98ad040. A separate measured-before Models capture uses that same index; it is not a new run relabeled against the updated source. Models changes are confined to842,394–1060,605 in the ratio cells and their glow. Six other full frames are byte-identical. Providers again has105 unexplained global-header pixels with maximum channel delta4, preserved unmasked; that historical rendering gate stays open.

```powershell
npm.cmd run build -w @quotapulse/web
npm.cmd run test -w @quotapulse/web
node --import tsx scripts/check-model-ratio-bars.mts
node --import tsx scripts/check-history.mts
```

The gallery retains complete frames and the SHA-verified original Models reference. Actual product/consistent QA values differ from the concept, and no99–100% approval or similarity percentage is claimed. Review156 remains the latest native ZIP, containing source155; it does not include source157 chips or source158 ratio paint/precision. No native/ZIP, physical tray/monitor, performance or migration/rollback acceptance was rerun here. Remaining visual/control/motion, customer/provider and desktop requirements still need the full blueprint audit. Main and unrelated work remain preserved.
'''.encode())
(out/'review.html').write_bytes('''<!doctype html><meta charset="utf-8"><title>Models ratio paint / source158</title><style>body{font:14px system-ui;margin:20px;background:#071020;color:#def}a{color:#5cf}select{padding:8px;margin:6px}section{display:grid;grid-template-columns:1fr 1fr;gap:12px}img{width:100%;border:1px solid #456}figure{margin:0}figcaption{margin:8px 0}@media(max-width:900px){section{grid-template-columns:1fr}}</style><h1>Models / original, source157, source158</h1><p>Original concept and consistent QA values differ. No similarity percentage or approval is claimed. <a href="README.md">Changes, evidence and limits</a></p><select id="left-source"><option value="refs">Original concept</option><option value="before">Before / source157</option></select><section><figure><figcaption id="left-label"></figcaption><img id="left" alt="Original or previous Models frame"></figure><figure><figcaption>Current / source158</figcaption><img id="right" src="after/models.png" alt="Current compiled Models frame"></figure></section><script>const source=document.getElementById('left-source');function show(){document.getElementById('left-label').textContent=source.options[source.selectedIndex].text;document.getElementById('left').src=source.value+'/models.png'}source.onchange=show;show()</script>'''.encode())
write('artifact-hashes.json',{p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='artifact-hashes.json'})
print('Sealed',len(load(out/'artifact-hashes.json')),'artifacts; viewer verified:',verified)
