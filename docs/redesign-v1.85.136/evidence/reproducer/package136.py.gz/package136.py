from pathlib import Path
import json,gzip,hashlib,subprocess
out=Path('docs/redesign-v1.85.136');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8').lstrip('\ufeff'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,zipped=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not zipped and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0)if zipped else b)
summary=load('tmp/release136/summary.json');inputs=load('tmp/release136/inputs.json');fixture=Path(summary['fixture']);report=load(fixture/'verification.json');archive=summary['archive']
assert report['sourceCommit']=='d2373e3aed7e01beac68f9417e6478c73d1256c1'
assert report['productionIndexSha256']=='0fd855c959228374a5733d3b0aebbb001e8b3394222eebe6c6836bd503cbc2d4'
assert summary['repositoryTests']==670 and summary['nativeCaptures']==16 and summary['modelControlChecks']==2 and summary['standaloneSmokeChecks']==6
assert archive['allEntryBytesMatch']and sha(Path(archive['archive']).read_bytes())==archive['sha256']
assert subprocess.check_output(['git','-C',inputs['checkout'],'status','--porcelain','--untracked-files=no'],text=True).strip()==''
assert sha(Path(inputs['buildReceipt']).read_bytes())==report['buildReceiptSha256']
assert not(Path(inputs['bundle'])/'review-data').exists()
for row in report['captures']:
 name=row['phase']+'-'+row['route']+'.png';assert sha((fixture/name).read_bytes())==row['sha256'];copy(fixture/name,'images/'+name)
for name in ['verification.json','settings.json']:copy(fixture/name,'evidence/native/'+name)
for name in ['summary.json','inputs.json','archive.json']:copy('tmp/release136/'+name,'evidence/'+name)
copy('tmp/release136/standalone-smoke/bundle-verification.json','evidence/standalone-smoke.json')
for p in Path('tmp/release136/build').iterdir():
 if p.suffix in ['.json','.log']:copy(p,'evidence/build/'+p.name+'.gz',True)
for name in ['build-review136.ps1','prepare-review136.cjs','archive-review136.ps1','extract-review136.ps1','check-native-review136.mts','check-bundle136.mts','audit-review136.cjs','check-viewer136.mjs','package136.py']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
viewer=load(out/'evidence/viewer.json');assert viewer['status']=='passed'and len(viewer['cases'])==16 and viewer['errors']==[]
for name in ['review136-native.log','review136-archive.log','review136-zip-smoke.log']:copy('tmp/'+name,'evidence/logs/'+name+'.gz',True)
write('delivery.json',{'sourceCommit':report['sourceCommit'],'index':report['productionIndexSha256'],'archive':archive,'fullGoalComplete':False,'realReaders':'disabled by review launcher; no real usage collection','repositoryTests':670,'nativeCaptures':16,'nativeModelControlChecks':2,'standaloneSmokeChecks':6})
(out/'README.md').write_text(f'''# QuotaPulse review136 — source135

[Download the local review ZIP]({archive['archive'].replace(chr(92),'/')}) · [Actual native screenshots](review.html)

Validated portable review delivery of frozen source `{report['sourceCommit']}`. This includes source133 two-sector token distribution, source134 header/filter/sort controls and responsive token values, and source135 finite ring selection interpolation with live reduced-motion guards and single-line English legend. The archive uses matching daemon, web, Electron main, sandboxed preload and runtime assets. Main and previous review archives are unchanged.

## Try it

Extract into a new dedicated folder. In PowerShell from that folder:

```powershell
.\\scripts\\start-review.ps1
```

Open http://127.0.0.1:7807/#overview or use the review tray icon to open Dashboard. Stop this instance with `.\\scripts\\stop-review.ps1`. A different `-Port` is supported. Windows x64 and an installed Node runtime with ABI127 are required; this build used Node22.13.1. Node is external. No logon task is installed.

The launcher creates its own empty profile with readers/account probes and Pet disabled. **This launcher does not collect real usage.** No customer database, credentials or synthetic fixture database is included. Populated screenshots come from an owned QA profile using the actual production application. Real-reader/customer acceptance remains open.

Archive: {archive['bytes']} bytes, {archive['entries']} entries. SHA256: `{archive['sha256']}`.

## Evidence

All six fresh build steps passed, including 670 repository tests (123 daemon,349 web,198 tray; zero failed/skipped/cancelled). The web index is `{report['productionIndexSha256']}`, identical to committed source135 evidence.

Actual compiled production Electron main/preload ran two cycles and captured all eight dashboard routes in EN/dark, then TH/light after restoring THB37.25 and window1371×887 from Settings. Both native Models frames verify all four metric values, unknown qualifier and partial cost stay on a single glyph line. Two additional native checks exercise header period, keyboard sort, exact ring shares, native180ms selection animations and live reduced-motion changes; scope/sort do not replay ring motion. All served web bytes are compared to bundle assets. The owned three-row QA database retains221 stored tokens and native/computed/unknown cost bases; integrity passes. Source bundle bytes remain unchanged and every QA process is stopped.

Every ZIP entry matches the unused bundle. The actual ZIP was extracted outside repository dependencies and passed six WhatIf/start/stop/data-preservation/restart checks with its own profile and bundled runtime dependencies. Raw build receipt is retained compressed so its SHA binding remains exact.

## Limits

Native windows were positioned beyond physical displays with test-only anti-occlusion/background-throttling overrides. Captures use reduced motion; the explicit native Models checks separately enable normal motion. First viewport: `{json.dumps(summary['firstViewport'])}`. First native image: `{json.dumps(summary['firstNativeImageSize'])}`. These are not physical-monitor, tray-click, reference-size pixel or performance acceptance. Two native language/theme combinations were exercised, not the full matrix.

Full blueprint and 99–100% visual acceptance remain open. Source135 retains three unexplained comparison-border pixel differences; prior distinct-document header differences remain open. See [source135 implementation evidence](../redesign-v1.85.135/README.md), the accepted v1.1 gap ledger and full requirement trace. This portable ZIP does not certify signed installation, two-version migration/rollback or real-reader behavior.
''',encoding='utf-8',newline='\n')
captures=report['captures'];phases=list(dict.fromkeys(row['phase']for row in captures));routes=list(dict.fromkeys(row['route']for row in captures))
html='''<!doctype html><meta charset="utf-8"><title>QuotaPulse review136 native dashboard</title><style>body{font:14px system-ui;background:#071020;color:#def;margin:20px}select{padding:8px;margin:6px}img{display:block;max-width:100%;border:1px solid #456}a{color:#5cf}</style><h1>Source135 / actual Electron review136</h1><p>Owned QA data. Not reference parity approval. <a href="README.md">Run instructions and limits</a></p><select id="route">'''+''.join('<option>'+route+'</option>'for route in routes)+'''</select><select id="phase">'''+''.join('<option>'+phase+'</option>'for phase in phases)+'''</select><img id="image" alt="Selected actual native dashboard"><script>const route=document.getElementById('route'),phase=document.getElementById('phase'),frame=document.getElementById('image');function show(){frame.src='images/'+phase.value+'-'+route.value+'.png'}route.onchange=phase.onchange=show;show()</script>'''
(out/'review.html').write_text(html,encoding='utf-8',newline='\n')
write('artifact-hashes.json',{str(p.relative_to(out)).replace('\\','/'):sha(p.read_bytes())for p in sorted(out.rglob('*'))if p.is_file()and p.name!='artifact-hashes.json'})
print(json.dumps({'artifacts':len(load(out/'artifact-hashes.json')),'source':report['sourceCommit'],'archive':archive['archive'],'sha256':archive['sha256']}))
