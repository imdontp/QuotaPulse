const fs=require('node:fs'),assert=require('node:assert/strict');
let s=fs.readFileSync('scripts/check-review-bundle.mts','utf8');
const old="const built=JSON.parse(readFileSync(resolve(output,'bundle-build.json'),'utf8'));";
assert.ok(s.includes(old));s=s.replace(old,"const input=JSON.parse(readFileSync(resolve(root,'tmp/release121/inputs.json'),'utf8'));\nconst built={...input,...JSON.parse(readFileSync(resolve(input.bundle,'review-manifest.json'),'utf8'))};\nassert.equal(built.requiredNodeAbi,process.versions.modules);");
s=s.replace("const output=resolve(root,'screens/tray-recovery');","const output=resolve(root,'tmp/release121/standalone-smoke');\nmkdirSync(output,{recursive:true});");
fs.writeFileSync('tmp/check-bundle121.mts',s);
