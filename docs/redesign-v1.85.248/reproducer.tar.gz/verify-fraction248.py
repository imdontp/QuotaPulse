from html.parser import HTMLParser
from pathlib import Path
import hashlib, json, tarfile

root = Path(__file__).resolve().parents[1]
directory = root / 'docs/redesign-v1.85.248'
previous = root / 'docs/redesign-v1.85.247/theme-captures.tar.gz'
report = json.loads((directory / 'stable-verification.json').read_text(encoding='utf-8'))
assert len(report['cases']) == 4
with tarfile.open(previous, 'r:gz') as archive:
    for case in report['cases']:
        for prefix, field in [('', 'sha256'), ('repeat-', 'repeatSha256')]:
            name = prefix + case['filename']
            archived = hashlib.sha256(archive.extractfile(name).read()).hexdigest()
            actual = hashlib.sha256((root / 'tmp/overview248-stable' / name).read_bytes()).hexdigest()
            assert archived == actual == case[field], name
class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.paths = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'img': self.paths.append(attrs['src'])
        if tag == 'a': self.paths.append(attrs['href'])
parser = Links()
parser.feed((directory / 'review.html').read_text(encoding='utf-8'))
assert len(parser.paths) == 5
for path in parser.paths: assert (directory / path).resolve(strict=True).is_file(), path
record = {'reusedCaptureArchive': '../redesign-v1.85.247/theme-captures.tar.gz', 'verifiedCaptureFiles': 8, 'htmlPathsVerified': len(parser.paths), 'scope': 'byte-identical synthetic integer captures only'}
(directory / 'gallery-verification.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified all eight unchanged captures against the retained archive and all comparison links.')
