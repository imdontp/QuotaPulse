from pathlib import Path
from PIL import Image
import hashlib, json, numpy as np, shutil

root = Path(__file__).resolve().parents[1]
out = root / 'docs/redesign-v1.85.248'
assert not out.exists()
old, new = (root / 'tmp/fidelity248' / phase for phase in ('before-selected', 'after-selected'))
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
before, after = (read(path / 'fraction-state.json') for path in (old, new))
assert before['text'] == after['text'] == '83.123456789%'
assert before['progress'] == after['progress'] == '83.123456789 100'
assert before['bounds']['left'] < before['globeLeft'] and before['bounds']['right'] > before['globeRight']
assert after['bounds']['left'] >= after['globeLeft'] and after['bounds']['right'] <= after['globeRight']
for folder in (old, new):
    capture = read(folder / 'verification.json')['results'][0]
    assert capture['repeatIdentical'] and not capture['errors'] and not capture['forbidden']
    assert sha(folder / 'overview.png') == capture['sha256'] == capture['repeatSha256']
stable = read(root / 'tmp/overview248-stable/verification.json')
index = sha(root / 'packages/web/dist/index.html')
assert stable['productionIndexSha256'] == read(new / 'verification.json')['productionIndexSha256'] == index
assert stable['captureMatrix']['complete'] and len(stable['pulseCoreChecks']) == 4
for check in stable['pulseCoreChecks']:
    assert all(value in check['boundaries'] for value in (0, 100, 125, 83.123456789, 99.99999999999999, 0.0000001)) and check['unknown']
assert sha(root / 'tmp/fidelity235/hero247-after/overview.png') == sha(root / 'tmp/fidelity235/precision248-integer/overview.png')
before_image, after_image = [Image.open(folder / 'overview.png').convert('RGB') for folder in (old, new)]
assert before_image.size == after_image.size == (1586, 992)
diff = np.any(np.asarray(before_image) != np.asarray(after_image), axis=2)
y, x = np.where(diff)
out.mkdir()
for folder, name in [(old, 'before'), (new, 'after')]:
    shutil.copyfile(folder / 'overview.png', out / f'{name}.png')
    shutil.copyfile(folder / 'fraction-state.json', out / f'{name}-state.json')
    shutil.copyfile(folder / 'verification.json', out / f'{name}-capture.json')
shutil.copyfile(root / 'tmp/overview248-stable/verification.json', out / 'stable-verification.json')
shutil.copyfile(root / 'tmp/fidelity235/precision248-integer/verification.json', out / 'integer-verification.json')
shutil.copyfile(root / 'tmp/fraction248-review.html', out / 'review.html')
record = {'productionIndexSha256': index, 'exactTextAndProgressPreserved': True, 'beforeOutsideGlobe': True, 'afterInsideGlobe': True,
          'integerCaptureIdenticalTo247': True, 'changedPixels': int(diff.sum()), 'changedBounds': [int(x.min()), int(y.min()), int(x.max()) + 1, int(y.max()) + 1],
          'scope': 'unmasked synthetic English/dark capture; not whole-dashboard visual acceptance'}
(out / 'analysis.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(record, indent=2))
