from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / 'tmp/capture-project235.mts').read_text(encoding='utf-8')
assert "addQuotaSample(1, '5h', 83," in source
source = source.replace("addQuotaSample(1, '5h', 83,", "addQuotaSample(1, '5h', 83.123456789,")
source = source.replace("'tmp/fidelity235/'", "'tmp/fidelity248/'")
needle = '    const geometry = await page.evaluate(() => {'
assert source.count(needle) == 1
probe = '''    if (routeName === 'overview') {
      const fractionState = await page.locator('.qp-pulse').evaluate(element => {
        const art = element.querySelector('.qp-pulse-art')!.getBoundingClientRect();
        const label = element.querySelector('.qp-pulse-label strong')!;
        const box = label.getBoundingClientRect();
        return { text: label.textContent, title: label.getAttribute('title'), aria: label.getAttribute('aria-label'),
          bounds: box.toJSON(), globeLeft: art.left + art.width * 66 / 360, globeRight: art.left + art.width * 294 / 360,
          progress: element.querySelector('[data-testid="pulse-progress"]')?.getAttribute('stroke-dasharray') };
      });
      writeFileSync(resolve(output, 'fraction-state.json'), JSON.stringify(fractionState, null, 2));
    }
'''
source = source.replace(needle, probe + needle)
destination = root / 'tmp/capture-fraction248.mts'
assert not destination.exists()
destination.write_text(source, encoding='utf-8', newline='\n')
