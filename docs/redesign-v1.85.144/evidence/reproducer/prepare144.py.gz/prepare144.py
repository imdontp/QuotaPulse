from pathlib import Path
mapping={'release141':'release144','review141':'review144','v1.85.140':'v1.85.143','1319c196e85e92e231b13e6a69dff68c97273705':'8c10e147439c9037131af77449c3ada0a6d9970f','2bab6990b174526765b76cc512552e3daf1c97a2a9b07aa1157ffd33cdd9b732':'fe8a649c287962fb33a67b296a21f880f7cafe95cfcb8fbceb0ee8da3ea7bfe1'}
for name in ['build-review141.ps1','prepare-review141.cjs','archive-review141.ps1','extract-review141.ps1','check-bundle141.mts','check-native-review141.mts','check-reader-archive141.mts','audit-review141.cjs']:
 s=Path('tmp',name).read_text(encoding='utf-8-sig')
 for before,after in mapping.items():s=s.replace(before,after)
 Path('tmp',name.replace('141','144')).write_text(s,encoding='utf-8',newline='\n')
