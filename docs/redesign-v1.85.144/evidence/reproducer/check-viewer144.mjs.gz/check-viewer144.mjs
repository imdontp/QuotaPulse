﻿import assert from 'node:assert/strict';
import { readFileSync,writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { chromium } from 'playwright';
const root=resolve('docs/redesign-v1.85.144'),report=JSON.parse(readFileSync(resolve(root,'evidence/native/verification.json')));
const browser=await chromium.launch({channel:'chrome',headless:true});
try {
 const page=await browser.newPage(),errors=[],cases=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(pathToFileURL(resolve(root,'review.html')).href);
 for(const row of report.captures){await page.locator('#route').selectOption(row.route);await page.locator('#phase').selectOption(row.phase);const path='images/'+row.phase+'-'+row.route+'.png';await page.waitForFunction(({path,width})=>{const img=document.getElementById('image');return img.complete&&img.naturalWidth===width&&decodeURI(img.currentSrc).endsWith(path)},{path,width:row.nativeImageSize.width});cases.push(row.phase+'/'+row.route)}
 assert.equal(cases.length,16);assert.deepEqual(errors,[]);writeFileSync(resolve(root,'evidence/viewer.json'),JSON.stringify({status:'passed',browser:browser.version(),cases,errors},null,2)+'\n');console.log(JSON.stringify({checked:cases.length,errors}));
}finally{await browser.close()}


