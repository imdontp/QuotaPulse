from pathlib import Path
s=Path('tmp/cleanup-owned141.ps1').read_text(encoding='utf-8')
for before,after in {
 'redesign-validation-v1.85.140':'redesign-validation-v1.85.143',
 'v1.85.140-review141':'v1.85.143-review144',
 '11124639f5dfce24d500eb5844aceb16e90ef704718be50b79916f62b4ba7ea5':'b44c66722d4f4102543b454ddcbd87d7df2875ac150fc135909c4c3cf53a2e31',
 'release141':'release144','cleanup141.json':'cleanup144.json',
 'QuotaPulse-review-Ee37jj':'QuotaPulse-review-sgOLyV','QuotaPulse-review-vw0bkO':'QuotaPulse-review-DxCRua',
 '2bab6990b174526765b76cc512552e3daf1c97a2a9b07aa1157ffd33cdd9b732':'fe8a649c287962fb33a67b296a21f880f7cafe95cfcb8fbceb0ee8da3ea7bfe1',
}.items():s=s.replace(before,after)
Path('tmp/cleanup-owned144.ps1').write_text(s,encoding='utf-8',newline='\n')
