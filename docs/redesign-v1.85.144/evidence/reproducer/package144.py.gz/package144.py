from pathlib import Path
import json,gzip,hashlib,subprocess,sys
out=Path('docs/redesign-v1.85.144');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8').lstrip('\ufeff'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,zipped=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not zipped and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0)if zipped else b)
summary=load('tmp/release144/summary.json');inputs=load('tmp/release144/inputs.json');fixture=Path(summary['fixture']);report=load(fixture/'verification.json');archive=summary['archive']
assert report['status']=='passed'and report['sourceCommit']=='8c10e147439c9037131af77449c3ada0a6d9970f'
assert report['productionIndexSha256']=='fe8a649c287962fb33a67b296a21f880f7cafe95cfcb8fbceb0ee8da3ea7bfe1'
assert summary['repositoryTests']==674 and len(report['captures'])==16 and len(report['projectChecks'])==len(report['paletteChecks'])==len(report['historyChecks'])==2
assert archive['allEntryBytesMatch']and sha(Path(archive['archive']).read_bytes())==archive['sha256']
assert sha(Path(inputs['buildReceipt']).read_bytes())==report['buildReceiptSha256']
assert subprocess.check_output(['git','-C',inputs['checkout'],'status','--porcelain','--untracked-files=no'],text=True).strip()==''
assert not(Path(inputs['bundle'])/'review-data').exists()
for row in report['captures']:
 name=row['phase']+'-'+row['route']+'.png';assert sha((fixture/name).read_bytes())==row['sha256'];copy(fixture/name,'images/'+name)
 native=fixture/(row['phase']+'-'+row['route']+'-native-attempt-1.png');assert sha(native.read_bytes())==row['nativeCaptureSha256']
 if not row['paintOraclePixelsExact']:copy(native,'images/native-api/'+name)
for phase in ['initial','restored-th-light']:copy(fixture/(phase+'-palette-retained.png'),'images/'+phase+'-palette-retained.png')
for name in ['verification.json','settings.json']:copy(fixture/name,'evidence/native/'+name)
for name in ['summary.json','inputs.json','archive.json','reader-smoke.json','cleanup141.json']:copy('tmp/release144/'+name,'evidence/'+name)
copy('tmp/release144/cleanup144.json','evidence/cleanup144.json')
copy('tmp/release144/standalone-smoke/bundle-verification.json','evidence/standalone-smoke.json')
for name in ['reader-ingested.png','reader-incremental.png']:copy('screens/review-readers/'+name,'images/readers/'+name)
for p in Path('tmp/release144/build').iterdir():
 if p.suffix in ['.log','.json']:copy(p,'evidence/build/'+p.name+'.gz',True)
for name in ['prepare144.py','build-review144.ps1','prepare-review144.cjs','archive-review144.ps1','extract-review144.ps1','check-native-review144.mts','check-bundle144.mts','check-reader-archive144.mts','audit-review144.cjs','cleanup-owned141.ps1','check-viewer144.mjs','package144.py']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
for name in ['cleanup-owned144.ps1','prepare-cleanup144.py']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
for name in ['native','archive','zip-smoke','reader-smoke']:copy('tmp/review144-'+name+'.log','evidence/logs/'+name+'.log.gz',True)
verified=(out/'evidence/viewer.json').exists()
if verified:
 viewer=load(out/'evidence/viewer.json');assert viewer['status']=='passed'and len(viewer['cases'])==16 and viewer['errors']==[]
else:assert '--draft'in sys.argv
write('delivery.json',{'sourceCommit':report['sourceCommit'],'productionIndexSha256':report['productionIndexSha256'],'archive':archive,'repositoryTests':674,'nativeCaptures':16,'nativeProjectChecks':report['projectChecks'],'nativePaletteChecks':report['paletteChecks'],'nativeHistoryChecks':report['historyChecks'],'nativeModelControlChecks':2,'standaloneSmokeChecks':6,'actualArchiveReaderChecks':6,'reviewPageVerified':verified,'fullGoalComplete':False})
(out/'README.md').write_text(f'''# Review144 — runnable source143

[Review ZIP]({archive['archive'].replace(chr(92),'/')}) · [Actual Electron images](review.html) · [Source143 implementation/diagnosis](../redesign-v1.85.143/README.md) · [Reference comparison](../redesign-v1.85.143/review.html)

Validated bounded portable delivery of frozen source `{report['sourceCommit']}`. This replaces the older review141 package for testing. It includes Projects reference summary/footer, the History reference filter toolbar, palette/query/keyboard intent surviving route loading, and bounded occupied Cost model tables with all ranked rows retained. Source143 additionally passes the complete combined integration suite,205 browser route-lifecycle cases and351 web tests; those implementation checks are distinct from this native/ZIP validation.

## Try it

Extract into a new dedicated folder and run PowerShell there:

```powershell
.\\scripts\\start-review.ps1 -EnableReaders
```

Open http://127.0.0.1:7807/#overview. Explicit `-EnableReaders` enables existing installed harness/configured quota readers into separate `review-data`; the original application database is not imported. Initial scanning can take several minutes. Omit the switch to start with readers/account probes off and an empty profile. Stop with `.\\scripts\\stop-review.ps1` before changing modes. Restart without the switch retains collected review data but disables collection. The switch applies to this portable launcher; versioned wrappers do not expose it. Pet is disabled. No customer database, credentials or synthetic fixture database is included.

Windows x64 and installed Node ABI127 are required; this was validated with Node22.13.1. Node is external. `-Port` selects a separate port. No logon task is installed.

Archive: {archive['bytes']} bytes; {archive['entries']} entries. SHA256 `{archive['sha256']}`. Web index `{report['productionIndexSha256']}`.

## Validation

All six fresh frozen-checkout build/package steps passed with674 repository tests (125 daemon,351 web,198 tray; zero failed/skipped/cancelled). The compact sparse checkout contains application packages/scripts/root files from the exact commit; historical documentation is omitted from this disposable build checkout. Matching daemon, renderer, Electron main/preload, approved runtime assets and notices are packaged.

Actual production Electron main and exact sandboxed preload ran two cycles with16 dashboard images: EN/dark, then TH/light after restoring THB37.25 and1371x887 Settings.64 served web assets matched the bundle; all3159 bundle files stayed unchanged. The three-row owned QA database retains221 tokens and native/computed/unknown price bases, with integrity check passing.

Two native cold-module checks deliberately hold the compiled Overview module, open/type in the real palette, release it, retain query/input focus and navigate to monthly Cost. Two native History checks preserve an unapplied draft, exercise More filters/Escape focus, apply an empty-result query, then clear via keyboard and restore151 tokens/two records while preserving source/session/all-time scope. Existing two native Projects fact/keyboard checks and two Models period/sort/180ms ring/live-reduced-motion checks also pass. All own native processes stop cleanly. These are two native language/theme combinations, not the full native matrix.

Every ZIP entry was byte-verified against its unused source folder. A fresh ZIP extraction outside repository dependencies passed six WhatIf/start/stop/data-preservation/restart checks. A separate fresh extraction passed six opt-in reader lifecycle checks using an owned fake home and synthetic Codex log:150 to190 tokens, one session retained through refresh/restart, prompt exclusion, unchanged source/original-profile sentinels. Account probes were disabled only for that reader QA. No customer logs or credentials were used.

## Limits and remaining work

The populated screenshots use owned QA data; they are not packaged demo content. Native windows were placed beyond physical displays with test-only anti-occlusion/background-throttling overrides. Captures use reduced motion except explicit normal-motion Models checks. Gallery images are actual Electron page screenshots after DOM readiness; separate `capturePage` bitmap comparisons remain diagnostics, not full exact-raster approval. Non-exact diagnostic frames are retained under `images/native-api`. First actual viewport `{json.dumps(summary['firstViewport'])}`; native image `{json.dumps(summary['firstNativeImageSize'])}`. This is not physical monitor/tray operation or resource/performance evidence.

All-time History currently spans the query's epoch-to-now range, which makes sparse owned data visually spread from1970; improving that display extent while preserving complete queries is a remaining visual usability item. The sparse native Cost fixture does not certify the occupied eight-model layout; source143's separate browser cases cover that. Original-reference99–100% approval, complete native/customer/all-provider matrices, signed installation and two-version migration/rollback remain open. Source143 retains105 unexplained Providers global-header pixel differences in one comparison; no masks or tolerance changes close that gate.

Disk pressure interrupted the initial full documentation checkout. The retry used a sparse application-only worktree and removed only two verified, stopped, generated review141 QA extractions (their source ZIP/hash and all original source/data were preserved). The cleanup receipt is retained. Main and older review ZIPs are unchanged.

After successful ZIP validation, the two review144 QA extractions were also removed manually after the same exact-path/hash/process checks; their receipt is retained. The executable ZIP and unused runtime source folder remain. This QA-only cleanup is not part of the packaged launcher; normal Stop preserves the user's review data.
''',encoding='utf-8',newline='\n')
routes=list(dict.fromkeys(row['route']for row in report['captures']));phases=list(dict.fromkeys(row['phase']for row in report['captures']))
html='''<!doctype html><meta charset="utf-8"><title>Source143 Electron review144</title><style>body{font:14px system-ui;background:#071020;color:#def;margin:20px}select{padding:8px;margin:6px}img{display:block;max-width:100%;border:1px solid #456}a{color:#5cf}</style><h1>Source143 / actual Electron review144</h1><p>Owned QA data. <a href="README.md">Run instructions and limits</a> · <a href="../redesign-v1.85.143/review.html">Reference comparison</a> · <a href="images/initial-palette-retained.png">Retained native palette</a></p><select id="route">'''+''.join('<option'+(' selected'if route=='projects'else'')+'>'+route+'</option>'for route in routes)+'''</select><select id="phase">'''+''.join('<option>'+phase+'</option>'for phase in phases)+'''</select><img id="image" alt="Actual production Electron dashboard"><script>const route=document.getElementById('route'),phase=document.getElementById('phase'),frame=document.getElementById('image');function show(){frame.src='images/'+phase.value+'-'+route.value+'.png'}route.onchange=phase.onchange=show;show()</script>'''
(out/'review.html').write_text(html,encoding='utf-8',newline='\n')
write('artifact-hashes.json',{str(p.relative_to(out)).replace('\\','/'):sha(p.read_bytes())for p in sorted(out.rglob('*'))if p.is_file()and p.name!='artifact-hashes.json'})
print(json.dumps({'artifacts':len(load(out/'artifact-hashes.json')),'archive':archive['archive'],'sha256':archive['sha256'],'viewerVerified':verified}))
