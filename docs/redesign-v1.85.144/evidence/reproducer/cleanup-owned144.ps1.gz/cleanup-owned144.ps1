$ErrorActionPreference='Stop'
. ./scripts/review-profile.ps1
$archive='C:\Users\TH12367283\Projects\QuotaPulse\tmp\worktrees\redesign-validation-v1.85.143\tmp\review-bundles\QuotaPulse-v1.85.143-review144.zip'
$archiveSha='b44c66722d4f4102543b454ddcbd87d7df2875ac150fc135909c4c3cf53a2e31'
Assert-ReviewPlainPath $archive
if((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $archiveSha){throw 'Restorable review archive hash mismatch'}
$tempRoot=(Resolve-Path -LiteralPath ([IO.Path]::GetTempPath())).Path.TrimEnd('\')
$checks=@()
foreach($recordFile in @('tmp/release144/standalone-smoke/bundle-verification.json','tmp/release144/reader-smoke.json')){
 $record=Get-Content -LiteralPath $recordFile -Raw | ConvertFrom-Json
 if($record.status -ne 'passed' -or $record.archiveSha256 -ne $archiveSha -or $record.archive -ne $archive){throw 'Owned QA receipt mismatch'}
 $cleanupTargetAbsolute=(Resolve-Path -LiteralPath $record.extracted).Path
 if((Split-Path -Parent $cleanupTargetAbsolute).TrimEnd('\') -ne $tempRoot -or (Split-Path -Leaf $cleanupTargetAbsolute) -notmatch '^QuotaPulse-review-[a-zA-Z0-9]+$'){throw 'Cleanup escaped the exact owned temporary extraction directory'}
 if($cleanupTargetAbsolute -notin @('C:\Users\TH12367283\AppData\Local\Temp\QuotaPulse-review-sgOLyV','C:\Users\TH12367283\AppData\Local\Temp\QuotaPulse-review-DxCRua')){throw 'Unexpected QA directory'}
 Assert-ReviewPlainPath $cleanupTargetAbsolute
 if(@(Get-ChildItem -LiteralPath $cleanupTargetAbsolute -Recurse -Force -Attributes ReparsePoint).Count -ne 0){throw 'Linked entries are not eligible for cleanup'}
 if((Get-FileHash -LiteralPath (Join-Path $cleanupTargetAbsolute 'packages/web/dist/index.html') -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'fe8a649c287962fb33a67b296a21f880f7cafe95cfcb8fbceb0ee8da3ea7bfe1'){throw 'Extracted build fingerprint mismatch'}
 $state=Get-Content -LiteralPath (Join-Path $cleanupTargetAbsolute 'review-data/review-processes.json') -Raw | ConvertFrom-Json
 foreach($role in @('daemon','tray')){if(Get-Process -Id $state.$role.pid -ErrorAction SilentlyContinue){throw 'Recorded QA process is still alive; refusing cleanup'}}
 $bytes=(Get-ChildItem -LiteralPath $cleanupTargetAbsolute -Recurse -File -Force | Measure-Object Length -Sum).Sum
 $checks+=@{path=$cleanupTargetAbsolute;bytes=$bytes;receipt=$recordFile;recordedProcessesStopped=$true;archiveSha256=$archiveSha}
}
$freeBefore=(Get-PSDrive C).Free
foreach($check in $checks){Remove-Item -LiteralPath $check.path -Recurse -Force}
New-Item -ItemType Directory -Path tmp/release144 -Force | Out-Null
$result=@{kind='only two owned stopped QA extractions removed; source and review ZIP retained';checks=$checks;freeBefore=$freeBefore;freeAfter=(Get-PSDrive C).Free}
[IO.File]::WriteAllText((Join-Path (Get-Location) 'tmp/release144/cleanup144.json'),($result|ConvertTo-Json -Depth 6)+"`n",[Text.UTF8Encoding]::new($false))
$result|ConvertTo-Json -Depth 6
