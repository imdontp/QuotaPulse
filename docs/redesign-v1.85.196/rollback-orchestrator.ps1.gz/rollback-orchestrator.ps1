<# Run an ACTUAL previous/current checkout rollback in a new isolated review profile.
No scheduled tasks or live collectors. Requires root's exclusive native execution slot.
PrepareOnly checks real bundle/checkout bindings without starting apps.
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$PreviousBundle,
  [Parameter(Mandatory)][string]$PreviousProvenance,
  [Parameter(Mandatory)][string]$CurrentBundle,
  [Parameter(Mandatory)][string]$CurrentProvenance,
  [Parameter(Mandatory)][string]$GitExecutable,
  [ValidateRange(1024,65535)][int]$Port=7818,
  [switch]$PrepareOnly
)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
. (Join-Path $root 'scripts/review-profile.ps1')
$helper=Join-Path $PSScriptRoot 'check-archive-rollback196.cjs'
$node=(Get-Command node -ErrorAction Stop).Source
$base=[IO.Path]::GetFullPath((Join-Path $root '../../../tmp/version-rollback196'))
Assert-ReviewPlainPath $base
New-Item -ItemType Directory -Path $base -Force | Out-Null
$fixture=Join-Path $base ('run-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $fixture | Out-Null
$target=Join-Path $fixture 'installation'
$identityPath=Join-Path $fixture 'identities.json'
$report=Join-Path $fixture 'verification.json'
$stages=[Collections.Generic.List[object]]::new()
function Save-Json([string]$Path,$Value) { [IO.File]::WriteAllText($Path,($Value | ConvertTo-Json -Depth 50)+"`n",[Text.UTF8Encoding]::new($false)) }
Save-Json (Join-Path $fixture 'fixture.json') @{mode='synthetic-two-archive-rollback';fixture=$fixture}
$config=Join-Path $fixture 'inputs.json'
Save-Json $config @{previousBundle=(Resolve-Path -LiteralPath $PreviousBundle).Path;previousProvenance=(Resolve-Path -LiteralPath $PreviousProvenance).Path;currentBundle=(Resolve-Path -LiteralPath $CurrentBundle).Path;currentProvenance=(Resolve-Path -LiteralPath $CurrentProvenance).Path;gitExecutable=(Resolve-Path -LiteralPath $GitExecutable).Path}
function Node-Check([string[]]$Arguments) {
  & $node $helper @Arguments
  if ($LASTEXITCODE -ne 0) { throw "Rollback helper failed: $($Arguments[0])" }
}
function Marker { Get-Content -LiteralPath (Join-Path $target 'installation.json') -Raw | ConvertFrom-Json }
function Active { Join-Path (Join-Path $target 'releases') (Marker).active }
function Stop-Owned {
  if ((Test-Path -LiteralPath (Join-Path $target 'installation.json')) -and (Test-Path -LiteralPath (Join-Path $target 'review-data\review-processes.json'))) {
    & (Join-Path $target 'stop.ps1')
  }
}

$identity=$null;$archives=$null;$baseline=$null;$cleanupError=$null
try {
  Node-Check -Arguments @('inspect',$config,$identityPath)
  $identity=Get-Content -LiteralPath $identityPath -Raw | ConvertFrom-Json
  if ($PrepareOnly) {
    Save-Json $report @{status='prepared only; no app launched';fixture=$fixture;identities=$identity;wholeGoalComplete=$false}
    Write-Host "Two-archive bindings verified only: $report"
    return
  }
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $archives=@{previous=@{path=$identity.previous.archive;sha256=(Get-FileHash -LiteralPath $identity.previous.archive -Algorithm SHA256).Hash.ToLowerInvariant()};current=@{path=$identity.current.archive;sha256=(Get-FileHash -LiteralPath $identity.current.archive -Algorithm SHA256).Hash.ToLowerInvariant()}}
  & (Join-Path $root 'scripts/install-review.ps1') -Archive $archives.previous.path -ExpectedSha256 $archives.previous.sha256 -Destination $target
  # First start creates only the disposable profile/schema. Stop before direct synthetic seeding.
  & (Join-Path $target 'start.ps1') -Port $Port
  Stop-Owned
  $baseline=Join-Path $fixture 'baseline.json'
  Node-Check -Arguments @('seed',$fixture,(Active),$baseline)
  foreach ($stage in @(
    @{name='previous-seeded';identity=$identity.previous},
    @{name='current-upgrade';identity=$identity.current},
    @{name='previous-rollback';identity=$identity.previous},
    @{name='current-recovery';identity=$identity.current}
  )) {
    if ($stage.name -eq 'current-upgrade') {
      & (Join-Path $root 'scripts/install-review.ps1') -Archive $archives.current.path -ExpectedSha256 $archives.current.sha256 -Destination $target
    } elseif ($stage.name -in @('previous-rollback','current-recovery')) {
      & (Join-Path $target 'rollback.ps1')
    }
    $expectedRelease='release-'+$(if($stage.identity.sourceCommit -eq $identity.previous.sourceCommit){$archives.previous.sha256}else{$archives.current.sha256})
    if ((Marker).active -ne $expectedRelease) { throw "Wrong active release during $($stage.name)" }
    $expected=Join-Path $fixture ($stage.name+'-identity.json')
    Save-Json $expected $stage.identity
    $bound=Join-Path $fixture ($stage.name+'-installed.json')
    Node-Check -Arguments @('installed',$fixture,$expected,$bound)
    & (Join-Path $target 'start.ps1') -Port $Port
    $live=Join-Path $fixture ($stage.name+'-live.json')
    Node-Check -Arguments @('live',$fixture,$expected,$live)
    $processState=Get-Content -LiteralPath (Join-Path $target 'review-data\review-processes.json') -Raw | ConvertFrom-Json
    $processes=@()
    foreach ($role in @('daemon','tray')) {
      $record=$processState.$role
      $proc=Get-CimInstance Win32_Process -Filter "ProcessId=$([int]$record.pid)" -ErrorAction Stop
      $entry=Join-Path (Active) 'scripts\task-entry.cjs'
      $data=Join-Path $target 'review-data'
      if (-not $proc -or -not $proc.CommandLine.Contains($entry) -or -not $proc.CommandLine.Contains($data) -or -not $proc.CommandLine.Contains("--role $role") -or -not $proc.CommandLine.Contains('--no-readers') -or $proc.CreationDate.ToUniversalTime().ToString('O') -ne $record.created) { throw "Actual $role process identity does not match this installed checkout" }
      $processes+=@{role=$role;pid=$record.pid;created=$record.created;commandLine=$proc.CommandLine;executablePath=$proc.ExecutablePath}
    }
    Stop-Owned
    foreach ($record in $processes) {
      $remaining=Get-CimInstance Win32_Process -Filter "ProcessId=$([int]$record.pid)" -ErrorAction SilentlyContinue
      if ($remaining -and $remaining.CreationDate.ToUniversalTime().ToString('O') -eq $record.created) { throw 'Owned process has not reached terminal after scoped stop' }
    }
    & $node --import tsx (Join-Path $root 'tmp/check-rollback-native196.mts') $fixture $stage.name
    if ($LASTEXITCODE -ne 0) { throw "Native isolated profile check failed: $($stage.name)" }
    $native=Get-Content -LiteralPath (Join-Path $fixture ($stage.name+'-native.json')) -Raw | ConvertFrom-Json
    if ($native.status -ne 'passed' -or $native.release -ne (Marker).active) { throw 'Native result does not match the active release' }
    $after=Join-Path $fixture ($stage.name+'-snapshot.json')
    Node-Check -Arguments @('snapshot',$fixture,(Active),$after)
    if ([IO.File]::ReadAllText($baseline) -ne [IO.File]::ReadAllText($after)) { throw "Durable schema/fact/null/pricing/settings/window invariants changed during $($stage.name); original and observed snapshots retained" }
    $sentinel=Join-Path $target 'review-data\rollback-sentinel.txt'
    if ([IO.File]::ReadAllText($sentinel) -ne "synthetic-only; preserve across actual app checkout rollback`n") { throw 'Synthetic profile sentinel changed' }
    $stages.Add(@{name=$stage.name;sourceCommit=$stage.identity.sourceCommit;release=(Marker).active;installed=$bound;live=$live;snapshot=$after;processes=$processes;ownedProcessesTerminal=$true;durableSnapshotEqual=$true;native=$native})
  }
  Save-Json $report @{status='passed actual two-archive rollback';fixture=$fixture;identities=$identity;archives=$archives;baseline=$baseline;stages=@($stages);readersDisabled=$true;wholeGoalComplete=$false;limitations=@('unsigned review bundle with host Node prerequisite; no production install or tasks','actual installed daemon and tray processes checked; native dashboard separately launched from the active release after wrapper processes stop','DB app/notification/window settings and native Electron language/theme/currency/rate covered in one isolated shared profile','pet/tray animation disabled by existing review start helper; no pet appearance preference preservation claim','stored schema and usage/pricing invariants; no supported migration to a different schema is claimed','no signed artifact, user visual acceptance, CPU budget or whole RC claim')}
  Write-Host "Actual two-checkout rollback passed: $report"
} catch {
  Save-Json $report @{status='failed or incomplete actual two-archive rollback';fixture=$fixture;error=$_.Exception.ToString();stages=@($stages);wholeGoalComplete=$false}
  throw
} finally {
  try { Stop-Owned } catch { $cleanupError=$_.Exception.ToString(); Write-Warning "Owned review cleanup failed; fixture retained: $cleanupError" }
  if ($cleanupError) {
    $saved=Get-Content -LiteralPath $report -Raw | ConvertFrom-Json
    $saved.status='incomplete; owned cleanup requires inspection'
    $saved | Add-Member -NotePropertyName cleanupError -NotePropertyValue $cleanupError -Force
    Save-Json $report $saved
    throw "Owned cleanup failed: $cleanupError"
  }
}
