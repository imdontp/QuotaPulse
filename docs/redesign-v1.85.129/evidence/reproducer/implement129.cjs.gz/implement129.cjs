const fs=require('fs'),assert=require('assert/strict');
function edit(p,fn){const before=fs.readFileSync(p,'utf8'),after=fn(before);assert.notEqual(after,before,p);fs.writeFileSync(p,after);}
const dir='packages/web/src/redesign/';
// These modules use VendorIcon exclusively for recorded-provider fields.
for(const name of ['live.tsx','cost.tsx'])edit(dir+name,s=>s.replace("import { VendorIcon } from '@/components/vendor-icon';","import { ProviderMark as VendorIcon } from './provider-mark';"));
for(const name of ['overview.tsx','models.tsx','projects.tsx','history-record-details.tsx'])edit(dir+name,s=>{
 s=s.replace("import { VendorIcon } from '@/components/vendor-icon';","import { VendorIcon } from '@/components/vendor-icon';\nimport { ProviderMark } from './provider-mark';");
 for(const expression of name==='overview.tsx'?["node.key ?? 'unknown'","item.provider ?? 'unknown'"]:name==='models.tsx'?["group.provider ?? 'unknown'","value.provider || 'unknown'"]:name==='projects.tsx'?["provider","row.provider ?? 'unknown'"]:["row.provider ?? 'unknown'"]){
  const old='<VendorIcon vendor={'+expression+'}';assert.ok(s.includes(old),name+expression);s=s.replaceAll(old,'<ProviderMark vendor={'+expression+'}');
 }
 return s;
});
edit(dir+'models.tsx',s=>{
 s=s.replace('  const providerRows = data ? modelProviderTrends(data) : [];',`  const providerRows = data ? modelProviderTrends(data) : [];
  const recordedProviders = new Set(groups.map(group => group.provider).filter(provider => provider !== null && provider.trim() !== ''));
  const missingProviderPairs = groups.filter(group => group.provider === null || group.provider.trim() === '').length;
  const inputTokens = data ? data.totals.inputTokens + data.totals.cachedInputTokens + data.totals.cacheWriteTokens : 0;`);
 const first='<strong>{number(groups.length)}</strong>';assert.equal(s.split(first).length,2);
 s=s.replace(first,first+`<small data-testid="models-provider-count" data-known-providers={recordedProviders.size} data-unknown-provider-pairs={missingProviderPairs}>{t('redesign.providersUsed')}: {number(recordedProviders.size)}{missingProviderPairs > 0 && <abbr title={t('redesign.unknownValue') + ': ' + number(missingProviderPairs) + ' ' + t('redesign.modelsCount')}> + ?</abbr>}</small>`);
 const calls="<small>{t('redesign.modelsCalls')}: {number(data!.totals.calls)}</small>";assert.ok(s.includes(calls));
 s=s.replace(calls,`<small className="qp-model-token-components" title={t('redesign.liveFlowBreakdown')}><span data-component="input" data-value={inputTokens} title={number(inputTokens)}>{t('redesign.modelsInput')} <b>{f.tokens(inputTokens)}</b></span><span data-component="output" data-value={data!.totals.outputTokens} title={number(data!.totals.outputTokens)}>{t('redesign.modelsOutput')} <b>{f.tokens(data!.totals.outputTokens)}</b></span></small>`);
 return s;
});
for(const [locale,text] of [['en','Input'],['th','อินพุต']])edit('packages/web/src/i18n/'+locale+'.ts',s=>s.replace("  'redesign.modelsFreshInput':",`  'redesign.modelsInput': '${text}',\n  'redesign.modelsFreshInput':`));
edit(dir+'models.css',s=>s+`\n/* Reference summary facts use recorded counts/components, without growth claims. */
.qp-model-summary .qp-model-token-components { display:flex; flex-wrap:wrap; align-content:start; gap:2px 10px; }
.qp-model-token-components>span { white-space:nowrap; font-size:10px; }
.qp-model-token-components b { color:var(--qp-accent); font-weight:500; }
.qp-model-summary [data-testid=models-provider-count] { overflow-wrap:anywhere; }
`);
