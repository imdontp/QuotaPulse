const fs=require('fs');
let s=fs.readFileSync('tmp/check-summary129-native.mts','utf8');
const begin=s.indexOf(' for(const [routeName,ready]of Object.entries(targets))'),end=s.indexOf(' assert.equal(sha(readFileSync(indexPath)),index);',begin);
s=s.slice(0,begin)+fs.readFileSync('tmp/scenarios129-body.txt','utf8')+s.slice(end);
s=s.replace('tmp/fidelity129/native','tmp/fidelity129/scenarios');fs.writeFileSync('tmp/check-summary129-scenarios.mts',s);
fs.cpSync('tmp/fidelity128/final','tmp/fidelity129/before',{recursive:true});
let analysis=fs.readFileSync('tmp/analyze128.py','utf8').replaceAll('tmp/fidelity128','tmp/fidelity129');fs.writeFileSync('tmp/analyze129.py',analysis);
