from pathlib import Path
import json,hashlib,gzip,subprocess,re
root=Path('docs/redesign-v1.85.129');base=Path('tmp/fidelity129');root.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf8').lstrip('\ufeff'))
def write(name,value):
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
def copy(src,name,zipped=False):
 b=Path(src).read_bytes()
 if str(src).endswith('.log'):b=b.decode('utf-16' if b[:2]==b'\xff\xfe' else 'utf8').lstrip('\ufeff').replace('\r\n','\n').encode()
 if zipped:b=gzip.compress(b,mtime=0)
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
index=sha(Path('packages/web/dist/index.html').read_bytes());native=load(base/'native/verification.json');scenarios=load(base/'scenarios/verification.json');final=load(base/'final/verification.json');before=load(base/'before/verification.json');analysis=load(base/'analysis.json')
assert index==native['index']==scenarios['index']==final['productionIndexSha256']==analysis['afterIndex']
assert native['status']=='passed' and len(native['results'])==48
assert scenarios['status']=='passed' and len(scenarios['results'])==12
assert all(r['repeatIdentical'] for r in final['results']) and all(r['mainGeometryEqual'] for r in analysis['rows'])
stable=load('screens/models-comparison/verification.json');assert stable['productionIndexSha256']==index and len(stable['cases'])==4
assert stable['status']=='repeatable within recorded raster tolerance; review candidates, not approved visual baselines'
routes=[]
for r in final['results']:
 name=r['route'];prior=next(p for p in before['results'] if p['route']==name);beforePath='../redesign-v1.85.128/images/final/'+name+'.png'
 assert sha((root/beforePath).read_bytes())==prior['sha256'];original='../redesign-v1.85.69/refs/'+name+'.png';assert sha((root/original).read_bytes())==r['referenceSha256']
 source=base/'final'/(name+'.png');assert sha(source.read_bytes())==r['sha256']
 current=beforePath
 if r['sha256']!=prior['sha256']:current='images/'+name+'.png';copy(source,current)
 routes.append({'route':name,'original':original,'before':beforePath,'final':current,'beforeSha256':prior['sha256'],'finalSha256':r['sha256'],'referenceSha256':r['referenceSha256']})
for name in ['native','scenarios','before','final']:copy(base/name/'verification.json','evidence/'+name+'.json.gz',True)
copy(base/'analysis.json','evidence/analysis.json')
copy('screens/models-comparison/verification.json','evidence/stable.json.gz',True);copy(base/'stable-th-dark/verification.json','evidence/isolated-th-dark.json.gz',True)
for name in ['models-en-dark.png','models-en-light.png','models-th-dark.png','models-th-light.png']:copy(Path('screens/models-comparison')/name,'images/stable/'+name)
for name in ['models-th-light-390','models-en-dark-1672']:copy(base/'native'/(name+'.png'),'images/native/'+name+'.png')
for name in ['unknown-th-dark-390','filtered-th-light-390','empty-en-light-390']:copy(base/'scenarios'/(name+'.png'),'images/scenarios/'+name+'.png')
for name in ['build129-web-final.log','test129-web.log','fidelity129-native.log','fidelity129-scenarios.log','fidelity129-final.log','stable129-models.log','stable129-models-th-dark-diagnosis.log','stable129-models-final.log']:copy(Path('tmp')/name,'evidence/logs/'+name+'.gz',True)
for name in ['implement129.cjs','prepare129.cjs','prepare129-scenarios.cjs','native129-body.txt','scenarios129-body.txt','check-summary129-native.mts','check-summary129-scenarios.mts','capture-fidelity129.mts','analyze-summary129.py','package129.py','check-viewer129.mjs']:copy(Path('tmp')/name,'evidence/reproducer/'+name+'.gz',True)
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+['packages/web/src/redesign/provider-mark.tsx'];assert len(paths)==12
write('source-fingerprints.json',[{'path':p,'rawSha256':sha(Path(p).read_bytes()),'lfSha256':sha(Path(p).read_bytes().replace(b'\r\n',b'\n'))} for p in paths])
for name in ['harness-icon.tsx','vendor-icon.tsx']:
 p='packages/web/src/components/'+name;assert subprocess.check_output(['git','show','HEAD:'+p]).replace(b'\r\n',b'\n')==Path(p).read_bytes().replace(b'\r\n',b'\n')
test=Path('tmp/test129-web.log').read_bytes();test=test.decode('utf-16' if test[:2]==b'\xff\xfe' else 'utf8');assert re.search(r'^# pass 335\r?$',test,re.M) and re.search(r'^# fail 0\r?$',test,re.M)
summary={'checkpoint':'v1.85.129','parent':'367aa77172ff4cdf8b8abc02f3fedfee6adbb969','index':index,'webTests':335,'browserMatrixCases':48,'edgeScopeCases':12,'stablePairs':len(stable['cases']),'stableExactPairs':sum(r['sha256']==r['repeatSha256'] for r in stable['cases']),'withinContextExactRepeats':8,'mainGeometryUnchanged':True,'fullRedesignComplete':False,'fullDistinctDocumentGate':'Not rerun for all pages;128 full gate and Providers/History repeat failures remain unresolved','initialModelsAttempt':'Failed at Thai dark initial chart readiness. Not reproduced in isolated Thai dark, then final four-context run passed. Cause not established; an overlapping completed-source rebuild occurred during the first run.'}
write('summary.json',summary);write('review-manifest.json',{'index':index,'captures':routes})
(root/'README.md').write_text('''# Models summary and provider identity v1.85.129

[Open before / current / original review](review.html). Full redesign remains incomplete; this is not99–100% visual acceptance.

## Implemented from the supplied reference

- Models now shows the number of distinct named recorded providers below the model/route count. Null and empty provider groups are excluded from that count and shown with a separate +? disclosure, including the actual number of affected pairs. This is scoped source data, not a catalogue claim or invented four-provider constant.
- The token summary now shows recorded input and output beneath the total, matching the reference's information placement. Input combines fresh input, cache reads and cache writes; the tooltip explains components and possible stored-total differences. Compact values retain exact localized counts in their titles. Total remains the independently recorded total, even when components do not reconcile. Calls remain available in the comparison and detail.
- Anthropic recorded-provider fields use a native SVG company AI mark based on the supplied reference. Claude model and subscription/product marks retain their original star. This applies to Overview runtime/activity, Live provider fields, Projects provider fields, Models provider comparison/distribution, History provider cells/detail and Cost provider cells. Other identities retain the existing VendorIcon exactly; no alias/prefix guessing, vendor/model reassignment or data rewriting. Original shared VendorIcon/HarnessIcon files are unchanged. No Pet, backend or new dependency changes.

## Verification

- TypeScript/production build passed.335/335 web tests passed.
-48 actual Chrome cases: six affected routes, EN/TH, dark/light,390/1672. Models summary is independently reconciled with the API URL actually requested by the UI. The comparison keeps the provider company mark separate from the model artwork. Summary content fits its cards, and pages have no horizontal overflow, browser errors or forbidden writes. These are Chrome browser tests, not a physical desktop/Electron acceptance run.
-12 additional390px scenarios cover each language/theme with null and empty provider identities, an Anthropic filter, and a scope with no events. The fixture intentionally contains stored totals777/888 that differ from their components; the app keeps the recorded total and the real input/output values. Synthetic rows exist only in this owned in-memory QA database and are not shipped.
- Final Models distinct-document repeat gate passed all four language/theme pairs under its existing tolerance; exact-pair count is recorded in summary.json. This also exercises source-backed summary/history charts, keyboard model selection, complete table data, unknown/zero/tiny ratio boundaries and390/900/1280 overflow.
- The first four-context attempt timed out waiting for the Thai dark trend before its functional assertions. The isolated Thai dark reproduction passed exactly, and the final complete run passed. Cause is NOT established; a source-equivalent rebuild overlapped the first run. No timeout increase, rendering workaround or relaxed tolerance was introduced. The harness now records DOM/pending-request/screenshot diagnostics if page readiness fails again. The failed initial log is retained.
- All eight source-sized pages repeat byte exactly within their own contexts, and main region geometry is unchanged. See analysis.json for every before/current pixel delta. Providers has105 header pixels/max4 different from128 despite no Providers source change; this remains an observed difference without a cause/resolution claim. No diagnostic masks were used to pass tests.

## Still outstanding

The full all-page distinct-document gate is not proven green:128 Providers/History header-repeat failures remain unresolved. Global visual fidelity, remaining card/ring/material/control comparisons, physical desktop/real-reader acceptance and a ZIP that includes126–129 remain work. The runnable review125 ZIP is still based on source124. Main remains unchanged; source and tag are isolated on design/redesign-foundation.
''',encoding='utf8',newline='\n')
manifest=json.dumps({'captures':routes})
(root/'review.html').write_text('''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>QuotaPulse129 review</title><style>body{background:#08111e;color:#deecff;font:15px system-ui;margin:20px}a{color:#38c9ff}select{padding:8px;margin:5px}img{width:100%;height:auto;display:block;margin:12px 0;border:1px solid #234}</style><h1>QuotaPulse129</h1><p>Models recorded summary and provider/company artwork. Overall redesign incomplete. <a href="README.md">Evidence and limits</a></p><label>Page <select id="route">'''+''.join('<option>'+r['route']+'</option>' for r in routes)+'''</select></label><label>Frame <select id="phase"><option value="final">Current129</option><option value="original">Original concept</option><option value="before">Before128</option></select></label><p id="caption"></p><img id="image" alt="Selected dashboard frame"><h2>Thai light narrow example</h2><img src="images/native/models-th-light-390.png" alt="Real summary data in a narrow Thai light browser"><script>const data='''+manifest+''',route=document.getElementById('route'),phase=document.getElementById('phase'),frame=document.getElementById('image');function render(){const row=data.captures.find(r=>r.route===route.value);frame.src=row[phase.value];document.getElementById('caption').textContent=route.value+' / '+phase.value}route.onchange=phase.onchange=render;render();</script></html>''',encoding='utf8',newline='\n')
write('artifact-hashes.json',{str(p.relative_to(root)).replace('\\','/'):sha(p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file() and p.name!='artifact-hashes.json'})
print(json.dumps(summary))
