const fs=require('fs'),assert=require('assert/strict');
let s=fs.readFileSync('packages/web/src/sections/history.tsx','utf8');
s=s.replace("import { VendorIcon } from '@/components/vendor-icon';","import { VendorIcon } from '@/components/vendor-icon';\nimport { ProviderMark } from '@/redesign/provider-mark';");
const old='<span className="qp-history-provider"><VendorIcon';assert.ok(s.includes(old));s=s.replace(old,'<span className="qp-history-provider"><ProviderMark');fs.writeFileSync('packages/web/src/sections/history.tsx',s);
s=fs.readFileSync('tmp/check-marks128-native.mts','utf8');s=s.slice(0,s.indexOf('const results:unknown[]=[];')).replace('tmp/fidelity128/native','tmp/fidelity129/native');s+=fs.readFileSync('tmp/native129-body.txt','utf8');fs.writeFileSync('tmp/check-summary129-native.mts',s);
s=fs.readFileSync('tmp/capture-fidelity128.mts','utf8').replaceAll('tmp/fidelity128','tmp/fidelity129');fs.writeFileSync('tmp/capture-fidelity129.mts',s);
