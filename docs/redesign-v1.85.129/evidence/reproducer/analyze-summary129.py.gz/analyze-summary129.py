from pathlib import Path
from PIL import Image
import numpy as np,json
root=Path('tmp/fidelity129');load=lambda p:json.loads(p.read_text(encoding='utf8'))
before=load(root/'before/verification.json');after=load(root/'final/verification.json');rows=[]
for entry in after['results']:
 route=entry['route'];old=next(r for r in before['results'] if r['route']==route)
 a=np.asarray(Image.open(root/'before'/f'{route}.png').convert('RGB')).astype(int);b=np.asarray(Image.open(root/'final'/f'{route}.png').convert('RGB')).astype(int)
 d=np.abs(a-b);changed=d.max(axis=2)>0;yy,xx=np.where(changed)
 rows.append({'route':route,'changedPixels':int(changed.sum()),'maxChannelDelta':int(d.max()),'bbox':None if not len(xx) else [int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())],'mainGeometryEqual':old['geometry']['mainRegions']==entry['geometry']['mainRegions'],'beforeRepeatExact':old['repeatIdentical'],'afterRepeatExact':entry['repeatIdentical']})
summary={'scope':'Whole before/after frames; no masks and not a concept similarity percentage','beforeIndex':before['productionIndexSha256'],'afterIndex':after['productionIndexSha256'],'rows':rows}
(root/'analysis.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode());print(json.dumps(summary))
