from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'tmp/capture-provider184.mts').read_text(encoding='utf-8')
old="""    await page.addInitScript(() => {
      (window as unknown as { __QUOTAPULSE_TOKEN__: string }).__QUOTAPULSE_TOKEN__ = 'stable-capture-test';
      localStorage.setItem('quotapulse-prefs', JSON.stringify({ lang: 'en', currency: 'USD', rate: 1, hiddenSubscriptions: [] }));
      localStorage.setItem('quotapulse-theme', 'dark');
    });"""
new="""    const taskLang=process.env.QP_PROVIDER184_LANG??'en',taskTheme=process.env.QP_PROVIDER184_THEME??'dark';
    await page.addInitScript(({lang,theme}) => {
      (window as unknown as { __QUOTAPULSE_TOKEN__: string }).__QUOTAPULSE_TOKEN__ = 'stable-capture-test';
      localStorage.setItem('quotapulse-prefs', JSON.stringify({ lang, currency: 'USD', rate: 1, hiddenSubscriptions: [] }));
      localStorage.setItem('quotapulse-theme', theme);
    },{lang:taskLang,theme:taskTheme});"""
assert s.count(old)==1
s=s.replace(old,new)
s=s.replace("language: 'en', theme: 'dark'", "language: process.env.QP_PROVIDER184_LANG??'en', theme: process.env.QP_PROVIDER184_THEME??'dark'")
anchor='    await context.close();'
assert s.count(anchor)==1
probe='''    const cases=[];
    for(const width of [390,900,1200,1280,1535,1536,1672]) {
      await page.setViewportSize({width,height:941});await page.waitForTimeout(60);
      assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,`${taskLang}/${taskTheme}/${width}: page overflow`);
      const cards=await page.locator('.qp-provider-card').evaluateAll(nodes=>nodes.map(node=>{
        const rect=node.getBoundingClientRect(),head=node.querySelector('.qp-provider-card-head')!.getBoundingClientRect(),body=node.querySelector('.qp-provider-windows')!.getBoundingClientRect(),footer=node.querySelector('footer')!.getBoundingClientRect();
        return {quota:node.getAttribute('data-has-quota'),top:rect.top,bottom:rect.bottom,height:rect.height,headBottom:head.bottom,bodyTop:body.top,bodyBottom:body.bottom,footerTop:footer.top,footerBottom:footer.bottom,message:node.querySelector('.qp-provider-windows')!.textContent,windows:node.querySelectorAll('[data-window-kind]').length};
      }));
      assert.equal(cards.length,4);assert.ok(cards.some(c=>c.quota==='true')&&cards.some(c=>c.quota==='false'));
      for(const card of cards) {assert.ok(card.headBottom<=card.bodyTop+1 && card.bodyBottom<=card.footerTop+1 && card.footerBottom<=card.bottom+1,`Card content overlaps: ${JSON.stringify({width,card})}`);if(card.quota==='false'){assert.equal(card.windows,0);assert.ok(card.message?.trim());}}
      const rows=new Map<number,typeof cards>();for(const c of cards){const y=Math.round(c.top);rows.set(y,[...(rows.get(y)??[]),c]);}
      if(width>=1280)for(const row of rows.values())if(row.some(c=>c.quota==='true'))assert.ok(Math.max(...row.map(c=>c.height))-Math.min(...row.map(c=>c.height))<1,`Mixed row does not align: ${width} ${JSON.stringify(row)}`);
      cases.push({width,cards:cards.map(c=>({quota:c.quota,top:c.top,height:c.height})),noOverflow:true,contentFits:true});
    }
    const syntheticRows=[];
    for(const width of [1280,1536,1672]) {
      await page.setViewportSize({width,height:941});
      const layouts=await page.evaluate(()=>{
        const grid=document.querySelector('.qp-provider-grid')!,quota=grid.querySelector('.qp-provider-card[data-has-quota=true]')!,empty=grid.querySelector('.qp-provider-card[data-has-quota=false]')!;
        const original=[...grid.children];const extras=Array.from({length:4},()=>empty.cloneNode(true) as HTMLElement);for(const node of extras)grid.append(node);
        const allEmpty=[...grid.children].map(node=>{const r=node.getBoundingClientRect();return {top:Math.round(r.top),height:r.height,quota:node.getAttribute('data-has-quota'),footer:node.querySelector('footer')!.getBoundingClientRect().bottom,bottom:r.bottom};}), rows=[...new Set(allEmpty.map(c=>c.top))].sort((a,b)=>a-b),second=allEmpty.filter(c=>c.top===rows[1]);
        const replaceIndex=allEmpty.findIndex(c=>c.top===rows[1]);const replacement=quota.cloneNode(true) as HTMLElement;grid.children[replaceIndex]!.replaceWith(replacement);
        const hidden=document.createElement('p');hidden.className='qp-provider-hidden';hidden.textContent='Synthetic hidden state';const target=[...grid.children].find(node=>node.getAttribute('data-has-quota')==='false'&&Math.round(node.getBoundingClientRect().top)===rows[1]);if(target)target.insertBefore(hidden,target.querySelector('.qp-provider-windows'));
        const mixed=[...grid.children].map(node=>{const r=node.getBoundingClientRect();return {top:Math.round(r.top),height:r.height,quota:node.getAttribute('data-has-quota'),footer:node.querySelector('footer')!.getBoundingClientRect().bottom,bottom:r.bottom};});grid.replaceChildren(...original);return {allEmpty,second,mixed,secondTop:rows[1],hiddenTested:!!target};
      });
      assert.ok(layouts.second.length>0 && layouts.second.every(c=>c.quota==='false'&&c.height<200),`All-empty second row should stay compact at ${width}`);
      const row=layouts.mixed.filter(c=>c.top===layouts.secondTop);assert.ok(row.some(c=>c.quota==='true')&&row.some(c=>c.quota==='false')&&layouts.hiddenTested);
      assert.ok(Math.max(...row.map(c=>c.height))-Math.min(...row.map(c=>c.height))<1);assert.ok(row.every(c=>c.footer<=c.bottom+1));
      syntheticRows.push({width,allEmptyHeights:layouts.second.map(c=>c.height),mixedHeights:row.map(c=>c.height),hiddenTested:true});
    }
    const owner=page.locator('.qp-provider-card-head button').last();await owner.focus();await page.keyboard.press('Enter');assert.equal(await owner.getAttribute('aria-pressed'),'true');
    writeFileSync(resolve(output,'layout-matrix.json'),JSON.stringify({lang:taskLang,theme:taskTheme,cases,syntheticRows,keyboard:true},null,2)+'\\n');
    console.log(`Provider alignment: ${taskLang}/${taskTheme} seven viewports and three synthetic second-row cases passed.`);
'''
s=s.replace(anchor,probe+anchor)
(root/'tmp/check-provider184-matrix.mts').write_text(s,encoding='utf-8',newline='\n')
