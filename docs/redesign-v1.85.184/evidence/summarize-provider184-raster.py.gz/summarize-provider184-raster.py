from pathlib import Path
from PIL import Image
import hashlib, json
import numpy as np

root=Path(__file__).resolve().parents[1]
base=root/'tmp/fidelity173'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load_image(p):return np.asarray(Image.open(p).convert('RGB'))
def compare(a,b):
    mask=np.any(a!=b,axis=2);delta=np.abs(a.astype('int16')-b.astype('int16'))
    y,x=np.where(mask)
    return {'pixels':int(mask.sum()),'maxChannelDelta':int(delta.max()),'header':int(mask[:60].sum()),'sidebar':int(mask[60:,:226].sum()),'workspace':int(mask[60:,226:].sum()),'bounds':[int(x.min()),int(y.min()),int(x.max()),int(y.max())] if len(x) else None}

results=[]
for name in ['original','original2','aligned','none','layer','layer2']:
    directory=base/('provider184-raster-'+name)
    images=[load_image(directory/f'providers-{i}.png') for i in range(6)]
    meta=[json.loads((directory/f'header-{i}.json').read_text(encoding='utf-8')) for i in range(6)]
    results.append({'variant':name,'header':meta[0],'headerInputsIdentical':all(m==meta[0] for m in meta),'firstVsRest':[compare(images[0],image) for image in images[1:]],'captureSha256':[digest(directory/f'providers-{i}.png') for i in range(6)]})
old=load_image(base/'provider184-raster-original/providers-0.png')
layer=load_image(base/'provider184-raster-layer/providers-0.png')
faildir=root/'tmp/provider184-stable-failure'
failures=[]
for name,prefix in [('initial',''),('retry','retry-')]:
    a=faildir/(prefix+'before.png');b=faildir/(prefix+'repeat.png')
    failures.append({'attempt':name,**compare(load_image(a),load_image(b)),'beforeSha256':digest(a),'repeatSha256':digest(b)})
report={'scope':'Six independent browser contexts per variant; isolated in-memory synthetic API; CSS overrides were applied only inside browser tests.','results':results,'originalVsLayer':compare(old,layer),'originalStableGateFailures':failures,'conclusion':'Rendering is sensitive to header transform/compositing in this probe, but a unique cause and safe production fix are not established. No screenshot pixels were masked and no threshold was changed.'}
(root/'tmp/provider184-raster-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'originalVsLayer':report['originalVsLayer'],'failures':failures},indent=2))
