from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'tmp/capture-provider184.mts').read_text(encoding='utf-8')
anchor='  for (const [routeName, readySelector] of Object.entries(targets)) {'
assert s.count(anchor)==1
s=s.replace(anchor,'  let captureIndex = 0;\n  for (const [routeName, readySelector] of Array.from({length:6},()=>Object.entries(targets)).flat()) {\n    const shotIndex=captureIndex++;')
anchor="    const first = await page.screenshot({ path: resolve(output, `${routeName}.png`), animations: 'disabled' });"
assert s.count(anchor)==1
insert='''    if(process.env.QP_RASTER_VARIANT==='aligned') await page.addStyleTag({content:'.qp-redesign[data-testid^=production-] .qp-topbar-actions>button[aria-haspopup=dialog]{transform:translateY(-1px)!important}'});
    if(process.env.QP_RASTER_VARIANT==='none') await page.addStyleTag({content:'.qp-redesign[data-testid^=production-] .qp-topbar-actions>button[aria-haspopup=dialog]{transform:none!important}'});
    if(process.env.QP_RASTER_VARIANT==='layer') await page.addStyleTag({content:'.qp-redesign[data-testid^=production-] .qp-topbar-actions>button[aria-haspopup=dialog]{transform:translate3d(0,-.5px,0)!important}'});
    const rasterMeta=await page.locator('.qp-topbar-actions>button[aria-haspopup=dialog]').evaluate(element=>{const s=getComputedStyle(element),r=element.getBoundingClientRect();return {rect:r.toJSON(),transform:s.transform,background:s.backgroundImage,border:s.border,boxShadow:s.boxShadow,radius:s.borderRadius,font:s.font,opacity:s.opacity,dpr:devicePixelRatio}});
    writeFileSync(resolve(output,`header-${shotIndex}.json`),JSON.stringify(rasterMeta,null,2));
'''
s=s.replace(anchor,insert+anchor.replace('`${routeName}.png`','`${routeName}-${shotIndex}.png`'))
s=s.replace('`${routeName}-repeat.png`','`${routeName}-${shotIndex}-repeat.png`')
(root/'tmp/capture-provider184-raster.mts').write_text(s,encoding='utf-8',newline='\n')
print('Prepared six-context header raster probe')
