from pathlib import Path
root = Path(__file__).resolve().parents[1]
code = (root/'tmp/capture-type173.mts').read_text(encoding='utf-8')
anchor = '    const first = await page.screenshot('
assert code.count(anchor) == 1
probe = '''    if(routeName==='providers') {
      const cards=await page.locator('.qp-provider-card').evaluateAll(nodes=>nodes.map(node=>({title:node.querySelector('.qp-provider-card-head button')?.textContent,hasQuota:node.getAttribute('data-has-quota'),rect:node.getBoundingClientRect().toJSON(),message:node.querySelector('.qp-provider-windows')?.textContent,windows:[...node.querySelectorAll('[data-window-kind]')].map(e=>({kind:e.getAttribute('data-window-kind'),text:e.textContent})),footer:node.querySelector('footer')?.getBoundingClientRect().toJSON()})));
      assert.ok(cards.some(card=>card.hasQuota==='true') && cards.some(card=>card.hasQuota==='false'));
      writeFileSync(resolve(output,'provider-cards.json'),JSON.stringify(cards,null,2)+'\\n');
    }
'''
code=code.replace(anchor,probe+anchor)
(root/'tmp/capture-provider184.mts').write_text(code,encoding='utf-8',newline='\n')
print('Prepared mixed-quota provider capture')
