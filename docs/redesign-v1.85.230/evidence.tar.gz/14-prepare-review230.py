from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[1]
old = '0e3b87f5718f6fcdea92130e9b245c769e9d5063'
new = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert new.startswith('429877f')
names = ['build-review224.py', 'check-native-review224.mts', 'deliver-review224.ps1',
         'extract-review224.ps1', 'check-bundle224.mts', 'check-reader-archive224.mts',
         'check-install224.ps1', 'check-installed224.cjs', 'prepare-cleanup224.py', 'cleanup224.ps1']
for name in names:
    source = (root / 'tmp' / name).read_text(encoding='utf-8-sig')
    source = (source.replace(old, new).replace("startswith('0e3b87f')", f"startswith('{new[:7]}')")
              .replace('review224', 'review230').replace('release224', 'release230')
              .replace('installed224', 'installed230').replace('cleanup224', 'cleanup230')
              .replace('v1.85.223', 'v1.85.229')
              .replace(r'v1\.85\.223', r'v1\.85\.229'))
    destination = root / 'tmp' / name.replace('224', '230')
    assert not destination.exists(), destination
    assert old not in source and 'release224' not in source and 'review224' not in source
    destination.write_text(source, encoding='utf-8', newline='\n')
print('Prepared review230 drivers for', new)
