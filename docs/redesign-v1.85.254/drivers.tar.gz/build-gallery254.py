from pathlib import Path
from hashlib import sha256
from PIL import Image
import json, shutil

root=Path(__file__).resolve().parents[1]
capture=root/'tmp/fidelity235/all254'
prior=root/'docs/redesign-v1.85.245'
out=root/'docs/redesign-v1.85.254'
refs=Path('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs')
names=['overview','live','projects','models','cost','history','alerts','providers']
digest=lambda p:sha256(p.read_bytes()).hexdigest()
manifest=json.loads((capture/'verification.json').read_text(encoding='utf8'))
assert len(manifest['results'])==8 and all(row['repeatIdentical'] and not row['errors'] and not row['forbidden'] for row in manifest['results'])
assert manifest['productionIndexSha256']==digest(root/'packages/web/dist/index.html')
assert not out.exists()
out.mkdir()
results=[]
for name in names:
    row=next(row for row in manifest['results'] if row['route']==name)
    image=capture/(name+'.png'); repeat=capture/(name+'-repeat.png'); old=prior/(name+'.png')
    original=refs/(name+'.png'); retained=root/'docs/redesign-v1.85.156/refs'/(name+'.png')
    assert digest(image)==digest(repeat)==row['sha256'] and digest(original)==digest(retained)==row['referenceSha256']
    with Image.open(image) as a, Image.open(old) as b:
        assert a.mode==b.mode=='RGB' and a.info==b.info=={} and a.size==b.size
        current_pixels=a.tobytes(); old_pixels=b.tobytes()
    same=current_pixels==old_pixels
    target=old if same else out/(name+'.png')
    if not same: shutil.copyfile(image,target)
    results.append({'page':name,'referenceSha256':digest(original),'freshPngSha256':digest(image),
                    'displayedPngSha256':digest(target),'pixelSha256':sha256(current_pixels).hexdigest(),
                    'reusedPriorByExactRgbPixels':same,'displayedPath':('../redesign-v1.85.245/' if same else '')+name+'.png'})
assert [r['page'] for r in results if not r['reusedPriorByExactRgbPixels']]==['overview','models','history']
shutil.copyfile(capture/'verification.json',out/'capture-verification.json')
(out/'images-verification.json').write_text(json.dumps({'sourceCommit':'6ef57f1','productionIndexSha256':manifest['productionIndexSha256'],'images':results},indent=2)+'\n',encoding='utf8')
header='''<!doctype html><html lang="th"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>QuotaPulse: เปรียบเทียบ Dashboard กับ concept</title><style>body{margin:24px;background:#071021;color:#dbe8ff;font:16px/1.5 system-ui,sans-serif}p{color:#b6cbe7}a{color:#73ceff}details{margin:12px 0;border:1px solid #27406b;border-radius:8px}summary{padding:12px;cursor:pointer;font-weight:600}summary:focus-visible{outline:2px solid #73ceff}.pair{display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:12px}figure{margin:0;min-width:0}img{display:block;width:100%;height:auto}figcaption{padding:6px}@media(max-width:900px){.pair{grid-template-columns:1fr}body{margin:12px}}</style><h1>เปรียบเทียบ Dashboard กับ concept</h1><p>ด้านซ้ายคือภาพอ้างอิง ด้านขวาคือ build ปัจจุบันโดยใช้ข้อมูลจำลองในการทดสอบ จำนวนรายการ ตัวเลข และกราฟจึงต่างจาก concept ได้ คลิกภาพเพื่อดูขนาดเต็ม การเปรียบเทียบนี้ยังไม่ใช่การรับรองความเหมือนทั้งหมด</p><p><a href="README.md">ขอบเขตและสิ่งที่ยังต้องตรวจ</a></p>'''
parts=[header]
for r in results:
    name=r['page']; title=name.title(); ref='../redesign-v1.85.156/refs/'+name+'.png'; cur=r['displayedPath']
    parts.append(f'<details{" open" if name=="overview" else ""}><summary>{title}</summary><div class="pair"><figure><figcaption>Concept</figcaption><a href="{ref}"><img loading="lazy" src="{ref}" alt="{title} concept"></a></figure><figure><figcaption>แอปปัจจุบัน — ข้อมูลทดสอบ</figcaption><a href="{cur}"><img loading="lazy" src="{cur}" alt="{title} จากแอป"></a></figure></div></details>')
parts.append('</html>')
(out/'review.html').write_text('\n'.join(parts)+'\n',encoding='utf8',newline='\n')
text='''# ภาพเปรียบเทียบ Dashboard จาก source ล่าสุด

[เปิดภาพเทียบทั้ง 8 หน้า](review.html) ภาพแอปใช้ source `6ef57f1` และฐานข้อมูลจำลองที่แยกไว้สำหรับการทดสอบ ตัวเลข จำนวนรายการ และรูปกราฟจึงไม่ใช่ข้อมูลจริงของผู้ใช้และไม่จำเป็นต้องตรงกับ concept

ภาพจับที่ viewport เท่าภาพอ้างอิง ภาษาอังกฤษ ธีมมืด DPR 1 และ reduced motion ด้วย headless Chrome ภาพจับซ้ำของทั้ง 8 หน้าเป็นไฟล์ตรงกันทุกไบต์ ไม่มี browser error หรือคำขอที่ชุดตรวจห้าม ทั้ง 8 ภาพอ้างอิงมี hash ตรงกับไฟล์ refs ของ blueprint และ web build ที่จับภาพมี hash ตาม `capture-verification.json`

เพื่อไม่เก็บภาพซ้ำโดยไม่จำเป็น Overview, Models และ History เก็บภาพใหม่ ส่วนอีก 5 ภาพใช้ PNG จาก checkpoint245 หลังตรวจว่าขนาด โหมด RGB, PNG metadata และพิกเซลทุกตำแหน่งตรงกับภาพที่จับใหม่ ไฟล์ PNG ของภาพเก่าและใหม่มี hash ต่างกัน จึงไม่ได้อ้างว่าไฟล์ตรงกันทุกไบต์ รายละเอียดอยู่ใน `images-verification.json`

ยังต้องตรวจสี ภาพ ตัวอักษร ระยะ กราฟและการจัดวางในทุกหน้าเพิ่มเติม เทียบกับ blueprint และ overrides โดยเฉพาะกราฟ Live, การ์ด Projects/Providers และ History detail ซึ่งข้อมูลจริงมีจำนวนและชนิดต่างจาก concept ภาพชุดนี้ไม่ยืนยันความเหมือน 99–100%, ภาษาไทย ธีมสว่าง motion การใช้ข้อมูล provider จริง หรือการทำงานบนจอจริง Review249 predates การแก้ History และ source ด้าน transcript ที่ตามมา
'''
(out/'README.md').write_text(text,encoding='utf8',newline='\n')
print('Gallery prepared; current images:',[r['page'] for r in results if not r['reusedPriorByExactRgbPixels']])
