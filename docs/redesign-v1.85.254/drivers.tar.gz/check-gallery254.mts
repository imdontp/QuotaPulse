import assert from 'node:assert/strict';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { chromium } from 'playwright';

const root=resolve('.'), gallery=resolve(root,'docs/redesign-v1.85.254/review.html');
const browser=await chromium.launch({channel:'chrome',headless:true});
try {
  const page=await browser.newPage({viewport:{width:1440,height:900}}), errors:string[]=[];
  page.on('pageerror',error=>errors.push(error.message));
  await page.goto(pathToFileURL(gallery).href);
  assert.equal(await page.locator('details').count(),8);
  const summaries=page.locator('details>summary');
  for(let i=0;i<8;i++){
    const summary=summaries.nth(i), before=await summary.locator('..').evaluate((node:HTMLDetailsElement)=>node.open);
    await summary.focus(); await page.keyboard.press('Enter');
    assert.equal(await summary.locator('..').evaluate((node:HTMLDetailsElement)=>node.open),!before,`keyboard ${i}`);
    await summary.focus(); await page.keyboard.press('Enter');
    assert.equal(await summary.locator('..').evaluate((node:HTMLDetailsElement)=>node.open),before,`keyboard restore ${i}`);
  }
  await page.locator('details').evaluateAll(nodes=>nodes.forEach(node=>(node as HTMLDetailsElement).open=true));
  await page.locator('img').evaluateAll(nodes=>nodes.forEach(node=>(node as HTMLImageElement).loading='eager'));
  await page.waitForFunction(()=>[...document.images].every(image=>image.complete && image.naturalWidth>0));
  const images=await page.locator('img').evaluateAll(nodes=>nodes.map(node=>({src:(node as HTMLImageElement).src,alt:node.getAttribute('alt'),width:(node as HTMLImageElement).naturalWidth})));
  assert.equal(images.length,16); assert.ok(images.every(image=>image.alt && image.width>0 && image.src.startsWith('file:')));
  for(const image of images) assert.ok(existsSync(fileURLToPath(image.src)),image.src);
  assert.deepEqual(errors,[]);
  const verification=JSON.parse(readFileSync(resolve(root,'docs/redesign-v1.85.254/images-verification.json'),'utf8'));
  assert.equal(verification.images.length,8);
  const result={status:'passed',details:8,keyboardToggles:16,localImages:images.length,pageErrors:errors};
  writeFileSync(resolve(root,'docs/redesign-v1.85.254/gallery-verification.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result));
} finally { await browser.close(); }
