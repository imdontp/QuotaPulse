/** Repeatability gate; synthetic production captures, not approved visual baselines. */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium, type Page, type Request, type Route } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import { recordQuotaAlerts } from '../packages/daemon/src/api/queries.js';
import type { Overview, CompareResult, MinuteTrendResponse, ProviderModelMinuteResponse, ProjectDetailResponse, DetailedProjectResponse, DetailedModelResponse, ModelDetailResponse, CostAnalysisResponse, QuotaHistoryResponse, UsageResponse, AlertEvent } from '../packages/web/src/api.js';
import { en } from '../packages/web/src/i18n/en.js';
import { th } from '../packages/web/src/i18n/th.js';
import { dimensions, runtimeActivityState, type RuntimeGraph } from '../packages/web/src/redesign/model.js';
import { activeQuotaRiskCount, getQuotaRiskModel } from '../packages/web/src/redesign/alert-risks.js';
import { averageDailyTokenPace, cacheShareTrendSeries, metricTrendSeries } from '../packages/web/src/redesign/metric-series.js';
import { cacheSharePercent, percentagePointChange, relativeChangePercent } from '../packages/web/src/redesign/insight-model.js';
import type { UsageEventsResponse } from '../packages/web/src/lib/usage-events.js';
import { countdown, tokens as formatTokens } from '../packages/web/src/format.js';
import { usageEventParams } from '../packages/web/src/lib/usage-events.js';
import { activityTokensPerMinute, activityTrendScope, latestActivityByHarness } from '../packages/web/src/redesign/activity-trend.js';
import { ACTIVITY_SPARKLINE_HEIGHT } from '../packages/web/src/redesign/activity-sparkline.js';
import { checkLiveMinuteRefresh } from '../scripts/check-live-minute-refresh.mjs';
import { checkLiveTokenFlow } from '../scripts/check-live-token-flow.mjs';
import { checkSectionMarks } from '../scripts/check-section-marks.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));
const priorTimezone = process.env.TZ;
process.env.TZ = 'Asia/Bangkok';
const liveOnly = process.env.QUOTAPULSE_CAPTURE_SCOPE === 'live';
const compositionOnly = process.env.QUOTAPULSE_CAPTURE_SCOPE === 'composition';
const runtimeLayoutOnly = process.env.QUOTAPULSE_CAPTURE_SCOPE === 'runtime-layout';
const overviewOnly = process.env.QUOTAPULSE_CAPTURE_SCOPE === 'overview' || runtimeLayoutOnly;
const projectsOnly = process.env.QUOTAPULSE_CAPTURE_SCOPE === 'projects';
const providersOnly = process.env.QUOTAPULSE_CAPTURE_SCOPE === 'providers';
const modelsOnly = process.env.QUOTAPULSE_CAPTURE_SCOPE === 'models';
const costOnly = process.env.QUOTAPULSE_CAPTURE_SCOPE === 'cost';
const historyOnly = process.env.QUOTAPULSE_CAPTURE_SCOPE === 'history';
const alertsOnly = process.env.QUOTAPULSE_CAPTURE_SCOPE === 'alerts';
const settingsOnly = process.env.QUOTAPULSE_CAPTURE_SCOPE === 'settings';
const captureLanguages = process.env.QUOTAPULSE_CAPTURE_LANGUAGE ? [process.env.QUOTAPULSE_CAPTURE_LANGUAGE] : ['en', 'th'];
const captureThemes = process.env.QUOTAPULSE_CAPTURE_THEME ? [process.env.QUOTAPULSE_CAPTURE_THEME] : ['dark', 'light'];
assert.ok(captureLanguages.every(language => language === 'en' || language === 'th'), 'Capture language must be en or th');
assert.ok(captureThemes.every(theme => theme === 'dark' || theme === 'light'), 'Capture theme must be dark or light');
const taskLang=process.env.QUOTAPULSE_SIDEBAR_LANGUAGE ?? 'en';
const taskTheme=process.env.QUOTAPULSE_SIDEBAR_THEME ?? 'dark';
const output = resolve(root, `tmp/source-art95-final8-${taskLang}-${taskTheme}`);
mkdirSync(output, { recursive: true });
// A failed attempt must never leave a previous success manifest in this folder.
rmSync(resolve(output, 'verification.json'), { force: true });
rmSync(resolve(output, 'cost-reference-layout.json'), { force: true });
rmSync(resolve(output, 'reference-detail-regions.json'), { force: true });
const fixedNow = Date.parse('2025-05-17T13:42:00.000Z');
// Freeze Date only, keeping real timers/performance for HTTP, browser and cleanup.
// This applies to internal query helpers too, without changing production clocks.
const realDate = globalThis.Date;
globalThis.Date = new Proxy(realDate, {
  construct(target, args) { return Reflect.construct(target, args.length ? args : [fixedNow]); },
  apply() { return new realDate(fixedNow).toString(); },
  get(target, property, receiver) { return property === 'now' ? () => fixedNow : Reflect.get(target, property, receiver); },
});
const db = openDb(':memory:');
db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at,account_key,account_provider,account_display_name,account_state,account_last_success_at)
  VALUES (1,'codex','fixed','/synthetic/nonexistent','Codex fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow}),
    (2,'hermes','fixed','/synthetic/nonexistent','Hermes fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (3,'claude-code','fixed','/synthetic/nonexistent','Claude Code fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (4,'opencode','fixed','/synthetic/nonexistent','OpenCode fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow});`);
const referenceProjects = ['QuotaPulse', 'Agent Platform', 'Edge Services', 'Developer Tools', 'Research Lab'];
const referenceModels = [
  { name: 'DeepSeek V4.1', provider: 'deepseek', share: 38 },
  { name: 'GPT-5.x', provider: 'openai', share: 24 },
  { name: 'Claude 3.7', provider: 'anthropic', share: 18 },
  { name: 'Claude 3.5', provider: 'anthropic', share: 11 },
  { name: 'Others', provider: 'openrouter', share: 9 },
  { name: 'GPT-4.1 mini', provider: 'openai', share: 0 },
];
const session = db.prepare('INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (?,?,?,?,?)');
const usage = db.prepare('INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source,cost_input_usd,cost_cached_input_usd,cost_cache_write_usd,cost_output_usd,cost_cache_saving_usd,price_provider) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
// Synthetic catalogue rates for the in-memory visual fixture only. The saved
// amount is derived from the same fresh/cached input components the UI reports.
const fixtureInputUsdPerMillion = 0.0593846153846154, fixtureCachedInputUsdPerMillion = 0.004, fixtureOutputUsdPerMillion = 0.004;
for (let index = 0; index < 12; index++) {
  // Keep the reference map's 4 Codex, 2 Claude Code, 6 Hermes, 0 OpenCode
  // recent-session distribution while preserving the same 12 sessions.
  const source = [1, 1, 1, 1, 3, 3, 2, 2, 2, 2, 2, 2][index]!;
  session.run(index + 1, source, `fixture-session-${index}`, referenceProjects[0], fixedNow - 10_000);
  const model = referenceModels[index % referenceModels.length]!;
  const totalTokens = model.share === 0 ? 1 : model.share * 721_000_000 / 600;
  for (let call = 0; call < 3; call++) {
    const inputShare = [.6, .65, .7][(index + call) % 3]!;
    const inputTokens = totalTokens * inputShare * .58, cachedInputTokens = totalTokens * inputShare * .42;
    const outputTokens = totalTokens * (1 - inputShare);
    const costSource = index === 0 ? 'native' : 'computed';
    const inputUsd = inputTokens / 1_000_000 * fixtureInputUsdPerMillion;
    const cachedInputUsd = cachedInputTokens / 1_000_000 * fixtureCachedInputUsdPerMillion;
    const outputUsd = outputTokens / 1_000_000 * fixtureOutputUsdPerMillion;
    const cacheSavingUsd = cachedInputTokens / 1_000_000 * (fixtureInputUsdPerMillion - fixtureCachedInputUsdPerMillion);
    // Keep each session's latest record within four minutes, then spread older calls across the visible 30-minute interval.
    const ageMs = call === 0 ? 15_000 + index * 20_000 : source === 2
      ? 300_000 + index * 120_000 + (call === 2 ? 30_000 : 0)
      : 300_000 + index * 240_000 + (call === 2 ? 90_000 : 0);
    const recordedAt = fixedNow - ageMs;
    usage.run(source, index + 1, `fixed-${index}-${call}`, recordedAt, model.name, model.provider,
      inputTokens, cachedInputTokens, outputTokens, totalTokens, call + 1,
      costSource === 'native' ? (index + 1) / 100 : inputUsd + cachedInputUsd + outputUsd, costSource,
      costSource === 'native' ? null : inputUsd, costSource === 'native' ? null : cachedInputUsd,
      costSource === 'native' ? null : 0, costSource === 'native' ? null : outputUsd,
      costSource === 'native' ? null : cacheSavingUsd, costSource === 'native' ? null : model.provider);
  }
}
// A stale recorded OpenCode route keeps the concept's zero-active-session edge
// visible without manufacturing a provider relationship or changing live counts.
const openCodeAt = fixedNow - 10 * 60_000;
session.run(13, 4, 'fixture-opencode-quota-pulse', referenceProjects[0], openCodeAt);
usage.run(4, 13, 'fixed-opencode-route', openCodeAt, 'DeepSeek V4.1', 'deepseek', 1, 0, 0, 1, 1,
  null, 'unknown', null, null, null, null, null, null);
// The monthly concept is focused on QuotaPulse while the machine-wide quick
// stats still report all five named projects. Keep four small monthly records
// for the other projects, outside the recent-session window.
for (let index = 1; index < referenceProjects.length; index++) {
  const id = 100 + index, source = [1, 3, 4, 2][index - 1]!;
  const model = referenceModels[index - 1]!;
  const at = fixedNow - 10 * 60_000;
  session.run(id, source, `fixture-project-${index}`, referenceProjects[index], at);
  const inputUsd = fixtureInputUsdPerMillion / 1_000_000;
  usage.run(source, id, `fixture-project-usage-${index}`, at, model.name, model.provider, 1, 0, 0, 1, 1,
    inputUsd, 'computed', inputUsd, 0, 0, 0, 0, model.provider);
}
// Values below the old visual minimum catch inflated nonzero bars in both charts.
const tinyUsage = db.prepare("INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source) VALUES (1,1,?,?,'DeepSeek V4.1','deepseek',1,0,0,1,1,0,'computed')");
tinyUsage.run('fixed-tiny-minute', fixedNow - 15 * 60_000);
tinyUsage.run('fixed-tiny-day', fixedNow - 3 * 86_400_000);
const quota = db.prepare('INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin) VALUES (?,?,?,?,?,?,?,?)');
const addQuotaSample = (sourceId: number, window: string, percent: number | null, resetAt: number | null, observedAt: number) => quota.run(sourceId, window, percent, resetAt, observedAt, observedAt, observedAt, 'fixed-fixture');
// Complete history must include older reset periods, nulls and more than eight
// readings per period, without changing the latest live quota/default selection.
for (let segment = 0; segment < 4; segment++) for (let index = 0; index < 12; index++) {
  const at = fixedNow - (5 - segment) * 3_600_000 + index * 60_000;
  addQuotaSample(1, '5h', index === 4 ? null : index === 1 ? 0.5 : index * 8, segment === 0 ? null : fixedNow - (4 - segment) * 3_600_000, at);
}
addQuotaSample(1, '5h', 38, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 5 * 60_000);
addQuotaSample(1, '5h', 83, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 30_000);
addQuotaSample(1, 'weekly', 62, fixedNow + (3 * 24 + 5) * 3_600_000, fixedNow - 30_000);
const monthlyReset = fixedNow + (6 * 24 + 2) * 3_600_000;
addQuotaSample(1, 'monthly', 59, monthlyReset, fixedNow - 48 * 3_600_000);
addQuotaSample(1, 'monthly', 65.5, monthlyReset, fixedNow - 24 * 3_600_000);
addQuotaSample(1, 'monthly', 72, monthlyReset, fixedNow - 30_000);
addQuotaSample(2, 'monthly', 58, fixedNow + (12 * 24 + 6) * 3_600_000, fixedNow - 30_000);
addQuotaSample(2, 'daily', 34, fixedNow + (7 * 60 + 18) * 60_000, fixedNow - 30_000);
recordQuotaAlerts(db, fixedNow);
const scheduler = new Scheduler(db, [], { pollMs: 1_000_000, detectMs: 1_000_000 });
const daemon = buildServer(db, scheduler, { token: 'stable-capture-test', port: 7816, webRoot: resolve(root, 'packages/web/dist') });
let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;
const errors: string[] = [];
const forbidden: string[] = [];
const requestOrigins = new WeakMap<Request, { route: string; started: number }>();
const chartChecks: Array<{ page: string; lang: string; theme: string; buckets: number; tokens: number; flowEvidence?: Awaited<ReturnType<typeof checkLiveTokenFlow>> }> = [];
const sectionMarkChecks: Array<Awaited<ReturnType<typeof checkSectionMarks>>> = [];
const modelCostChecks: Array<{ route: string; lang: string; theme: string; buckets: number; collapsedBottom: number }> = [];
const quotaChecks: Array<{ page: string; lang: string; theme: string; segments: number; samples: number; unknown: number }> = [];
const pulseCoreChecks: Array<{ lang: string; theme: string; assetSha256: string; imageWidth: number; selectedUsed: number[]; boundaries: number[]; unknown: boolean; reducedMotion: boolean }> = [];
const pulseAmbientChecks: Array<{ lang: string; theme: string; width: number; height: number; centerError: number; decorative: boolean; staticArtwork: boolean }> = [];
const modelMarkChecks: Array<{ lang: string; theme: string; vendors: string[]; unknown: number; tokens: number; legacyFallback: boolean; keyboardDetail: boolean; framedMarkContained: boolean }> = [];
const overviewPeriodChecks: Array<{ lang: string; theme: string; tokensByRange: Record<string, number>; selectedQuotaPreserved: boolean; customSourcePreserved: boolean; focusRestored: boolean }> = [];
const overviewInsightChecks: Array<{ lang: string; theme: string; cards: number; cacheShare: number | null; pricedCalls: number; totalCalls: number; states: string[] }> = [];
const quotaGroupChecks: Array<{ lang: string; theme: string; owners: number; windows: number; sameNameSeparate: boolean; keyboardScrolled: boolean; historyIdentity: boolean }> = [];
const recentActivityChecks: Array<{ lang: string; theme: string; records: number; keyboardHistory: boolean; unknownGrain: boolean; largeTokens: boolean; perHarnessLatestQueries: boolean; futureRangeEmpty: boolean }> = [];
const iconViewports = new Map<string, unknown>();
const overviewVectors = new Map<string, unknown>();
const sidebarRasterStates = new Map<string, unknown>();
const sidebarRasterEvidence: Array<{ filename: string; pass: number; state: unknown }> = [];
const activityBitmapChecks: Array<{ lang: string; theme: string; recordId: number; points: number; width: number; height: number; paintedPixels: number; sha256: string }> = [];
const activityRendererChecks: Array<{ lang: string; theme: string; accessibleValues: boolean; themeRedraw: boolean; resized: boolean; singlePoint: boolean; zeroBaseline: boolean }> = [];
const runtimeChecks: Array<{ lang: string; theme: string; nodes: number; edges: number; inspected: number; modelShares: number; directionArrows: boolean; nativeMotion: boolean }> = [];
const runtimeGeometryChecks: Array<{ lang: string; theme: string; state: string; paths: number; maxError: number }> = [];
const shellChecks: Array<{ page: string; lang: string; theme: string; modal: boolean; backgroundExcluded: boolean }> = [];
const headerChecks: Array<{ page: string; lang: string; theme: string; width: number; height: number; sidebarWidth: number; dateText: string | null }> = [];
const workspaceChecks: Array<{ page: string; lang: string; theme: string; label: { x: number; y: number; width: number; height: number }; scope: { x: number; y: number; width: number; height: number } }> = [];
const fontChecks: Array<{ page: string; lang: string; theme: string; family: string; custom: boolean; glyphs: number }> = [];
const settingsChecks: Array<{ lang: string; theme: string; sections: number; language: boolean; currency: boolean; rate: number; widths: number[] }> = [];
const cases: Array<{ page: string; lang: string; theme: string; filename: string; sha256: string; repeatSha256?: string; changedPixels?: number; maxChannelDelta?: number; semanticContrasts: Array<{ role: string; color: string; minimumRatio: number }>; checkedElements: string[] }> = [];
const overviewLayouts: Array<{ lang: string; theme: string; heroBottom: number; activityBottom: number; models: number; railHeight: number; runtimeProvidersVisible: number; edgeMaxError: number; pulseCenter: { x: number; y: number }; modelTitleOutside: boolean }> = [];
const overviewReferenceLabelChecks: Array<{ lang: string; theme: string; labels: string[]; modelRailLabel: string | null }> = [];
const overviewConceptDataChecks: Array<{ lang: string; theme: string; periodRange: string; modelNames: string[]; modelShares: number[]; quotaGroups: Array<{ owner: string; windows: string[]; labels: string[] }>; quotaContentHeight: number; quotaViewportHeight: number; selectedWindow: string | null; pulsePercent: number | null; pulseLabel: string | null; pulseDetail: string | null; cacheShare: number | null; cacheSavingsUsd: number | null; cacheSavingsKnownCalls: number; mapProject: string | null; mapProjects: number; mapRecords: number; mapSessions: number; mapHarnessSessions: Record<string, number> }> = [];
const referenceColumnChecks: Array<{ page: string; lang: string; theme: string; headerTop: number; railTop: number; summaryRight: number; railLeft: number }> = [];
const liveDensityChecks: Array<{ lang: string; theme: string; bottom: number; sessions: number; records: number }> = [];
const liveMinuteChecks: Array<{ lang: string; theme: string; state: string; pairs: number; cells: number; missing: number; zero: number; recorded: number; partial: number; included: number; aggregate: number; unknown: number; table: boolean; labelGeometry: Array<{ viewport: number; width: number; clientWidth: number; scrollWidth: number; modelClientWidth: number; modelScrollWidth: number; name: string | null | undefined }> }> = [];
const liveRefreshChecks: Array<Awaited<ReturnType<typeof checkLiveMinuteRefresh>>> = [];
const projectCardChecks: Array<{ lang: string; theme: string; cards: number; bottom: number; unknownNative: number; stableIdentityTones: boolean; sourceTopCards: Array<{ x: number; width: number }> }> = [];
const providerChecks: Array<{ lang: string; theme: string; bottom: number; compared: number; unavailable: boolean; expired: boolean; proportional: boolean }> = [];
const referenceDetailRegions: Array<{ page: string; lang: string; theme: string; regions: unknown }> = [];
const modelComparisonChecks: Array<{ lang: string; theme: string; bottom: number; rows: number; ratios: number; boundaryRatios: boolean }> = [];
const costAxisChecks: Array<{ route: string; lang: string; theme: string; priced: boolean; maxAmount: number; maxTokens: number }> = [];
const costReferenceRegions: Array<{ lang: string; theme: string; pass: number; regions: Record<string, { x: number; y: number; width: number; height: number; bottom: number }> }> = [];
const historyChecks: Array<{ lang: string; theme: string; eventId: number; widths: number[]; modal: boolean; focusRestored: boolean }> = [];
const historyRailChecks: Array<{ lang: string; theme: string; x: number; y: number; width: number; height: number; contentGap: number; transparentBackdrop: boolean }> = [];
const pageHeadingChecks: Array<{ page: string; lang: string; theme: string; tileSize: number; headings: number; decorative: boolean }> = [];
const historyDensityChecks: Array<{ lang: string; theme: string; bottom: number; visibleRows: number; records: number; keyboardScrolled: boolean; table: { top: number; bottom: number; headerHeight: number }; firstRows: Array<{ top: number; bottom: number; height: number }>; cellContents: Array<{ selector: string; height: number; lineHeight: string; verticalAlign: string }> }> = [];
const alertChecks: Array<{ lang: string; theme: string; bottom: number; events: number; expandedEvents: number; keyboardScrolled: boolean; empty: boolean }> = [];
const sha = (bytes: Buffer) => createHash('sha256').update(bytes).digest('hex');
const fontPath = 'fonts/noto-sans-thai/';
const fontProvenance = JSON.parse(readFileSync(resolve(root, `packages/web/public/${fontPath}provenance.json`), 'utf8'));
assert.equal(sha(readFileSync(resolve(root, `packages/web/dist/${fontPath}NotoSansThai-variable.ttf`))), fontProvenance.sha256);
assert.deepEqual(readFileSync(resolve(root, `packages/web/dist/${fontPath}OFL.txt`)), readFileSync(resolve(root, `packages/web/public/${fontPath}OFL.txt`)));
const rendererArgs = ['--disable-gpu', '--deterministic-mode', '--disable-skia-runtime-opts', '--force-color-profile=srgb'];
const allPages = [
  ['overview', '.qp-activity-item'], ['live', '.qp-live-chart'],
  ['projects', '.qp-project-trend'], ['providers', '.qp-provider-health tbody tr'],
  ['models', '.qp-model-trend'], ['cost', '.qp-cost-chart'],
  ['history', '[data-testid="usage-history"] tbody tr'], ['alerts', '.qp-quota-point'],
  ['settings', '[data-slot="card"]'],
] as const;
const pages = liveOnly ? allPages.filter(([destination]) => destination === 'live') : compositionOnly ? allPages.filter(([destination]) => ['overview', 'live', 'models'].includes(destination)) : overviewOnly ? allPages.filter(([destination]) => destination === 'overview') : projectsOnly ? allPages.filter(([destination]) => destination === 'projects') : providersOnly ? allPages.filter(([destination]) => destination === 'providers') : modelsOnly ? allPages.filter(([destination]) => destination === 'models') : costOnly ? allPages.filter(([destination]) => destination === 'cost') : historyOnly ? allPages.filter(([destination]) => destination === 'history') : alertsOnly ? allPages.filter(([destination]) => destination === 'alerts') : settingsOnly ? allPages.filter(([destination]) => destination === 'settings') : allPages;

async function checkLiveMinuteValues(page: Page, data: ProviderModelMinuteResponse, lang: string, theme: string, state: string) {
  const expected = data.groups.slice(0, 12);
  const matrixNote = page.locator('.qp-live-matrix-note');
  const matrixSummary = matrixNote.locator('summary');
  await matrixSummary.focus(); await page.keyboard.press('Enter');
  assert.equal(await matrixNote.getAttribute('open'), '');
  const copy = lang === 'th' ? th : en;
  assert.deepEqual(await matrixNote.locator('p').allTextContents(), [
    `${copy['redesign.liveMatrixNote']} ${copy['redesign.liveMatrixTop']}`,
    copy['redesign.liveMinuteContext'],
    `${copy['redesign.liveMinuteNote']} ${copy['redesign.liveMinutePartialNote']}`,
    copy['redesign.liveMinuteWindowAll'],
    `${copy['redesign.liveMinuteExcluded']}: ${copy['redesign.liveAggregate']} · ${copy['redesign.liveUnknownGrain']}`,
  ], 'Matrix information must retain all original meaning, scope and provenance');
  await matrixNote.locator('[role=region]').focus();
  assert.equal(await matrixNote.locator('[role=region]').evaluate(element => element === document.activeElement), true);
  await matrixSummary.focus(); await page.keyboard.press('Enter');
  assert.equal(await matrixNote.getAttribute('open'), null);
  const matrix = page.locator('.qp-live-matrix-row');
  assert.equal(await matrix.count(), expected.length);
  const expectedRuns: Array<{ provider: string; keys: string[] }> = [];
  for (const group of expected) {
    const identity = JSON.stringify(group.provider), key = JSON.stringify([group.provider, group.model]);
    const previous = expectedRuns.at(-1);
    if (previous?.provider === identity) previous.keys.push(key);
    else expectedRuns.push({ provider: identity, keys: [key] });
  }
  const providerGroups = page.locator('.qp-live-provider-group');
  assert.deepEqual(await providerGroups.evaluateAll(groups => groups.map(group => ({
    provider: group.getAttribute('data-provider'),
    keys: Array.from(group.querySelectorAll('.qp-live-matrix-row')).map(row => row.getAttribute('data-pair-key')),
  }))), expectedRuns, 'Shared provider plates must retain exact consecutive identities and API pair ranking');
  for (const group of await providerGroups.all()) {
    assert.equal(await group.locator('.qp-live-matrix-provider-plate').count(), 1);
    assert.equal(await group.locator('.qp-live-provider-mark').count(), 1);
    assert.equal(await group.locator('.qp-live-matrix-provider-plate').getAttribute('aria-hidden'), 'true');
    assert.equal(await group.locator('.qp-live-provider-mark').evaluate(mark => {
      const bounds = mark.getBoundingClientRect();
      return bounds.width === 24 && bounds.height === 24;
    }), true, 'Shared provider mark retains its source-sized 24px glyph');
  }
  const rows = await matrix.evaluateAll(elements => elements.map(element => ({
    key: element.getAttribute('data-pair-key'),
    callRecords: Number(element.getAttribute('data-call-records')),
    aggregateRecords: Number(element.getAttribute('data-aggregate-records')),
    unknownRecords: Number(element.getAttribute('data-unknown-records')),
    total: element.querySelector('.qp-live-matrix-total>span')!.textContent,
    exactTotal: element.querySelector('.qp-live-matrix-total>span')!.getAttribute('aria-label'),
    totalTitle: element.querySelector('.qp-live-matrix-total>span')!.getAttribute('title'),
    filterable: element.querySelector('button') !== null,
    accessibleName: element.querySelector('button')?.getAttribute('aria-label') ?? null,
    cells: Array.from(element.querySelectorAll<HTMLElement>('.qp-live-minute-strip>i')).map(cell => ({
      at: Number(cell.dataset.at), state: cell.dataset.state,
      tokens: cell.hasAttribute('data-tokens') ? Number(cell.dataset.tokens) : null,
      records: cell.hasAttribute('data-records') ? Number(cell.dataset.records) : null,
      calls: cell.hasAttribute('data-calls') ? Number(cell.dataset.calls) : null,
      partial: cell.dataset.partial === 'true', intensity: Number(cell.style.getPropertyValue('--qp-minute-intensity')),
    })),
  })));
  const format = new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US');
  const max = Math.max(0, ...data.rows.map(row => row.total_tokens));
  const times = Array.from({ length: Math.floor((data.to - 1) / 60000) - Math.floor(data.from / 60000) + 1 }, (_, index) => Math.floor(data.from / 60000) * 60000 + index * 60000);
  assert.equal(times.length, 31);
  let missing = 0, zero = 0, recorded = 0, partial = 0;
  const tableExpected: Array<{ key: string; at: number; state: string; tokens: string; records: string; calls: string }> = [];
  for (const [index, group] of expected.entries()) {
    const actual = rows[index], key = JSON.stringify([group.provider, group.model]);
    assert.equal(actual.key, key); assert.equal(actual.total, new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US', { notation: 'compact', maximumFractionDigits: 1 }).format(group.tokens));
    assert.equal(actual.exactTotal, String(group.tokens)); assert.equal(actual.totalTitle, format.format(group.tokens));
    assert.equal(actual.callRecords, group.callRecords); assert.equal(actual.aggregateRecords, group.aggregateRecords); assert.equal(actual.unknownRecords, group.unknownRecords);
    assert.equal(actual.filterable, group.provider !== null && group.provider !== '' && group.model !== null && group.model !== '');
    if (actual.filterable) assert.equal(actual.accessibleName, `${group.provider} · ${group.model} · ${String(group.tokens)} ${copy['redesign.tokens']} · ${copy['redesign.liveMinuteWindow']} · ${format.format(group.callRecords)} ${copy['redesign.liveMinuteIncluded']}`, 'Grouped model controls must retain full provider and recorded-value meaning');
    assert.equal(actual.cells.length, times.length);
    for (const [cellIndex, at] of times.entries()) {
      const row = data.rows.find(row => row.bucket_ts === at && row.provider === group.provider && row.model === group.model);
      const exists = row !== undefined && row.records > 0;
      const cellState = !exists ? 'missing' : row.total_tokens === 0 ? 'zero' : 'recorded';
      const cellPartial = Math.min(data.to, at + 60000) - Math.max(data.from, at) < 60000;
      assert.deepEqual(actual.cells[cellIndex], { at, state: cellState, tokens: exists ? row.total_tokens : null, records: exists ? row.records : null, calls: exists ? row.calls : null, partial: cellPartial, intensity: exists && max > 0 ? row.total_tokens / max : 0 });
      if (cellState === 'missing') missing++; else if (cellState === 'zero') zero++; else recorded++;
      if (cellPartial) partial++;
      tableExpected.push({ key, at, state: cellState, tokens: exists ? format.format(row.total_tokens) : '—', records: exists ? format.format(row.records) : '—', calls: exists ? format.format(row.calls) : '—' });
    }
  }
  const aggregate = data.groups.reduce((sum, group) => sum + group.aggregateRecords, 0);
  const unknown = data.groups.reduce((sum, group) => sum + group.unknownRecords, 0);
  for (const [coverage, count] of [['included', data.coverage.includedRecords], ['aggregate', aggregate], ['unknown', unknown]] as const) assert.equal(await page.locator(`.qp-live-matrix-coverage [data-coverage=${coverage}]`).getAttribute('data-count'), String(count));
  const summary = page.locator('.qp-live-minute-data>summary');
  await summary.focus(); await page.keyboard.press('Enter');
  assert.equal(await page.locator('.qp-live-minute-data').getAttribute('open'), '');
  const table = await page.locator('.qp-live-minute-data-table tbody tr').evaluateAll(elements => elements.map(element => ({
    key: element.getAttribute('data-pair-key'), at: Number(element.getAttribute('data-at')), state: element.getAttribute('data-state'),
    tokens: element.querySelectorAll('td')[3].firstChild!.textContent,
    records: element.querySelectorAll('td')[4].textContent, calls: element.querySelectorAll('td')[5].textContent,
  })));
  assert.deepEqual(table, tableExpected);
  const labelGeometry: (typeof liveMinuteChecks)[number]['labelGeometry'] = [];
  for (const width of [390, 900, 1280]) {
    await page.setViewportSize({ width, height: 941 });
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `Live minute table overflow at ${width}`);
    const labels = await page.locator('.qp-live-matrix-label>span:last-child').evaluateAll(elements => elements.map(element => {
      const model = element.querySelector('b')!;
      return { width: element.getBoundingClientRect().width, clientWidth: element.clientWidth, scrollWidth: element.scrollWidth, modelClientWidth: model.clientWidth, modelScrollWidth: model.scrollWidth, name: model.textContent };
    }));
    assert.ok(labels.every(label => label.width >= 45 || label.scrollWidth <= label.clientWidth), `Matrix model labels are nearly hidden at ${width}: ${JSON.stringify(labels)}`);
    labelGeometry.push(...labels.map(label => ({ viewport: width, ...label })));
  }
  await page.setViewportSize({ width: 1672, height: 941 });
  const desktopLabels = await page.locator('.qp-live-matrix-label>span:last-child').evaluateAll(elements => elements.map(element => {
    const model = element.querySelector('b')!;
    return { width: element.getBoundingClientRect().width, clientWidth: element.clientWidth, scrollWidth: element.scrollWidth, modelClientWidth: model.clientWidth, modelScrollWidth: model.scrollWidth, name: model.textContent };
  }));
  assert.ok(desktopLabels.every(label => label.modelScrollWidth <= label.modelClientWidth), `Desktop matrix model labels are clipped: ${JSON.stringify(desktopLabels)}`);
  labelGeometry.push(...desktopLabels.map(label => ({ viewport: 1672, ...label })));
  const region = page.locator('.qp-live-minute-data-table'); await region.focus(); await page.keyboard.press('End');
  await page.waitForFunction(() => { const e = document.querySelector('.qp-live-minute-data-table')!; return e.scrollTop > 0 && e.scrollTop + e.clientHeight >= e.scrollHeight - 1; });
  await summary.focus(); await page.keyboard.press('Enter'); await page.setViewportSize({ width: 1672, height: 941 }); await page.evaluate(() => scrollTo(0, 0));
  liveMinuteChecks.push({ lang, theme, state, pairs: expected.length, cells: times.length * expected.length, missing, zero, recorded, partial, included: data.coverage.includedRecords, aggregate, unknown, table: true, labelGeometry });
}

async function checkLiveDensity(page: Page, lang: string, theme: string, pending: Set<Request>) {
  await page.setViewportSize({ width: 1672, height: 941 });
  await page.evaluate(() => window.scrollTo(0, 0));
  referenceDetailRegions.push({ page: 'live', lang, theme, regions: await page.evaluate(() => Object.fromEntries(['.qp-live-top', '.qp-live-header', '.qp-live-metrics', '.qp-live-sessions', '.qp-live-session-tools', '.qp-live-table', '.qp-live-table thead', '.qp-live-table tbody tr', '.qp-live-trend', '.qp-live-records', '.qp-live-rail', '.qp-live-rail>section:first-child', '.qp-live-matrix-section', '.qp-live-matrix-heading', '.qp-live-minute-range', '.qp-live-matrix', '.qp-live-matrix-row:first-child', '.qp-live-matrix-coverage'].map(selector => {
    const { x, y, width, height, bottom } = document.querySelector(selector)!.getBoundingClientRect();
    return [selector, { x, y, width, height, bottom }];
  }))) });
  const note = page.locator('.qp-live-session-note');
  const noteSummary = note.locator('summary');
  await noteSummary.focus(); await page.keyboard.press('Enter');
  assert.equal(await note.getAttribute('open'), '');
  assert.equal(await note.locator('p').innerText(), (lang === 'th' ? th : en)['redesign.liveMetricsNote'], 'Full session counting disclosure remains available');
  await page.keyboard.press('Enter');
  assert.equal(await note.getAttribute('open'), null);
  const metrics = await page.locator('.qp-live-metrics>div').evaluateAll(cards => cards.map(card => {
    const value = card.querySelector('strong')!, label = card.querySelector('small')!, icon = card.querySelector('.qp-live-metric-icon')!;
    return { valueBottom: value.getBoundingClientRect().bottom, labelTop: label.getBoundingClientRect().top, tone: getComputedStyle(card).getPropertyValue('--qp-live-metric-tone').trim(), iconColor: getComputedStyle(icon).color };
  }));
  for (const metric of metrics) {
    assert.ok(metric.valueBottom <= metric.labelTop, 'Live metric value belongs above its label');
    assert.deepEqual(rgb(metric.iconColor), rgb(metric.tone), 'Metric icon must use its source card tone');
  }
  const tableGeometry = await page.locator('.qp-live-table').evaluate(element => ({ height: element.getBoundingClientRect().height, firstRowHeight: element.querySelector('tbody tr')!.getBoundingClientRect().height }));
  assert.ok(Math.abs(tableGeometry.height - 270) <= 1, `Live table source viewport: ${JSON.stringify(tableGeometry)}`);
  assert.ok(Math.abs(tableGeometry.firstRowHeight - 30) <= 1, `Live row source rhythm: ${JSON.stringify(tableGeometry)}`);
  const bottom = await page.locator('.qp-live-records').evaluate(element => element.getBoundingClientRect().bottom);
  assert.ok(bottom <= 941, `Live feed and pagination exceed viewport: ${bottom}`);
  const railBottom = await page.locator('.qp-live-matrix-section').evaluate(element => element.getBoundingClientRect().bottom);
  assert.ok(railBottom <= 941, `Live canonical minute matrix exceeds the source viewport: ${railBottom}`);
  const sessions = page.locator('.qp-live-table tbody tr');
  const records = page.locator('.qp-live-feed li');
  assert.equal(await sessions.count(), 10); assert.equal(await records.count(), 8);
  const feedFrame = await page.locator('.qp-live-feed').boundingBox();
  assert.ok(feedFrame);
  assert.ok(await records.nth(5).evaluate((element, bottom) => element.getBoundingClientRect().bottom <= bottom + 1, feedFrame.y + feedFrame.height), 'Six complete feed rows must fit the source viewport');
  const firstFeedPage = await records.allTextContents();
  const feedButtons = page.locator('.qp-live-feed-pagination button');
  const nextFeed = page.waitForResponse(response => response.url().includes('/api/usage-events?') && new URL(response.url()).searchParams.get('offset') === '8');
  await feedButtons.last().focus(); await page.keyboard.press('Enter');
  assert.equal((await nextFeed).status(), 200); await settled(page, pending);
  assert.equal(await records.count(), 8);
  const previousFeed = page.waitForResponse(response => response.url().includes('/api/usage-events?') && (new URL(response.url()).searchParams.get('offset') ?? '0') === '0');
  await feedButtons.first().focus(); await page.keyboard.press('Enter');
  assert.equal((await previousFeed).status(), 200); await settled(page, pending);
  assert.deepEqual(await records.allTextContents(), firstFeedPage, 'Feed toolbar pagination must restore the original records');
  const query = new URLSearchParams({ bucket: 'minute', group_by: 'provider_model', from: String(fixedNow - 30 * 60_000), to: String(fixedNow + 1) });
  const response = await daemon.inject({ method: 'GET', url: `/api/trend?${query}`, headers: { 'x-quotapulse-token': 'stable-capture-test' } });
  assert.equal(response.statusCode, 200);
  await checkLiveMinuteValues(page, response.json<ProviderModelMinuteResponse>(), lang, theme, 'canonical');
  for (const selector of ['.qp-live-table', '.qp-live-feed']) {
    const region = page.locator(selector);
    await region.focus(); await page.keyboard.press('End');
    await page.waitForFunction(selector => {
      const element = document.querySelector(selector)!;
      return element.scrollTop > 0 && element.scrollTop + element.clientHeight >= element.scrollHeight - 1;
    }, selector);
    const bounds = await region.evaluate(element => {
      const last = element.querySelector('tbody tr:last-child, li:last-child')!.getBoundingClientRect();
      return { last: last.bottom, bottom: element.getBoundingClientRect().bottom };
    });
    assert.ok(bounds.last <= bounds.bottom + 1, `${selector} final record is not keyboard reachable`);
    await region.evaluate(element => { element.scrollTop = 0; });
  }
  const target = sessions.last().getByRole('button');
  await target.focus(); await page.keyboard.press('Enter');
  const detail = page.locator('.qp-live-dialog[open]'); await detail.waitFor();
  assert.equal(await detail.locator('dd').first().textContent(), await target.textContent());
  await page.keyboard.press('Escape'); await detail.waitFor({ state: 'hidden' });
  assert.equal(await target.evaluate(element => element === document.activeElement), true);
  await page.locator('.qp-live-table').evaluate(element => { element.scrollTop = 0; });
  liveDensityChecks.push({ lang, theme, bottom, sessions: await sessions.count(), records: await records.count() });
  // Owned memory-only diagnostic records. Restored before any later canonical page.
  const original = JSON.stringify(db.prepare('SELECT * FROM usage_event ORDER BY id').all());
  db.prepare("INSERT INTO source(id,harness,profile,root_path,display_name,detected_at) VALUES (910,'future-adapter','fixed','/synthetic/nonexistent','Unknown grain fixture',0)").run();
  const insert = db.prepare('INSERT INTO usage_event(source_id,session_id,dedup_key,ts,provider,model,input_tokens,output_tokens,total_tokens,call_count) VALUES (?,?,?,?,?,?,?,0,?,1)');
  insert.run(1, 1, 'live-minute-zero-fixture', fixedNow - 60000, 'nous', 'zero-minute-model', 0, 0);
  insert.run(1, 1, 'live-minute-empty-fixture', fixedNow - 120000, '', '', 1, 1);
  insert.run(910, null, 'live-minute-unknown-fixture', fixedNow - 60000, null, null, 400, 400);
  try {
    const diagnostic = await daemon.inject({ method: 'GET', url: `/api/trend?${query}`, headers: { 'x-quotapulse-token': 'stable-capture-test' } });
    assert.equal(diagnostic.statusCode, 200); const data = diagnostic.json<ProviderModelMinuteResponse>();
    await page.goto('http://127.0.0.1:7804/?live-minutes=states#live', { waitUntil: 'domcontentloaded' }); await page.locator('.qp-live-minute-strip').first().waitFor(); await settled(page, pending);
    await checkLiveMinuteValues(page, data, lang, theme, 'owned-diagnostic');
    const checked = liveMinuteChecks.at(-1)!; assert.ok(checked.zero > 0 && checked.missing > 0 && checked.recorded > 0 && checked.unknown > 0 && checked.aggregate > 0);
    const icon = page.locator('.qp-live-provider-group').filter({ has: page.locator('.qp-live-matrix-label b', { hasText: 'zero-minute-model' }) }).locator('.qp-live-provider-mark');
    const bounds = await icon.evaluate(element => { const outer = element.getBoundingClientRect(); return Array.from(element.querySelectorAll('svg')).map(svg => { const r = svg.getBoundingClientRect(); return r.left >= outer.left - .1 && r.top >= outer.top - .1 && r.right <= outer.right + .1 && r.bottom <= outer.bottom + .1; }); });
    assert.ok(bounds.length > 0 && bounds.every(Boolean), 'Nous mark is clipped');
    await page.screenshot({ path: resolve(output, `live-minute-states-${lang}-${theme}.png`), animations: 'disabled' });
  } finally {
    db.prepare("DELETE FROM usage_event WHERE dedup_key IN ('live-minute-zero-fixture','live-minute-empty-fixture','live-minute-unknown-fixture')").run();
    db.prepare('DELETE FROM source WHERE id=910').run();
    assert.equal(JSON.stringify(db.prepare('SELECT * FROM usage_event ORDER BY id').all()), original);
    await page.goto('http://127.0.0.1:7804/?live-minutes=restored#live', { waitUntil: 'domcontentloaded' }); await page.locator('.qp-live-minute-strip').first().waitFor(); await settled(page, pending);
  }
  liveRefreshChecks.push(await checkLiveMinuteRefresh(page, pending, response.json<ProviderModelMinuteResponse>(), lang, theme));
}

async function checkModelComparison(page: Page, lang: string, theme: string, pending: Set<Request>) {
  await page.setViewportSize({ width: 1672, height: 941 }); await page.evaluate(() => window.scrollTo(0, 0));
  referenceDetailRegions.push({ page: 'models', lang, theme, regions: await page.evaluate(() => Object.fromEntries(['.qp-model-comparison', '.qp-model-providers', '.qp-model-detail>.qp-panel:first-child', '.qp-model-distribution', '.qp-model-donut'].map(selector => {
    const { x, y, width, height, bottom } = document.querySelector(selector)!.getBoundingClientRect();
    return [selector, { x, y, width, height, bottom }];
  }))) });
  const bottom = await page.locator('.qp-model-providers').evaluate(element => element.getBoundingClientRect().bottom);
  const primaryRegions = await page.evaluate(() => Object.fromEntries(['.qp-model-header', '.qp-model-summary', '.qp-model-summary article:last-child', '.qp-model-comparison', '.qp-model-providers'].map(selector => {
    const { y, height, bottom } = document.querySelector(selector)!.getBoundingClientRect();
    return [selector, { y, height, bottom, ...(selector.endsWith('article:last-child') ? { fields: [...document.querySelector(selector)!.children].map(element => ({ text: element.textContent, height: element.getBoundingClientRect().height, width: element.getBoundingClientRect().width, lineHeight: getComputedStyle(element).lineHeight })) } : {}) }];
  })));
  assert.ok(bottom <= 941, `Model comparison/provider panels exceed viewport: ${JSON.stringify(primaryRegions)}`);
  const month = new Date(fixedNow); month.setDate(1); month.setHours(0, 0, 0, 0);
  const query = new URLSearchParams({ detailed: '1', trends: '1', from: String(month.getTime()), to: String(fixedNow + 1) });
  const result = await daemon.inject({ method: 'GET', url: `/api/models?${query}`, headers: { 'x-quotapulse-token': 'stable-capture-test' } });
  assert.equal(result.statusCode, 200); const data = result.json<DetailedModelResponse>();
  const rows = page.locator('.qp-model-table-wrap tbody tr'); assert.equal(await rows.count(), 6);
  referenceDetailRegions.push({ page: 'models', lang, theme, regions: await page.locator('.qp-model-layout').evaluate(element => Object.fromEntries(['.qp-model-detail>.qp-panel:first-child', '.qp-model-detail-identity', '.qp-model-detail-provider', '.qp-model-detail-identity h3', '.qp-model-detail-stats', '.qp-model-comparison', '.qp-model-maker-mark'].map(selector => {
    const node = element.querySelector(selector)!; const { x, y, width, height, bottom } = node.getBoundingClientRect();
    return [selector, { x, y, width, height, bottom }];
  }))) });
  assert.equal(await page.locator('.qp-model-summary-icon').count(), 4);
  assert.ok(data.trends, 'Models fixture must include recorded histories');
  const recordedBuckets = new Map(data.trends.points.map(point => [point.start, point]));
  const bucketCount = Math.ceil((data.scope.to - data.scope.from) / data.trends.bucketMs);
  for (const [index, metric] of ['pairs', 'tokens', 'sessions', 'api_value_usd'].entries()) {
    const chart = page.locator('.qp-model-summary article').nth(index).locator('.qp-model-summary-spark');
    assert.equal(await chart.count(), 1, `Models ${metric} must render its real historical sparkline`);
    const rendered = await chart.locator('circle').evaluateAll(elements => elements.map(element => ({ at: Number(element.getAttribute('data-at')), value: Number(element.getAttribute('data-value')) })));
    const expected = Array.from({ length: bucketCount }, (_, bucket) => {
      const at = data.scope.from + bucket * data.trends!.bucketMs;
      const point = recordedBuckets.get(at);
      return metric === 'api_value_usd' && (!point || point.api_priced_calls === 0) ? null : { at, value: point ? point[metric as 'pairs' | 'tokens' | 'sessions' | 'api_value_usd'] : 0 };
    }).filter(point => point !== null);
    assert.deepEqual(rendered, expected, `Models ${metric} historical values differ from recorded API bins`);
  }
  const providerCharts = page.locator('.qp-model-provider-list button');
  assert.equal(await providerCharts.count(), new Set(data.groups.map(group => group.provider)).size);
  for (const button of await providerCharts.all()) {
    const provider = await button.getAttribute('data-provider-missing') === 'true' ? null : await button.getAttribute('data-provider');
    const expected = Array.from({ length: bucketCount }, (_, bucket) => {
      const at = data.scope.from + bucket * data.trends!.bucketMs;
      return { at, value: data.trends!.providers.find(point => point.provider === provider && point.start === at)?.tokens ?? 0 };
    });
    const rendered = await button.locator('.qp-model-provider-spark circle').evaluateAll(elements => elements.map(element => ({ at: Number(element.getAttribute('data-at')), value: Number(element.getAttribute('data-value')) })));
    assert.deepEqual(rendered, expected, `Provider ${JSON.stringify(provider)} sparkline differs from its exact scoped API history`);
  }
  const historyDisclosure = page.locator('.qp-model-history');
  await historyDisclosure.locator('summary').focus(); await page.keyboard.press('Enter');
  assert.equal(await historyDisclosure.locator('tbody tr').count(), bucketCount, 'All Models summary/provider buckets must remain available');
  await historyDisclosure.locator('summary').focus(); await page.keyboard.press('Enter');
  for (const group of data.groups) {
    const row = rows.filter({ has: page.getByRole('button', { name: group.model!, exact: true }) });
    assert.equal(await row.locator('.qp-model-maker-mark').getAttribute('data-vendor'), group.vendor, 'Maker artwork must retain the API maker independently of the routed provider');
    assert.equal(await row.locator('.qp-model-maker-mark').getAttribute('aria-hidden'), 'true', 'Decorative maker framing must not alter the model control name');
    const input = group.inputTokens + group.cachedInputTokens + group.cacheWriteTokens;
    const values = [group.cachedInputTokens / input * 100, (group.native_calls + group.computed_calls + group.estimated_calls) / group.calls * 100];
    const bars = row.locator('.qp-model-ratio .qp-bar>span'); assert.equal(await bars.count(), 2);
    for (const [index, value] of values.entries()) assert.ok(Math.abs(parseFloat((await bars.nth(index).getAttribute('style'))!.split(':')[1]) - value) < 0.0001);
  }
  const last = rows.last().getByRole('button'); const identity = await last.locator('.qp-model-name').textContent();
  await last.focus(); await page.keyboard.press('Enter'); await settled(page, pending);
  assert.equal(await last.getAttribute('aria-pressed'), 'true');
  assert.equal(await page.locator('.qp-model-detail h3').textContent(), identity);
  const selectedGroup = data.groups.find(group => group.model === identity);
  assert.ok(selectedGroup);
  assert.equal(await page.locator('.qp-model-detail-provider').getAttribute('data-vendor'), selectedGroup.provider ?? selectedGroup.vendor ?? 'unknown');
  assert.equal(await page.locator('.qp-model-detail-provider svg, .qp-model-detail-provider>span').count(), 1, 'Selected model detail shows its actual provider mark or unknown fallback');
  await page.locator('.qp-model-search input').fill('no-such-synthetic-model'); assert.equal(await rows.count(), 0);
  await page.locator('.qp-model-search input').fill(''); await settled(page, pending);
  const fixture = structuredClone(data);
  fixture.groups[0].inputTokens = 0; fixture.groups[0].cachedInputTokens = 0; fixture.groups[0].cacheWriteTokens = 0; fixture.groups[0].calls = 0;
  fixture.groups[1].cachedInputTokens = 0;
  fixture.groups[1].native_calls = 0; fixture.groups[1].computed_calls = 0; fixture.groups[1].estimated_calls = 0;
  fixture.groups[2].inputTokens = 199; fixture.groups[2].cachedInputTokens = 1; fixture.groups[2].cacheWriteTokens = 0;
  fixture.groups[2].calls = 200; fixture.groups[2].native_calls = 0; fixture.groups[2].computed_calls = 1; fixture.groups[2].estimated_calls = 0;
  const pattern = '**/api/models?*';
  await page.route(pattern, route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(fixture) }));
  try {
    await page.goto('http://127.0.0.1:7804/?model-ratios=boundary#models', { waitUntil: 'domcontentloaded' });
    await page.locator('.qp-model-table-wrap tbody tr').first().waitFor(); await settled(page, pending);
    for (const [index, expected] of [[0, null], [1, 0], [2, 0.5]] as const) {
      const row = page.locator('.qp-model-table-wrap tbody tr').filter({ has: page.getByRole('button', { name: fixture.groups[index].model!, exact: true }) });
      const bars = row.locator('.qp-model-ratio .qp-bar>span');
      if (expected === null) { assert.equal(await bars.count(), 0); assert.equal(await row.locator('td').nth(6).textContent(), '—'); assert.equal(await row.locator('td').nth(7).textContent(), '—'); }
      else { assert.equal(await bars.count(), 2); for (const bar of await bars.all()) assert.equal(await bar.evaluate(element => parseFloat(element.style.width)), expected); }
    }
    for (const width of [390, 900, 1280]) { await page.setViewportSize({ width, height: 941 }); assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true); }
  } finally { await page.unroute(pattern); }
  modelComparisonChecks.push({ lang, theme, bottom, rows: data.groups.length, ratios: data.groups.length * 2, boundaryRatios: true });
}

async function checkAlerts(page: Page, lang: string, theme: string, pending: Set<Request>) {
  await page.setViewportSize({ width: 1672, height: 941 }); await page.evaluate(() => scrollTo(0, 0));
  const bottom = await page.locator('.qp-alert-layout').evaluate(element => element.getBoundingClientRect().bottom + scrollY);
  const geometry = await page.locator('.qp-alert-main').evaluate(element => Array.from(element.children).map(child => { const rect = child.getBoundingClientRect(); return { className: (child as HTMLElement).className, top: rect.top, bottom: rect.bottom, height: rect.height }; }));
  assert.ok(bottom <= 941, `Alerts occupied panels exceed viewport: ${JSON.stringify({ bottom, geometry })}`);
  referenceDetailRegions.push({ page: 'alerts', lang, theme, regions: await page.evaluate(() => Object.fromEntries(['.qp-alert-top', '.qp-alert-header', '.qp-alert-summary', '.qp-alert-chart', '.qp-alert-forecast', '.qp-alert-forecast-reading', '.qp-alert-forecast-orb', '.qp-alert-forecast-facts', '.qp-alert-forecast-warning', '.qp-alert-guidance', '.qp-alert-guidance-heading', '.qp-alert-guidance-list', '.qp-alert-guidance-list>li:first-child', '.qp-alert-history', '.qp-alert-history-heading'].map(selector => {
    const element = document.querySelector(selector);
    if (!element) return [selector, null];
    const { x, y, width, height, bottom } = element.getBoundingClientRect();
    return [selector, { x, y, width, height, bottom }];
  }))) });
  assert.deepEqual(await page.locator('.qp-alert-rules [data-threshold]').allTextContents(), ['50%', '80%', '95%']);
  const copy = lang === 'th' ? th : en;
  const overviewResult = await daemon.inject({ method: 'GET', url: '/api/overview', headers: { 'x-quotapulse-token': 'stable-capture-test' } });
  const overview = overviewResult.json<Overview>();
  const risks = getQuotaRiskModel(overview.limits, overview.settings.hidden_subscriptions, overview.now).risks;
  const riskRows = page.locator('.qp-alert-risk>ul>li[data-level]');
  const summaryCount = await page.locator('[data-summary="redesign.alertCurrent"] strong').innerText();
  for (const level of ['critical', 'warning', 'info', 'stale', 'all']) {
    const button = page.locator(`.qp-alert-risk-filters button[data-level="${level}"]`);
    await button.click();
    assert.equal(await button.getAttribute('aria-pressed'), 'true');
    assert.equal(await riskRows.count(), risks.filter(risk => level === 'all' || risk.level === level).length, 'Filtered rows must match actual quota risks');
    assert.equal(await page.locator('[data-summary="redesign.alertCurrent"] strong').innerText(), summaryCount, 'Filtering must not change global risk count');
  }
  const search = page.locator('.qp-alert-risk-search input');
  if (risks.length) {
    await search.fill(risks[0].owner);
    assert.deepEqual(await riskRows.evaluateAll(rows => rows.map(row => row.getAttribute('data-owner'))), risks.filter(risk => risk.owner.toLowerCase().includes(risks[0].owner.toLowerCase()) || [risk.title, risk.window, risk.reading.subscription_provider, risk.reading.account_provider].some(value => value?.toLowerCase().includes(risks[0].owner.toLowerCase()))).map(risk => risk.owner));
  }
  await search.fill('no-matching-quota-owner-7654321');
  assert.equal(await riskRows.count(), 0);
  await page.getByText(copy['redesign.alertNoMatch'], { exact: true }).waitFor();
  await search.fill('');
  const sort = page.locator('.qp-alert-risk-toolbar select');
  await sort.selectOption('recent');
  assert.deepEqual(await riskRows.evaluateAll(rows => rows.map(row => [row.getAttribute('data-owner'), row.getAttribute('data-window')])), [...risks].sort((a,b) => b.reading.last_seen_at-a.reading.last_seen_at || a.title.localeCompare(b.title)).map(risk => [risk.owner, risk.window]));
  await sort.selectOption('severity');
  await settled(page, pending);
  const forecastSelect = page.locator('.qp-alert-chart select');
  const initialWindow = await forecastSelect.inputValue();
  const forecastStates = new Set<string>();
  const forecastWindows: string[] = [];
  const keys = await forecastSelect.locator('option').evaluateAll(options => options.map(option => (option as HTMLOptionElement).value));
  for (const key of keys) {
    if (await forecastSelect.inputValue() !== key) {
      await forecastSelect.selectOption(key);
      await page.waitForFunction(key => document.querySelector('.qp-alert-chart')?.getAttribute('data-history-key') === key, key);
      await settled(page, pending);
    }
    const [owner, window] = JSON.parse(key) as [string, string];
    const params = new URLSearchParams({ subscription_key: owner, window_kind: window, from: String(Math.max(0, fixedNow - 30 * 86_400_000)), to: String(fixedNow + 1) });
    const quotaResponse = await daemon.inject({ method: 'GET', url: `/api/quota-history?${params}`, headers: { 'x-quotapulse-token': 'stable-capture-test' } });
    assert.equal(quotaResponse.statusCode, 200);
    const quota = quotaResponse.json<QuotaHistoryResponse>();
    forecastStates.add(quota.reader?.forecast.status ?? 'unknown');
    if (quota.reader?.forecast.status === 'ready' && quota.reader.forecast.projectedFullAt != null) forecastWindows.push(key);
    const expected = quota.reader?.forecast.status === 'ready' && quota.reader.forecast.projectedFullAt != null
      ? new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US', { maximumFractionDigits: 1 }).format(Math.max(0, (quota.reader.forecast.projectedFullAt - fixedNow) / 86_400_000))
      : lang === 'th' ? 'ไม่ทราบ' : 'Unknown';
    assert.equal(await page.getByTestId('alert-forecast-days').textContent(), expected, 'Forecast days differ from daemon result');
      const facts = page.locator('.qp-alert-forecast-facts');
    const clock = new Intl.DateTimeFormat(lang === 'th' ? 'th-TH' : 'en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    const projected = quota.reader?.forecast.status === 'ready' && quota.reader.forecast.projectedFullAt != null
      ? clock.format(quota.reader.forecast.projectedFullAt) : copy['redesign.alertForecastUnknown'];
    assert.deepEqual(await facts.locator('dt').allTextContents(), [copy['redesign.projected'], copy['redesign.alertReset']]);
    assert.deepEqual(await facts.locator('dd').allTextContents(), [projected, quota.reader?.resetAt == null ? '--' : clock.format(quota.reader.resetAt)], 'Adjacent forecast dates differ from selected daemon reader');
    assert.ok((await facts.locator('small').innerText()).includes(quota.reader!.origin), 'Forecast reader origin disappeared from adjacent facts');
    const fullAt = quota.reader?.forecast.status === 'ready' ? quota.reader.forecast.projectedFullAt : null;
    const resetAt = quota.reader?.resetAt;
    const guidance = page.locator('.qp-alert-guidance-list');
    assert.deepEqual(await guidance.locator('li').evaluateAll(rows => rows.map(row => row.getAttribute('data-guidance'))), ['quota', 'reset', 'reader', 'notifications']);
    const ownerHref = `#providers?${new URLSearchParams({ owner, window })}`;
    for (const action of ['quota', 'reset']) assert.equal(await guidance.locator(`[data-guidance="${action}"] a`).getAttribute('href'), ownerHref, 'Guidance must follow the selected quota');
    assert.equal(await guidance.locator('[data-guidance="reset"] p').innerText(), resetAt != null && resetAt > fixedNow ? `${copy['redesign.alertGuidanceReportedReset']} ${clock.format(resetAt)}` : copy['redesign.alertGuidanceResetUnknown']);
    if (quota.reader?.sourceId != null) assert.equal(await guidance.locator('[data-guidance="reader"] a').getAttribute('href'), `#settings?section=diagnostics&source=${quota.reader.sourceId}`, 'Diagnostics must identify the actual selected reader');
    assert.equal(await guidance.locator('[data-guidance="notifications"] a').getAttribute('href'), '#settings');
    const beforeReset = fullAt != null && resetAt != null && fullAt < resetAt;
    const warning = page.locator('.qp-alert-forecast-warning');
    assert.equal(await warning.count(), beforeReset ? 1 : 0, 'Forecast warning must follow the selected daemon forecast');
    if (beforeReset) {
      assert.equal(await warning.locator('strong').innerText(), copy['redesign.alertForecast']);
      assert.equal(await warning.locator('span').innerText(), `${resetAt - fullAt < 60_000 ? '<1m' : countdown(resetAt, fullAt)} ${copy['redesign.beforeReset']}`);
    }
  }
  assert.ok(forecastStates.has('ready'), 'Ready forecast fixture was not checked');
  assert.ok([...forecastStates].some(status => status !== 'ready'), 'Unavailable forecast fixture was not checked');
  assert.equal(initialWindow, forecastWindows[0] ?? keys[0], 'Alerts should default to the first quota window with an API-backed forecast');
  if (await forecastSelect.inputValue() !== initialWindow) {
    await forecastSelect.selectOption(initialWindow);
    await page.waitForFunction(key => document.querySelector('.qp-alert-chart')?.getAttribute('data-history-key') === key, initialWindow);
    await settled(page, pending);
  }
  for (const [threshold, color] of [[80, '--qp-warning'], [95, '--qp-danger']] as const) {
    const swatch = await page.locator(`.qp-alert-rules [data-threshold="${threshold}"]`).first().evaluate((element, color) => ({ actual: getComputedStyle(element).color, expected: getComputedStyle(document.querySelector('.qp-redesign')!).getPropertyValue(color).trim() }), color);
    assert.deepEqual(rgb(swatch.actual), rgb(swatch.expected));
  }
  const response = await daemon.inject({ method: 'GET', url: '/api/alerts?limit=100', headers: { 'x-quotapulse-token': 'stable-capture-test' } });
  assert.equal(response.statusCode, 200); const events = response.json<{ events: AlertEvent[] }>().events;
  const items = page.locator('.qp-alert-history li'); assert.equal(await items.count(), events.length);
  for (const [index, event] of events.entries()) {
    assert.equal(await items.nth(index).locator('.qp-alert-event-threshold').innerText(), `${event.threshold}%`);
    assert.ok((await items.nth(index).locator('strong').innerText()).includes(event.subscription_display_name ?? event.display_name));
  }
  const more = page.locator('.qp-alert-history button'); const originalLabel = await more.innerText();
  const expanded = page.waitForResponse(response => response.url().includes('/api/alerts?limit=500'));
  await more.focus(); await page.keyboard.press('Enter'); assert.equal((await expanded).status(), 200); await settled(page, pending);
  assert.notEqual(await more.innerText(), originalLabel);
  const collapsed = page.waitForResponse(response => response.url().includes('/api/alerts?limit=100'));
  await page.keyboard.press('Enter'); assert.equal((await collapsed).status(), 200); await settled(page, pending);
  assert.equal(await more.innerText(), originalLabel);
  assert.ok(events.length > 0);
  const pattern = '**/api/alerts?*';
  for (const state of ['large', 'empty']) {
    const fixture = state === 'empty' ? [] : Array.from({ length: 60 }, (_, index) => ({ ...events[index % events.length], id: 1000 + index }));
    await page.route(pattern, route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ events: fixture }) }));
    try {
      await page.goto(`http://127.0.0.1:7804/?alert-history=${state}#alerts`, { waitUntil: 'domcontentloaded' });
      await page.locator('.qp-alert-history').waitFor(); await settled(page, pending);
      assert.equal(await page.locator('.qp-alert-history li').count(), fixture.length);
      assert.ok(await page.locator('.qp-alert-layout').evaluate(element => element.getBoundingClientRect().bottom + scrollY <= 941));
      const list = page.locator('.qp-alert-history ol');
      if (state === 'empty') assert.equal(await list.count(), 0);
      else {
        await list.focus(); await page.keyboard.press('End'); await page.waitForTimeout(300);
        assert.ok(await list.evaluate(element => element.scrollTop > 0));
        assert.ok(await list.evaluate(element => element.lastElementChild!.getBoundingClientRect().bottom <= element.getBoundingClientRect().bottom + 1));
        for (const width of [390, 900, 1280]) { await page.setViewportSize({ width, height: 941 }); assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true); }
        await page.setViewportSize({ width: 1672, height: 941 });
      }
    } finally { await page.unroute(pattern); }
  }
  const notificationPattern = '**/api/notification-settings';

  for (const quietEnd of [420, 1320]) {
    const settings = { enabled: false, snooze_until: fixedNow + 3_600_000, quiet_start: 1320, quiet_end: quietEnd, updated_at: fixedNow };
    await page.route(notificationPattern, route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(settings) }));
    try {
      await page.goto(`http://127.0.0.1:7804/?notification-guidance=${quietEnd}#alerts`, { waitUntil: 'domcontentloaded' });
      await page.locator('.qp-alert-guidance-list').waitFor(); await settled(page, pending);
      const text = await page.locator('[data-guidance="notifications"] p').innerText();
      assert.ok(text.includes(copy['redesign.alertGuidanceNotificationsOff']));
      assert.ok(text.includes(copy['redesign.alertGuidanceSnoozedUntil']));
      assert.equal(text.includes(copy['redesign.alertGuidanceQuietHours']), quietEnd !== 1320, 'Equal quiet-hour endpoints disable the quiet window');
      if (quietEnd === 420) assert.ok(text.includes('22:00–07:00'));
      assert.ok(await page.locator('.qp-alert-layout').evaluate(element => element.getBoundingClientRect().bottom + scrollY <= 941), 'Long notification facts must remain in the native frame');
    } finally { await page.unroute(notificationPattern); }
  }
  alertChecks.push({ lang, theme, bottom, events: events.length, expandedEvents: 60, keyboardScrolled: true, empty: true, selectedGuidance: true, notificationGuidance: true });
}

async function checkHistoryDetails(page: Page, lang: string, theme: string, pass: number, pending: Set<Request>) {
  const history = page.getByTestId('usage-history');
  const trigger = history.locator('tbody tr').first().getByRole('button');
  const detailDialog = page.locator('dialog[aria-labelledby=history-detail-title]');
  let eventId: number;
  if (await detailDialog.evaluate(element => (element as HTMLDialogElement).open)) {
    const selected = history.locator('tr[data-selected=true] button');
    assert.equal(await history.locator('tr[data-selected=true]').count(), 1, 'History opens with one recorded event selected');
    eventId = Number((await selected.innerText()).slice(1));
  } else {
    eventId = Number((await trigger.innerText()).slice(1));
    await trigger.focus(); await page.keyboard.press('Enter');
  }
  const response = await daemon.inject({ method: 'GET', url: `/api/usage-events?from=0&to=${fixedNow}&limit=50`, headers: { 'x-quotapulse-token': 'stable-capture-test' } });
  assert.equal(response.statusCode, 200);
  const row = response.json().rows.find((row: { event_id: number }) => row.event_id === eventId);
  assert.ok(row);
  const dialog = page.getByRole('dialog'); await dialog.waitFor();
  assert.equal(await dialog.evaluate(element => element.matches(':modal')), true);
  assert.equal(await history.locator('tr[data-selected=true]').count(), 1);
  assert.equal(await history.locator('tr[data-selected=true] button').innerText(), `#${eventId}`);
  const groups = dialog.locator('.qp-history-detail-groups section'); assert.equal(await groups.count(), 4);
  const tokens = dialog.locator('[data-group="history.tokenBreakdown"] dd');
  for (const [index, value] of [row.total_tokens, row.input_tokens, row.cached_input_tokens, row.cache_write_tokens, row.output_tokens, row.reasoning_tokens].entries()) {
    assert.equal(await tokens.nth(index).innerText(), formatTokens(value));
    assert.equal(await tokens.nth(index).getAttribute('aria-label'), String(value));
    assert.equal(await tokens.nth(index).getAttribute('title'), value.toLocaleString(lang, { maximumFractionDigits: 20 }));
  }
  for (const value of [row.project, row.harness, row.provider, row.vendor, row.model]) assert.ok((await groups.first().innerText()).includes(value));
  const ownerData = (await daemon.inject({ method: 'GET', url: '/api/overview', headers: { 'x-quotapulse-token': 'stable-capture-test' } })).json<Overview>();
  const harnessOwner = ownerData.harnesses.find(harness => harness.harness === row.harness && harness.source_ids.includes(row.source_id));
  assert.ok(harnessOwner, 'Selected recorded source has no harness ownership metadata');
  const harnessMark = dialog.locator('.qp-history-detail-identity[data-field="3"] svg').first();
  assert.equal(await harnessMark.count(), 1, 'Known harness owner must display its published mark');
  if (harnessOwner.vendor !== row.vendor) {
    const modelMark = dialog.locator('.qp-history-detail-identity[data-field="6"] svg').first();
    assert.notEqual(await harnessMark.innerHTML(), await modelMark.innerHTML(), 'Harness owner mark was replaced with the routed model maker');
  }
  await page.evaluate(() => window.scrollTo(0, 0)); await settled(page, pending);
  if (pass === 0) {
    const rail = (await dialog.boundingBox())!;
    const content = (await history.boundingBox())!;
    const backdrop = await dialog.evaluate(element => getComputedStyle(element, '::backdrop').backgroundColor);
    assert.ok(Math.abs(rail.x - 1374) <= 8, 'History detail rail differs from source desktop position estimate');
    assert.equal(rail.width, 288); assert.equal(rail.y, 60); assert.ok(rail.height <= 867);
    const contentGap = rail.x - content.x - content.width;
    assert.ok(contentGap >= 8 && contentGap <= 16, `History content/detail gap: ${contentGap}`);
    assert.equal(backdrop, 'rgba(0, 0, 0, 0)', 'Desktop History backdrop dims the reference view');
    historyRailChecks.push({ lang, theme, ...rail, contentGap, transparentBackdrop: true });
    referenceDetailRegions.push({ page: 'history', lang, theme, regions: await dialog.evaluate(element => Object.fromEntries(['.qp-history-detail-record-meta', '.qp-history-detail-identities', '.qp-history-detail-identity[data-field="2"]', '[data-group="history.tokenBreakdown"]', '[data-group="history.pricingSource"]'].map(selector => {
      const { x, y, width, height, bottom } = element.querySelector(selector)!.getBoundingClientRect();
      return [selector, { x, y, width, height, bottom }];
    }))) });
  }
  const filename = `history-selected-${lang}-${theme}.png`;
  await page.evaluate(() => { const focused = document.activeElement; if (focused instanceof HTMLElement) focused.blur(); });
  await page.mouse.move(0, 0);
  await page.waitForTimeout(200);
  await page.addStyleTag({ content: '*,*::before,*::after{transition:none!important;caret-color:transparent!important}' });
  await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  const screenshot = await page.screenshot({ path: resolve(output, pass === 0 ? filename : `repeat-${filename}`), animations: 'disabled' });
  if (pass === 0) cases.push({ page: 'history-selected', lang, theme, filename, sha256: sha(screenshot), semanticContrasts: [], checkedElements: ['API-matched recorded metadata', 'native modal', 'selected record'] });
  else {
    const item = cases.find(item => item.filename === filename)!; item.repeatSha256 = sha(screenshot);
    const difference = await comparePixels(page, readFileSync(resolve(output, filename)), screenshot);
    item.changedPixels = difference.changedPixels; item.maxChannelDelta = difference.maxChannelDelta;
    assert.ok(difference.maxChannelDelta <= 10 && difference.changedPixels / difference.pixelCount <= 0.00005, `${filename}: ${JSON.stringify(difference)}`);
  }
  if (pass === 0) {
    for (const width of [390, 900, 1280]) {
      await page.setViewportSize({ width, height: 941 });
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
      assert.equal(await dialog.evaluate(element => element.scrollWidth <= element.clientWidth), true);
      const box = await dialog.boundingBox(); assert.ok(box && box.x >= 0 && box.x + box.width <= width && box.height <= 941);
      await dialog.evaluate(element => { element.scrollTop = element.scrollHeight; });
      const heading = await dialog.locator('.qp-history-detail-heading').boundingBox(); assert.ok(heading && heading.y >= box.y && heading.y + heading.height <= box.y + box.height);
    }
    // Stress only the compact text layout after canonical screenshots; this is
    // not an API fixture or a substituted value in production/reference captures.
    const compactToken = tokens.first().locator('span');
    const originalCompactToken = await compactToken.innerText();
    try {
      await compactToken.evaluate((element, value) => { element.textContent = value; }, formatTokens(1e12));
      assert.equal(await tokens.first().evaluate(element => element.scrollWidth <= element.clientWidth), true, 'Large History token count exceeds its tile');
      assert.equal(await dialog.evaluate(element => element.scrollWidth <= element.clientWidth), true, 'Large History token count creates horizontal dialog overflow');
    } finally {
      await compactToken.evaluate((element, value) => { element.textContent = value; }, originalCompactToken);
    }
    await dialog.getByRole('button').first().focus();
    let browserFocusStep = false;
    for (let index = 0; index < 10; index++) {
      await page.keyboard.press('Tab');
      const focus = await dialog.evaluate(element => element.contains(document.activeElement) ? 'dialog' : document.activeElement === document.body ? 'browser' : 'background');
      assert.notEqual(focus, 'background', 'Modal allowed focus on a background control');
      assert.ok(!(browserFocusStep && focus === 'browser'), 'Tab did not return from browser chrome to the modal');
      browserFocusStep = focus === 'browser';
    }
    await dialog.getByRole('button').first().focus();
    await trigger.evaluate(element => element.focus());
    assert.equal(await dialog.evaluate(element => element.contains(document.activeElement)), true, 'Background control accepted programmatic focus');
  }
  await page.keyboard.press('Escape'); await dialog.waitFor({ state: 'hidden' });
  assert.equal(await trigger.evaluate(element => element === document.activeElement), true);
  assert.equal(await history.locator('tr[data-selected=true]').count(), 0);
  if (pass === 0) historyChecks.push({ lang, theme, eventId, widths: [390, 900, 1280], modal: true, focusRestored: true });
  await page.setViewportSize({ width: 1672, height: 941 }); await page.evaluate(() => window.scrollTo(0, 0));
}
async function checkHistoryDensity(page: Page, lang: string, theme: string) {
  const history = page.getByTestId('usage-history');
  const region = history.locator('.qp-history-table');
  const geometry = await region.evaluate(element => {
    const box = element.getBoundingClientRect();
    const rows = [...element.querySelectorAll('tbody tr')];
    return {
      visibleRows: rows.filter(row => { const rect = row.getBoundingClientRect(); return rect.top >= box.top && rect.bottom <= box.bottom; }).length,
      records: rows.length,
      table: { top: box.top, bottom: box.bottom, headerHeight: element.querySelector('thead')!.getBoundingClientRect().height },
      firstRows: rows.slice(0, 10).map(row => { const rect = row.getBoundingClientRect(); return { top: rect.top, bottom: rect.bottom, height: rect.height }; }),
      cellContents: ['.qp-history-harness', '.qp-history-project', '.qp-history-provider', 'button'].map(selector => {
        const content = rows[0].querySelector(selector)!;
        const style = getComputedStyle(content);
        return { selector, height: content.getBoundingClientRect().height, lineHeight: style.lineHeight, verticalAlign: style.verticalAlign };
      }),
    };
  });
  const bottom = await history.locator('.qp-history-records').evaluate(element => element.getBoundingClientRect().bottom + scrollY);
  console.log('History occupied geometry', lang, theme, { bottom, ...geometry });
  console.log('History summary geometry', JSON.stringify(await history.locator('.qp-history-summary article').evaluateAll(elements => elements.map(element => ({ height: element.getBoundingClientRect().height, children: [...element.children].map(child => ({ tag: child.tagName, text: child.textContent, y: child.getBoundingClientRect().y, height: child.getBoundingClientRect().height, column: getComputedStyle(child).gridColumn, row: getComputedStyle(child).gridRow })) })))));
  assert.ok(bottom <= 941, `History pagination outside desktop viewport: ${bottom}`);
  assert.ok(geometry.visibleRows >= 10, `Fewer than ten complete History fixture rows: ${geometry.visibleRows}`);
  assert.equal(await history.locator('.qp-history-heading select').first().inputValue(), 'last30', 'History defaults to the concept 30-day view');
  const response = await daemon.inject({ method: 'GET', url: `/api/usage-events?from=${fixedNow - 30 * 86_400_000}&to=${fixedNow + 1}&limit=50`, headers: { 'x-quotapulse-token': 'stable-capture-test' } });
  assert.equal(response.statusCode, 200);
  const expectedRecords = response.json<UsageEventsResponse>().total;
  assert.equal(geometry.records, expectedRecords, 'Scrollable region dropped API records in the selected 30-day range');
  for (const row of response.json<UsageEventsResponse>().rows) {
    const rendered = region.locator('tbody tr').filter({ has: page.locator('button').filter({ hasText: new RegExp(`^#${row.event_id}$`) }) });
    assert.equal(await rendered.count(), 1, `Missing History record #${row.event_id}`);
    assert.equal(await rendered.locator('.qp-history-model-name').textContent(), row.model ?? '—', 'History preserves the raw API model name');
    assert.equal(await rendered.locator('.qp-history-model').getAttribute('title'), row.model, 'History preserves the complete model tooltip');
    assert.equal(await rendered.locator('.qp-history-model-maker').getAttribute('data-vendor'), row.vendor, 'History maker comes from vendor metadata independently of provider');
    assert.equal(await rendered.locator('.qp-history-model-maker').getAttribute('aria-hidden'), 'true');
  }
  referenceDetailRegions.push({ page: 'history-summary', lang, theme, regions: await history.locator('.qp-history-summary').evaluate(element => [...element.querySelectorAll('article')].map(article => {
    const plate = article.querySelector('i')!;
    const caption = article.querySelector('small');
    if (caption) {
      const a = plate.getBoundingClientRect(), b = caption.getBoundingClientRect();
      if (Math.min(a.right, b.right) > Math.max(a.left, b.left) && Math.min(a.bottom, b.bottom) > Math.max(a.top, b.top)) throw new Error('History summary plate overlaps factual caption');
    }
    return Object.fromEntries([['article', article], ['plate', plate], ['label', article.querySelector('span')!], ['caption', caption]].map(([name, node]) => {
      if (!(node instanceof Element)) return [name, null];
      const { x, y, width, height, bottom } = node.getBoundingClientRect();
      return [name, { x, y, width, height, bottom }];
    }));
  })) });
  await region.focus(); await page.keyboard.press('End'); await page.waitForTimeout(300);
  assert.ok(await region.evaluate(element => element.scrollTop > 0), 'History region did not scroll with keyboard');
  const last = region.locator('tbody tr').last().getByRole('button');
  await last.focus(); await page.keyboard.press('Enter'); await page.getByRole('dialog').waitFor();
  assert.ok((await page.locator('#history-detail-title').innerText()).includes(await last.innerText()));
  await page.keyboard.press('Escape'); await page.getByRole('dialog').waitFor({ state: 'hidden' });
  assert.equal(await last.evaluate(element => element === document.activeElement), true);
  await region.evaluate(element => { element.scrollTop = 0; element.scrollLeft = 0; });
  await last.evaluate(element => element.blur()); await page.evaluate(() => scrollTo(0, 0));
  historyDensityChecks.push({ lang, theme, bottom, ...geometry, keyboardScrolled: true });
}
async function checkProviders(page: Page, lang: string, theme: string, pending: Set<Request>) {
  await page.setViewportSize({ width: 1672, height: 941 });
  await page.evaluate(() => window.scrollTo(0, 0));
  const bottom = await page.locator('.qp-provider-bottom').evaluate(element => element.getBoundingClientRect().bottom);
  const geometry = await page.evaluate(() => ({ scrollY, documentHeight: document.documentElement.scrollHeight, viewport: { width: innerWidth, height: innerHeight }, cards: Array.from(document.querySelectorAll<HTMLElement>('.qp-provider-card')).map(element => ({ title: element.querySelector('.qp-provider-card-head button')?.textContent, hasQuota: element.dataset.hasQuota, top: element.getBoundingClientRect().top, bottom: element.getBoundingClientRect().bottom, height: element.getBoundingClientRect().height })), gridColumns: getComputedStyle(document.querySelector('.qp-provider-grid')!).gridTemplateColumns, panels: ['.qp-provider-header', '.qp-provider-grid', '.qp-provider-inspector', '.qp-provider-bottom'].map(selector => { const element = document.querySelector<HTMLElement>(selector); const rect = element?.getBoundingClientRect(); return { selector, exists: !!element, top: rect?.top, bottom: rect?.bottom, height: rect?.height, open: element instanceof HTMLDetailsElement ? element.open : undefined }; }) }));
  assert.ok(bottom <= 941, `Provider comparison/reader panels exceed viewport: ${JSON.stringify(geometry)}`);
  referenceDetailRegions.push({ page: 'providers', lang, theme, regions: geometry });
  const result = await daemon.inject({ method: 'GET', url: '/api/overview', headers: { 'x-quotapulse-token': 'stable-capture-test' } });
  assert.equal(result.statusCode, 200);
  const data = result.json<Overview>();
  const expectedVendors = [...data.subscriptions.map(subscription => subscription.provider), ...data.sourceStatus.filter(source => source.account_key === null).map(source => source.vendor ?? 'unknown')].sort();
  const actualVendors = await page.locator('.qp-provider-card').evaluateAll(elements => elements.map(element => element.getAttribute('data-vendor') ?? 'unknown').sort());
  assert.deepEqual(actualVendors, expectedVendors, 'Provider card tint selector must use the card\'s actual vendor metadata');
  const latest = [1, 2].map(source => data.limits.filter(reading => reading.source_id === source && reading.window_kind === 'monthly').sort((a, b) => b.last_seen_at - a.last_seen_at)[0]);
  const rows = page.locator('.qp-provider-comparison li'); assert.equal(await rows.count(), 2);
  const visibleWindows = page.locator('.qp-provider-card .qp-provider-windows>div');
  assert.equal(await visibleWindows.count(), 5, 'Provider cards show every published quota window');
  assert.deepEqual(await visibleWindows.evaluateAll(elements => elements.map(element => element.getAttribute('data-window-kind')).sort()), ['5h', 'daily', 'monthly', 'monthly', 'weekly']);
  for (const [index, reading] of latest.entries()) {
    const bar = rows.nth(index).locator('.qp-bar');
    assert.equal(await bar.evaluate(element => element.style.getPropertyValue('--qp-quota-used')), `${reading.used_percent}%`);
    const heights = await bar.evaluate(element => ({ outer: element.getBoundingClientRect().height, inner: element.firstElementChild!.getBoundingClientRect().height }));
    assert.ok(Math.abs(heights.inner / heights.outer * 100 - reading.used_percent!) < 0.02);
    assert.ok((await rows.nth(index).locator('strong').textContent())!.includes(String(reading.used_percent)));
    const valueBox = await rows.nth(index).locator('strong').boundingBox();
    const barBox = await bar.boundingBox(); const nameBox = await rows.nth(index).locator('button').boundingBox();
    assert.ok(valueBox && barBox && nameBox && valueBox.y + valueBox.height <= barBox.y + barBox.height - heights.inner + 1 && nameBox.y >= barBox.y + barBox.height, 'Percent must sit above the observed bar and owner below its plot');
  }
  const last = rows.last().locator('button'); const owner = await last.locator('.qp-provider-comparison-name').textContent();
  await last.focus(); await page.keyboard.press('Enter');
  assert.equal(await last.getAttribute('aria-pressed'), 'true');
  assert.ok((await page.locator('.qp-provider-detail h2').textContent())!.includes(owner!));
  assert.equal(await page.locator('.qp-provider-inspector').getAttribute('open'), '');
  assert.equal(await page.locator('.qp-provider-detail').isVisible(), true);
  assert.equal(await page.locator('.qp-provider-detail-windows>div').count(), 2, 'The owner inspector retains every quota window');
  await page.locator('.qp-provider-comparison select').selectOption('weekly');
  assert.equal(await visibleWindows.count(), 5, 'Changing the comparison window does not hide card quota rows');
  assert.equal(await page.locator('.qp-provider-detail-windows>div').count(), 2, 'Changing the comparison window does not hide owner detail');
  await page.locator('.qp-provider-comparison select').selectOption('monthly');
  const inspectorToggle = page.locator('.qp-provider-inspector>summary');
  await inspectorToggle.focus(); await page.keyboard.press('Enter');
  assert.equal(await page.locator('.qp-provider-detail').isVisible(), false);
  await inspectorToggle.focus(); await page.keyboard.press('Enter');
  assert.equal(await page.locator('.qp-provider-detail').isVisible(), true);
  for (const width of [390, 900, 1280]) {
    await page.setViewportSize({ width, height: 941 });
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `Provider horizontal overflow at ${lang}/${theme}/${width}px`);
  }
  const pattern = '**/api/overview';
  for (const state of ['unknown', 'expired', 'tiny'] as const) {
    const fixture = structuredClone(data);
    for (const reading of fixture.limits) {
      if (state === 'unknown') reading.used_percent = null;
      else if (state === 'expired') reading.resets_at = fixedNow - 1;
      else reading.used_percent = reading.source_id === 1 ? 0.5 : 0;
    }
    await page.route(pattern, route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(fixture) }));
    try {
      await page.setViewportSize({ width: 1672, height: 941 });
      await page.goto(`http://127.0.0.1:7804/?provider-check=${state}#providers`, { waitUntil: 'domcontentloaded' });
      await page.locator('.qp-provider-health').waitFor(); await settled(page, pending);
      if (state !== 'tiny') { assert.equal(await page.locator('.qp-provider-comparison li').count(), 0); assert.equal(await page.locator('.qp-provider-comparison-chart').count(), 0); }
      else {
        const heights = await page.locator('.qp-provider-comparison li .qp-bar').evaluateAll(elements => elements.map(element => element.firstElementChild!.getBoundingClientRect().height));
        assert.equal(heights.length, 2); assert.ok(heights[0] > 0 && heights[0] < 1); assert.equal(heights[1], 0);
      }
    } finally { await page.unroute(pattern); }
  }
  providerChecks.push({ lang, theme, bottom, compared: latest.length, unavailable: true, expired: true, proportional: true });
}

async function checkProjectCards(page: Page, lang: string, theme: string, pending: Set<Request>) {
  const month = new Date(fixedNow); month.setDate(1); month.setHours(0, 0, 0, 0);
  const query = new URLSearchParams({ detailed: '1', trends: '1', from: String(month.getTime()), to: String(fixedNow + 1) });
  const result = await daemon.inject({ method: 'GET', url: `/api/projects?${query}`, headers: { 'x-quotapulse-token': 'stable-capture-test' } });
  assert.equal(result.statusCode, 200);
  const data = result.json<DetailedProjectResponse>();
  const cards = page.locator('.qp-project-card');
  assert.equal(await cards.count(), 5);
  referenceDetailRegions.push({ page: 'projects', lang, theme, regions: await page.locator('.qp-project-layout').evaluate(element => Object.fromEntries(['.qp-project-card', '.qp-project-card .qp-project-icon', '.qp-project-card-identity>strong', '.qp-project-detail', '.qp-project-detail .qp-project-icon', '.qp-project-detail h2', '.qp-project-trend-panel', '.qp-project-rail'].map(selector => {
    const node = element.querySelector(selector)!; const { x, y, width, height, bottom } = node.getBoundingClientRect();
    return [selector, { x, y, width, height, bottom }];
  }))) });
  const bottom = await page.locator('.qp-project-cards').evaluate(element => element.getBoundingClientRect().bottom);
  const trendPanel = await page.locator('.qp-project-trend-panel').evaluate(element => {
    const panel = element.getBoundingClientRect();
    return { x: panel.x, width: panel.width, enclosed: Array.from(element.querySelectorAll('h3,svg,.qp-chart-access,.qp-footnote')).every(child => { const r = child.getBoundingClientRect(); return r.left >= panel.left && r.right <= panel.right + .1 && r.top >= panel.top && r.bottom <= panel.bottom + .1; }) };
  });
  assert.ok(Math.abs(trendPanel.x - 1137) <= 2 && Math.abs(trendPanel.width - 503) <= 2, `Project trend enclosure differs from original source horizontal geometry: ${JSON.stringify(trendPanel)}`);
  assert.ok(trendPanel.enclosed, 'Actual trend, scale, chart-data action and pricing coverage must stay inside the project trend enclosure');
  const sourceTopCards = await page.locator('.qp-project-card').evaluateAll(elements => elements.slice(0, 2).map(element => {
    const rect = element.getBoundingClientRect(); return { x: rect.x, width: rect.width };
  }));
  const sourceCardEstimates = [{ x: 243, width: 465 }, { x: 716, width: 396 }];
  assert.equal(sourceTopCards.length, sourceCardEstimates.length);
  for (const [index, card] of sourceTopCards.entries()) {
    assert.ok(Math.abs(card.x - sourceCardEstimates[index]!.x) <= 6 && Math.abs(card.width - sourceCardEstimates[index]!.width) <= 6,
      `Project card ${index + 1} differs from the reference top row: ${JSON.stringify(card)}`);
  }
  assert.ok(bottom <= 941, `Project card region exceeds canonical viewport: ${bottom}`);
  const railBottom = await page.locator('.qp-project-rail').evaluate(element => element.getBoundingClientRect().bottom);
  assert.ok(railBottom <= 941, `Project ranking rail exceeds canonical viewport: ${railBottom}`);
  const money = new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US', { style: 'currency', currency: 'USD' });
  const tonesByProject = new Map<string, string>();
  for (const group of data.groups) {
    const card = cards.filter({ has: page.locator('.qp-project-card-identity>strong', { hasText: group.key! }) });
    assert.equal(await card.count(), 1);
    tonesByProject.set(JSON.stringify(group.key), (await card.getAttribute('data-tone'))!);
    assert.equal(await card.evaluate(element => element.querySelector('.qp-project-card-facts')!.getBoundingClientRect().bottom <= element.getBoundingClientRect().bottom - 1), true, 'Project facts are clipped by the card');
    const actual = await card.locator('.qp-project-spark>circle').evaluateAll(elements => elements.map(element => ({ at: Number(element.getAttribute('data-at')), value: Number(element.getAttribute('data-value')) })));
    const expected = Array.from({ length: Math.ceil((data.scope.to - data.scope.from) / data.trends!.bucketMs) }, (_, index) => {
      const at = data.scope.from + index * data.trends!.bucketMs;
      return { at, value: data.trends!.points.find(point => point.project === group.key && point.start === at)?.tokens ?? 0 };
    });
    assert.deepEqual(actual, expected);
    assert.equal(actual.reduce((sum, point) => sum + point.value, 0), group.tokens);
    const values = card.locator('.qp-project-card-money>span');
    for (const [index, amount, priced] of [[0, group.reported_native_usd, group.native_calls], [1, group.api_value_usd, group.computed_calls + group.estimated_calls]]) {
      const expected = priced === 0 ? (lang === 'th' ? 'ไม่ทราบ' : 'Unknown') : `${money.format(amount)}${priced < group.calls ? '+' : ''}`;
      assert.equal(await values.nth(index).locator('.qp-cost-value>span:first-child').textContent(), expected);
      assert.ok((await values.nth(index).locator('.qp-cost-value').getAttribute('title'))!.includes(`${priced} / ${group.calls}`));
    }
  }
  assert.ok(data.groups.some(group => group.native_calls === 0));
  assert.ok(data.groups.some(group => group.native_calls > 0 && group.native_calls < group.calls));
  const sortSelect = page.locator('.qp-project-toolbar select').last();
  await sortSelect.selectOption('recent'); await settled(page, pending);
  for (const group of data.groups) {
    const card = cards.filter({ has: page.locator('.qp-project-card-identity>strong', { hasText: group.key! }) });
    assert.equal(await card.getAttribute('data-tone'), tonesByProject.get(JSON.stringify(group.key)), 'Project identity tint changed when sorting cards');
  }
  await sortSelect.selectOption('tokens'); await settled(page, pending);
  // Keyboard selection must keep the existing detail/identity behavior.
  const last = cards.last(); const identity = await last.locator('.qp-project-card-identity>strong').textContent(); const lastTone = await last.getAttribute('data-tone');
  await last.focus(); await page.keyboard.press('Enter'); await settled(page, pending);
  const lastBounds = await last.boundingBox(); const regionBounds = await page.locator('.qp-project-cards').boundingBox();
  assert.ok(lastBounds && regionBounds && lastBounds.y >= regionBounds.y && lastBounds.y + lastBounds.height <= regionBounds.y + regionBounds.height + 1, 'Final project card is not keyboard reachable');
  assert.equal(await last.getAttribute('aria-pressed'), 'true');
  assert.ok((await page.locator('.qp-project-detail h2').textContent())!.includes(identity!));
  assert.equal(await page.locator('.qp-project-detail').getAttribute('data-tone'), lastTone, 'Selected project detail tint must match its card');
  await page.locator('.qp-project-search input').fill('no-such-synthetic-project');
  assert.equal(await cards.count(), 0);
  await page.locator('.qp-project-search input').fill('');
  const first = cards.filter({ has: page.locator('.qp-project-card-identity>strong', { hasText: 'QuotaPulse' }) });
  await first.click(); await settled(page, pending);
  const selectedRows = data.rows.filter(row => row.project === 'QuotaPulse');
  const panels = page.locator('.qp-project-identity-panel');
  assert.equal(await panels.count(), 2);
  assert.equal(await panels.nth(0).locator('li').count(), new Set(selectedRows.map(row => row.harness).filter(Boolean)).size);
  assert.equal(await panels.nth(1).locator('li').count(), new Set(selectedRows.map(row => row.provider).filter(Boolean)).size);
  const messages = lang === 'th' ? th : en;
  await page.getByRole('button', { name: messages['redesign.projectMetadataTab'], exact: true }).click();
  await settled(page, pending);
  assert.equal(await page.locator('.qp-project-full-breakdown li').count(), selectedRows.length);
  const actualBreakdown = await page.locator('.qp-project-full-breakdown li strong').allTextContents();
  const formatter = new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US', { maximumFractionDigits: 0 });
  assert.deepEqual(actualBreakdown, selectedRows.map(row => formatter.format(row.tokens)));
  await page.getByRole('button', { name: messages['redesign.projectOverviewTab'], exact: true }).click();
  await settled(page, pending);
  await first.evaluate(element => (element as HTMLElement).blur()); await page.evaluate(() => window.scrollTo(0, 0));
  projectCardChecks.push({ lang, theme, cards: data.groups.length, bottom, unknownNative: data.groups.filter(group => group.native_calls === 0).length, stableIdentityTones: true, sourceTopCards });
}

async function settled(page: Page, pending: Set<Request>) {
  const deadline = performance.now() + 30_000;
  let idle = 0;
  while (idle < 12) {
    if (performance.now() >= deadline) {
      const waiting = [...pending].map(request => {
        const url = new URL(request.url()), origin = requestOrigins.get(request);
        return { method: request.method(), path: url.pathname, queryKeys: [...url.searchParams.keys()],
          routeAtStart: origin?.route, ageMs: origin ? Math.round(performance.now() - origin.started) : null,
          failure: request.failure()?.errorText ?? null };
      });
      assert.fail(`API requests did not settle: ${JSON.stringify(waiting)}`);
    }
    idle = pending.size === 0 ? idle + 1 : 0;
    await page.waitForTimeout(25);
  }
  await page.evaluate(async () => {
    await document.fonts.load('14px "Noto Sans Thai"', 'ไทย');
    await document.fonts.ready;
  });
  // Native form controls/compositor paints can outlive the last HTTP request.
  await page.waitForTimeout(1_000);
}

async function openRuntimeMapOptions(page: Page) {
  const disclosure = page.locator('.qp-runtime-options');
  if (await disclosure.getAttribute('open') === null) {
    await page.locator('.qp-runtime-options>summary').focus();
    await page.keyboard.press('Enter');
  }
  await page.locator('.qp-runtime-options[open]').waitFor();
}

async function closeRuntimeMapOptions(page: Page) {
  const disclosure = page.locator('.qp-runtime-options');
  if (await disclosure.getAttribute('open') !== null) {
    await page.locator('.qp-runtime-options>summary').focus();
    await page.keyboard.press('Enter');
  }
  await page.locator('.qp-runtime-options:not([open])').waitFor();
}

async function comparePixels(page: Page, first: Buffer, second: Buffer) {
  return page.evaluate(async ({ first, second }) => {
    // Inline decoding avoids tsx's nested-function __name helper in page context.
    const firstImage = new Image(); firstImage.src = `data:image/png;base64,${first}`;
    const secondImage = new Image(); secondImage.src = `data:image/png;base64,${second}`;
    await Promise.all([firstImage.decode(), secondImage.decode()]);
    const firstCanvas = new OffscreenCanvas(firstImage.width, firstImage.height);
    const secondCanvas = new OffscreenCanvas(secondImage.width, secondImage.height);
    const firstContext = firstCanvas.getContext('2d')!; firstContext.drawImage(firstImage, 0, 0);
    const secondContext = secondCanvas.getContext('2d')!; secondContext.drawImage(secondImage, 0, 0);
    const a = { width: firstImage.width, height: firstImage.height, pixels: firstContext.getImageData(0, 0, firstImage.width, firstImage.height).data };
    const b = { width: secondImage.width, height: secondImage.height, pixels: secondContext.getImageData(0, 0, secondImage.width, secondImage.height).data };
    if (a.width !== b.width || a.height !== b.height) throw new Error('Capture dimensions differ');
    let changedPixels = 0; let maxChannelDelta = 0;
    for (let index = 0; index < a.pixels.length; index += 4) {
      let changed = false;
      for (let channel = 0; channel < 4; channel++) {
        const delta = Math.abs(a.pixels[index + channel] - b.pixels[index + channel]);
        maxChannelDelta = Math.max(maxChannelDelta, delta); changed ||= delta !== 0;
      }
      if (changed) {
        changedPixels++;
      }
    }
    return { changedPixels, maxChannelDelta, pixelCount: a.width * a.height };
  }, { first: first.toString('base64'), second: second.toString('base64') });
}

// WCAG relative luminance. Check computed CSS colors, rather than antialiased glyphs.
const rgb = (color: string) => color.startsWith('#') ? (color.length === 4 ? color.slice(1).split('').map(value => value + value).join('') : color.slice(1)).match(/../g)!.map(value => parseInt(value, 16)) : color.match(/[\d.]+/g)!.slice(0, 3).map(Number);
const luminance = (color: string) => rgb(color).map(value => value / 255).map(value => value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4).reduce((sum, value, index) => sum + value * [0.2126, 0.7152, 0.0722][index], 0);
const contrast = (foreground: string, background: string) => (Math.max(luminance(foreground), luminance(background)) + 0.05) / (Math.min(luminance(foreground), luminance(background)) + 0.05);
assert.deepEqual(rgb('#fff'), rgb('rgb(255, 255, 255)'));
assert.equal(contrast('#000', '#fff'), 21);
async function semanticContrast(page: Page) {
  const result = await page.evaluate(() => {
    const root = document.querySelector('.qp-redesign')!; const style = getComputedStyle(root);
    const colors = Object.fromEntries(['danger', 'warning', 'series', 'success', 'muted'].map(role => [role, style.getPropertyValue(`--qp-${role}`).trim()]));
    const backgrounds = [style.backgroundColor, style.getPropertyValue('--qp-panel').trim(), style.backgroundImage.match(/rgb\([^)]+\)/)![0]];
    const samples = [['danger', '.qp-alert-level[data-level=critical]'], ['warning', '.qp-alert-level[data-level=warning]'], ['series', '.qp-cost-chart-labels>span:nth-child(2)'], ['success', '.qp-daemon-badge[data-state=live]'], ['muted', '.qp-chart-scale>span']].flatMap(([role, selector]) => {
      const element = root.querySelector(selector); return element ? [{ role, selector, color: getComputedStyle(element).color }] : [];
    });
    return { colors, backgrounds, samples };
  });
  const semanticContrasts = Object.entries(result.colors).map(([role, color]) => ({ role, color, minimumRatio: Math.min(...result.backgrounds.map(background => contrast(color, background))) }));
  for (const item of semanticContrasts) assert.ok(item.minimumRatio >= 4.5, `${item.role}: insufficient text contrast (${item.minimumRatio})`);
  for (const sample of result.samples) assert.deepEqual(rgb(sample.color), rgb(result.colors[sample.role]), `${sample.selector}: semantic color was overridden`);
  return { semanticContrasts, checkedElements: result.samples.map(sample => sample.selector) };
}

async function checkChartAccess(page: Page, destination: 'live' | 'projects', lang: string, theme: string, pending: Set<Request>) {
  const headers = { 'x-quotapulse-token': 'stable-capture-test' };
  if (destination === 'live') {
    const result = await daemon.inject({ method: 'GET', url: `/api/trend?bucket=minute&group_by=none&from=${fixedNow - 1_800_000}&to=${fixedNow + 1}`, headers });
    assert.equal(result.statusCode, 200);
    const trend = result.json<MinuteTrendResponse>();
    const flowEvidence = await checkLiveTokenFlow(page, trend, lang, theme, pending, output);
    chartChecks.push({ page: destination, lang, theme, buckets: Math.floor((trend.to - 1) / 60000) - Math.floor(trend.from / 60000) + 1, tokens: trend.rows.reduce((sum, row) => sum + row.total_tokens, 0), flowEvidence });
    return;
  }
  const month = new Date(fixedNow); month.setDate(1); month.setHours(0, 0, 0, 0);
  const query = new URLSearchParams({ from: String(month.getTime()), to: String(fixedNow + 1), project: 'QuotaPulse' });
  const result = await daemon.inject({ method: 'GET', url: `/api/project-detail?${query}&limit=20&offset=0`, headers });
  assert.equal(result.statusCode, 200);
  const detail = result.json<ProjectDetailResponse>();
  const expected = Array.from({ length: Math.ceil((detail.scope.to - detail.scope.from) / detail.bucketMs) }, (_, index) => ({ at: detail.scope.from + index * detail.bucketMs, tokens: detail.points.find(point => point.start === detail.scope.from + index * detail.bucketMs)?.tokens ?? 0 }));
  const disclosure = page.locator('.qp-chart-data'); const summary = disclosure.locator('summary');
  await summary.focus(); await page.keyboard.press('Enter');
  assert.equal(await disclosure.getAttribute('open'), '');
  assert.equal(await disclosure.locator('table').isVisible(), true);
  const rows = await disclosure.locator('tbody tr').evaluateAll(elements => elements.map(element => ({ at: Number(element.getAttribute('data-at')), tokens: Number(element.getAttribute('data-value')), text: element.querySelector('td:last-child')!.textContent, stamp: element.querySelector('td:first-child')!.textContent, iso: element.querySelector('time')!.getAttribute('datetime') })));
  assert.deepEqual(rows.map(({ at, tokens }) => ({ at, tokens })), expected);
  const format = new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US');
  for (const row of rows) { assert.equal(row.text, format.format(row.tokens)); assert.equal(row.iso, new Date(row.at).toISOString()); assert.equal(row.stamp, new Date(row.at).toLocaleString(lang === 'th' ? 'th-TH' : 'en-US')); }
  const maximum = Math.max(0, ...expected.map(point => point.tokens));
  assert.ok(expected.some(point => point.tokens === 1) && expected.some(point => point.tokens === 0), 'Tiny and zero bucket regression fixtures must be present');
  const points = await page.locator('.qp-project-trend>circle').evaluateAll(elements => elements.map(element => ({ at: Number(element.getAttribute('data-at')), tokens: Number(element.getAttribute('data-value')), cy: Number(element.getAttribute('cy')) })));
  assert.deepEqual(points.map(({ at, tokens }) => ({ at, tokens })), expected);
  points.forEach((point, index) => assert.ok(Math.abs(point.cy - (94 - 88 * expected[index].tokens / (maximum || 1))) < 0.0001, 'Project line point is not proportional to the API value'));
  for (const width of [390, 900, 1280]) {
    await page.setViewportSize({ width, height: 941 });
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `${destination}: expanded data table overflows at ${width}`);
  }
  await summary.focus(); await page.keyboard.press('Enter'); assert.equal(await disclosure.getAttribute('open'), null);
  chartChecks.push({ page: destination, lang, theme, buckets: expected.length, tokens: expected.reduce((sum, point) => sum + point.tokens, 0) });
}

async function checkModelCostAccess(page: Page, destination: 'models' | 'cost', lang: string, theme: string, pending: Set<Request>) {
  const routes = destination === 'models'
    ? ['models?metric=tokens', 'models?metric=calls', 'models?metric=api_value_usd']
    : ['cost?basis=api&range=month', 'cost?basis=native&range=month&bucket=week', 'cost?basis=native&range=month&source=2'];
  const locale = lang === 'th' ? 'th-TH' : 'en-US';
  const number = new Intl.NumberFormat(locale);
  const money = new Intl.NumberFormat(locale, { style: 'currency', currency: 'USD' });
  for (const route of routes) {
    await page.setViewportSize({ width: 1672, height: 941 });
    const responsePromise = page.waitForResponse(response => response.url().includes(destination === 'models' ? '/api/model-detail?' : '/api/cost-analysis?') && response.status() === 200);
    await page.goto(`http://127.0.0.1:7804/?chart-access=${encodeURIComponent(route)}#${route}`, { waitUntil: 'domcontentloaded' });
    const response = await responsePromise;
    // Query the daemon independently using the precise scope/identity requested by the UI.
    const result = await daemon.inject({ method: 'GET', url: new URL(response.url()).pathname + new URL(response.url()).search, headers: { 'x-quotapulse-token': 'stable-capture-test' } });
    assert.equal(result.statusCode, 200);
    const data = result.json<ModelDetailResponse | CostAnalysisResponse>();
    await page.locator('.qp-chart-data').waitFor(); await settled(page, pending);
    const collapsedBottom = await page.locator(destination === 'models' ? '.qp-model-detail' : '.qp-cost-layout').evaluate(element => element.getBoundingClientRect().bottom);
    if (destination === 'cost' && collapsedBottom >= 941) console.log('Cost overflow geometry', await page.locator('.qp-cost-top,.qp-cost-summary,.qp-cost-trend,.qp-cost-models,.qp-cost-projects,.qp-cost-sessions,.qp-cost-insights').evaluateAll(elements => elements.map(element => ({ className: element.className, top: element.getBoundingClientRect().top, height: element.getBoundingClientRect().height }))));
    assert.ok(collapsedBottom < 941, `${route}: collapsed detail outside viewport (${collapsedBottom})`);
    if (destination === 'cost') {
      const cost = data as CostAnalysisResponse;
      // Independently sampled dot centers in refs/cost.png; these represent identity, not rank.
      const sourcePalette = new Map([['openai', '#177af6'], ['anthropic', '#7a3cf6'], ['google', '#01bcf5'], ['deepseek', '#f78c3f']]);
      const pricedProviders = cost.providers.filter(row => row.pricedCalls > 0);
      const legendColors = await page.locator('.qp-cost-providers ol>li>i').evaluateAll(nodes => nodes.map(node => getComputedStyle(node).backgroundColor));
      assert.deepEqual(legendColors.map(rgb), pricedProviders.map(row => rgb(sourcePalette.get(row.provider?.toLowerCase() ?? '') ?? '#7d8ba0')), 'Cost legend colors must follow source provider identities regardless of actual rank');
      const positiveProviders = cost.providers.filter(row => row.pricedCalls > 0 && row.amount > 0);
      const edgeShares = await page.locator('.qp-cost-donut-edge:not(.qp-cost-donut-inner-edge)').evaluateAll(nodes => nodes.map(node => Number(node.getAttribute('stroke-dasharray')?.split(' ')[0])));
      assert.deepEqual(edgeShares, cost.totals.amount > 0 ? positiveProviders.map(row => row.amount / cost.totals.amount) : [], 'Decorative Cost edges must retain actual provider amount fractions');
      const edgeColors = await page.locator('.qp-cost-donut-edge:not(.qp-cost-donut-inner-edge)').evaluateAll(nodes => nodes.map(node => getComputedStyle(node).color));
      // Original sector rims are brighter than their independently sampled legend dots.
      const sourceRims = new Map([['openai', '#2ad1fb'], ['anthropic', '#a35ffa'], ['google', '#00bfed'], ['deepseek', '#f89840']]);
      assert.deepEqual(edgeColors.map(rgb), cost.totals.amount > 0 ? positiveProviders.map(row => rgb(sourceRims.get(row.provider?.toLowerCase() ?? '') ?? '#75879d')) : [], 'Cost ring rims must follow independently sampled source colors in actual provider order');
      assert.equal(await page.locator('.qp-cost-donut-seam').count(), cost.totals.amount > 0 && positiveProviders.length > 1 ? positiveProviders.length : 0, 'Zero or single-provider cost must not invent sector boundaries');
      const expectedBucket = route.includes('bucket=week') ? 'week' : 'day';
      assert.equal(cost.bucket, expectedBucket, `${route}: response bucket must match the selected interval`);
      assert.equal(cost.bucketMs, expectedBucket === 'week' ? 7 * 86_400_000 : 86_400_000);
      assert.equal(await page.locator('.qp-cost-toolbar select').nth(2).inputValue(), expectedBucket, `${route}: interval selection must match API aggregation`);
      if (route === 'cost?basis=api&range=month') {
        const monthStart = new Date(fixedNow); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);
        assert.equal(await page.locator('.qp-cost-toolbar select').first().inputValue(), 'month', 'Explicit month Cost route must select month-to-date');
        assert.equal(cost.scope.from, monthStart.getTime(), 'Month Cost API request must begin at local month start');
        assert.equal(cost.scope.to, fixedNow + 1, 'Month Cost API request must end at the current instant');
        const unitValue = await page.locator('.qp-cost-summary article:nth-child(4)>strong').innerText();
        const prefs = await page.evaluate(() => JSON.parse(localStorage.getItem('quotapulse-prefs') ?? '{}') as { currency?: string; rate?: number });
        const currency = prefs.currency === 'THB' ? 'THB' : 'USD';
        const rate = currency === 'THB' && Number.isFinite(prefs.rate) && prefs.rate! > 0 ? prefs.rate! : 1;
        const expectedUnitValue = new Intl.NumberFormat(locale, { style: 'currency', currency, maximumFractionDigits: 6 })
          .format(cost.totals.amount / cost.totals.pricedTokens * 1000 * rate);
        assert.equal(unitValue, expectedUnitValue, 'Per-1K cost must retain meaningful precision for fractional-unit values');
      }
      const maxAmount = Math.max(0, ...cost.points.map(point => point.amount));
      const maxTokens = Math.max(0, ...cost.points.map(point => point.pricedTokens));
      if (cost.totals.pricedCalls > 0) {
        for (const [axis, maximum] of [['amount', maxAmount], ['tokens', maxTokens]] as const) {
          const ticks = page.locator(`.qp-cost-axis[data-axis=${axis}]>span`);
          assert.equal(await ticks.count(), 5);
          assert.deepEqual(await ticks.evaluateAll(elements => elements.map(element => Number(element.getAttribute('data-value')))), [1, 0.75, 0.5, 0.25, 0].map(fraction => fraction * maximum));
          if (axis === 'amount') assert.deepEqual(await ticks.allTextContents(), [1, 0.75, 0.5, 0.25, 0].map(fraction => money.format(fraction * maximum)));
        }
        const times = page.locator('.qp-cost-plot-dates time');
        assert.equal(await times.nth(0).getAttribute('datetime'), new Date(cost.scope.from).toISOString());
        assert.equal(await times.nth(1).getAttribute('datetime'), new Date(cost.scope.to).toISOString());
        assert.equal(await times.nth(0).textContent(), new Date(cost.scope.from).toLocaleString(locale, { dateStyle: 'short', timeStyle: 'short' }));
        const heights = await page.locator('.qp-cost-column').evaluateAll(elements => elements.map(element => parseFloat((element as HTMLElement).style.height)));
        const points = Array.from({ length: Math.ceil((cost.scope.to - cost.scope.from) / cost.bucketMs) }, (_, index) => cost.points.find(point => point.start === cost.scope.from + index * cost.bucketMs)?.amount ?? 0);
        assert.equal(heights.length, points.length);
        heights.forEach((height, index) => assert.ok(Math.abs(height - points[index] / (maxAmount || 1) * 100) < 0.0001));
        const tokenPoints = await page.locator('.qp-cost-token-line>circle').evaluateAll(elements => elements.map(element => ({ at: Number(element.getAttribute('data-at')), value: Number(element.getAttribute('data-value')), x: Number(element.getAttribute('cx')), y: Number(element.getAttribute('cy')) })));
        const expectedTokens = points.map((_, index) => { const at = cost.scope.from + index * cost.bucketMs; return { at, value: cost.points.find(point => point.start === at)?.pricedTokens ?? 0 }; });
        assert.deepEqual(tokenPoints.map(({ at, value }) => ({ at, value })), expectedTokens);
        tokenPoints.forEach((point, index) => {
          assert.ok(Math.abs(point.y - (100 - 100 * point.value / (maxTokens || 1))) < 0.0001, 'Token line does not match its own axis');
          assert.ok(Math.abs(point.x - 1000 * (index + 0.5) / tokenPoints.length) < 0.0001, 'Token point is not centered on its bucket');
        });
      } else assert.equal(await page.locator('.qp-cost-plot').count(), 0, 'Unpriced scope must not show a monetary plot/axis');
      for (const [selector, groups] of [['.qp-cost-models', cost.models], ['.qp-cost-projects', cost.projects]] as const) {
        const expected = groups.filter(group => group.pricedCalls > 0).slice(0, 8);
        const bars = await page.locator(`${selector} .qp-cost-share b`).evaluateAll(elements => elements.map(element => parseFloat((element as HTMLElement).style.width)));
        assert.equal(bars.length, expected.length);
        bars.forEach((width, index) => assert.ok(Math.abs(width - (cost.totals.amount > 0 ? expected[index].amount / cost.totals.amount * 100 : 0)) < 0.0001, 'Share bar differs from recorded amount fraction'));
      }
      if (cost.sessions.length > 0) {
        const table = page.locator('.qp-cost-sessions .qp-cost-table');
        assert.equal(await table.locator('tbody tr').count(), cost.sessions.length);
        await table.focus(); await page.keyboard.press('End');
        const last = table.locator('tbody tr:last-child a');
        await last.focus(); await page.keyboard.press('Tab'); await page.keyboard.press('Shift+Tab');
        assert.equal(await last.evaluate(element => element === document.activeElement), true, 'Last session link is not keyboard reachable');
        assert.equal(await last.evaluate(element => { const row = element.getBoundingClientRect(); const scroll = element.closest('.qp-cost-table')!.getBoundingClientRect(); return row.top >= scroll.top && row.bottom <= scroll.bottom; }), true, 'Last session is hidden by its table viewport');
      }
      costAxisChecks.push({ route, lang, theme, priced: cost.totals.pricedCalls > 0, maxAmount, maxTokens });
    }
    const disclosure = page.locator('.qp-chart-data'); const summary = disclosure.locator('summary');
    await summary.focus(); await page.keyboard.press('Enter');
    assert.equal(await disclosure.getAttribute('open'), '');
    const starts = Array.from({ length: Math.ceil((data.scope.to - data.scope.from) / data.bucketMs) }, (_, index) => data.scope.from + index * data.bucketMs);
    const rows = disclosure.locator('tbody tr'); assert.equal(await rows.count(), starts.length);
    const calls = route.includes('metric=calls');
    const values: number[] = [];
    for (const [index, start] of starts.entries()) {
      const row = rows.nth(index);
      assert.equal(await row.getAttribute('data-at'), String(start));
      assert.equal(await row.locator('time').getAttribute('datetime'), new Date(start).toISOString());
      assert.equal(await row.locator('time').textContent(), new Date(start).toLocaleString(locale));
      if (destination === 'models') {
        const point = (data as ModelDetailResponse).points.find(point => point.start === start);
        const value = (calls ? point?.calls : point?.tokens) ?? 0; values.push(value);
        assert.equal(await row.getAttribute('data-value'), String(value));
        assert.equal(await row.locator('td').nth(1).textContent(), number.format(value));
      } else {
        const point = (data as CostAnalysisResponse).points.find(point => point.start === start) ?? { amount: 0, pricedTokens: 0, pricedCalls: 0, allCalls: 0 };
        for (const [attribute, value] of Object.entries({ amount: point.amount, 'priced-tokens': point.pricedTokens, 'priced-calls': point.pricedCalls, 'all-calls': point.allCalls })) assert.equal(await row.getAttribute(`data-${attribute}`), String(value));
        const expected = point.allCalls === 0 ? money.format(0) : point.pricedCalls === 0 ? (lang === 'th' ? 'ไม่ทราบ' : 'Unknown') : money.format(point.amount) + (point.pricedCalls < point.allCalls ? '+' : '');
        assert.equal(await row.locator('.qp-cost-value>span').first().textContent(), expected);
        assert.equal(await row.locator('td').nth(2).textContent(), number.format(point.pricedTokens));
        assert.equal(await row.locator('td').nth(3).textContent(), `${number.format(point.pricedCalls)} / ${number.format(point.allCalls)} ${lang === 'th' ? 'คำขอ' : 'Calls'}`);
      }
    }
    if (destination === 'models') {
      assert.ok(values.includes(0), 'Zero model buckets must remain zero');
      if (!route.includes('api_value_usd')) assert.ok(values.includes(1), 'Tiny model bucket fixture is missing');
      const points = await page.locator('.qp-model-trend>circle').evaluateAll(elements => elements.map(element => ({ at: Number(element.getAttribute('data-at')), value: Number(element.getAttribute('data-value')), cy: Number(element.getAttribute('cy')) })));
      const maximum = Math.max(0, ...values);
      assert.deepEqual(points.map(point => point.at), starts);
      assert.deepEqual(points.map(point => point.value), values);
      points.forEach((point, index) => assert.ok(Math.abs(point.cy - (94 - 88 * values[index] / (maximum || 1))) < 0.0001));
      const header = await disclosure.locator('th').nth(1).textContent();
      assert.equal(header, lang === 'th' ? (calls ? 'คำขอ' : 'โทเค็นที่บันทึก') : (calls ? 'Calls' : 'Recorded tokens'));
    } else {
      const cost = data as CostAnalysisResponse;
      assert.equal(await disclosure.getAttribute('data-basis'), cost.basis);
      if (route.includes('source=2')) {
        assert.ok(cost.totals.allCalls > 0); assert.equal(cost.totals.pricedCalls, 0);
      } else if (cost.basis === 'api') {
        assert.ok(cost.points.some(point => point.pricedCalls > 0 && point.amount === 0), 'Known-zero price bucket fixture is missing');
        assert.ok(cost.points.some(point => point.pricedCalls > 0 && point.pricedCalls < point.allCalls), 'Partial price bucket fixture is missing');
      } else assert.ok(cost.points.some(point => point.allCalls > 0 && point.pricedCalls === 0), 'Unknown native bucket fixture is missing');
    }
    for (const width of [390, 900, 1280]) {
      await page.setViewportSize({ width, height: 941 });
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `${route}: expanded table overflow at ${width}`);
    }
    await summary.focus(); await page.keyboard.press('Enter'); assert.equal(await disclosure.getAttribute('open'), null);
    modelCostChecks.push({ route, lang, theme, buckets: starts.length, collapsedBottom });
  }
}

async function checkFontAccess(page: Page, destination: string, lang: string, theme: string) {
  const cdp = await page.context().newCDPSession(page);
  try {
    await cdp.send('DOM.enable'); await cdp.send('CSS.enable');
    const { root } = await cdp.send('DOM.getDocument');
    const selector = lang === 'th' ? '.qp-sidebar nav a span' : '.qp-tools button:last-child';
    const { nodeId } = await cdp.send('DOM.querySelector', { nodeId: root.nodeId, selector });
    const { fonts } = await cdp.send('CSS.getPlatformFontsForNode', { nodeId });
    const thai = fonts.find(font => font.familyName === 'Noto Sans Thai');
    assert.ok(thai && thai.isCustomFont && thai.glyphCount > 0, `${destination}/${lang}/${theme}: Thai glyphs did not use the bundled custom font`);
    assert.ok(fonts.every(font => font.isCustomFont), 'Selected Thai label must not fall back to system fonts');
    fontChecks.push({ page: destination, lang, theme, family: thai.familyName, custom: thai.isCustomFont, glyphs: thai.glyphCount });
  } finally { await cdp.detach(); }
}

async function checkShellAccess(page: Page, destination: string, lang: string, theme: string) {
  const originalViewport = page.viewportSize()!;
  const scopedPage = ['overview', 'live', 'projects', 'models', 'cost', 'history'].includes(destination);
  const monthStart = new Date(fixedNow); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);
  const from = destination === 'live' ? fixedNow - 30 * 60_000 : destination === 'history' ? fixedNow - 30 * 86_400_000 : monthStart.getTime();
  const statsQuery = scopedPage ? `?from=${from}&to=${fixedNow + 1}` : '';
  const statsResponse = await daemon.inject({ method: 'GET', url: `/api/runtime-summary${statsQuery}`, headers: { 'x-quotapulse-token': 'stable-capture-test' } });
  assert.equal(statsResponse.statusCode, 200);
  const stats = statsResponse.json<Record<string, number>>();
  const overviewResponse = await daemon.inject({ method: 'GET', url: '/api/overview', headers: { 'x-quotapulse-token': 'stable-capture-test' } });
  assert.equal(overviewResponse.statusCode, 200);
  const overview = overviewResponse.json<Overview>();
  const expectedAlertCount = activeQuotaRiskCount(overview);
  await page.waitForFunction(expected => {
    const badge = document.querySelector<HTMLElement>('.qp-nav-count');
    return expected > 0 ? badge?.textContent === (expected > 99 ? '99+' : String(expected)) : badge === null;
  }, expectedAlertCount, { timeout: 15_000 });
  const alertsLink = page.locator('.qp-sidebar nav a[href="#alerts"]');
  const expectedAlertLabel = lang === 'th' ? th['redesign.currentQuotaRisks'] : en['redesign.currentQuotaRisks'];
  const formattedAlertCount = new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US').format(expectedAlertCount);
  if (destination === 'alerts') {
    const pageRiskCount = page.locator('[data-summary="redesign.alertCurrent"] strong');
    await pageRiskCount.waitFor({ state: 'visible', timeout: 15_000 });
    assert.equal(await pageRiskCount.textContent(), formattedAlertCount, 'Alerts page summary and sidebar badge must share the same live risk count');
  }
  if (expectedAlertCount > 0) {
    assert.equal(await alertsLink.getAttribute('aria-label'), `${lang === 'th' ? th['redesign.alerts'] : en['redesign.alerts']} · ${expectedAlertLabel}: ${formattedAlertCount}`);
    assert.equal(await alertsLink.getAttribute('data-alert-count'), expectedAlertCount > 99 ? '99+' : String(expectedAlertCount));
    assert.equal(await alertsLink.locator('.qp-nav-count').getAttribute('aria-hidden'), 'true');
  } else {
    assert.equal(await alertsLink.getAttribute('data-alert-count'), null);
  }
  const statsCard = page.locator('.qp-quick-stats');
  assert.equal(await statsCard.getAttribute('aria-describedby'), 'qp-quick-stats-note');
  assert.equal(await statsCard.locator('h2').textContent(), 'Quick Stats');
  assert.equal(await statsCard.locator('p').count(), 0, 'Workspace scope is already shown in the header');
  assert.equal(await page.locator('.qp-sidebar nav a[href="#models"] > span').textContent(), lang === 'th' ? 'โมเดล' : 'Models');
  const moreMenu = page.locator('.qp-nav-more');
  const moreSummary = moreMenu.locator(':scope > summary');
  assert.equal(await moreSummary.isVisible(), true, `${destination}: OVR-001 requires More on every screen`);
  const moreWasOpen = await moreMenu.evaluate(element => (element as HTMLDetailsElement).open);
  if (!moreWasOpen) await moreSummary.click();
  for (const href of ['#overview', '#live', '#projects', '#models', '#history', '#alerts', '#providers', '#cost?range=month', '#settings']) {
    assert.equal(await page.locator(`.qp-sidebar nav a[href="${href}"]`).isVisible(), true, `${destination}: global destination ${href} must be reachable`);
  }
  if (!moreWasOpen) await moreSummary.click();
  const statsNote = await statsCard.locator('#qp-quick-stats-note').boundingBox();
  assert.ok(statsNote && statsNote.width === 1 && statsNote.height === 1, 'The session-count caveat remains available to assistive technology without extending the reference card');
  const recentSessionLink = statsCard.locator('[data-stat=recentSessions]').locator('..').locator('dt a');
  const quickSessionsLabel = lang === 'th' ? th['redesign.quickSessions'] : en['redesign.quickSessions'];
  const noteKey = scopedPage ? 'redesign.quickStatsScopedNote' : 'redesign.quickStatsNote';
  const quickStatsNote = lang === 'th' ? th[noteKey] : en[noteKey];
  assert.equal(await recentSessionLink.locator('span').textContent(), quickSessionsLabel);
  assert.equal(await recentSessionLink.getAttribute('title'), quickStatsNote, 'Active-session label must disclose its observation window and limitation');
  for (const key of ['namedProjects', 'models', 'providers', 'recentSessions']) {
    const value = statsCard.locator(`[data-stat=${key}]`);
    assert.equal(await value.textContent(), new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US').format(stats[key]));
    const label = value.locator('..').locator('dt a>span');
    const valueBox = await value.boundingBox(); const labelBox = await label.boundingBox();
    assert.ok(valueBox && labelBox && valueBox.y + valueBox.height <= labelBox.y, 'Quick-stat count is not above its label');
  }
  assert.equal(await page.locator('.qp-sidebar-brand').count(), 1);
  for (const width of [originalViewport.width, 390, 900, 1280]) {
    await page.setViewportSize({ width, height: originalViewport.height });
    const header = await page.locator('.qp-topbar').boundingBox();
    const brand = await page.locator('.qp-topbar .qp-brand').boundingBox();
    const sidebar = await page.locator('.qp-sidebar').boundingBox();
    assert.ok(header && brand && sidebar);
    assert.equal(header.x, 0); assert.equal(header.width, width); assert.equal(header.height, 60);
    assert.equal(brand.x, 0);
    const overviewReferenceWidth = destination === 'overview' && width > 1500;
    const expectedSidebar = overviewReferenceWidth ? 211 : width <= 500 ? 48 : width <= 1100 ? 66 : width <= 1600 ? 216 : 226;
    const expectedBrand = overviewReferenceWidth ? 252 : width <= 1100 ? expectedSidebar : Math.max(253, Math.min(267, width * .16));
    assert.ok(Math.abs(brand.width - expectedBrand) < .02);
    assert.equal(sidebar.width, expectedSidebar);
    if (expectedAlertCount > 0) {
      const alertLinkBox = await alertsLink.boundingBox();
      const alertBadgeBox = await alertsLink.locator('.qp-nav-count').boundingBox();
      assert.ok(alertLinkBox && alertBadgeBox);
      assert.ok(alertBadgeBox.x >= alertLinkBox.x && alertBadgeBox.x + alertBadgeBox.width <= alertLinkBox.x + alertLinkBox.width,
        `Quota-risk badge escaped the Alerts link at ${width}px`);
      assert.ok(alertBadgeBox.y >= alertLinkBox.y && alertBadgeBox.y + alertBadgeBox.height <= alertLinkBox.y + alertLinkBox.height,
        `Quota-risk badge escaped the Alerts link vertically at ${width}px`);
    }
    let dateText: string | null = null;
    if (width > 1100) {
      const mark = await page.locator('.qp-topbar .qp-brand>svg').boundingBox();
      const wordmark = await page.locator('.qp-topbar .qp-brand>span').boundingBox();
      assert.ok(mark && wordmark);
      assert.equal(mark.width, 42); assert.equal(mark.height, 42);
      assert.equal(mark.x, 20);
      const brandRightGap = overviewReferenceWidth ? 2 : 8;
      assert.ok(wordmark.x + wordmark.width <= brand.x + brand.width - brandRightGap,
        `Brand text must fit its source-sized header column: ${JSON.stringify({ brand, mark, wordmark })}`);
      const status = page.locator('.qp-daemon-badge');
      const state = await status.getAttribute('data-state');
      assert.equal(state, 'live');
      assert.equal(await status.getAttribute('role'), 'status');
      assert.equal(await status.getAttribute('aria-label'), lang === 'th' ? 'การเชื่อมต่อ daemon: กำลังอัปเดต' : 'Daemon connection: live');
      assert.equal(await page.locator('.qp-daemon-caption').textContent(), lang === 'th' ? th['redesign.daemonConnected'] : en['redesign.daemonConnected']);
      assert.equal(await page.locator('.qp-workspace-label').textContent(), lang === 'th' ? 'พื้นที่ทำงาน' : 'Workspace');
      assert.equal((await page.locator('.qp-machine-scope').innerText()).trim(), lang === 'th' ? 'เครื่องนี้' : 'This machine');
      if (destination === 'overview' && width >= 1500) {
        const workspace = await Promise.all(['.qp-workspace-label', '.qp-machine-scope'].map(async selector => page.locator(selector).evaluate(element => {
          const rect = element.getBoundingClientRect();
          return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
        })));
        const [label, scope] = workspace;
        const expectedLabelX = lang === 'en' ? 518 : label.x;
        const expectedScopeX = lang === 'en' ? 619 : label.x + label.width + 43;
        assert.ok(Math.abs(label.x - expectedLabelX) <= 4 && Math.abs(scope.x - expectedScopeX) <= 4 && Math.abs(scope.width - 170) <= 2,
          `Workspace header differs from measured reference bounds: ${JSON.stringify({ label, scope })}`);
        assert.ok(Math.abs((label.y + label.height / 2) - (scope.y + scope.height / 2)) <= 1,
          `Workspace label and scope should share a horizontal baseline: ${JSON.stringify({ label, scope })}`);
        workspaceChecks.push({ page: destination, lang, theme, label, scope });
      }
      assert.equal(await page.locator('.qp-topbar button[aria-haspopup=dialog]').getAttribute('aria-label'), lang === 'th' ? 'ค้นหาทุกอย่าง...' : 'Search anything...');
      assert.deepEqual(await page.locator('.qp-tools button').evaluateAll(elements => elements.map(element => element.getAttribute('aria-label'))), lang === 'th' ? ['เปลี่ยนธีมสี', 'เปลี่ยนภาษา'] : ['Switch color theme', 'Switch language']);
      assert.equal(await page.locator('.qp-tools button:last-child').innerText(), lang === 'th' ? 'EN' : 'ไทย');
      if (width > 1400) {
        dateText = await page.locator('.qp-header-clock time').first().textContent();
        const expectedDate = lang === 'en' ? 'Sat, May 17, 2025' : await page.evaluate(now => new Intl.DateTimeFormat('th-TH', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric', timeZone: 'Asia/Bangkok' }).format(now), fixedNow);
        assert.equal(dateText, expectedDate, 'Review clock date must match the source concept capture');
        assert.deepEqual(await page.locator('.qp-header-clock time').evaluateAll(elements => elements.map(element => element.getAttribute('datetime'))), [new Date(fixedNow).toISOString(), new Date(fixedNow).toISOString()]);
        const clock = await page.locator('.qp-header-clock time').last().textContent();
        assert.equal(clock, new Intl.DateTimeFormat(lang === 'th' ? 'th-TH' : 'en-US', { hour: '2-digit', minute: '2-digit', hourCycle: 'h23', timeZone: 'Asia/Bangkok' }).format(fixedNow));
      }
    }
    const navigation = page.locator('.qp-sidebar nav');
    assert.equal(await navigation.locator('a').count(), 9);
    assert.equal(await navigation.locator(':scope > a').count(), 6, 'Six concept routes must remain in the primary sidebar');
    assert.equal(await navigation.locator('.qp-nav-more > a').count(), 3, 'Additional routes must remain available in More');
    assert.equal(await navigation.locator('.qp-nav-more').getAttribute('open'), ['providers', 'cost', 'settings'].includes(destination) ? '' : null);
    if (width === 1280) {
      const moreSummary = await navigation.locator('.qp-nav-more > summary').boundingBox();
      assert.ok(moreSummary && moreSummary.height <= 32.1, 'More remains compact ahead of Quick Stats');
    }
    if (destination === 'overview' && width === originalViewport.width && width > 1500) {
      const moreSummary = navigation.locator('.qp-nav-more > summary');
      assert.equal(await moreSummary.isVisible(), true, 'OVR-001 keeps More visible on the Overview desktop');
      const menuCenters = await navigation.locator(':scope > a').evaluateAll(elements => elements.map(element => {
        const box = element.getBoundingClientRect(); return box.y + box.height / 2;
      }));
      const menuSteps = menuCenters.slice(1).map((center, index) => center - menuCenters[index]!);
      assert.equal(menuCenters.length, 6);
      assert.ok(menuSteps.every(step => step >= 39 && step <= 47), `Overview navigation rhythm drifted from the concept: ${JSON.stringify(menuSteps)}`);
      await page.locator('.qp-topbar button[aria-haspopup=dialog]').click();
      const commandDialog = page.locator('.qp-command-dialog[open]');
      await commandDialog.waitFor({ state: 'visible' });
      const commandLabels = await commandDialog.locator('button').allTextContents();
      for (const key of ['redesign.provider', 'redesign.cost', 'redesign.settings'] as const) {
        const label = lang === 'th' ? th[key] : en[key];
        assert.ok(commandLabels.some(value => value.includes(label)), `The command palette must retain ${key} after its sidebar entry is collapsed`);
      }
      await page.keyboard.press('Escape');
      await page.locator('.qp-command-dialog').waitFor({ state: 'hidden' });
      const quickStatsBox = await statsCard.boundingBox();
      assert.ok(quickStatsBox && Math.abs(quickStatsBox.y - 421) <= 1, `Quick Stats must retain its reference-aligned y position: ${JSON.stringify(quickStatsBox)}`);
    }
    assert.equal(await page.locator('.qp-sidebar nav a[aria-current=page]').count(), 1);
    const shellBounds = await page.evaluate(() => {
      const selectors = ['.qp-runtime', '.qp-runtime>.qp-section-heading', '.qp-runtime-controls', '.qp-map-scroll', '.qp-map'];
      return { documentWidth: document.documentElement.scrollWidth, viewportWidth: innerWidth, elements: selectors.map(selector => {
        const element = document.querySelector<HTMLElement>(selector);
        if (!element) return { selector, missing: true };
        const box = element.getBoundingClientRect(), style = getComputedStyle(element);
        return { selector, left: Math.round(box.left), right: Math.round(box.right), width: Math.round(box.width), scrollWidth: element.scrollWidth, minWidth: style.minWidth, overflowX: style.overflowX };
      }) };
    });
    assert.ok(shellBounds.documentWidth <= shellBounds.viewportWidth, `Shell horizontal overflow at ${destination}/${lang}/${theme}/${width}px: ${JSON.stringify(shellBounds)}`);
    const sourceReviewRegions = width > 1100 ? await page.evaluate(() => Object.fromEntries(['.qp-brand>span', '.qp-brand small', '.qp-sidebar nav>a', '.qp-quick-stats h2', '.qp-quick-stats dt a', '.qp-nav-active>svg'].map(selector => {
      const element = document.querySelector(selector)!;
      const { x, y, width, height } = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return [selector, { x, y, width, height, fontSize: style.fontSize, fontWeight: style.fontWeight, color: style.color, filter: style.filter }];
    }))) : undefined;
    headerChecks.push({ page: destination, lang, theme, width, height: header.height, sidebarWidth: sidebar.width, dateText, sourceReviewRegions });
  }
  await page.setViewportSize(originalViewport);
  const originalHash = await page.evaluate(() => location.hash);
  const shell = page.getByTestId(`production-${destination}`);
  assert.equal(await shell.locator('.qp-sidebar nav').getAttribute('aria-label'), lang === 'th' ? 'เมนูหลัก' : 'Main navigation');
  const main = shell.locator('main');
  assert.ok(await main.getAttribute('aria-label'));
  await shell.locator('.qp-skip').focus(); await page.keyboard.press('Enter');
  assert.equal(await main.evaluate(element => element === document.activeElement), true);
  const trigger = shell.locator('.qp-topbar button[aria-haspopup=dialog]');
  await trigger.focus(); await page.keyboard.press('Enter');
  const modal = shell.locator('.qp-command-dialog');
  await modal.waitFor();
  assert.equal(await modal.evaluate(element => element.matches(':modal')), true);
  assert.equal(await trigger.getAttribute('aria-expanded'), 'true');
  const search = modal.getByRole('searchbox');
  assert.ok(await search.getAttribute('aria-label'));
  assert.equal(await search.evaluate(element => element === document.activeElement), true);
  await page.keyboard.press('Shift+Tab');
  assert.equal(await modal.locator('button').last().evaluate(element => element === document.activeElement), true);
  await page.keyboard.press('Tab');
  assert.equal(await search.evaluate(element => element === document.activeElement), true);
  await page.evaluate(() => (document.querySelector('.qp-sidebar a') as HTMLElement).focus());
  assert.equal(await search.evaluate(element => element === document.activeElement), true, 'Background must remain inert');
  const cdp = await page.context().newCDPSession(page);
  try {
    const tree = await cdp.send('Accessibility.getFullAXTree');
    const roles = tree.nodes.filter(node => !node.ignored).map(node => node.role?.value);
    assert.ok(roles.includes('dialog') && roles.includes('searchbox'));
    assert.ok(!roles.includes('main') && !roles.includes('navigation'), 'Modal must exclude background landmarks from the browser accessibility tree');
  } finally { await cdp.detach(); }
  await page.keyboard.press('ArrowDown');
  assert.equal(await modal.getByRole('status').textContent(), lang === 'th' ? 'สด' : 'Live');
  await search.fill('no-such-synthetic-page');
  assert.equal(await modal.locator('button').count(), 1);
  await page.keyboard.press('Enter'); assert.equal(await modal.evaluate(element => element.matches(':modal')), true);
  await page.keyboard.press('Escape'); await modal.waitFor({ state: 'hidden' });
  assert.equal(await trigger.evaluate(element => element === document.activeElement), true);
  assert.equal(await trigger.getAttribute('aria-expanded'), 'false');
  await page.keyboard.press('Control+k'); await modal.waitFor();
  assert.equal(await search.inputValue(), '');
  if (destination === 'overview') {
    for (const width of [390, 900, 1280]) {
      await page.setViewportSize({ width, height: 992 });
      const box = await modal.locator('div').first().boundingBox();
      assert.ok(box && box.x >= 0 && box.x + box.width <= width && box.y + box.height <= 992);
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
      if (width === 390) await page.screenshot({ path: resolve(output, `palette-${lang}-${theme}-390.png`), animations: 'disabled' });
    }
  }
  await page.mouse.click(4, 4); await modal.waitFor({ state: 'hidden' });
  assert.equal(await trigger.evaluate(element => element === document.activeElement), true);
  assert.equal(await page.evaluate(() => location.hash), originalHash);
  if (destination === 'live') {
    const sessions = shell.locator('.qp-live-table tbody tr button');
    assert.ok(await sessions.count() >= 2);
    for (const index of [0, 1, 0]) {
      const target = sessions.nth(index); await target.focus(); await page.keyboard.press('Enter');
      const detail = shell.locator('.qp-live-dialog[open]'); await detail.waitFor();
      assert.equal(await detail.getAttribute('aria-labelledby'), 'qp-live-detail-title');
      assert.ok(await detail.locator('#qp-live-detail-title').textContent());
      assert.equal(await detail.locator('dd').first().textContent(), await target.textContent());
      await page.keyboard.press('Escape'); await detail.waitFor({ state: 'hidden' });
      assert.equal(await target.evaluate(element => element === document.activeElement), true);
    }
  }
  shellChecks.push({ page: destination, lang, theme, modal: true, backgroundExcluded: true });
}

async function checkSettingsAccess(page: Page, lang: string, theme: string) {
  const settings = page.locator('.qp-settings-grid');
  assert.equal(await settings.locator('[data-slot=card]').count(), 6);
  assert.equal(await page.getByTestId('production-settings').locator('h1').count(), 1);
  const originalLanguage = lang === 'en' ? 'English' : 'Thai';
  const alternateLanguage = lang === 'en' ? 'Thai' : 'English';
  assert.equal(await settings.getByRole('button', { name: originalLanguage, exact: true }).getAttribute('aria-pressed'), 'true');
  await settings.getByRole('button', { name: alternateLanguage, exact: true }).click();
  assert.equal(await page.evaluate(() => document.documentElement.lang), lang === 'en' ? 'th' : 'en');
  await settings.getByRole('button', { name: originalLanguage, exact: true }).click();
  await settings.getByRole('button', { name: /THB/ }).click();
  const rate = settings.locator('input[inputmode=decimal]');
  await rate.fill('40'); await rate.press('Enter');
  const preferences = await page.evaluate(() => JSON.parse(localStorage.getItem('quotapulse-prefs')!));
  assert.equal(preferences.currency, 'THB'); assert.equal(preferences.rate, 40);
  assert.equal(await settings.getByRole('button', { name: /THB/ }).getAttribute('aria-pressed'), 'true');
  await settings.getByRole('button', { name: /USD/ }).click();
  assert.equal(await rate.count(), 0);
  assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem('quotapulse-prefs')!).rate), 1);
  for (const width of [390, 900, 1280]) {
    await page.setViewportSize({ width, height: 941 });
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `Settings overflow: ${lang}/${theme}/${width}`);
  }
  await page.setViewportSize({ width: 1672, height: 941 });
  await page.evaluate(() => { (document.activeElement as HTMLElement)?.blur(); scrollTo(0, 0); });
  settingsChecks.push({ lang, theme, sections: 6, language: true, currency: true, rate: 40, widths: [390, 900, 1280] });
}

async function checkRuntimeGeometry(page: Page, graph: RuntimeGraph, lang: string, theme: string, state: string) {
  const copy = lang === 'th' ? th : en;
  const visible = dimensions.map(dimension => new Set(graph.nodes[dimension].slice(0, 8).map(node => node.key)));
  const expected = graph.edges.filter(edge => visible[edge.column].has(edge.from) && visible[edge.column + 1].has(edge.to)).map(edge => JSON.stringify([edge.column, edge.from, edge.to]));
  assert.ok(expected.length > 0, `Connected populated ${state} fixture has no expected visible edges`);
  assert.equal(await page.locator('.qp-runtime-legend').textContent(), copy['redesign.tokenFlow']);
  const expectedEdges = graph.edges.filter(edge => visible[edge.column].has(edge.from) && visible[edge.column + 1].has(edge.to));
  const activityView = await page.locator('.qp-runtime').evaluate(root => ({
    legend: {
      title: root.querySelector('.qp-runtime-activity-legend')?.getAttribute('title'),
      active: root.querySelector('.qp-runtime-activity-legend [data-state=active]')?.textContent,
      idle: root.querySelector('.qp-runtime-activity-legend [data-state=idle]')?.textContent,
    },
    edgeStates: Array.from(root.querySelectorAll<SVGPathElement>('.qp-map-edges>path'), path => path.dataset.activityState),
    nodes: Array.from(root.querySelectorAll<HTMLElement>('.qp-map-node'), node => ({
      dimension: node.dataset.dimension,
      key: node.dataset.key,
      state: node.dataset.activityState ?? null,
      lastActivityAt: node.dataset.lastActivityAt ?? null,
      activeSessions: node.dataset.activeSessions ?? null,
      activityLabel: node.querySelector('[data-testid=runtime-node-activity]')?.textContent ?? null,
    })),
  }));
  assert.deepEqual(activityView.legend, {
    title: copy['redesign.runtimeActivityNote'],
    active: copy['redesign.runtimeActivityActive'],
    idle: copy['redesign.runtimeActivityIdle'],
  });
  assert.deepEqual(activityView.edgeStates, expectedEdges.map(edge => runtimeActivityState(edge.lastActivityAt, graph.now, graph.activityWindowMs)));
  assert.deepEqual(activityView.nodes, dimensions.flatMap(dimension => graph.nodes[dimension].slice(0, 8).map(node => {
    const state = runtimeActivityState(node.lastActivityAt, graph.now, graph.activityWindowMs);
    const label = state === 'active' ? copy['redesign.runtimeActivityActive'] : state === 'idle' ? copy['redesign.runtimeActivityIdle'] : state === 'unknown' && dimension === 'provider' ? copy['redesign.runtimeActivityUnknown'] : null;
    return {
      dimension,
      key: JSON.stringify(node.key),
      state,
      lastActivityAt: node.lastActivityAt === null ? null : String(node.lastActivityAt),
      activeSessions: String(node.activeSessions),
      activityLabel: dimension === 'provider' ? label : null,
    };
  })));
  await page.waitForFunction(expected => {
    const paths = Array.from(document.querySelectorAll<SVGPathElement>('.qp-map-edges>path'));
    if (paths.length !== expected.length) return false;
    const nodes = Array.from(document.querySelectorAll<HTMLElement>('.qp-map-node'));
    const dimensions = ['project', 'harness', 'provider', 'model'];
    return paths.every((path, index) => {
      const column = Number(path.dataset.column);
      if (JSON.stringify([column, JSON.parse(path.dataset.from!), JSON.parse(path.dataset.to!)]) !== expected[index]) return false;
      const from = nodes.find(node => node.dataset.dimension === dimensions[column] && node.dataset.key === path.dataset.from)?.getBoundingClientRect();
      const to = nodes.find(node => node.dataset.dimension === dimensions[column + 1] && node.dataset.key === path.dataset.to)?.getBoundingClientRect();
      const matrix = path.getScreenCTM();
      if (!from || !to || !matrix) return false;
      const start = path.getPointAtLength(0).matrixTransform(matrix), end = path.getPointAtLength(path.getTotalLength()).matrixTransform(matrix);
      return Math.max(Math.abs(start.x - from.right), Math.abs(start.y - from.top - from.height / 2), Math.abs(end.x - to.left), Math.abs(end.y - to.top - to.height / 2)) <= 1;
    });
  }, expected, { timeout: 15_000 });
  const weightedPaths = await page.locator('.qp-map-edges>path').evaluateAll(paths => paths.map(path => ({
    column: Number((path as SVGPathElement).dataset.column),
    tokens: Number((path as SVGPathElement).dataset.tokens),
    width: Number.parseFloat(getComputedStyle(path).strokeWidth),
  })));
  assert.equal(weightedPaths.length, expected.length);
  for (const [index, path] of weightedPaths.entries()) {
    const columnTotal = graph.nodes[dimensions[path.column]!].reduce((total, node) => total + node.tokens, 0);
    const expectedWidth = columnTotal > 0 ? Math.max(1.2, Math.min(4.4, 1.2 + path.tokens / columnTotal * 6)) : 1.2;
    assert.ok(Math.abs(path.width - expectedWidth) < 0.01, `Runtime edge ${index} width must encode its share of recorded token flow (${path.width} != ${expectedWidth})`);
  }
  const maxError = await page.locator('.qp-map-edges>path').evaluateAll(paths => {
    const nodes = Array.from(document.querySelectorAll<HTMLElement>('.qp-map-node'));
    const dimensions = ['project', 'harness', 'provider', 'model'];
    return Math.max(0, ...paths.map(element => {
      const path = element as SVGPathElement, column = Number(path.dataset.column), matrix = path.getScreenCTM()!;
      const from = nodes.find(node => node.dataset.dimension === dimensions[column] && node.dataset.key === path.dataset.from)!.getBoundingClientRect();
      const to = nodes.find(node => node.dataset.dimension === dimensions[column + 1] && node.dataset.key === path.dataset.to)!.getBoundingClientRect();
      const start = path.getPointAtLength(0).matrixTransform(matrix), end = path.getPointAtLength(path.getTotalLength()).matrixTransform(matrix);
      return Math.max(Math.abs(start.x - from.right), Math.abs(start.y - from.top - from.height / 2), Math.abs(end.x - to.left), Math.abs(end.y - to.top - to.height / 2));
    }));
  });
  assert.ok(maxError <= 1);
  runtimeGeometryChecks.push({ lang, theme, state, paths: expected.length, maxError });
}

async function checkRuntimeAccess(page: Page, lang: string, theme: string, pending: Set<Request>) {
  // Owned synthetic rows exist only for this check; default capture data stays fixed.
  try {
    db.prepare("INSERT INTO source(id,harness,profile,root_path,display_name,detected_at) VALUES (900,'codex','runtime-access','/synthetic/nonexistent','Runtime access fixture',?)").run(fixedNow);
    const extra = db.prepare("INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,total_tokens,call_count,cost_usd,cost_source) VALUES (900,?,?,?,?,?,1,1,1,0,'computed')");
    for (let index = 0; index < 11; index++) {
      session.run(900 + index, 900, `runtime-${index}`, index === 9 ? null : index === 10 ? '' : `Runtime extra project ${index}`, fixedNow - 10_000);
      extra.run(900 + index, `runtime-${index}`, fixedNow - 10_000, index === 9 ? null : index === 10 ? '' : `runtime-model-${index}`, index === 9 ? null : index === 10 ? '' : 'runtime-provider');
    }
    await page.setViewportSize({ width: 1586, height: 992 });
    const response = page.waitForResponse(response => new URL(response.url()).pathname === '/api/runtime-map' && response.status() === 200);
    await page.goto('http://127.0.0.1:7804/?runtime-access=full#overview', { waitUntil: 'domcontentloaded' });
    const graph = await (await response).json() as RuntimeGraph;
    await settled(page, pending);
    assert.ok(graph.nodes.project.length > 8 && graph.nodes.model.length > 8);
    await openRuntimeMapOptions(page);
    await page.locator('.qp-runtime-project select').selectOption(''); await settled(page, pending);
    await checkRuntimeGeometry(page, graph, lang, theme, 'desktop-many-nodes');
    const modelTotal = graph.nodes.model.reduce((total, node) => total + node.tokens, 0);
    const modelCards = page.locator('.qp-map-node[data-dimension=model]');
    assert.equal(await modelCards.count(), 8);
    const shareFormat = new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US', { maximumFractionDigits: 1 });
    for (let index = 0; index < 8; index++) {
      const node = graph.nodes.model[index], card = modelCards.nth(index), share = node.tokens / modelTotal * 100;
      assert.equal(await card.getAttribute('data-tokens'), String(node.tokens));
      assert.equal(await card.getAttribute('data-total'), String(modelTotal));
      assert.equal(await card.locator('.qp-node-share small').textContent(), `${shareFormat.format(share)}%`);
      const width = await card.locator('.qp-node-track>span').evaluate(element => Number.parseFloat((element as HTMLElement).style.width));
      assert.ok(Math.abs(width - share) < 0.0001);
      assert.ok((await card.getAttribute('aria-label'))?.includes(`${shareFormat.format(share)}%`));
    }
    const sessionNumber = new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US');
    for (const dimension of ['project', 'harness', 'provider'] as const) {
      const visible = graph.nodes[dimension].slice(0, 8), cards = page.locator(`.qp-map-node[data-dimension=${dimension}]`);
      assert.equal(await cards.count(), visible.length);
      for (const [index, node] of visible.entries()) {
        const card = cards.nth(index);
        assert.equal(await card.getAttribute('data-sessions'), String(node.sessions));
        if (dimension !== 'provider') {
          const activeDimension = dimension === 'project' || dimension === 'harness';
          const value = activeDimension ? node.activeSessions : node.sessions;
          const label = activeDimension ? (lang === 'th' ? 'เซสชันที่ใช้งานล่าสุด' : 'active sessions') : (lang === 'th' ? 'เซสชัน' : 'sessions');
          assert.equal(await card.locator('[data-testid=runtime-node-sessions]').textContent(), `${sessionNumber.format(value)} ${label}`);
        }
      }
    }
    assert.equal(await page.locator('.qp-map-node[data-dimension=harness][data-runtime-name=codex] .qp-node-label-main').textContent(), 'Codex CLI');
    assert.equal(await page.locator('.qp-map-node[data-dimension=provider][data-runtime-name=runtime-provider] .qp-node-label-main').textContent(), 'runtime-provider');
    assert.deepEqual(await page.locator('.qp-map-column h3').evaluateAll(elements => elements.map(element => element.textContent?.trim())), [lang === 'th' ? 'โปรเจกต์' : 'Project', lang === 'th' ? 'ฮาร์เนส' : 'Harness', lang === 'th' ? 'ผู้ให้บริการ' : 'Provider', lang === 'th' ? 'โมเดล' : 'Model']);
    if (graph.nodes.project.length === 1) assert.deepEqual(await page.locator('.qp-map-column[data-dimension=project] h3 span').evaluate(element => { const rect = element.getBoundingClientRect(); return { width: rect.width, height: rect.height }; }), { width: 1, height: 1 });
    const paths = page.locator('.qp-map-edges>path');
    assert.ok(await paths.count() > 0);
    for (const path of await paths.all()) {
      const marker = await path.getAttribute('marker-end');
      assert.ok(marker?.startsWith('url(#'));
      assert.equal(await page.locator('.qp-map-edges marker').getAttribute('orient'), 'auto');
    }
    const visibleKeys = dimensions.map(dimension => new Set(graph.nodes[dimension].slice(0, 8).map(node => JSON.stringify(node.key))));
    const expectedFlowEdges = dimensions.slice(0, 3).flatMap((_, column) => graph.edges
      .filter(edge => edge.column === column && visibleKeys[column].has(JSON.stringify(edge.from)) && visibleKeys[column + 1].has(JSON.stringify(edge.to)))
      .sort((a, b) => b.tokens - a.tokens || JSON.stringify([a.from, a.to]).localeCompare(JSON.stringify([b.from, b.to])))
      .slice(0, 2)
      .map(edge => ({ column: String(edge.column), from: JSON.stringify(edge.from), to: JSON.stringify(edge.to), tokens: String(edge.tokens) })));
    const flowEdges = await page.locator('.qp-map-flow-dot').evaluateAll(elements => elements.map(element => ({ column: element.getAttribute('data-column'), from: element.getAttribute('data-from'), to: element.getAttribute('data-to'), tokens: element.getAttribute('data-tokens') })));
    assert.deepEqual(flowEdges, expectedFlowEdges);
    assert.equal(await page.locator('.qp-map-flow-dot animateMotion').count(), 0, 'Reduced motion must keep flow particles static');
    await page.emulateMedia({ reducedMotion: 'no-preference' });
    const flowDot = page.locator('.qp-map-flow-dot').first();
    const map = page.locator('.qp-map');
    const originalTransform = await map.evaluate(element => (element as HTMLElement).style.transform);
    try {
      await flowDot.locator('animateMotion').waitFor({ state: 'attached' });
      const position = () => flowDot.evaluate(element => {
        const circle = element as SVGCircleElement;
        const point = new DOMPoint(circle.cx.baseVal.value, circle.cy.baseVal.value).matrixTransform(circle.getScreenCTM()!);
        return { x: point.x, y: point.y };
      });
      const before = await position();
      await page.waitForTimeout(400);
      const after = await position();
      assert.ok(Math.hypot(after.x - before.x, after.y - before.y) > 2, 'Active flow particle must travel along its recorded edge');
      await map.evaluate(element => { (element as HTMLElement).style.transform = 'translateY(2000px)'; });
      await page.waitForFunction(() => document.querySelectorAll('.qp-map-flow-dot animateMotion').length === 0);
      await map.evaluate((element, transform) => { (element as HTMLElement).style.transform = transform; }, originalTransform);
      await flowDot.locator('animateMotion').waitFor({ state: 'attached' });
    } finally {
      await map.evaluate((element, transform) => { (element as HTMLElement).style.transform = transform; }, originalTransform);
      await page.emulateMedia({ reducedMotion: 'reduce' });
      await page.waitForFunction(() => document.querySelectorAll('.qp-map-flow-dot animateMotion').length === 0);
    }
    const disclosure = page.locator('.qp-runtime-data'); const summary = disclosure.locator('summary');
    assert.equal(await disclosure.locator('table').count(), 0);
    await summary.focus(); await page.keyboard.press('Enter');
    await disclosure.locator('.qp-runtime-nodes').waitFor();
    assert.equal(await disclosure.locator('caption').count(), 2);
    assert.equal(await disclosure.locator('th[scope=col]').count(), 10);
    const number = new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US');
    const expected = dimensions.flatMap(dimension => graph.nodes[dimension].map(node => ({ identity: JSON.stringify([dimension, node.key]), tokens: String(node.tokens), records: String(node.records), sessions: String(node.sessions), values: [node.tokens, node.records, node.sessions].map(value => number.format(value)) })));
    const rows = await disclosure.locator('.qp-runtime-nodes tbody tr').evaluateAll(elements => elements.map(element => ({ identity: element.getAttribute('data-identity'), tokens: element.getAttribute('data-tokens'), records: element.getAttribute('data-records'), sessions: element.getAttribute('data-sessions'), values: Array.from(element.querySelectorAll('td')).slice(2).map(cell => cell.textContent) })));
    assert.deepEqual(rows, expected);
    const edges = await disclosure.locator('.qp-runtime-edges tbody tr').evaluateAll(elements => elements.map(element => ({ identity: element.getAttribute('data-identity'), tokens: element.getAttribute('data-tokens'), value: element.querySelector('td:last-child')?.textContent })));
    assert.deepEqual(edges, graph.edges.map(edge => ({ identity: JSON.stringify([edge.column, edge.from, edge.to]), tokens: String(edge.tokens), value: number.format(edge.tokens) })));
    for (const column of [0, 1, 2]) assert.equal(graph.edges.filter(edge => edge.column === column).reduce((sum, edge) => sum + edge.tokens, 0), graph.totals.tokens);
    let inspected = 0;
    for (const [dimension, key] of [['model', 'runtime-model-8'], ['project', null], ['project', ''], ['model', null], ['model', '']] as const) {
      const button = disclosure.locator('.qp-runtime-nodes tbody tr').filter({ has: page.locator('button') });
      const index = expected.findIndex(node => node.identity === JSON.stringify([dimension, key]));
      const target = button.nth(index).locator('button');
      await target.focus(); await page.keyboard.press('Enter');
      const dialog = page.locator('.qp-dialog[open]'); await dialog.waitFor();
      assert.equal(await dialog.locator('h2').textContent(), await target.textContent());
      const node = graph.nodes[dimension].find(node => node.key === key)!;
      assert.deepEqual(await dialog.locator('.qp-detail-grid strong').allTextContents(), [node.tokens, node.sessions, node.callRecords, node.aggregateRecords].map(value => number.format(value)));
      await page.keyboard.press('Escape'); await dialog.waitFor({ state: 'hidden' });
      assert.equal(await target.evaluate(element => element === document.activeElement), true);
      inspected++;
    }
    await page.screenshot({ path: resolve(output, `runtime-expanded-${lang}-${theme}.png`), animations: 'disabled', fullPage: true });
    for (const width of [390, 900, 1280]) {
      await page.setViewportSize({ width, height: 992 });
      const overflow = await page.evaluate(() => ({ scrollWidth: document.documentElement.scrollWidth, viewport: innerWidth,
        layout: Array.from(document.querySelectorAll<HTMLElement>('.qp-runtime-options,.qp-runtime-options-panel,.qp-runtime-heading-main,.qp-map-scroll,.qp-map')).map(element => {
          const rect = element.getBoundingClientRect();
          return { className: element.className, left: Math.round(rect.left), right: Math.round(rect.right), width: Math.round(rect.width), scrollWidth: element.scrollWidth };
        }),
        elements: Array.from(document.querySelectorAll<HTMLElement>('*')).flatMap(element => {
          const rect = element.getBoundingClientRect();
          return rect.width && (rect.left < -1 || rect.right > innerWidth + 1)
            ? [{ tag: element.tagName, className: String(element.className), left: Math.round(rect.left), right: Math.round(rect.right), width: Math.round(rect.width) }]
            : [];
        }).sort((a, b) => b.right - a.right).slice(0, 8) }));
      assert.equal(overflow.scrollWidth <= overflow.viewport, true, `Runtime overflow at ${width}: ${JSON.stringify(overflow)}`);
      await checkRuntimeGeometry(page, graph, lang, theme, `resize-${width}`);
      await page.locator('.qp-map-scroll').evaluate(element => { element.scrollLeft = element.scrollWidth; element.scrollTop = element.scrollHeight; });
      assert.ok(await page.locator('.qp-map-scroll').evaluate(element => element.scrollLeft > 0 || element.scrollTop > 0), `Runtime scroll did not move at ${width}`);
      await checkRuntimeGeometry(page, graph, lang, theme, `scroll-${width}`);
      await page.locator('.qp-map-scroll').evaluate(element => { element.scrollLeft = 0; element.scrollTop = 0; });
    }
    await summary.focus(); await page.keyboard.press('Enter');
    await disclosure.locator('table').first().waitFor({ state: 'detached' });
    runtimeChecks.push({ lang, theme, nodes: rows.length, edges: edges.length, inspected, modelShares: 8, directionArrows: true, nativeMotion: true });
  } finally {
    db.transaction(() => { db.prepare('DELETE FROM usage_event WHERE source_id=900').run(); db.prepare('DELETE FROM session WHERE source_id=900').run(); db.prepare('DELETE FROM source WHERE id=900').run(); })();
    assert.equal((db.prepare('SELECT COUNT(*) AS count FROM usage_event').get() as { count: number }).count, 43);
  }
}

async function checkSingleProjectRuntime(page: Page, lang: string, theme: string, pending: Set<Request>) {
  const saved = db.prepare('SELECT id,project FROM session ORDER BY id').all() as Array<{ id: number; project: string | null }>;
  try {
    db.prepare('UPDATE session SET project=?').run('Single project fixture');
    await page.setViewportSize({ width: 1586, height: 992 });
    const response = page.waitForResponse(response => new URL(response.url()).pathname === '/api/runtime-map' && response.status() === 200);
    await page.goto('http://127.0.0.1:7804/?runtime-layout=single#overview', { waitUntil: 'domcontentloaded' });
    const graph = await (await response).json() as RuntimeGraph;
    await settled(page, pending);
    assert.equal(graph.nodes.project.length, 1);
    assert.equal(await page.locator('.qp-map').getAttribute('data-single-project'), 'true');
    const project = page.locator('.qp-map-node[data-dimension=project]');
    assert.equal((await project.boundingBox())!.height, 80);
    const projectLabel = await project.evaluate(element => element.getAttribute('aria-label'));
    const projectActiveSessionLabel = new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US').format(graph.nodes.project[0].activeSessions);
    assert.ok(projectLabel?.includes(projectActiveSessionLabel), `Single-project node aria-label omits its active-session count (${projectLabel})`);
    await checkRuntimeGeometry(page, graph, lang, theme, 'single-project');
    await project.focus(); await page.keyboard.press('Enter');
    const detail = page.locator('.qp-dialog'); await detail.waitFor({ state: 'visible', timeout: 10_000 });
    assert.equal(await detail.getAttribute('open'), '');
    assert.equal(await detail.getAttribute('aria-labelledby'), 'qp-detail-title');
    assert.equal(await page.locator('#qp-detail-title').textContent(), 'Single project fixture');
    await page.keyboard.press('Escape'); await detail.waitFor({ state: 'hidden', timeout: 10_000 });
    assert.equal(await project.evaluate(element => element === document.activeElement), true);
    await page.screenshot({ path: resolve(output, `runtime-single-${lang}-${theme}.png`), animations: 'disabled' });
    // Replace the visible graph on the same React page, exercising observer cleanup.
    const updateRoute = (hash: string) => page.evaluate(hash => { location.hash = hash; }, hash);
    await updateRoute('#overview?range=custom&from=1&to=2'); await settled(page, pending);
    await page.waitForFunction(() => document.querySelector('.qp-runtime') && !document.querySelector('.qp-map'));
    assert.equal(await page.locator('.qp-map-edges>path').count(), 0);
    runtimeGeometryChecks.push({ lang, theme, state: 'empty-replacement', paths: 0, maxError: 0 });
    await updateRoute('#overview?range=today'); await settled(page, pending);
    await checkRuntimeGeometry(page, graph, lang, theme, 'single-restored');
  } finally {
    db.transaction(() => { const restore = db.prepare('UPDATE session SET project=? WHERE id=?'); for (const row of saved) restore.run(row.project, row.id); })();
  }
}

async function checkModelMarks(page: Page, lang: string, theme: string, pending: Set<Request>) {
  const saved = db.prepare('SELECT id,model FROM usage_event ORDER BY id').all() as Array<{ id: number; model: string | null }>;
  const replacements = [
    ['DeepSeek V4.1', 'deepseek-v4-fixture', 'deepseek'],
    ['GPT-5.x', 'openai/gpt-5-fixture', 'openai'],
    ['Claude 3.7', 'claude-3.7-fixture', 'anthropic'],
    ['Claude 3.5', 'claude-3.5-fixture', 'anthropic'],
  ] as const;
  const day = new Date(fixedNow); day.setHours(0, 0, 0, 0);
  const url = `/api/runtime-map?from=${day.getTime()}&to=${fixedNow + 1}`;
  const headers = { 'x-quotapulse-token': 'stable-capture-test' };
  const baseline = (await daemon.inject({ url, headers })).json<RuntimeGraph>();
  const pattern = '**/api/runtime-map?*';
  let routed = false;
  try {
    db.transaction(() => {
      const update = db.prepare('UPDATE usage_event SET model=? WHERE model=?');
      for (const [prior, name] of replacements) update.run(name, prior);
    })();
    const graph = (await daemon.inject({ url, headers })).json<RuntimeGraph>();
    assert.deepEqual(graph.totals, baseline.totals, 'Maker metadata must not alter usage totals');
    for (const [, name, vendor] of replacements) assert.equal(graph.nodes.model.find(node => node.key === name)?.vendor, vendor);
    assert.equal(graph.nodes.model.filter(node => !node.vendor).length, 1);
    for (const column of [0, 1, 2]) assert.equal(graph.edges.filter(edge => edge.column === column).reduce((sum, edge) => sum + edge.tokens, 0), graph.totals.tokens);
    await page.setViewportSize({ width: 1586, height: 992 });
    await page.goto('http://127.0.0.1:7804/?model-marks=known#overview', { waitUntil: 'domcontentloaded' });
    await settled(page, pending);
    await openRuntimeMapOptions(page);
    await page.locator('.qp-runtime-project select').selectOption(''); await settled(page, pending);
    const hero = page.locator('.qp-model-row'), runtime = page.locator('.qp-map-node[data-dimension=model]');
    const displayedModels = graph.nodes.model.slice(0, 5);
    assert.equal(await hero.count(), displayedModels.length);
    assert.equal(await runtime.count(), graph.nodes.model.length);
    for (const [index, node] of graph.nodes.model.entries()) {
      assert.equal(await runtime.nth(index).getAttribute('data-key'), JSON.stringify(node.key));
      assert.equal(await runtime.nth(index).getAttribute('data-tokens'), String(node.tokens));
      const icons = [[runtime.nth(index).locator('.qp-node-icon'), 15]] as const;
      for (const [icon, size] of index < displayedModels.length
        ? [[hero.nth(index).locator('.qp-model-identity i'), 18] as const, ...icons]
        : icons) {
        assert.equal(await icon.getAttribute('data-model-vendor'), node.vendor ?? null);
        assert.equal(await icon.getAttribute('aria-hidden'), 'true');
        if (!node.vendor) { assert.equal(await icon.locator('svg.lucide-box').count(), 1); continue; }
        assert.equal(await icon.locator('svg.lucide-box').count(), 0);
        const mark = icon.locator('.qp-model-mark');
        const box = (await mark.boundingBox())!;
        assert.equal(box.width, size); assert.equal(box.height, size);
        const vectors = await mark.locator('svg').evaluateAll(elements => elements.filter(element => element.getBoundingClientRect().width > 0).map(element => {
          const rect = element.getBoundingClientRect();
          return { x: rect.x, y: rect.y, width: rect.width, height: rect.height, hidden: element.getAttribute('aria-hidden'), focusable: element.getAttribute('focusable'), paths: element.querySelectorAll('path').length };
        }));
        assert.equal(vectors.length, 1); assert.ok(vectors[0].paths > 0);
        assert.equal(vectors[0].hidden, 'true'); assert.equal(vectors[0].focusable, 'false');
        assert.ok(vectors[0].x >= box.x - .1 && vectors[0].y >= box.y - .1 && vectors[0].x + vectors[0].width <= box.x + size + .1 && vectors[0].y + vectors[0].height <= box.y + size + .1, `${node.vendor} maker artwork exceeds its frame`);
      }
    }
    await checkRuntimeGeometry(page, graph, lang, theme, 'known-model-makers');
    await page.screenshot({ path: resolve(output, `model-marks-${lang}-${theme}.png`), animations: 'disabled' });
    const selected = displayedModels.findIndex(node => node.vendor === 'openai');
    const target = hero.nth(selected);
    await target.focus(); await page.keyboard.press('Enter'); await page.getByRole('dialog').waitFor();
    assert.equal(await page.locator('#qp-detail-title').textContent(), graph.nodes.model[selected].key);
    await page.keyboard.press('Escape'); await page.getByRole('dialog').waitFor({ state: 'hidden' });
    assert.equal(await target.evaluate(element => element === document.activeElement), true);
    // An older daemon may omit the additive maker field. Keep its real totals and names.
    const legacy = { ...graph, nodes: { ...graph.nodes, model: graph.nodes.model.map(({ vendor: _vendor, ...node }) => node) } };
    await page.route(pattern, route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(legacy) })); routed = true;
    await page.goto('http://127.0.0.1:7804/?model-marks=legacy#overview', { waitUntil: 'domcontentloaded' }); await settled(page, pending);
    assert.equal(await page.locator('.qp-model-identity i[data-model-vendor],.qp-map-node[data-dimension=model] .qp-node-icon[data-model-vendor]').count(), 0);
    assert.equal(await page.locator('.qp-model-identity i svg.lucide-box').count(), displayedModels.length);
    assert.equal(await page.locator('.qp-map-node[data-dimension=model] .qp-node-icon svg.lucide-box').count(), graph.nodes.model.length);
    assert.deepEqual(await page.locator('.qp-map-node[data-dimension=model]').evaluateAll(elements => elements.map(element => ({ key: element.getAttribute('data-key'), tokens: element.getAttribute('data-tokens') }))), graph.nodes.model.map(node => ({ key: JSON.stringify(node.key), tokens: String(node.tokens) })));
    modelMarkChecks.push({ lang, theme, vendors: replacements.map(([, , vendor]) => vendor), unknown: 1, tokens: graph.totals.tokens, legacyFallback: true, keyboardDetail: true, framedMarkContained: true });
  } finally {
    if (routed) await page.unroute(pattern);
    db.transaction(() => { const restore = db.prepare('UPDATE usage_event SET model=? WHERE id=?'); for (const row of saved) restore.run(row.model, row.id); })();
  }
}

async function checkPulseCore(page: Page, lang: string, theme: string, pending: Set<Request>) {
  const copy = lang === 'th' ? th : en;
  const home = 'http://127.0.0.1:7804/?pulse-core=asset#overview';
  await page.goto(home, { waitUntil: 'domcontentloaded' });
  await page.locator('.qp-quota').first().waitFor(); await settled(page, pending);
  const image = page.getByTestId('pulse-earth');
  const assetUrl = new URL((await image.getAttribute('href'))!, home).href;
  const response = await page.request.get(assetUrl);
  assert.equal(response.status(), 200);
  assert.ok(response.headers()['content-type']?.startsWith('image/png'));
  const assetSha256 = sha(readFileSync(resolve(root, 'packages/web/public/redesign/pulse-earth-v4.png')));
  assert.equal(sha(await response.body()), assetSha256, 'Served Earth asset differs from the retained source');
  const imageWidth = await page.evaluate(url => new Promise<number>((resolve, reject) => {
    const image = new Image(); image.onload = () => resolve(image.naturalWidth);
    image.onerror = () => reject(new Error('Earth asset failed to decode')); image.src = url;
  }), assetUrl);
  assert.equal(imageWidth, 1254);
  assert.equal(await image.locator('..').getAttribute('aria-hidden'), 'true', 'Decorative Earth must not replace the readable quota label');
  const ambient = await page.locator('.qp-pulse-ambient').evaluate(element => {
    const field = element.getBoundingClientRect(), pulse = element.closest('.qp-pulse')!.getBoundingClientRect();
    return { width: field.width, height: field.height, pulseWidth: pulse.width,
      centerError: Math.abs(field.left + field.width * 375 / 760 - pulse.left - pulse.width / 2),
      decorative: element.getAttribute('aria-hidden') === 'true' && getComputedStyle(element).pointerEvents === 'none',
      staticArtwork: element.getAnimations({ subtree: true }).length === 0 };
  });
  assert.ok(ambient.width >= ambient.pulseWidth * 2, 'Reference decoration must extend beyond the globe');
  assert.ok(ambient.centerError < 1);
  assert.equal(ambient.decorative, true); assert.equal(ambient.staticArtwork, true);
  pulseAmbientChecks.push({ lang, theme, width: ambient.width, height: ambient.height, centerError: ambient.centerError, decorative: ambient.decorative, staticArtwork: ambient.staticArtwork });
  const data = (await daemon.inject({ method: 'GET', url: '/api/overview', headers: { 'x-quotapulse-token': 'stable-capture-test' } })).json<Overview>();
  const selectedUsed: number[] = [];
  const quotas = page.locator('.qp-quota');
  for (let index = 0; index < await quotas.count(); index++) {
    const button = quotas.nth(index);
    const owner = await button.getAttribute('data-owner');
    const window = await button.getAttribute('data-window');
    const reading = data.limits.filter(limit => (limit.subscription_display_name ?? limit.account_display_name ?? limit.display_name) === owner && limit.window_kind === window).sort((a, b) => b.last_seen_at - a.last_seen_at)[0];
    assert.ok(reading && reading.used_percent !== null);
    const used = reading.used_percent!;
    await button.click();
    await page.waitForFunction(value => document.querySelector('.qp-pulse-label strong')?.textContent === `${value}%`, used);
    assert.equal(await page.getByTestId('pulse-progress').getAttribute('stroke-dasharray'), `${Math.min(100, used)} 100`);
    const meter = page.locator('.qp-metric-meter');
    assert.equal(await meter.getAttribute('data-value'), String(used), 'Metric rail meter must follow the selected quota');
    const selectedWindowLabel = await button.locator('.qp-quota-heading').evaluate(element => element.firstElementChild?.firstChild?.textContent?.trim() ?? '');
    assert.equal(await meter.locator('.qp-metric-meter-context').textContent(), selectedWindowLabel, 'Metric rail meter must identify the selected quota window');
    assert.equal(await meter.locator('small strong').textContent(), `${Math.round(used)}%`);
    assert.equal(await page.locator('.qp-pulse-state').textContent(), window === 'monthly'
      ? lang === 'th' ? 'ใช้โควตารายเดือน' : 'Monthly used'
      : lang === 'th' ? 'โควตาที่ใช้ไป' : 'Quota used');
    const pill = page.getByTestId('pulse-runway');
    assert.equal(await pill.getAttribute('data-reset-at'), String(reading.resets_at));
    const projectedAt = reading.forecast?.status === 'ready' && reading.forecast.projectedFullAt! > fixedNow ? reading.forecast.projectedFullAt : null;
    assert.equal(await pill.getAttribute('data-projected-at'), projectedAt === null ? null : String(projectedAt));
    const runwayConsequence = page.getByTestId('quota-runway-consequence');
    if (projectedAt === null) {
      const forecastKey = reading.forecast?.status === 'flat' ? 'redesign.forecastFlat'
        : reading.forecast?.status === 'reset' ? 'redesign.forecastReset' : 'redesign.forecastInsufficient';
      assert.equal(await runwayConsequence.textContent(), copy[forecastKey]);
    } else if (projectedAt < reading.resets_at!) {
      const beforeReset = reading.resets_at! - projectedAt;
      const durationBeforeReset = beforeReset < 60_000 ? '<1m' : countdown(fixedNow + beforeReset, fixedNow);
      assert.equal(await runwayConsequence.textContent(), `${copy['redesign.runwayHitLimitLead']} ${durationBeforeReset} ${copy['redesign.beforeReset']}${lang === 'th' ? '' : '.'}`);
    } else assert.equal(await runwayConsequence.textContent(), copy['redesign.runwayAfterReset']);
    const projection = page.getByTestId('pulse-projection');
    if (projectedAt === null) assert.equal(await projection.count(), 0, 'Do not state a projection without a valid forecast');
    else if (projectedAt < reading.resets_at!) {
      const expectedDuration = projectedAt - fixedNow < 60_000 ? '<1m' : countdown(projectedAt, fixedNow);
      assert.equal(await projection.textContent(), lang === 'th'
        ? `ด้วยอัตราปัจจุบัน คาดว่าโควตาจะเต็มในอีก ${expectedDuration} ก่อนรีเซ็ต`
        : `At the current pace, quota is projected to fill in ${expectedDuration} before reset.`);
    } else assert.equal(await projection.textContent(), lang === 'th'
      ? 'ด้วยอัตราปัจจุบัน คาดว่าจะยังใช้โควตาไม่เต็มก่อนรีเซ็ต'
      : 'At the current pace, the quota is projected to remain within its limit until reset.');
    const track = page.locator('.qp-runway-track');
    assert.equal(await track.getAttribute('data-now'), String(fixedNow));
    assert.equal(await track.getAttribute('data-reset-at'), String(reading.resets_at));
    assert.equal(await track.getAttribute('data-projected-at'), projectedAt === null ? null : String(projectedAt));
    const expectedMarker = projectedAt !== null && projectedAt < reading.resets_at! ? (projectedAt - fixedNow) / (reading.resets_at! - fixedNow) * 100 : null;
    assert.equal(await track.locator('.qp-runway-marker').count(), expectedMarker === null ? 0 : 1);
    if (expectedMarker !== null) {
      const percent = await track.locator('.qp-runway-marker').evaluate(element => parseFloat((element as HTMLElement).style.left));
      // CSSOM serializes the inline percentage to four decimal places.
      assert.ok(Math.abs(percent - expectedMarker) < 0.00005, `Runway marker must reflect forecast/reset timestamps (${percent} != ${expectedMarker}; projected=${projectedAt}; reset=${reading.resets_at}; owner=${owner}; window=${window})`);
    }
    assert.equal(await page.locator('.qp-runway-labels time').last().getAttribute('datetime'), new Date(reading.resets_at!).toISOString());
    if (projectedAt === null) assert.equal(await pill.locator('strong').first().textContent(), lang === 'th' ? 'ไม่ทราบ' : 'Unknown');
    const reducedSeconds = await page.getByTestId('pulse-progress').evaluate(element => parseFloat(getComputedStyle(element).transitionDuration));
    assert.ok(reducedSeconds <= 0.001, `Reduced motion must suppress the quota transition, observed ${reducedSeconds}s`);
    selectedUsed.push(used);
  }
  const pattern = '**/api/overview*';
  for (const used of [100, 0, 125, null]) {
    await page.route(pattern, route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ ...data, limits: data.limits.map(limit => ({ ...limit, used_percent: used })) }) }));
    try {
      await page.goto(`http://127.0.0.1:7804/?pulse-core=${used ?? 'unknown'}#overview`, { waitUntil: 'domcontentloaded' });
      await page.locator('.qp-core-grid').waitFor(); await settled(page, pending);
      assert.equal(await page.locator('.qp-pulse-label strong').textContent(), used === null ? '—' : `${used}%`);
      const progress = page.getByTestId('pulse-progress');
      if (used === null) {
        assert.equal(await progress.count(), 0, 'Unknown quota must not render an invented progress arc');
        assert.equal(await page.getByTestId('pulse-projection').count(), 0, 'Unknown quota must not render a projected fill sentence');
        assert.equal(await page.getByTestId('pulse-runway').getAttribute('data-projected-at'), null);
        assert.equal(await page.getByTestId('pulse-runway').getAttribute('data-reset-at'), null);
        assert.equal(await page.locator('.qp-runway-track').count(), 0, 'Unknown quota must not invent a runway timeline');
      }
      else {
        assert.equal(await progress.getAttribute('stroke-dasharray'), `${Math.min(100, used)} 100`);
        if (used === 0) assert.equal(await progress.getAttribute('stroke-linecap'), 'butt', 'Zero progress must not show a rounded minimum dot');
      }
    } finally { await page.unroute(pattern); }
  }
  await page.goto(home, { waitUntil: 'domcontentloaded' });
  await page.locator('.qp-quota').first().waitFor(); await settled(page, pending);
  for (const state of ['imminent', 'after-reset', 'flat', 'stale', 'expired'] as const) {
    const fixture = { ...data, limits: data.limits.map(limit => ({ ...limit,
      last_seen_at: state === 'stale' ? fixedNow - 7_200_000 : fixedNow,
      resets_at: state === 'expired' ? fixedNow - 1 : limit.resets_at,
      forecast: { ...limit.forecast, status: state === 'flat' ? 'flat' : 'ready', projectedFullAt: state === 'flat' ? null : state === 'after-reset' ? limit.resets_at! + 60_000 : fixedNow + 30_000 },
    })) };
    await page.route(pattern, route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(fixture) }));
    try {
      await page.goto(`http://127.0.0.1:7804/?runway-state=${state}#overview`, { waitUntil: 'domcontentloaded' });
      await page.getByTestId('quota-runway').waitFor(); await settled(page, pending);
      const track = page.locator('.qp-runway-track');
      if (state === 'stale' || state === 'expired') {
        assert.equal(await track.count(), 0, `${state} quota must not display a live timeline`);
        assert.equal(await page.locator('.qp-runway-message').isVisible(), true);
        assert.equal(await page.getByTestId('quota-runway-consequence').count(), 0, `${state} quota must not display a runway consequence`);
        assert.equal(await page.getByTestId('pulse-projection').count(), 0, `${state} quota must not display a projected fill sentence`);
      } else {
        assert.equal(await track.locator('.qp-runway-marker').count(), state === 'imminent' ? 1 : 0);
        assert.equal(await track.locator('.qp-runway-risk').count(), state === 'imminent' ? 1 : 0);
        const reset = Number(await track.getAttribute('data-reset-at'));
        const projected = state === 'flat' ? null : state === 'after-reset' ? reset + 60_000 : fixedNow + 30_000;
        assert.equal(await track.getAttribute('data-projected-at'), projected === null ? null : String(projected));
        if (state === 'imminent') {
          const beforeReset = reset - projected!;
          const durationBeforeReset = beforeReset < 60_000 ? '<1m' : countdown(fixedNow + beforeReset, fixedNow);
          assert.equal(await page.getByTestId('quota-runway-consequence').textContent(), `${copy['redesign.runwayHitLimitLead']} ${durationBeforeReset} ${copy['redesign.beforeReset']}${lang === 'th' ? '' : '.'}`);
        }
        if (state === 'after-reset') assert.equal(await page.getByTestId('quota-runway-consequence').textContent(), copy['redesign.runwayAfterReset']);
        if (state === 'flat') assert.equal(await page.getByTestId('quota-runway-consequence').textContent(), copy['redesign.forecastFlat']);
        if (state === 'imminent') {
          assert.ok((await page.locator('.qp-runway-outcome>strong').first().textContent())!.startsWith('<1m'));
          const marker = await track.locator('.qp-runway-marker').evaluate(element => parseFloat((element as HTMLElement).style.left));
          assert.ok(Math.abs(marker - 30_000 / (reset - fixedNow) * 100) < 0.00001);
        }
        if (state === 'flat') {
          assert.equal(await page.locator('.qp-runway-labels small').textContent(), lang === 'th' ? 'ไม่ทราบ' : 'Unknown');
          assert.equal(await page.getByTestId('pulse-projection').count(), 0, 'Flat usage must not claim a fill date');
        }
        if (state === 'imminent') {
          const expected = lang === 'th'
            ? 'ด้วยอัตราปัจจุบัน คาดว่าโควตาจะเต็มในอีก <1m ก่อนรีเซ็ต'
            : 'At the current pace, quota is projected to fill in <1m before reset.';
          assert.equal(await page.getByTestId('pulse-projection').textContent(), expected);
        }
        if (state === 'after-reset') assert.equal(await page.getByTestId('pulse-projection').textContent(), lang === 'th'
          ? 'ด้วยอัตราปัจจุบัน คาดว่าจะยังใช้โควตาไม่เต็มก่อนรีเซ็ต'
          : 'At the current pace, the quota is projected to remain within its limit until reset.');
      }
    } finally { await page.unroute(pattern); }
  }
  await page.goto(home, { waitUntil: 'domcontentloaded' }); await page.locator('.qp-overview-period select').waitFor(); await settled(page, pending);
  pulseCoreChecks.push({ lang, theme, assetSha256, imageWidth, selectedUsed, boundaries: [0, 100, 125], unknown: true, reducedMotion: true });
}

async function checkRecentActivity(page: Page, lang: string, theme: string, pending: Set<Request>) {
  const home = 'http://127.0.0.1:7804/?recent-activity=actual#overview';
  const response = page.waitForResponse(response => new URL(response.url()).pathname === '/api/usage-events' && response.status() === 200);
  const activityRequests: URL[] = [];
  const collectActivityRequest = (request: Request) => {
    const url = new URL(request.url());
    if (url.pathname === '/api/usage-events') activityRequests.push(url);
  };
  page.on('request', collectActivityRequest);
  await page.goto(home, { waitUntil: 'domcontentloaded' });
  const url = new URL((await response).url());
  const firstHarnessData = (await daemon.inject({ method: 'GET', url: url.pathname + url.search, headers: { 'x-quotapulse-token': 'stable-capture-test' } })).json<UsageEventsResponse>();
  const globalScope = { ...firstHarnessData.scope };
  delete globalScope.harness;
  const data = (await daemon.inject({ method: 'GET', url: `/api/usage-events?${usageEventParams(globalScope)}&limit=500&offset=0`, headers: { 'x-quotapulse-token': 'stable-capture-test' } })).json<UsageEventsResponse>();
  await settled(page, pending);
  page.off('request', collectActivityRequest);
  const cards = page.locator('.qp-activity-item');
  const expectedRows = latestActivityByHarness(data.rows);
  assert.equal(expectedRows.length, 4, 'Reference Overview fixture must expose all four recorded harnesses');
  assert.equal(await cards.count(), expectedRows.length);
  const perHarnessRequests = activityRequests.filter(request => request.searchParams.get('limit') === '1' && request.searchParams.has('harness'));
  const perHarnessLatestQueries = new Set(perHarnessRequests.map(request => request.searchParams.get('harness'))).size >= 4;
  assert.ok(perHarnessLatestQueries,
    'Recent activity must query the newest row per harness so a high-volume harness cannot starve others');
  assert.equal(new Set(expectedRows.map(record => record.harness.toLowerCase())).size, expectedRows.length, 'Activity cards must use distinct harnesses');
  const locale = lang === 'th' ? 'th-TH' : 'en-US';
  const number = new Intl.NumberFormat(locale, { maximumFractionDigits: 0 });
  const compact = new Intl.NumberFormat(locale, { notation: 'compact', maximumFractionDigits: 1 });
  for (const [index, record] of expectedRows.entries()) {
    const card = cards.nth(index);
    assert.equal(await card.getAttribute('data-record-id'), String(record.event_id));
    assert.equal(await card.getAttribute('data-grain'), record.grain);
    assert.equal(await card.locator('.qp-activity-meta time').getAttribute('datetime'), new Date(record.timestamp_ms).toISOString());
    const expectedHarness = ({ codex: 'Codex CLI', hermes: 'Hermes Agent', 'claude-code': 'Claude Code', opencode: 'OpenCode' } as Record<string, string>)[record.harness] ?? record.harness;
    assert.equal(await card.locator('.qp-activity-identity b').textContent(), expectedHarness);
    assert.equal(await card.getAttribute('href'), record.session_key === null ? '#history?range=today' : `#history?range=all&session_id=${record.session_key}`);
    const trendScope = activityTrendScope(globalScope, record, data.now);
    assert.equal(trendScope !== null, record.grain === 'call' && record.model !== null && record.provider !== null);
    const minute = trendScope ? (await daemon.inject({ method: 'GET', url: `/api/trend?bucket=minute&group_by=none&${usageEventParams(trendScope)}`, headers: { 'x-quotapulse-token': 'stable-capture-test' } })).json<MinuteTrendResponse>() : null;
    const rate = activityTokensPerMinute(minute);
    const rateValue = card.locator('.qp-activity-value strong');
    assert.equal(await rateValue.getAttribute('data-rate-value'), rate === null ? null : String(rate));
    const expectedState = record.grain === 'session_aggregate' ? 'aggregate' : rate === null ? 'unavailable' : 'measured';
    const expectedValue = record.grain === 'session_aggregate' ? compact.format(record.total_tokens) : rate === null ? '—' : compact.format(rate);
    assert.equal(await card.locator('.qp-activity-value').getAttribute('data-rate-state'), expectedState);
    assert.equal(await rateValue.textContent(), expectedValue);
    const sparklineLocator = card.locator('canvas.qp-activity-sparkline');
    const hasSparkline = await sparklineLocator.count() === 1;
    const expectedSparkline = Boolean(minute?.coverage.includedRecords && record.grain === 'call' && record.model && record.provider);
    assert.equal(hasSparkline, expectedSparkline, 'Only recorded minute data for an individual call may draw a waveform');
    const sparkline = hasSparkline ? await sparklineLocator.boundingBox() : null;
    if (hasSparkline) assert.ok(sparkline && Math.abs(sparkline.height - ACTIVITY_SPARKLINE_HEIGHT) < .1, 'Recorded call waveform must use the reference-sized chart row');
    assert.equal(await card.locator('.qp-activity-value small').textContent(), record.grain === 'session_aggregate' ? (lang === 'th' ? 'โทเค็นที่ตรวจพบ' : 'tokens observed') : (lang === 'th' ? 'โทเค็น/นาที' : 'tokens/min'));
    const points = await card.locator('[data-at][data-value]').evaluateAll(elements => elements.map(element => ({ at: Number(element.getAttribute('data-at')), value: Number(element.getAttribute('data-value')) })));
    if (minute?.coverage.includedRecords) {
      const firstBucket = Math.floor(minute.from / 60_000) * 60_000;
      const expected = Array.from({ length: Math.ceil(minute.to / 60_000) - firstBucket / 60_000 }, (_, offset) => {
        const at = firstBucket + offset * 60_000;
        return { at, value: minute.rows.filter(row => row.bucket_ts === at).reduce((sum, row) => sum + row.total_tokens, 0) };
      });
      assert.deepEqual(points, expected);
      const canvas = card.locator('canvas.qp-activity-sparkline');
      const bitmap = await canvas.evaluate(async (element: HTMLCanvasElement, input: { expected: Array<{ at: number; value: number }>; chartHeight: number }) => {
        const { expected, chartHeight } = input;
        const rect = element.getBoundingClientRect(), context = element.getContext('2d')!;
        const pixels = context.getImageData(0, 0, element.width, element.height).data;
        const maximum = Math.max(...expected.map(point => point.value));
        // Independent endpoint checks use API buckets, not canvas fallback metadata.
        const margin = Math.max(1, rect.width * .008), first = expected[0].at, last = expected.at(-1)!.at;
        const covered = expected.every(point => {
          const x = (last > first ? margin + (rect.width - 2 * margin) * (point.at - first) / (last - first) : rect.width / 2) * element.width / rect.width;
          const y = (chartHeight - 1 - (chartHeight - 2) * point.value / (maximum || 1)) * element.height / chartHeight;
          for (let py = Math.max(0, Math.floor(y) - 1); py <= Math.min(element.height - 1, Math.ceil(y) + 1); py++)
            for (let px = Math.max(0, Math.floor(x) - 1); px <= Math.min(element.width - 1, Math.ceil(x) + 1); px++)
              if (pixels[(py * element.width + px) * 4 + 3] > 64) return true;
          return false;
        });
        const digest = await crypto.subtle.digest('SHA-256', pixels.buffer);
        return { width: element.width, height: element.height, cssWidth: rect.width, dpr: devicePixelRatio, covered,
          paintedPixels: pixels.filter((value, index) => index % 4 === 3 && value > 0).length,
          sha256: [...new Uint8Array(digest)].map(value => value.toString(16).padStart(2, '0')).join('') };
      }, { expected, chartHeight: ACTIVITY_SPARKLINE_HEIGHT });
      assert.equal(bitmap.width, Math.round(bitmap.cssWidth * bitmap.dpr));
      assert.equal(bitmap.height, Math.round(ACTIVITY_SPARKLINE_HEIGHT * bitmap.dpr));
      assert.equal(bitmap.covered, true, 'Canvas must paint the independent API bucket positions');
      assert.ok(bitmap.paintedPixels > 0);
      activityBitmapChecks.push({ lang, theme, recordId: record.event_id, points: expected.length, width: bitmap.width, height: bitmap.height, paintedPixels: bitmap.paintedPixels, sha256: bitmap.sha256 });
    } else assert.equal(points.length, 0);
  }
  const allTrend = (await daemon.inject({ method: 'GET', url: `/api/trend?bucket=minute&group_by=none&${new URLSearchParams({ from: String(globalScope.from), to: String(globalScope.to), ...(globalScope.sourceId === undefined ? {} : { source_id: String(globalScope.sourceId) }), grain: 'call' })}`, headers: { 'x-quotapulse-token': 'stable-capture-test' } })).json<MinuteTrendResponse>();
  const totalRate = activityTokensPerMinute(allTrend);
  assert.equal(await page.locator('.qp-activity-total').getAttribute('data-rate-state'), totalRate === null ? 'unavailable' : 'measured');
  assert.equal(await page.locator('[data-activity-total]').textContent(), `${totalRate === null ? '—' : compact.format(totalRate)} ${lang === 'th' ? 'โทเค็น/นาที' : 'tokens/min'}`);
  const rendererRecord = expectedRows.find(record => record.grain === 'call' && record.model !== null && record.provider !== null);
  assert.ok(rendererRecord, 'Activity renderer test requires a recorded call with a known model and provider');
  await checkActivityRenderer(page, lang, theme, pending, rendererRecord.timestamp_ms);
  const first = cards.first(), href = await first.getAttribute('href');
  await first.focus(); await page.keyboard.press('Enter'); await page.waitForURL(url => url.hash === href);
  await page.getByTestId('usage-history').waitFor({ timeout: 15000 });
  await page.locator('.qp-history-records[aria-busy="false"]').waitFor({ timeout: 15000 });
  await settled(page, pending);
  assert.equal(await page.locator('.qp-history-records table').isVisible(), true, 'Keyboard History destination did not load its actual records');
  const payload = structuredClone(data);
  payload.rows = payload.rows.slice(0, 1).map(record => ({ ...record, total_tokens: 123456789012345, grain: 'unknown', session_key: null, model: null, provider: null, harness: 'Very long recorded harness identity for overflow checking' }));
  const pattern = (candidate: URL) => candidate.origin === url.origin && candidate.pathname === '/api/usage-events';
  let diagnosticReads = 0;
  const handler = async (route: Route) => {
    if (route.request().method() !== 'GET') return route.fallback();
    diagnosticReads++;
    await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(payload) });
  };
  await page.route(pattern, handler);
  try {
    await page.goto('http://127.0.0.1:7804/?recent-activity=unknown#overview', { waitUntil: 'domcontentloaded' }); await settled(page, pending);
    assert.ok(diagnosticReads > 0, 'Scoped Overview diagnostic GET was not reached');
    assert.equal(await cards.count(), 1);
    assert.equal(await cards.locator('.qp-activity-value strong').textContent(), '—');
    assert.equal(await cards.locator('.qp-activity-value').getAttribute('data-rate-state'), 'unavailable');
    assert.ok((await cards.getAttribute('title'))?.includes(number.format(123456789012345)));
    assert.equal(await cards.locator('.qp-activity-meta small').textContent(), lang === 'th' ? 'ไม่ทราบ' : 'Unknown');
    assert.equal(await cards.getAttribute('href'), '#history?range=today');
    assert.equal(await cards.locator('[data-at][data-value]').count(), 0);
    for (const width of [390, 900, 1280]) {
      await page.setViewportSize({ width, height: 992 });
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `Recent activity overflow ${lang}/${theme}/${width}`);
      const containment = await cards.evaluate(element => {
        const bounds = element.getBoundingClientRect();
        return [...element.querySelectorAll('.qp-activity-value,.qp-activity-meta')].every(child => { const rect = child.getBoundingClientRect(); return rect.right <= bounds.right + 1 && rect.bottom <= bounds.bottom + 1; });
      });
      assert.equal(containment, true);
    }
  } finally { await page.unroute(pattern, handler); }
  const futureFrom = data.now + 60_000, futureTo = futureFrom + 60_000;
  const futureRequests: URL[] = [];
  const collectFutureActivity = (request: Request) => {
    const candidate = new URL(request.url());
    if (candidate.pathname === '/api/usage-events') futureRequests.push(candidate);
  };
  page.on('request', collectFutureActivity);
  await page.goto(`http://127.0.0.1:7804/#overview?range=custom&from=${futureFrom}&to=${futureTo}`, { waitUntil: 'domcontentloaded' });
  await page.getByTestId('production-overview').waitFor({ timeout: 15000 });
  await settled(page, pending);
  page.off('request', collectFutureActivity);
  assert.equal(futureRequests.length, 0, 'A future-only custom range must skip the empty activity query');
  assert.equal(await page.locator('.qp-activity-item').count(), 0);
  assert.equal(await page.locator('.qp-activity-total').getAttribute('data-rate-state'), 'unavailable');
  assert.equal(await page.locator('p[role="status"][class*="bg-warn/10"]').count(), 0, 'A future-only Overview should load without a stale-snapshot error');
  recentActivityChecks.push({ lang, theme, records: expectedRows.length, keyboardHistory: true, unknownGrain: true, largeTokens: true,
    perHarnessLatestQueries, futureRangeEmpty: futureRequests.length === 0 });
  await page.setViewportSize({ width: 1586, height: 992 });
  await page.goto(home, { waitUntil: 'domcontentloaded' }); await settled(page, pending);
}

async function checkActivityRenderer(page: Page, lang: string, theme: string, pending: Set<Request>, recentAt: number) {
  const chart = page.locator('canvas.qp-activity-sparkline').first();
  const snapshot = () => chart.evaluate(element => {
    const canvas = element as HTMLCanvasElement;
    const data = document.getElementById(canvas.getAttribute('aria-describedby')!)!;
    return { pixels: canvas.toDataURL(), width: canvas.width, height: canvas.height, cssWidth: canvas.getBoundingClientRect().width,
      points: [...data.querySelectorAll('li')].map(point => ({ at: Number(point.getAttribute('data-at')), value: Number(point.getAttribute('data-value')) })) };
  });
  const before = await snapshot();
  assert.ok(before.points.length > 1);
  const cdp = await page.context().newCDPSession(page);
  try {
    const document = await cdp.send('DOM.getDocument');
    const { nodeId } = await cdp.send('DOM.querySelector', { nodeId: document.root.nodeId, selector: 'canvas.qp-activity-sparkline' });
    const tree = await cdp.send('Accessibility.getPartialAXTree', { nodeId });
    const image = tree.nodes.find(node => !node.ignored && node.role?.value === 'image');
    assert.ok(image?.description?.value?.includes(new Date(before.points[0].at).toLocaleString(lang === 'th' ? 'th-TH' : 'en-US')), 'Minute values must be exposed through the image accessibility description');
  } finally { await cdp.detach(); }
  const themeButton = page.locator('.qp-tools button').first();
  await themeButton.click();
  await page.waitForFunction(prior => (document.querySelector('canvas.qp-activity-sparkline') as HTMLCanvasElement).toDataURL() !== prior, before.pixels);
  assert.deepEqual((await snapshot()).points, before.points);
  await themeButton.click();
  await page.waitForFunction(prior => (document.querySelector('canvas.qp-activity-sparkline') as HTMLCanvasElement).toDataURL() === prior, before.pixels);
  await page.setViewportSize({ width: 390, height: 992 });
  await page.waitForFunction(() => {
    const canvas = document.querySelector('canvas.qp-activity-sparkline') as HTMLCanvasElement;
    return canvas.width === Math.round(canvas.getBoundingClientRect().width * devicePixelRatio);
  });
  const narrow = await snapshot();
  assert.notEqual(narrow.width, before.width); assert.equal(narrow.height, ACTIVITY_SPARKLINE_HEIGHT);
  assert.deepEqual(narrow.points, before.points);
  await page.setViewportSize({ width: 1586, height: 992 });
  const home = 'http://127.0.0.1:7804/?activity-renderer=fixture#overview';
  const from = Math.floor(recentAt / 60_000) * 60_000, to = from + 60_000;
  await page.goto(`${home}?range=custom&from=${from}&to=${to}`, { waitUntil: 'domcontentloaded' }); await settled(page, pending);
  const chartCount = await chart.count();
  assert.ok(chartCount, `Activity renderer chart missing at ${page.url()} (quotaCount=${await page.locator('.qp-quota').count()}, heading=${await page.locator('h1').textContent()})`);
  const one = await snapshot();
  assert.equal(one.points.length, 1);
  const onePeak = await chart.evaluate(element => {
    const canvas = element as HTMLCanvasElement, context = canvas.getContext('2d')!;
    const data = context.getImageData(Math.floor(canvas.width / 2) - 1, 0, 3, 3).data;
    return data.some((value, index) => index % 4 === 3 && value > 64);
  });
  assert.equal(onePeak, true, 'Single positive bucket must paint the center peak');
  const saved = db.prepare('SELECT id,input_tokens,cached_input_tokens,output_tokens,total_tokens FROM usage_event').all() as Array<{ id: number; input_tokens: number; cached_input_tokens: number; output_tokens: number; total_tokens: number }>;
  try {
    db.exec('UPDATE usage_event SET input_tokens=0,cached_input_tokens=0,output_tokens=0,total_tokens=0');
    await page.goto(home, { waitUntil: 'domcontentloaded' }); await settled(page, pending);
    const zero = await snapshot();
    assert.ok(zero.points.length > 1); assert.ok(zero.points.every(point => point.value === 0));
    const ink = await chart.evaluate(element => {
      const canvas = element as HTMLCanvasElement, pixels = canvas.getContext('2d')!.getImageData(0, 0, canvas.width, canvas.height).data;
      return { upper: pixels.slice(0, 4 * canvas.width * 4).some((value, index) => index % 4 === 3 && value > 0),
        baseline: pixels.slice(10 * canvas.width * 4).some((value, index) => index % 4 === 3 && value > 0) };
    });
    assert.equal(ink.upper, false, 'All-zero buckets must not paint a false upper peak');
    assert.equal(ink.baseline, true);
  } finally {
    db.transaction(() => { const restore = db.prepare('UPDATE usage_event SET input_tokens=?,cached_input_tokens=?,output_tokens=?,total_tokens=? WHERE id=?'); for (const row of saved) restore.run(row.input_tokens,row.cached_input_tokens,row.output_tokens,row.total_tokens,row.id); })();
    await page.goto(home, { waitUntil: 'domcontentloaded' }); await settled(page, pending);
  }
  activityRendererChecks.push({ lang, theme, accessibleValues: true, themeRedraw: true, resized: true, singlePoint: true, zeroBaseline: true });
}

async function checkQuotaGroups(page: Page, lang: string, theme: string, pending: Set<Request>) {
  const original = (await daemon.inject({ method: 'GET', url: '/api/overview', headers: { 'x-quotapulse-token': 'stable-capture-test' } })).json<Overview>();
  const names = db.prepare('SELECT id,account_display_name FROM source WHERE id IN (1,2) ORDER BY id').all() as Array<{ id: number; account_display_name: string }>;
  const before = (db.prepare('SELECT COUNT(*) AS count FROM limit_sample').get() as { count: number }).count;
  const insert = db.prepare('INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin) VALUES (?,?,?,?,?,?,?,?)');
  try {
    for (const source of [1, 2]) for (const [index, window] of ['weekly', 'monthly', 'weekly_opus'].entries()) {
      const at = fixedNow - 60_000;
      insert.run(source, window, 20 + source * 7 + index * 9, fixedNow + (window === 'monthly' ? 31 : 7) * 86_400_000, at, at, at, 'quota-group-fixture');
    }
    const old = fixedNow - 3 * 3_600_000;
    insert.run(1, 'weekly', 99, fixedNow + 7 * 86_400_000, old, old, old, 'quota-group-superseded');
    await page.goto('http://127.0.0.1:7804/?quota-groups=multiple#overview', { waitUntil: 'domcontentloaded' });
    await page.locator('.qp-quota-group').first().waitFor(); await settled(page, pending);
    assert.equal(await page.locator('.qp-quota-group').count(), 2); assert.equal(await page.locator('.qp-quota').count(), 8);
    const data = (await daemon.inject({ method: 'GET', url: '/api/overview', headers: { 'x-quotapulse-token': 'stable-capture-test' } })).json<Overview>();
    for (let index = 0; index < 2; index++) {
      const group = page.locator('.qp-quota-group').nth(index), key = await group.getAttribute('data-owner-key');
      assert.equal(await group.locator('.qp-quota').count(), 4);
      const expectedState = data.subscriptions.find(subscription => subscription.subscription_key === key)?.state
        ?? data.sourceStatus.find(source => source.account_key === null && `source:${source.source_id}` === key)?.account_state
        ?? 'unknown';
      const status = group.locator('.qp-quota-group-status');
      assert.equal(await group.getAttribute('data-state'), expectedState);
      assert.equal(await status.getAttribute('data-state'), expectedState);
      assert.ok((await status.innerText()).trim().length > 0, 'Quota owner must show a localized API-backed status');
      assert.equal(await group.locator('.qp-quota-group-heading>.qp-chip').count(), 0, 'Quota owner header must not show a window count');
      const owner = data.limits.find(limit => (limit.subscription_key ?? limit.account_key) === key)!;
      const ownerName = owner.subscription_display_name ?? owner.account_display_name ?? owner.display_name;
      const visibleOwnerName = ownerName.replace(/\s+(Subscription)$/i, ' ($1)');
      assert.equal(await group.locator('h3').innerText(), visibleOwnerName);
      assert.equal(await group.locator('h3').getAttribute('aria-label'), ownerName, 'Quota owner heading keeps the full API label for assistive technology');
      const expectedWindows = [...new Set(data.limits.filter(limit => (limit.subscription_key ?? limit.account_key) === key).map(limit => limit.window_kind))];
      assert.equal(expectedWindows.length, 4);
      for (const window of expectedWindows) {
        const row = group.locator(`.qp-quota[data-window="${window}"]`);
        const actual = data.limits.filter(limit => (limit.subscription_key ?? limit.account_key) === key && limit.window_kind === window).sort((a, b) => b.last_seen_at - a.last_seen_at)[0];
        assert.equal(await row.locator('.qp-quota-number strong').textContent(), `${actual.used_percent}%`);
        assert.equal(await row.locator('.qp-bar>span').evaluate(element => (element as HTMLElement).style.width), `${Math.min(100, actual.used_percent!)}%`);
        assert.ok((await row.getAttribute('aria-label'))!.includes(lang === 'th' ? 'โควตาที่ใช้ไป' : 'Quota used'));
      }
    }
    const rail = page.locator('.qp-quota-groups'); await rail.focus(); await page.keyboard.press('End'); await page.waitForTimeout(150);
    assert.ok(await rail.evaluate(element => element.scrollTop > 0), 'All grouped windows must remain keyboard-scrollable');
    const last = page.locator('.qp-quota').last(), key = (await last.locator('..').getAttribute('data-owner-key'))!, window = (await last.getAttribute('data-window'))!;
    const reading = data.limits.filter(limit => (limit.subscription_key ?? limit.account_key) === key && limit.window_kind === window).sort((a, b) => b.last_seen_at - a.last_seen_at)[0]!;
    const responsePromise = page.waitForResponse(response => { const url = new URL(response.url()); return url.pathname === '/api/quota-history' && url.searchParams.get('subscription_key') === key && url.searchParams.get('window_kind') === window && response.status() === 200; });
    await last.focus(); await page.keyboard.press('Enter');
    const response = await responsePromise, history = await response.json() as QuotaHistoryResponse;
    assert.equal(history.subscriptionKey, key); assert.equal(history.windowKind, window); assert.equal(history.reader?.origin, reading.origin);
    assert.equal(history.reader?.sourceId, reading.source_id);
    await page.waitForFunction(value => document.querySelector('.qp-pulse-label strong')?.textContent === `${value}%`, reading.used_percent);
    const outer = page.getByTestId('quota-history'); await outer.locator('summary').first().focus(); await page.keyboard.press('Enter');
    await outer.locator('.qp-quota-point').first().waitFor();
    assert.equal(await outer.locator('.qp-quota-point').first().getAttribute('data-value'), String(reading.used_percent));
    await outer.locator('summary').first().focus(); await page.keyboard.press('Enter');
    db.prepare("UPDATE source SET account_display_name='Shared fixture label' WHERE id IN (1,2)").run();
    await page.goto('http://127.0.0.1:7804/?quota-groups=same-name#overview', { waitUntil: 'domcontentloaded' });
    await page.locator('.qp-quota-group').first().waitFor(); await settled(page, pending);
    assert.equal(await page.locator('.qp-quota-group').count(), 2); assert.equal(await page.locator('.qp-quota').count(), 8);
    const keys = await page.locator('.qp-quota-group').evaluateAll(elements => elements.map(element => element.getAttribute('data-owner-key')));
    assert.equal(new Set(keys).size, 2);
    assert.deepEqual(await page.locator('.qp-quota-group h3').allInnerTexts(), ['Shared fixture label', 'Shared fixture label']);
    for (const width of [390, 900, 1280]) {
      await page.setViewportSize({ width, height: 992 });
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `Grouped quota overflow: ${lang}/${theme}/${width}`);
    }
    await page.setViewportSize({ width: 1586, height: 992 });
    quotaGroupChecks.push({ lang, theme, owners: 2, windows: 8, sameNameSeparate: true, keyboardScrolled: true, historyIdentity: true });
  } finally {
    db.prepare('DELETE FROM limit_sample WHERE origin IN (?,?)').run('quota-group-fixture', 'quota-group-superseded');
    for (const source of names) db.prepare('UPDATE source SET account_display_name=? WHERE id=?').run(source.account_display_name, source.id);
    assert.equal((db.prepare('SELECT COUNT(*) AS count FROM limit_sample').get() as { count: number }).count, before);
  }
  await page.goto('http://127.0.0.1:7804/?quota-groups=restored#overview', { waitUntil: 'domcontentloaded' });
  await page.locator('.qp-quota').first().waitFor(); await settled(page, pending);
  assert.equal(await page.locator('.qp-quota').count(), original.limits.length);
}

async function checkOverviewInsights(page: Page, lang: string, theme: string, pending: Set<Request>) {
  const home = 'http://127.0.0.1:7804/?overview-insights=default#overview';
  const responsePromise = page.waitForResponse(response => new URL(response.url()).pathname === '/api/runtime-map' && response.status() === 200);
  await page.goto(home, { waitUntil: 'domcontentloaded' });
  const response = await responsePromise, url = new URL(response.url());
  const graph = (await daemon.inject({ method: 'GET', url: url.pathname + url.search, headers: { 'x-quotapulse-token': 'stable-capture-test' } })).json<RuntimeGraph>();
  await page.locator('.qp-insight-card').first().waitFor(); await settled(page, pending);
  const panel = page.getByTestId('usage-insights'), number = new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US', { maximumFractionDigits: 0 });
  const money = new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US', { style: 'currency', currency: 'USD' });
  const locale = lang === 'th' ? 'th-TH' : 'en-US';
  const range = await page.locator('.qp-overview-period select').inputValue();
  const metricUsage = (await daemon.inject({ method: 'GET', url: `/api/usage?${new URLSearchParams({ range, bucket: 'auto' })}`, headers: { 'x-quotapulse-token': 'stable-capture-test' } })).json<UsageResponse>();
  const span = metricUsage.range.to - metricUsage.range.from;
  const previousFrom = metricUsage.range.from - span;
  const comparisonResponse = previousFrom >= 0
    ? await daemon.inject({ method: 'GET', url: `/api/compare?from=${metricUsage.range.from}&to=${metricUsage.range.to}&previous_from=${previousFrom}&previous_to=${metricUsage.range.from}&group_by=none`, headers: { 'x-quotapulse-token': 'stable-capture-test' } })
    : null;
  assert.equal(comparisonResponse?.statusCode, 200, 'Previous-period comparison must be available for the fixture range');
  const comparison = comparisonResponse?.statusCode === 200 ? comparisonResponse.json<CompareResult>() : null;
  assert.equal(await panel.locator('.qp-insights-subtitle').innerText(), lang === 'th' ? 'สัญญาณการใช้งานและราคา' : 'Usage and pricing signals');
  async function values(expected: RuntimeGraph['totals']) {
    const input = expected.inputTokens + expected.cachedInputTokens + expected.cacheWriteTokens;
    const tokenChange = comparison ? relativeChangePercent(comparison.current.total_tokens, comparison.previous.total_tokens) : null;
    const tokenCard = panel.locator('[data-insight=burn]');
    assert.equal(await tokenCard.getAttribute('data-value'), tokenChange === null ? null : String(tokenChange));
    const signed = tokenChange === null ? '—' : `${new Intl.NumberFormat(locale, { maximumFractionDigits: 0, signDisplay: 'always' }).format(tokenChange)}%`;
    assert.equal(await tokenCard.locator('strong').textContent(), signed);
    const cacheShare = input ? expected.cachedInputTokens / input * 100 : null;
    assert.equal(await panel.locator('[data-insight=cache] strong').textContent(), cacheShare === null ? '—' : `${number.format(cacheShare)}%`);
    assert.equal(await panel.locator('[data-insight=cache]').getAttribute('data-state'), input ? 'measured' : 'unavailable');
    const previousCacheShare = comparison ? cacheSharePercent(comparison.previous) : null;
    const cacheDelta = percentagePointChange(cacheShare, previousCacheShare);
    const cacheDeltaLabel = cacheDelta === null ? null : `${cacheDelta > 0 ? '↑' : cacheDelta < 0 ? '↓' : '→'}${number.format(Math.abs(cacheDelta))} pp`;
    const cacheDeltaLocator = panel.locator('[data-insight=cache] .qp-insight-delta');
    assert.equal(await cacheDeltaLocator.count() ? await cacheDeltaLocator.textContent() : null, cacheDeltaLabel);
    const cacheSupport = await panel.locator('[data-insight=cache] p').textContent();
    if (expected.cacheSavingKnownCalls > 0) {
      assert.ok(cacheSupport?.includes(money.format(expected.cacheSavingKnownUsd)));
      assert.ok(cacheSupport?.includes(number.format(expected.cacheSavingKnownCalls)));
    }
    const priced = expected.nativeCalls + expected.computedCalls + expected.estimatedCalls, calls = priced + expected.unknownCalls;
    const recommendation = panel.locator('[data-insight=recommendation]');
    assert.ok(['fresh-reading','reduce-load','slow-down','use-cache','check-pricing','monitor'].includes((await recommendation.getAttribute('data-state')) ?? ''));
    assert.equal(await recommendation.getAttribute('data-pricing-state'), calls === 0 ? 'unavailable' : priced === calls ? 'complete' : 'partial');
    const recommendationDetail = recommendation.locator('.qp-insight-detail');
    if (await recommendation.getAttribute('data-state') === 'check-pricing') {
      assert.ok((await recommendationDetail.textContent())?.includes(number.format(expected.unknownCostRecords)));
    } else assert.equal(await recommendationDetail.count(), 0, 'Pricing coverage details only belong with a pricing recommendation');
    const paceComparison = panel.locator('[data-insight=pace-comparison]');
    assert.ok(['unknown','above-safe','within-safe'].includes((await paceComparison.getAttribute('data-state')) ?? ''));
    if (await paceComparison.getAttribute('data-state') === 'unknown') assert.equal(await paceComparison.locator('strong').textContent(), '—');
  }
  await values(graph.totals);
  const boxes = await panel.locator('.qp-insight-card').evaluateAll(elements => elements.map(element => { const box = element.getBoundingClientRect(); return { x: box.x, y: box.y, right: box.right, bottom: box.bottom }; }));
  assert.equal(boxes.length, 4); assert.equal(boxes[0].y, boxes[1].y); assert.equal(boxes[2].y, boxes[3].y);
  assert.ok(boxes[1].x > boxes[0].right && boxes[2].y > boxes[0].bottom, 'Insights must form the source two-column/two-row card arrangement');
  const pattern = '**/api/runtime-map?**', states = ['zero-cache-price', 'large-known-price', 'empty'];
  for (const state of states) {
    const totals = state === 'empty' ? Object.fromEntries(Object.keys(graph.totals).map(key => [key, 0])) as RuntimeGraph['totals'] : { ...graph.totals, cacheSavingKnownCalls: 3, cacheSavingKnownUsd: state === 'zero-cache-price' ? 0 : 1_234_567.89,
      ...(state === 'zero-cache-price' ? { inputTokens: graph.totals.inputTokens + graph.totals.cachedInputTokens + graph.totals.cacheWriteTokens, cachedInputTokens: 0, cacheWriteTokens: 0 } : { unknownCostRecords: 2 }) };
    const fixture = { ...graph, totals, ...(state === 'empty' ? { nodes: Object.fromEntries(dimensions.map(dimension => [dimension, []])), edges: [] } : {}) };
    await page.route(pattern, route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(fixture) }));
    try {
      await page.goto(`http://127.0.0.1:7804/?overview-insights=${state}#overview`, { waitUntil: 'domcontentloaded' });
      await panel.locator('.qp-insight-card').first().waitFor(); await settled(page, pending); await values(totals);
      const cacheMetric = page.locator('.qp-metric-rail[data-metric=cache]');
      const expectedSavings = totals.cacheSavingKnownCalls > 0 ? totals.cacheSavingKnownUsd : null;
      assert.equal(await cacheMetric.getAttribute('data-value'), expectedSavings === null ? null : String(expectedSavings), 'Cache savings remain unavailable without priced cache components, while a known zero remains measurable');
      const cacheMetricSupport = await cacheMetric.locator('.qp-metric-rail-support').first().getAttribute('title');
      const cacheMetricLines = await cacheMetric.locator('.qp-metric-rail-support').allTextContents();
      const pricingCalls = totals.nativeCalls + totals.computedCalls + totals.estimatedCalls + totals.unknownCalls;
      const inputTotal = totals.inputTokens + totals.cachedInputTokens + totals.cacheWriteTokens;
      const cacheSharePercent = inputTotal > 0 ? totals.cachedInputTokens / inputTotal * 100 : null;
      assert.equal(cacheMetricLines[0], cacheSharePercent === null ? (lang === 'th' ? th['redesign.noInput'] : en['redesign.noInput']) : `${new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US', { maximumFractionDigits: 0 }).format(cacheSharePercent)}% ${lang === 'th' ? th['redesign.cacheReadsShort'] : en['redesign.cacheReadsShort']}`);
      assert.equal(cacheMetricLines[1], pricingCalls > 0
        ? `${new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US').format(totals.cacheSavingKnownCalls)} / ${new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US').format(pricingCalls)} ${lang === 'th' ? th['redesign.cachePriceShort'] : en['redesign.cachePriceShort']}`
        : (lang === 'th' ? th['redesign.noCachePrice'] : en['redesign.noCachePrice']));
      if (pricingCalls > 0) assert.ok(cacheMetricSupport?.includes(`${new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US').format(totals.cacheSavingKnownCalls)} / ${new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US').format(pricingCalls)}`));
      else assert.ok(cacheMetricSupport?.includes(lang === 'th' ? th['redesign.noCachePrice'] : en['redesign.noCachePrice']));
      if (state === 'empty') {
        const recommendation = panel.locator('[data-insight=recommendation]');
        assert.equal(await recommendation.getAttribute('data-pricing-state'), 'unavailable');
        assert.notEqual(await recommendation.getAttribute('data-state'), 'check-pricing', 'No calls must not be described as a pricing issue');
      }
      for (const width of [390, 900, 1280]) {
        await page.setViewportSize({ width, height: 992 });
        assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `Insight card overflow: ${state}/${lang}/${theme}/${width}`);
        assert.equal(await panel.locator('.qp-insight-card').count(), 4);
        const bounds = await panel.boundingBox(); assert.ok(bounds);
        const textBoxes = await panel.locator('h3,strong,p').evaluateAll(elements => elements.map(element => { const box = element.getBoundingClientRect(); return { x: box.x, right: box.right }; }));
        assert.ok(textBoxes.every(box => box.x >= bounds.x && box.right <= bounds.x + bounds.width), 'Insight contents must stay inside their panel');
      }
      await page.setViewportSize({ width: 1586, height: 992 });
    } finally { await page.unroute(pattern); }
  }
  await page.goto(home, { waitUntil: 'domcontentloaded' }); await panel.locator('.qp-insight-card').first().waitFor(); await settled(page, pending);
  const total = graph.totals, input = total.inputTokens + total.cachedInputTokens + total.cacheWriteTokens, priced = total.nativeCalls + total.computedCalls + total.estimatedCalls;
  overviewInsightChecks.push({ lang, theme, cards: 4, cacheShare: input ? total.cachedInputTokens / input * 100 : null, pricedCalls: priced, totalCalls: priced + total.unknownCalls, states });
}

async function checkOverviewPeriod(page: Page, lang: string, theme: string, pending: Set<Request>) {
  const home = 'http://127.0.0.1:7804/?overview-period=presets#overview';
  await page.goto(home, { waitUntil: 'domcontentloaded' });
  await page.locator('.qp-quota').first().waitFor(); await settled(page, pending);
  await page.locator('.qp-quota').first().click();
  const selectedOwner = await page.locator('.qp-quota[aria-pressed=true]').getAttribute('data-owner');
  const starts = { today: Date.parse('2025-05-16T17:00:00Z'), week: Date.parse('2025-05-11T17:00:00Z'), month: Date.parse('2025-04-30T17:00:00Z'), all: 0 };
  const tokensByRange: Record<string, number> = {};
  for (const range of ['week', 'month', 'all', 'today'] as const) {
    const graphResponse = page.waitForResponse(response => new URL(response.url()).pathname === '/api/runtime-map' && response.status() === 200);
    const usageResponse = page.waitForResponse(response => new URL(response.url()).pathname === '/api/usage-events' && response.status() === 200);
    const metricResponse = page.waitForResponse(response => new URL(response.url()).pathname === '/api/usage' && response.status() === 200);
    await page.locator('.qp-overview-period select').selectOption(range);
    const response = await graphResponse;
    const query = new URL(response.url()).searchParams;
    assert.equal(query.get('from'), String(starts[range])); assert.equal(query.get('to'), String(fixedNow + 1));
    const usageQuery = new URL((await usageResponse).url()).searchParams;
    const activityTo = Math.min(Number(query.get('to')), fixedNow + 1);
    const activityFrom = Math.max(Number(query.get('from')), activityTo - 30 * 60_000);
    assert.equal(usageQuery.get('from'), String(activityFrom)); assert.equal(usageQuery.get('to'), String(activityTo));
    assert.equal(usageQuery.get('grain'), null, 'Live Activity keeps the latest observed record grain for each harness');
    const metricQuery = new URL((await metricResponse).url()).searchParams;
    assert.equal(metricQuery.get('range'), range);
    assert.equal(metricQuery.get('from'), query.get('from')); assert.equal(metricQuery.get('to'), query.get('to'));
    assert.equal(metricQuery.get('source_id'), query.get('source_id'));
    await page.locator('.qp-metrics').waitFor(); await settled(page, pending);
    const expected = (await daemon.inject({ method: 'GET', url: `/api/runtime-map?from=${starts[range]}&to=${fixedNow + 1}`, headers: { 'x-quotapulse-token': 'stable-capture-test' } })).json<RuntimeGraph>();
    assert.equal(await page.locator('.qp-metrics .qp-metric-rail strong').first().textContent(), new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US', {
      notation: 'compact',
      maximumFractionDigits: 1,
    }).format(expected.totals.tokens));
    assert.equal(new URLSearchParams(new URL(page.url()).hash.split('?')[1]).get('range'), range);
    assert.equal(await page.locator('.qp-quota[aria-pressed=true]').getAttribute('data-owner'), selectedOwner);
    assert.equal(await page.locator('.qp-overview-period select').evaluate(element => element === document.activeElement), true);
    const link = await page.locator('.qp-activity-actions>a').getAttribute('href');
    assert.equal(new URLSearchParams(link!.split('?')[1]).get('range'), range);
    tokensByRange[range] = expected.totals.tokens;
  }
  assert.ok(tokensByRange.month > tokensByRange.today, 'Period fixture must contain genuinely different totals');
  const from = starts.today, to = fixedNow + 1;
  await page.goto(`http://127.0.0.1:7804/?overview-period=custom#overview?range=custom&from=${from}&to=${to}&source=1&bucket=hour`, { waitUntil: 'domcontentloaded' });
  await page.locator('.qp-overview-period select').waitFor(); await settled(page, pending);
  assert.equal(await page.locator('.qp-overview-period select').inputValue(), 'custom');
  assert.ok((await page.locator('.qp-overview-period .qp-chip').textContent())!.includes('#1'));
  for (const width of [390, 900, 1280]) {
    await page.setViewportSize({ width, height: 992 });
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `Custom/source period control overflow: ${lang}/${theme}/${width}`);
  }
  await page.setViewportSize({ width: 1586, height: 992 });
  const scopedResponse = page.waitForResponse(response => new URL(response.url()).pathname === '/api/runtime-map' && response.status() === 200);
  await page.locator('.qp-overview-period select').selectOption('week');
  const query = new URL((await scopedResponse).url()).searchParams;
  assert.equal(query.get('source_id'), '1'); assert.equal(query.get('from'), String(starts.week));
  await page.locator('.qp-overview-period select').waitFor(); await settled(page, pending);
  const params = new URLSearchParams(new URL(page.url()).hash.split('?')[1]);
  assert.equal(params.get('source'), '1'); assert.equal(params.get('bucket'), 'hour');
  assert.equal(params.has('from'), false); assert.equal(params.has('to'), false);
  await page.reload({ waitUntil: 'domcontentloaded' }); await page.locator('.qp-overview-period select').waitFor(); await settled(page, pending);
  assert.equal(await page.locator('.qp-overview-period select').inputValue(), 'week');
  assert.ok((await page.locator('.qp-overview-period .qp-chip').textContent())!.includes('#1'));
  await page.goto(home, { waitUntil: 'domcontentloaded' }); await page.locator('.qp-overview-period select').waitFor(); await settled(page, pending);
  overviewPeriodChecks.push({ lang, theme, tokensByRange, selectedQuotaPreserved: true, customSourcePreserved: true, focusRestored: true });
}

async function checkQuotaAccess(page: Page, destination: 'overview' | 'alerts', lang: string, theme: string, pending: Set<Request>) {
  await page.setViewportSize({ width: 1672, height: 941 });
  await page.goto(`http://127.0.0.1:7804/?quota-access=${destination}#${destination}${destination === 'alerts' ? '?owner=openai%3Asubscription&window=5h' : ''}`, { waitUntil: 'domcontentloaded' });
  if (destination === 'overview') {
    const outer = page.getByTestId('quota-history');
    await outer.waitFor(); await settled(page, pending);
    assert.equal(await outer.locator('.qp-quota-chart').count(), 0, 'Collapsed Overview must not mount the full quota plot');
    await outer.locator('summary').first().focus(); await page.keyboard.press('Enter');
    assert.equal(await outer.getAttribute('open'), '');
  }
  await page.locator('.qp-quota-point').first().waitFor(); await settled(page, pending);
  const result = await daemon.inject({ method: 'GET', url: '/api/quota-history?subscription_key=openai%3Asubscription&window_kind=5h', headers: { 'x-quotapulse-token': 'stable-capture-test' } });
  assert.equal(result.statusCode, 200);
  const history = result.json<QuotaHistoryResponse>();
  const samples = history.segments.flatMap(segment => segment.samples);
  assert.ok(history.segments.length > 3 && history.segments.some(segment => segment.samples.length > 8), 'Complete-history fixture missing');
  assert.ok(samples.some(sample => sample.usedPercent === null) && samples.some(sample => sample.usedPercent === 0) && samples.some(sample => sample.usedPercent === 0.5));
  const chart = page.locator('.qp-quota-chart');
  assert.equal(await chart.locator('svg>g[data-reset]').count(), history.segments.length);
  const disclosure = chart.locator('.qp-quota-samples'); const summary = disclosure.locator('summary');
  assert.equal(await disclosure.locator('table').count(), 0, 'Collapsed quota samples must not mount all rows');
  await summary.focus(); await page.keyboard.press('Enter'); assert.equal(await disclosure.getAttribute('open'), '');
  await disclosure.locator('table').waitFor();
  assert.equal(await disclosure.locator('caption').isVisible(), true);
  assert.equal(await disclosure.locator('th[scope=col]').count(), 3);
  const expected = history.segments.flatMap(segment => segment.samples.map(sample => ({ at: sample.observedAt, value: sample.usedPercent, reset: segment.resetAt })));
  const rows = await disclosure.locator('tbody tr').evaluateAll(elements => elements.map(element => ({ at: Number(element.getAttribute('data-at')), value: element.getAttribute('data-value'), reset: element.getAttribute('data-reset'), cells: Array.from(element.querySelectorAll('td')).map(cell => cell.textContent), iso: Array.from(element.querySelectorAll('time')).map(time => time.getAttribute('datetime')) })));
  assert.equal(rows.length, expected.length);
  const locale = lang === 'th' ? 'th-TH' : 'en-US'; const number = new Intl.NumberFormat(locale, { maximumFractionDigits: 20 });
  const unknown = lang === 'th' ? 'ไม่ทราบ' : 'Unknown';
  rows.forEach((row, index) => {
    const sample = expected[index];
    assert.equal(row.at, sample.at); assert.equal(row.value, String(sample.value ?? 'unknown')); assert.equal(row.reset, String(sample.reset ?? 'unknown'));
    assert.deepEqual(row.cells, [new Date(sample.at).toLocaleString(locale), sample.value === null ? unknown : `${number.format(sample.value)}%`, sample.reset === null ? unknown : new Date(sample.reset).toLocaleString(locale)]);
    assert.deepEqual(row.iso, [new Date(sample.at).toISOString(), ...(sample.reset === null ? [] : [new Date(sample.reset).toISOString()])]);
  });
  const points = await chart.locator('.qp-quota-point').evaluateAll(elements => elements.map(element => ({ at: Number(element.getAttribute('data-at')), value: Number(element.getAttribute('data-value')), x: Number(element.getAttribute('cx')), y: Number(element.getAttribute('cy')) })));
  const known = samples.filter(sample => sample.usedPercent !== null);
  assert.equal(points.length, known.length);
  const viewBox = (await chart.locator('svg').getAttribute('viewBox'))!.split(' ').map(Number);
  const first = Math.min(...samples.map(sample => sample.observedAt)); const last = Math.max(...samples.map(sample => sample.observedAt));
  points.forEach((point, index) => {
    const sample = known[index]; assert.equal(point.at, sample.observedAt); assert.equal(point.value, sample.usedPercent);
    assert.ok(Math.abs(point.y - (6 + (100 - sample.usedPercent!) / 100 * 98)) < 0.0001, 'Incorrect percentage ordinate');
    assert.ok(Math.abs(point.x - (34 + (sample.observedAt - first) / (last - first) * (viewBox[2] - 40))) < 0.0001, 'Incorrect timestamp abscissa');
  });
  const expectedLines = history.segments.reduce((total, segment) => total + segment.samples.filter((sample, index) => index > 0 && sample.usedPercent !== null && segment.samples[index - 1].usedPercent !== null).length, 0);
  assert.equal(await chart.locator('.qp-quota-series').count(), expectedLines, 'Unknown/reset intervals must break the series');
  await page.screenshot({ path: resolve(output, `quota-expanded-${destination}-${lang}-${theme}.png`), animations: 'disabled' });
  for (const width of [390, 900, 1280]) {
    await page.setViewportSize({ width, height: 941 });
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `${destination}: quota table overflow at ${width}`);
  }
  await summary.focus(); await page.keyboard.press('Enter'); assert.equal(await disclosure.getAttribute('open'), null);
  await disclosure.locator('table').waitFor({ state: 'detached' });
  if (destination === 'overview') { const outer = page.getByTestId('quota-history'); await outer.locator('summary').first().focus(); await page.keyboard.press('Enter'); assert.equal(await outer.getAttribute('open'), null); await outer.locator('.qp-quota-chart').waitFor({ state: 'detached' }); }
  quotaChecks.push({ page: destination, lang, theme, segments: history.segments.length, samples: samples.length, unknown: samples.filter(sample => sample.usedPercent === null).length });
  if (destination === 'overview') {
    const pattern = '**/api/quota-history?**';
    for (const state of ['unknown', 'empty', 'recovered']) {
      if (state !== 'recovered') await page.route(pattern, route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ ...history, segments: state === 'empty' ? [{ resetAt: history.reader!.resetAt, samples: [] }] : history.segments.map(segment => ({ ...segment, samples: segment.samples.map(sample => ({ ...sample, usedPercent: null })) })) }) }));
      try {
        await page.goto(`http://127.0.0.1:7804/?quota-state=${state}#overview`, { waitUntil: 'domcontentloaded' });
        const outer = page.getByTestId('quota-history');
        try { await outer.waitFor(); } catch (error) {
          console.log('Quota history wait diagnostics', { state, lang, theme, url: page.url(), text: (await page.locator('body').innerText()).slice(0, 2200), pending: [...pending].map(request => new URL(request.url()).pathname), errors });
          throw error;
        }
        await settled(page, pending);
        await outer.locator('summary').first().focus(); await page.keyboard.press('Enter');
        if (state === 'empty') {
          await outer.getByRole('status').waitFor();
          assert.equal(await outer.locator('svg.qp-alert-segments').count(), 0, 'Empty history must not create an invalid time axis');
        } else {
          await outer.locator('.qp-quota-samples').waitFor();
          assert.equal(await outer.locator('.qp-quota-point').count(), state === 'unknown' ? 0 : known.length);
          if (state === 'unknown') {
            assert.equal(await outer.locator('.qp-quota-series').count(), 0);
            await outer.locator('.qp-quota-samples summary').focus(); await page.keyboard.press('Enter');
            await outer.locator('table').waitFor();
            assert.equal(await outer.locator('tr[data-value=unknown]').count(), samples.length);
          }
        }
      } finally { if (state !== 'recovered') await page.unroute(pattern); }
    }
  }
}



try {
 await daemon.listen({host:'127.0.0.1',port:7816});
 browser=await chromium.launch({channel:'chrome',headless:true,args:rendererArgs});
 const page=await browser.newPage({viewport:{width:1672,height:941},reducedMotion:'reduce',deviceScaleFactor:1,timezoneId:'Asia/Bangkok'});
 const pending=new Set<Request>();
 page.on('request',r=>{if(new URL(r.url()).pathname.startsWith('/api/')&&!r.url().includes('/events/stream'))pending.add(r)});
 page.on('requestfinished',r=>pending.delete(r));page.on('requestfailed',r=>pending.delete(r));
 await page.addInitScript(({lang,theme})=>{(window as unknown as {__QUOTAPULSE_TOKEN__:string}).__QUOTAPULSE_TOKEN__='stable-capture-test';localStorage.setItem('quotapulse-prefs',JSON.stringify({lang,currency:'USD',rate:1,hiddenSubscriptions:[]}));localStorage.setItem('quotapulse-theme',theme)},{lang:taskLang,theme:taskTheme});
 await page.clock.setFixedTime(fixedNow);
 const results=[];
async function checkNativeHeadingArt57(page: Page, route: string, native: boolean) {
 const mark = page.locator('.qp-page-heading-icon>svg.qp-heading-reference-svg');
 assert.equal(await mark.count(),1,`${route}: one decorative heading SVG`);
 const art=await mark.evaluate(svg=>{
  const r=svg.getBoundingClientRect();const shapes=[...svg.children];
  return {width:r.width,height:r.height,ariaHidden:svg.getAttribute('aria-hidden'),focusable:svg.getAttribute('focusable'),nativeDisplay:getComputedStyle(svg.querySelector('.qp-heading-reference-mark')!).display,fallbackDisplays:shapes.filter(el=>!el.classList.contains('qp-heading-reference-mark')).map(el=>getComputedStyle(el).display)};
 });
 assert.equal(art.ariaHidden,'true');assert.equal(art.focusable,'false');
 assert.equal(art.nativeDisplay,native?'inline':'none');
 assert.ok(art.fallbackDisplays.length>0);assert.ok(art.fallbackDisplays.every(d=>native?d==='none':d!=='none'));
 assert.equal(art.width,native?({live:28,models:28,alerts:32}[route]!):(route==='alerts'?26:21));
 assert.equal(art.height,art.width);return art;
}

 const expected:Record<string,{top:number;height:number;footer:number;pitch:number}>={overview:{top:421,height:289,footer:64,pitch:45},live:{top:442,height:291,footer:59,pitch:47.5},projects:{top:408,height:299,footer:65,pitch:46.5},models:{top:443,height:305,footer:64,pitch:47.5},providers:{top:444,height:305,footer:68,pitch:47.5},cost:{top:447,height:293,footer:63,pitch:47.5},history:{top:444,height:305,footer:65,pitch:47.5},alerts:{top:416,height:289,footer:68,pitch:47.5}};
 for(const route of Object.keys(expected)){
  await page.setViewportSize(route==='overview'?{width:1586,height:992}:{width:1672,height:941});
  await page.goto(`http://127.0.0.1:7816/?sidebar=${route}#${route}${route==='cost'?'?range=month':''}`,{waitUntil:'domcontentloaded'});
  await page.getByTestId(`production-${route}`).waitFor();await settled(page,pending);
  await page.waitForFunction(()=>/^\d[\d,]*$/.test(document.querySelector('[data-stat=models]')?.textContent??''));
  if(route==='history') {await page.locator('[data-history-detail-rail]').waitFor();await page.screenshot({path:resolve(output,'history-fresh-entry.png'),animations:'disabled'});writeFileSync(resolve(output,'history-entry-state.json'),JSON.stringify({scope:'Fresh actual History entry with non-blocking selected-record rail; before font/sidebar interactions',selected:await page.locator('#history-detail-title span').textContent(),row:await page.locator('[data-testid=usage-history] tr[data-selected=true]').innerText(),related:await page.locator('.qp-history-detail-actions>a').getAttribute('href')}));}
  if(await page.locator('dialog[open]').count())await page.keyboard.press('Escape');
  await checkFontAccess(page,route,taskLang,taskTheme);
  const brandMarks=await page.locator('.qp-brand>svg,.qp-sidebar-brand>svg').evaluateAll(els=>els.map(e=>({rect:e.getBoundingClientRect().toJSON(),legacy:getComputedStyle(e.querySelector('.qp-brand-mark-legacy')!).display,source:getComputedStyle(e.querySelector('.qp-brand-mark-source')!).display,focusable:e.getAttribute('focusable'),hidden:e.getAttribute('aria-hidden')})));
  assert.ok(brandMarks.every(m=>m.hidden==='true'&&m.focusable==='false'&&m.legacy===(taskTheme==='dark'?'none':'inline')&&m.source===(taskTheme==='dark'?'inline':'none')));
  const heading=await page.locator('.qp-redesign main h1').evaluateAll(els=>els.map(el=>{const r=el.getBoundingClientRect(),cs=getComputedStyle(el);return {text:el.textContent,x:r.x,y:r.y,width:r.width,height:r.height,font:cs.fontFamily,fontSize:cs.fontSize,fontWeight:cs.fontWeight,lineHeight:cs.lineHeight,transform:cs.transform}}));
  const controls=await page.locator('.qp-redesign main button:visible').evaluateAll(els=>els.slice(0,8).map(el=>{const r=el.getBoundingClientRect();return {text:el.textContent,x:r.x,y:r.y,width:r.width,height:r.height}}));
  assert.equal(heading.length,1);assert.ok(heading[0].height>0);
  assert.equal(await page.locator('.qp-nav-more a[href="#cost?range=month"]').textContent(),taskLang==='en'?'Cost Analysis':'ค่าใช้จ่าย');
  const warning=route==='alerts'?await page.locator('.qp-alert-forecast-warning').evaluate(el=>{const r=el.getBoundingClientRect(),cs=getComputedStyle(el),mark=el.querySelector('.qp-alert-forecast-warning-icon')!,m=mark.getBoundingClientRect(),svg=mark.querySelector('svg')!,b=svg.getBoundingClientRect();return {text:el.textContent,x:r.x,y:r.y,width:r.width,height:r.height,background:cs.background,alignment:cs.alignItems,mark:{display:getComputedStyle(mark).display,x:m.x,y:m.y,width:m.width,height:m.height,ariaHidden:mark.getAttribute('aria-hidden'),svgWidth:b.width,svgHeight:b.height,focusable:svg.getAttribute('focusable')}}}):null;
  if(warning){assert.equal(warning.mark.ariaHidden,'true');assert.equal(warning.mark.focusable,'false');assert.equal(warning.mark.svgWidth,28);assert.equal(warning.mark.svgHeight,28);assert.equal(warning.mark.display,taskTheme==='dark'?'grid':'contents');if(taskTheme==='dark'){assert.equal(warning.mark.width,44);assert.equal(warning.mark.height,44)}assert.ok(warning.text?.includes(taskLang==='en'?'Forecast reaches full use before reset':th['redesign.alertForecast']))}
  const headingArt=['live','models','alerts'].includes(route)?await checkNativeHeadingArt57(page,route,taskTheme==='dark'):null;
  const states=[];
  for(const state of ['default']){
   const more=page.locator('.qp-nav-more');
   if(state!=='default'&&(await more.getAttribute('open')!==null)!==(state==='open')){await more.locator('summary').focus();await page.keyboard.press('Enter');await settled(page,pending)}
   await page.evaluate(()=>{const e=document.activeElement;if(e instanceof HTMLElement)e.blur();document.querySelector('.qp-sidebar')!.scrollTop=0});await page.mouse.move(0,0);
   const geometry=await page.locator('.qp-sidebar').evaluate(el=>{
    const nav=el.querySelector('nav')!,quick=el.querySelector('.qp-quick-stats')!,footer=el.querySelector('.qp-sidebar-brand')!;
    const rows=[...nav.querySelectorAll(':scope>a')];
    const boxes=[el,nav,quick,footer,el.querySelector('.qp-nav-count')!,...rows].map(n=>{const r=n.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom}});
    return {open:el.querySelector('details')!.hasAttribute('open'),sidebar:boxes[0],clientHeight:el.clientHeight,scrollHeight:el.scrollHeight,nav:boxes[1],quick:boxes[2],footer:boxes[3],links:nav.querySelectorAll('a').length,rows:rows.map((a,i)=>({label:a.querySelector('span')!.textContent,...boxes[i+5]})),badge:boxes[4]};
   });
   assert.equal(geometry.links,9);assert.ok(geometry.nav.bottom<=geometry.quick.y+1,`${route}/${state}: navigation/card overlap`);assert.ok(geometry.quick.bottom<=geometry.footer.y+1,`${route}/${state}: card/footer overlap`);
   for(let i=1;i<geometry.rows.length;i++)assert.ok(Math.abs(geometry.rows[i].y-geometry.rows[i-1].y-expected[route].pitch)<=.1,`${route}: source row pitch`);
   if(!geometry.open){assert.ok(Math.abs(geometry.quick.y-expected[route].top)<=2,`${route}: source card top ${geometry.quick.y}`);assert.ok(taskLang==='en'?Math.abs(geometry.quick.height-expected[route].height)<=2:geometry.quick.height>=expected[route].height-2,`${route}: source card height ${geometry.quick.height}`);assert.ok(Math.abs(geometry.footer.height-expected[route].footer)<=2,`${route}: source footer height`)}
   await page.screenshot({path:resolve(output,`${route}-${state}.png`),animations:'disabled'});states.push({state,geometry});
  }
  results.push({route,states,brandMarks,heading,controls,warning,headingArt,costPaint:route==='cost'?await page.locator('.qp-cost-column').evaluateAll(els=>els.map(el=>({rect:el.getBoundingClientRect().toJSON(),height:(el as HTMLElement).style.height,background:getComputedStyle(el).backgroundImage,shadow:getComputedStyle(el).boxShadow,filter:getComputedStyle(el).filter}))):null,historyPaint:route==='history'?await page.locator('.qp-history-records').evaluate(el=>({card:el.getBoundingClientRect().toJSON(),background:getComputedStyle(el).backgroundColor,rows:[...el.querySelectorAll('tbody tr')].map(row=>({selected:row.getAttribute('data-selected'),rect:row.getBoundingClientRect().toJSON(),background:getComputedStyle(row).backgroundColor,cells:[...row.querySelectorAll('td')].map(cell=>({text:cell.textContent,rect:cell.getBoundingClientRect().toJSON(),background:getComputedStyle(cell).backgroundColor}))}))})):null});console.log(`Sidebar geometry passed: ${route}`);
 }
 writeFileSync(resolve(output,'geometry.json'),JSON.stringify({language:taskLang,theme:taskTheme,productionIndexSha256:sha(readFileSync(resolve(root,'packages/web/dist/index.html'))),results}));
 console.log('Final native eight-page capture, actual History fresh entry, font and sidebar geometry passed.');
}finally{await browser?.close();await daemon.close();db.close();globalThis.Date=realDate;process.env.TZ=priorTimezone;}
