# QuotaPulse Pet Mode v2 — Motion Extension Pack

This pack bridges the gap between the approved **static character concepts** and the current runtime, which already supports richer motion such as walking, sitting, lying down, sleeping, waking and stretching.

## Core decision

The original concept sheets remain the **identity/style source of truth**.

Do not overwrite them to include every runtime pose.

Instead use this pack as the new production layer:

```text
Original Concept
    ↓
Character Model / Pose Rules
    ↓
Motion Extension Sheet
    ↓
Animation Production Assets
    ↓
Runtime Integration
    ↓
Visual QA
```

## Stable characters covered
- Orbit Bot
- Pulse Fox
- Flux Blob
- Capsule Cat

## Bonus policy
Nova / Byte / Mochi / Kuro remain Experimental.
They receive motion-readiness guidance, not a full Stable production burden yet.

## Important
The visual reference boards in `01_visual_reference/` are concept/reference material. Final runtime animations should still be normalized to consistent transparent canvases, pivots, naming and reduced-motion fallbacks.
