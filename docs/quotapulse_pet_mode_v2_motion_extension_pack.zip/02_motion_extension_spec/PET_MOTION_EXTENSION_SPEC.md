# Pet Motion Extension Specification

## 1. Purpose

Pet Mode runtime has evolved beyond the first concept boards.

The original boards establish:
- identity,
- silhouette,
- face language,
- QuotaPulse brand anchors,
- color semantics,
- state personality.

The runtime now also needs:
- locomotion,
- resting poses,
- transitions,
- sleep/wake,
- interaction reactions,
- consistent side views.

This specification defines the missing production layer.

---

# 2. Source-of-truth hierarchy

Use this priority when visual decisions conflict:

1. **Original approved character concept**
2. **Character-specific pose spec**
3. **Motion Extension reference board**
4. **Generated production frame**
5. **Runtime fallback**

The original concept always wins for:
- face,
- proportions,
- silhouette,
- brand elements.

The runtime spec wins for:
- naming,
- pivot,
- playback,
- supported motions,
- reduced-motion behavior.

---

# 3. Required Motion Extension Set

Each Stable character should support:

## Identity / model
- front
- left
- right
- back
- 3/4
- neutral standing/idle

## Micro-expression
- blink
- look_left
- look_right
- curious
- happy
- concerned
- warning
- critical
- tired/sleepy

## Locomotion
- walk_left
- walk_right
- turn_left
- turn_right
- stop_left
- stop_right

## Rest
- sit
- lie_down
- sleep_loop
- wake_up
- stretch

## Interaction
- hover_react
- click_react
- talk_loop

## Existing core state
- healthy_idle
- working_loop
- warning_intro
- warning_loop
- critical_intro
- critical_loop
- reset_celebrate

---

# 4. Pose-sheet requirement

Before producing final animation clips, create one normalized pose/model sheet per Stable character.

Each sheet should include:

```text
Front / 3-4 / Side / Back

Idle
Walk key pose A
Walk passing pose
Walk key pose B
Turn
Stop

Sit
Lie down
Sleep
Wake
Stretch

Look left/right
Talk
Hover
Click

Warning
Critical
Reset
```

The purpose is to lock visual consistency before generating many frames.

---

# 5. Canvas contract

Recommended master:

```text
1024 x 1024
transparent background
full body
fixed pivot
consistent character scale
```

Per-character frames must share:
- identical canvas,
- identical pivot,
- consistent baseline,
- consistent body proportions.

Recommended normalized pivot:

```text
x = 0.5
y = 0.90–0.94
```

Flux Blob uses a nominal floating baseline/shadow line rather than feet.

---

# 6. Motion ownership

Separate:

```text
Character animation
≠
Desktop translation
```

A walk loop should show the walking cycle.

The Pet window/controller should perform actual screen movement.

Do not generate a walk clip where the character traverses hundreds of pixels inside the animation canvas.

---

# 7. Direction handling

Preferred:

- produce canonical `walk_right`
- produce native `walk_left` when asymmetrical details require it
- mirroring is acceptable only when it does not reverse logos, UI glyphs, antenna hardware, accessories or asymmetric markings incorrectly.

If mirrored output changes semantic brand details, use dedicated left/right assets.

---

# 8. Rest-state rules

## Sit
Must feel character-specific.

## Lie down
Must preserve recognizable silhouette.

## Sleep
Should be low-motion and loopable.

## Wake
Short transition back toward neutral.

## Stretch
Should communicate personality, not merely reuse a generic squash.

---

# 9. Stable character personality mapping

## Orbit Bot
Motion:
- deliberate,
- clean mechanical turns,
- compact servo steps,
- low-power sleep,
- antenna/status-led expression.

Avoid:
- animal-like limb motion,
- overly bouncy walk.

## Pulse Fox
Motion:
- organic gait,
- ears and tail lead emotion,
- comfortable sit/curl,
- expressive wake/stretch.

Avoid:
- robotic timing,
- stiff repeated tail movement.

## Flux Blob
Motion:
- glide instead of literal walk,
- squash/stretch,
- settle/compress for rest,
- low floating sleep.

Avoid:
- inventing fake legs to match the other characters.

## Capsule Cat
Motion:
- compact robotic-cat gait,
- loaf/sit,
- tail and LED-ear cues,
- curl/rest behaviors.

Avoid:
- becoming visually identical to Pulse Fox motion.

---

# 10. Transition contract

Recommended runtime flow:

```text
idle
  ↓
turn
  ↓
walk/glide
  ↓
stop
  ↓
idle
```

Rest flow:

```text
idle
  ↓
sit
  ↓
lie_down
  ↓
sleep_loop
  ↓
wake_up
  ↓
stretch
  ↓
idle
```

Urgent events interrupt rest:

```text
sleep
  ↓ critical/warning event
wake/cancel
  ↓
event reaction
```

Do not force a long decorative transition before showing Critical.

---

# 11. Reduced motion

Reduced motion does not remove status meaning.

Disable/reduce:
- autonomous locomotion,
- large stretch,
- strong bounce,
- dramatic shake.

Keep:
- static pose change,
- subtle blink,
- semantic color/status,
- speech bubble.

---

# 12. Runtime asset naming

```text
<character>/
  model/
  core/
  locomotion/
  rest/
  interaction/
  expressions/
```

Example:

```text
orbit-bot/
  locomotion/
    walk_left.webp
    walk_right.webp
    turn_left.webp
    turn_right.webp
    stop_left.webp
    stop_right.webp

  rest/
    sit.webp
    lie_down.webp
    sleep_loop.webp
    wake_up.webp
    stretch.webp
```

---

# 13. Production order

## Stage 1 — model lock
For all 4 Stable characters:
- turnaround,
- idle,
- side profile,
- proportions.

## Stage 2 — locomotion key poses
- walk/glide,
- turn,
- stop.

## Stage 3 — rest key poses
- sit,
- lie,
- sleep,
- wake,
- stretch.

## Stage 4 — production animation
Convert approved poses into loops/transitions.

## Stage 5 — runtime export
- transparent WebP,
- 512/256,
- metadata,
- fallback.

## Stage 6 — QA
- silhouette,
- pivot,
- frame jitter,
- identity drift,
- status consistency.

---

# 14. Acceptance criteria

Motion Extension is ready when:

- [ ] all 4 Stable characters have approved model/pose sheets
- [ ] walk/glide direction is visually correct
- [ ] sit/lie/sleep preserve identity
- [ ] left/right assets do not incorrectly mirror branding
- [ ] frames use consistent canvas/pivot
- [ ] no background baked into runtime assets
- [ ] Flux Blob uses character-appropriate locomotion
- [ ] rest behaviors differ meaningfully between characters
- [ ] reduced-motion fallback exists
- [ ] runtime does not depend on concept-board backgrounds/text
