# Recommended Execution Order

1. Keep current runtime implementation intact.
2. Approve the new Motion Extension reference board.
3. Produce/finalize Orbit Bot pose sheet.
4. Produce/finalize Pulse Fox pose sheet.
5. Produce/finalize Flux Blob pose sheet.
6. Produce/finalize Capsule Cat pose sheet.
7. Freeze model/pivot per character.
8. Produce runtime walk/glide/turn/stop assets.
9. Produce sit/lie/sleep/wake/stretch assets.
10. Integrate assets.
11. Run visual consistency QA.
12. Only then start Bonus readiness sheets.
