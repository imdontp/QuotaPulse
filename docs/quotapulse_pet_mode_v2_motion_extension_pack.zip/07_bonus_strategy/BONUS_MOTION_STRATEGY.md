# Bonus Character Motion Strategy

Bonus candidates:
- Nova
- Byte
- Mochi
- Kuro

Do not produce the entire Stable motion library for all four immediately.

## Step 1 — readiness sheet
For each candidate produce:
- front
- side
- idle
- movement direction
- sit/rest
- sleep
- one interaction pose

## Step 2 — evaluate
Check:
- silhouette consistency
- uniqueness vs Stable roster
- compatibility with Pet runtime
- animation difficulty
- small-size readability

## Step 3 — promote selectively
Only candidates promoted to Beta receive the full Motion Extension production set.

This prevents the asset workload from doubling before the Stable roster is visually complete.
