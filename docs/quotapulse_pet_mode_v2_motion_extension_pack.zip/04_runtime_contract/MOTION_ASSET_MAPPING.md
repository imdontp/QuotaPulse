# Motion Asset Mapping

Runtime semantic IDs can remain shared even if visual execution differs.

| Runtime semantic | Orbit Bot | Pulse Fox | Flux Blob | Capsule Cat |
|---|---|---|---|---|
| move_left | walk | walk | glide | walk |
| move_right | walk | walk | glide | walk |
| turn | mechanical rotate | organic turn | morph orientation | cat/robot turn |
| sit | compact sit | fox sit | squash rest | cat sit/loaf |
| lie_down | low-power rest | lie/curl | flatten | curl/loaf |
| sleep | low-power | curled sleep | low float | loaf/curl sleep |
| wake | system wake | ears-first wake | core rise | LED/ear wake |
| stretch | mechanical stretch | fox stretch | elongate | feline stretch |

This is intentional.

Do not force identical animation semantics to look identical.
