# Pose Approval Matrix

| Pose | Orbit Bot | Pulse Fox | Flux Blob | Capsule Cat |
|---|---|---|---|---|
| Front | ☐ | ☐ | ☐ | ☐ |
| 3/4 | ☐ | ☐ | ☐ | ☐ |
| Side | ☐ | ☐ | ☐ | ☐ |
| Back | ☐ | ☐ | ☐ | ☐ |
| Idle | ☐ | ☐ | ☐ | ☐ |
| Move L | ☐ | ☐ | ☐ | ☐ |
| Move R | ☐ | ☐ | ☐ | ☐ |
| Turn | ☐ | ☐ | ☐ | ☐ |
| Stop | ☐ | ☐ | ☐ | ☐ |
| Sit | ☐ | ☐ | ☐ | ☐ |
| Lie Down | ☐ | ☐ | ☐ | ☐ |
| Sleep | ☐ | ☐ | ☐ | ☐ |
| Wake | ☐ | ☐ | ☐ | ☐ |
| Stretch | ☐ | ☐ | ☐ | ☐ |
| Talk | ☐ | ☐ | ☐ | ☐ |
| Hover | ☐ | ☐ | ☐ | ☐ |
| Click | ☐ | ☐ | ☐ | ☐ |
