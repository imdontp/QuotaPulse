# Visual Consistency Checklist

For each Stable character:

## Identity
- [ ] face matches approved concept
- [ ] silhouette matches
- [ ] proportions stable
- [ ] brand anchor position stable
- [ ] semantic status colors correct

## Turnaround
- [ ] front approved
- [ ] 3/4 approved
- [ ] side approved
- [ ] back approved

## Locomotion
- [ ] walk/glide reads clearly
- [ ] turn direction correct
- [ ] stop transition clean
- [ ] left/right branding not incorrectly mirrored

## Rest
- [ ] sit is character-specific
- [ ] lie_down readable
- [ ] sleep loop suitable
- [ ] wake transition suitable
- [ ] stretch suitable

## Runtime
- [ ] transparent background
- [ ] same canvas
- [ ] same pivot
- [ ] no crop jitter
- [ ] no baked desktop movement
- [ ] 256px readability
- [ ] 128px silhouette readability
- [ ] reduced-motion fallback
