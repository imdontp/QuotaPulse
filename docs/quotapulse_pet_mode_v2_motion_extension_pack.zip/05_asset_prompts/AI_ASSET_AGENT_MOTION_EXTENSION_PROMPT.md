# AI Asset Agent Prompt — Motion Extension

Use the approved original concept image for the selected character and the matching character pose spec.

## Mission
Create a normalized **production pose sheet** before producing final animation frames.

## Required poses
- front
- 3/4
- side
- back
- idle
- move/walk key pose A
- passing pose
- move/walk key pose B
- turn
- stop
- sit
- lie down
- sleep
- wake
- stretch
- look left
- look right
- talk
- hover reaction
- click reaction
- warning
- critical
- reset

## Non-negotiable
- preserve approved concept identity
- same proportions and silhouette
- preserve QuotaPulse brand anchors
- no background in production outputs
- no text inside runtime character assets
- fixed canvas and pivot
- no uncontrolled translation
- left/right mirroring only if safe for asymmetric design
- reduced-motion fallback required

## Character-specific
Orbit Bot: compact mechanical motion.
Pulse Fox: organic ears/tail/body motion.
Flux Blob: glide/morph; no fake legs.
Capsule Cat: compact robotic-cat motion with tail/ear cues.

## Output order
1. pose sheet for approval
2. corrected pose sheet
3. animation key frames
4. runtime exports
