# AI Coding Agent Prompt — Integrate Motion Extension Assets

You are integrating approved Motion Extension assets into the existing QuotaPulse Pet Mode.

## Rules
- do not redesign quota/focus/tray logic
- original concept identity stays unchanged
- Pet State Engine remains shared
- desktop movement stays in movement controller
- animation assets do not own screen translation

## Work
1. inspect current runtime animation ids and asset folders
2. map the Motion Extension contract to existing ids
3. preserve backwards compatibility where possible
4. add rest-state assets:
   - sit
   - lie_down
   - sleep_loop
   - wake_up
   - stretch
5. validate walk/glide assets
6. ensure fixed canvas/pivot
7. add reduced-motion fallbacks
8. verify missing asset fallback
9. add visual/regression tests where practical

## Special case
Flux Blob may satisfy walk semantic ids with glide assets.
Do not add fake walking legs.

## Deliverables
- mapping table
- changed files
- missing assets
- fallback decisions
- QA results
