# Flux Blob — Production Pose Spec

## Identity anchors
- translucent fluid body
- embedded quota ring
- face inside front surface
- floating bubbles/orbs
- cyan/blue fluid palette

## Turnaround
Use:
- front
- side-ish orientation
- back
- 3/4 through blob/core orientation

## Locomotion
Do not literally walk.

Runtime semantic ids may still be `walk_left/right`, but visual implementation is:
- glide
- lean
- squash/stretch propulsion
- bubbles trail/settle

`turn`
- body/core orientation morph
- face rotates/slides naturally

`stop`
- soft overshoot then settle wobble

## Rest
`sit`
- compressed/squished resting blob

`lie_down`
- flattened relaxed blob

`sleep_loop`
- low float/flattened form
- slow internal pulse
- calm bubbles

`wake_up`
- core brightens
- shape rises

`stretch`
- elongated squash/stretch then settle

## Do not
- invent legs
- turn it into a robot/animal
- lose translucent-fluid identity
