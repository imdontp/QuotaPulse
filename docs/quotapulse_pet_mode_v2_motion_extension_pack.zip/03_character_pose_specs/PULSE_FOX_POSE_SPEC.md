# Pulse Fox — Production Pose Spec

## Identity anchors
- fox silhouette
- blue/cyan accents
- collar quota ring/status
- expressive ears
- large expressive tail

## Turnaround
- front
- 3/4
- side
- back

## Locomotion
`walk`
- natural compact fox gait
- head and tail counterbalance
- ears react softly

`turn`
- head leads
- shoulders/body follow
- tail completes motion

`stop`
- soft settle
- tail catches up

## Rest
`sit`
- classic fox seated posture

`lie_down`
- paws forward or curled rest

`sleep_loop`
- curl/comfortable rest
- slow breathing
- ears/tail occasionally twitch

`wake_up`
- ears react first
- eyes open
- body follows

`stretch`
- front-leg / body stretch
- tail lift

## Do not
- remove collar/status anchor
- make gait robotic
- make tail motion loop mechanically
