# Capsule Cat — Production Pose Spec

## Identity anchors
- compact capsule-shaped robotic cat
- screen face
- LED ears
- chest quota ring
- smart segmented tail

## Turnaround
- front
- 3/4
- side
- back

## Locomotion
`walk`
- short compact cat-like steps
- robotic but feline
- tail balances direction

`turn`
- ears/head respond first
- capsule body follows

`stop`
- paws/body settle
- tail settles last

## Rest
`sit`
- compact cat sit

`lie_down`
- curl or robotic loaf transition

`sleep_loop`
- loaf/curl
- dim screen eyes
- slow ear LED pulse

`wake_up`
- ears light first
- screen face wakes
- tail rises

`stretch`
- feline stretch adapted to capsule geometry

## Do not
- turn into Pulse Fox proportions
- remove capsule silhouette
- make tail purely decorative
