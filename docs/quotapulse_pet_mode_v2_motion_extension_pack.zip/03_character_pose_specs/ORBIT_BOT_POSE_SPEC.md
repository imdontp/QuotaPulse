# Orbit Bot — Production Pose Spec

## Identity anchors
- compact white/silver robot shell
- black screen face
- cyan status language
- chest quota ring / usage mark
- antenna/live indicator

## Turnaround
Required:
- front
- 3/4
- side
- back

## Locomotion
`walk_right`
- measured small mechanical steps
- body center remains stable
- subtle antenna counter-motion

`walk_left`
- dedicated asset if chest/antenna asymmetry cannot be mirrored safely

`turn`
- body rotates first, feet settle second
- screen face tracks direction

`stop`
- tiny braking/servo settle

## Rest
`sit`
- compact powered-down seated pose

`lie_down`
- lower shell/body, still recognizable as Orbit Bot

`sleep_loop`
- dim eyes
- slow antenna pulse
- tiny low-power breathing/servo motion

`wake_up`
- eyes brighten
- antenna activates

`stretch`
- controlled arm/body extension; still mechanical

## Do not
- give animal gait
- add new limbs
- move quota ring location
