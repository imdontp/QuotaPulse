from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / 'tmp/prepare-rollback249.py').read_text(encoding='utf-8')
previous = "('previous', '243', 'QuotaPulse-v1.85.242-review243.zip', './archive.json', '05b737fcf86a81489e44a6122abc24ec2a475858305fdcd4f3fa3a52f1018e67')"
current = "('current', '249', 'QuotaPulse-v1.85.248-review249.zip', 'archive.json', '86b49b46373dd3690326f6bb4b18dccd22c27bb87a3e60b3a85702581f6ae0c1')"
new_previous = current.replace("'current'", "'previous'", 1)
new_current = "('current', '257', 'QuotaPulse-v1.85.256-review257.zip', 'build/archive.json', 'ca16be89696ce45481f4e0c56f4840012bf745aee29fcf0de1259e33d172124a')"
assert previous in source and current in source
source = source.replace(previous, new_previous).replace(current, new_current)
source = source.replace('tmp/rollback249', 'tmp/rollback257')
source = source.replace("'rollback236', 'rollback249'", "'rollback236', 'rollback257'")
source = source.replace("'native236', 'native249'", "'native236', 'native257'")
source = source.replace("f'{stem}249.{ext}'", "f'{stem}257.{ext}'")
target = root / 'tmp/prepare-rollback257.py'
assert not target.exists()
target.write_text(source, encoding='utf-8', newline='\n')
