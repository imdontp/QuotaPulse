import json
from pathlib import Path
from PIL import Image, ImageChops
root=Path('tmp/quota116')
before=json.loads((root/'before/quota-rows.json').read_text())
after=json.loads((root/'after/quota-rows.json').read_text())
facts=['owner','window','text','aria','selected','stale','fillStyle','background','numberColor']
assert len(before)==len(after)==5
for first,last in zip(before,after):
    for key in facts: assert first[key]==last[key],key
    assert first['rect']==last['rect']
old=json.loads((root/'before/verification.json').read_text())
new=json.loads((root/'after/verification.json').read_text())
assert old['results'][0]['geometry']==new['results'][0]['geometry']
def diff(a,b):
    channels=ImageChops.difference(Image.open(a).convert('RGB'),Image.open(b).convert('RGB')).split()
    delta=ImageChops.lighter(ImageChops.lighter(channels[0],channels[1]),channels[2]); hist=delta.histogram()
    return dict(changedPixels=sum(hist[1:]),maxChannelDelta=max(i for i,n in enumerate(hist) if n),bounds=delta.getbbox())
left=Image.open(root/'before/overview.png').convert('RGB'); right=Image.open(root/'after/overview.png').convert('RGB')
changed=outside=0; bounds=None
for y in range(left.height):
    for x in range(left.width):
        if left.getpixel((x,y))!=right.getpixel((x,y)):
            changed+=1
            if not (1235<=x<1558 and 144<=y<451): outside+=1
report=dict(productionIndexSha256=new['productionIndexSha256'],preservedRows=5,preservedFacts=facts,quotaRowAndShellGeometryEqual=True,
    beforeAfter=diff(root/'before/overview.png',root/'after/overview.png'),pixelsOutsideQuotaRows=outside,
    immediateRepeat=diff(root/'after/overview.png',root/'after/overview-repeat.png'),
    usageColumn={phase:{'x':rows[0]['parts'][2]['rect']['x'],'width':rows[0]['parts'][2]['rect']['width']} for phase,rows in [('before',before),('after',after)]},
    scope='Native quota composition only; no whole-reference acceptance claim')
(root/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
