import assert from 'node:assert/strict';
import { readFileSync,writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { chromium } from 'playwright';
const root=resolve('docs/redesign-v1.85.159'),report=JSON.parse(readFileSync(resolve(root,'evidence/canonical-current.json')));assert.equal(report.productionIndexSha256,createHash('sha256').update(readFileSync('packages/web/dist/index.html')).digest('hex'));
const browser=await chromium.launch({channel:'chrome',headless:true});
try{
 const page=await browser.newPage(),errors=[],cases=[];page.on('pageerror',error=>errors.push(error.message));await page.goto(pathToFileURL(resolve(root,'review.html')).href);
 for(const mode of ['refs','before']){await page.locator('#left-source').selectOption(mode);await page.waitForFunction(mode=>['left','right'].every(id=>{const img=document.getElementById(id);return img.complete&&img.naturalWidth===1672&&img.naturalHeight===941&&decodeURI(img.currentSrc).endsWith((id==='left'?mode:'after')+'/cost.png')}),mode);cases.push(mode+'/cost');}
 assert.equal(cases.length,2);assert.deepEqual(errors,[]);writeFileSync(resolve(root,'evidence/viewer.json'),JSON.stringify({status:'passed',productionIndexSha256:report.productionIndexSha256,browser:browser.version(),cases,errors},null,2)+'\n');console.log(JSON.stringify({checked:cases.length,errors}));
}finally{await browser.close()}
