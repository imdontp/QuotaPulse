from pathlib import Path
import gzip,hashlib,json,sys
out=Path('docs/redesign-v1.85.159');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,compressed=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not compressed and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0) if compressed else b)
def log(path):
 b=Path(path).read_bytes();return b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
before=load('tmp/fidelity158/final/verification.json');after=load('tmp/fidelity159/final/verification.json');focused=load('screens/cost-range-picker/verification.json');diffs=load('tmp/fidelity159/analysis.json')
index=sha(Path('packages/web/dist/index.html').read_bytes())
assert before['productionIndexSha256']=='858169c3266facfdce012d87299a52466ca47b7c8ca137b6c273a979ac2cfd20'
assert after['productionIndexSha256']==focused['productionIndexSha256']==index
assert load('tmp/cost159-build-result.json')['status']==0
assert len(focused['cases'])==16 and len(focused['dstCases'])==4 and focused['bareCostAllTime'] and focused['errors']==[]
calendar=load('screens/usage-calendar/verification.json');history=load('screens/history-range-picker/verification.json')
assert calendar['productionIndexSha256']==history['productionIndexSha256']==index
assert len(calendar['checks'])==42 and len(history['cases'])==16 and history['errors']==[]
assert '# pass 353' in log('tmp/cost159-web-tests.log') and '# fail 0' in log('tmp/cost159-web-tests.log')
assert 'History/Overview/Projects/Live/Providers/Models/Cost/Alerts E2E passed' in log('tmp/cost159-integration-final.log')
assert 'History teardown: database closed' in log('tmp/cost159-integration-final.log')
matrix=load('screens/history/responsive-matrix.json');assert len(matrix['cases'])==144 and all(row['streams']<=1 for row in matrix['cases'])
assert len(after['results'])==8 and all(row['repeatIdentical'] and row['errors']==[] and row['forbidden']==[] for row in after['results'])
assert next(row for row in diffs if row['route']=='history')['changedPixels']==0
assert next(row for row in diffs if row['route']=='cost')['changedPixels']>0
ref=Path('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/cost.png')
assert sha(ref.read_bytes())==next(row for row in after['results'] if row['route']=='cost')['referenceSha256'];copy(ref,'refs/cost.png')
for phase,report,src in [('before',before,'tmp/fidelity158/final/cost.png'),('after',after,'tmp/fidelity159/final/cost.png')]:
 assert sha(Path(src).read_bytes())==next(row for row in report['results'] if row['route']=='cost')['sha256'];copy(src,phase+'/cost.png')
for src,dst in [('tmp/fidelity158/final/verification.json','canonical-before.json'),('tmp/fidelity159/final/verification.json','canonical-current.json'),('tmp/fidelity159/analysis.json','comparison.json'),('tmp/fidelity159/canonical-before-history-fix.json','canonical-before-history-fix.json'),('tmp/fidelity159/analysis-before-history-fix.json','comparison-before-history-fix.json'),('screens/cost-range-picker/verification.json','cost-picker.json'),('screens/usage-calendar/verification.json','calendar.json'),('screens/history-range-picker/verification.json','history-picker.json'),('screens/history/verification.json','integration.json'),('screens/history/responsive-matrix.json','integration-matrix.json'),('tmp/cost159-build-result.json','build-result.json')]:copy(src,'evidence/'+dst)
for name in ['en-dark-1672','th-light-390']:copy('screens/cost-range-picker/'+name+'-open.png','images/'+name+'.png')
copy('tmp/history159-before-fix.png','images/history-before-css-fix.png')
copy('tmp/fidelity159/final/history.png','images/history-after-css-fix.png')
for src,dst in [('tmp/cost159-build.log','build'),('tmp/cost159-browser-final.log','cost-picker'),('tmp/cost159-history-calendar.log','calendar'),('tmp/cost159-history-picker.log','history-picker'),('tmp/cost159-history-height-red.log','history-height-red'),('tmp/cost159-web-tests.log','web-tests'),('tmp/cost159-integration-first.log','integration-before-driver-fix'),('tmp/cost159-integration-final.log','integration'),('tmp/cost159-integration-spawn-denied.log','restricted-spawn'),('tmp/cost159-browser-first.log','initial-date-driver-failure'),('tmp/fidelity159-final.log','canonical-current')]:copy(src,'evidence/logs/'+dst+'.log.gz',True)
for name in ['capture-fidelity159.mts','diff159.py','build159.cjs','package159.py','check-viewer159.mjs']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
sources={}
for name in ['packages/web/src/components/usage-range.tsx','packages/web/src/redesign/cost.tsx','packages/web/src/redesign/cost.css','packages/web/src/redesign/history-range-picker.css','scripts/check-history.mts','scripts/check-history-range-picker.mts','scripts/check-cost-range-picker.mts']:
 b=Path(name).read_bytes();sources[name]={'rawSha256':sha(b),'lfSha256':sha(b.replace(b'\r\n',b'\n'))}
write('source-hashes.json',sources)
verified=(out/'evidence/viewer.json').exists()
if verified:
 viewer=load(out/'evidence/viewer.json');assert viewer['status']=='passed' and viewer['productionIndexSha256']==index and len(viewer['cases'])==2 and viewer['errors']==[]
else:assert '--draft' in sys.argv
write('delivery.json',{'parentCommit':'7189f5dc9379f263bc5594089145aa32e5f75154','productionIndexSha256':index,'webTests':353,'focusedCases':20,'calendarCases':42,'historyPickerCases':16,'fullIntegrationPassed':True,'responsiveCases':144,'canonicalRepeatPairs':8,'unchangedOtherFrames':sum(row['changedPixels']==0 for row in diffs),'historyFramePreserved':True,'reviewPageVerified':verified,'nativeRevalidated':False,'newArchiveCreated':False,'fullGoalComplete':False})
(out/'README.md').write_bytes('''# Cost reference calendar / source159

[Original / source158 / current gallery](review.html) · [Current Cost](after/cost.png) · [Open Thai mobile controls](images/th-light-390.png) · [Latest runnable ZIP review156](../redesign-v1.85.156/README.md)

The Cost header now uses the existing calendar capsule shared with History, matching the reference placement and235px wide dark date plate. Period, monetary basis and chart interval remain editable inside its nonmodal panel. Custom From/To fields are now available on Cost. The closed caption uses the actual resolved API dates, or a localized preset while its new request is pending. All time remains All time. Source scope, basis and bucket survive edits and History links. Native and API monetary amounts stay separate; no report, billing, projection, budget or concept data is fabricated.

Choosing a preset clears obsolete hidden custom bounds. Choosing Custom then seeds the currently resolved period rather than an older custom range. Date controls reuse the shared inclusive-end display and next-local-midnight query logic, including DST and cleared-field guards. Optional Period/month wording overrides preserve the original shared defaults for History and legacy mode. No dependency, provider reader, database migration, pet or popup behavior is added.

## Validation and diagnosis

Validated: production build;353 web tests;20 compiled Cost cases;42 shared calendar cases;16 compiled History picker cases; full dashboard integration with144 responsive cases. Cost covers EN/TH, dark/light,390/900/1280/1672 widths, exact151-token scoped records, native0.25 versus API0.00, preserved hourly bucket/source, custom edits, pending captions, preset-to-Custom seeding, all-time default, keyboard/open/Escape/focus/Tab/outside dismissal and viewport containment. Four New York DST cases verify23-hour spring and25-hour fall days. Tests use owned synthetic in-memory databases and real local HTTP, not customer data.

The first integration failed when a later Cost route tried to read the now-hidden Period control. Both relevant driver paths now open the real disclosure first; labels, values, assertions and timeouts are unchanged. An initial focused driver filled a date with its existing value, generating no change event; its distinct replacement date and exact exclusive-end assertion are retained. Restricted process startup failed with EPERM; the same authorized local test was rerun with process permission.

The first canonical comparison also caught a real CSS regression: importing the shared picker from Cost moved its stylesheet before History's equal-specificity rule, reducing History action buttons from35px to32px. A History-scoped selector now preserves35px independently of import order. The new behavioral geometry assertion fails32 versus35 against the earlier compiled build and passes after correction. The full History frame is compared unmasked against the historical source158 baseline. First-failure logs and before-fix images remain in evidence; no screenshot masking or tolerance relaxation was used.

Eight canonical current pairs are byte-identical within each context. Full-frame comparison results, including any remaining unrelated render differences, are in[evidence/comparison.json](evidence/comparison.json). Original reference dimensions and hashes are retained. Consistent QA values differ from the concept; this evidence does not establish99–100% fidelity or whole-blueprint acceptance. Historical Providers105-pixel and Models3-pixel variance investigations remain open even if a current pair is exact.

```powershell
npm.cmd run build -w @quotapulse/web
npm.cmd run test -w @quotapulse/web
node --import tsx scripts/check-cost-range-picker.mts
node --import tsx scripts/check-usage-calendar.mts
node --import tsx scripts/check-history-range-picker.mts
node --import tsx scripts/check-history.mts
```

Review156 remains the latest runnable native ZIP and contains source155. It excludes source157 project chips, source158 ratio paint/precision and source159 calendar controls. Native packaging, physical tray/monitors, performance, customer/provider acceptance and two-version migration/rollback were not rerun here. Remaining visual, motion and blueprint obligations still require the full audit. Main and unrelated work are preserved.
'''.encode())
(out/'review.html').write_bytes('''<!doctype html><meta charset="utf-8"><title>Cost reference calendar / source159</title><style>body{font:14px system-ui;margin:20px;background:#071020;color:#def}a{color:#5cf}select{padding:8px;margin:6px}section{display:grid;grid-template-columns:1fr 1fr;gap:12px}img{width:100%;border:1px solid #456}figure{margin:0}figcaption{margin:8px 0}@media(max-width:900px){section{grid-template-columns:1fr}}</style><h1>Cost / original, source158, source159</h1><p>Original concept and consistent QA values differ. No similarity percentage or approval is claimed. <a href="README.md">Changes, evidence and limits</a></p><select id="left-source"><option value="refs">Original concept</option><option value="before">Before / source158</option></select><section><figure><figcaption id="left-label"></figcaption><img id="left" alt="Original or previous Cost frame"></figure><figure><figcaption>Current / source159</figcaption><img id="right" src="after/cost.png" alt="Current compiled Cost frame"></figure></section><script>const source=document.getElementById('left-source');function show(){document.getElementById('left-label').textContent=source.options[source.selectedIndex].text;document.getElementById('left').src=source.value+'/cost.png'}source.onchange=show;show()</script>'''.encode())
write('artifact-hashes.json',{p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='artifact-hashes.json'})
print('Sealed',len(load(out/'artifact-hashes.json')),'artifacts; viewer verified:',verified)
