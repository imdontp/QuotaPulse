import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { chromium } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';

const now=Date.now(),db=openDb(':memory:'),port=7831,base=`http://127.0.0.1:${port}`;
db.prepare("INSERT INTO source(id,harness,profile,root_path,display_name,detected_at) VALUES (1,'codex','fixture','/synthetic','Fixture',?)").run(now);
const session=db.prepare('INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (?,1,?,?,?)');
const event=db.prepare('INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,total_tokens,call_count) VALUES (1,?,?,?,?,?,1,1)');
for(const [id,project,model] of [[1,null,null],[2,'',''],[3,'Other','gpt-4o']] as const){session.run(id,`s${id}`,project,now-1000);event.run(id,`e${id}`,now-1000,model,'openai')}
for(let id=4;id<=15;id++){session.run(id,`s${id}`,`Runtime project ${id}`,now-1000);event.run(id,`e${id}`,now-1000,`runtime-model-${id}`,'openai')}
const daemon=buildServer(db,new Scheduler(db,[],{pollMs:1000000,detectMs:1000000}),{token:'synthetic-dialog-test',port,webRoot:resolve('packages/web/dist')});
let browser:Awaited<ReturnType<typeof chromium.launch>>|undefined;
try{
 await daemon.listen({host:'127.0.0.1',port});browser=await chromium.launch({channel:'chrome',headless:true});
 const page=await browser.newPage({viewport:{width:1586,height:992},reducedMotion:'reduce',locale:'th'});
 const errors:string[]=[],forbidden:string[]=[];page.on('pageerror',error=>errors.push(error.message));
 await page.route('**/*',route=>{const request=route.request(),url=new URL(request.url());if(url.origin!==base||url.pathname.startsWith('/api/')&&request.method()!=='GET'){forbidden.push(request.method()+' '+url.pathname);return route.abort()}return route.continue()});
 await page.addInitScript(()=>{
  (window as any).__QUOTAPULSE_TOKEN__='synthetic-dialog-test';
  localStorage.setItem('quotapulse-theme','light');localStorage.setItem('quotapulse-prefs',JSON.stringify({lang:'th',currency:'USD',rate:1,hiddenSubscriptions:[]}));
  const entries:any[]=[];(window as any).__dialogTrace=entries;
  for(const type of ['focusin','click','close','cancel']) document.addEventListener(type,event=>{const target=event.target as HTMLElement;entries.push({type,at:performance.now(),tag:target?.tagName,text:target?.textContent?.slice(0,60),identity:target?.closest?.('tr')?.getAttribute('data-identity'),dialogOpen:document.querySelector('.qp-dialog')?.hasAttribute('open'),active:(document.activeElement as HTMLElement)?.textContent?.slice(0,60)});if(entries.length>1000)entries.shift()},true);
 });
 await page.goto(base+'/#overview',{waitUntil:'domcontentloaded'});
 const options=page.locator('.qp-runtime-options');await options.locator(':scope > summary').waitFor();await options.locator(':scope > summary').click();
 const disclosure=page.locator('.qp-runtime-data');await disclosure.locator(':scope > summary').click();
 const rows=disclosure.locator('.qp-runtime-nodes tbody tr');await rows.first().waitFor();
 const identities=await rows.evaluateAll(nodes=>nodes.map(node=>node.getAttribute('data-identity')));
 const targets=[null,''].map(key=>{const index=identities.indexOf(JSON.stringify(['project',key]));assert.ok(index>=0);return rows.nth(index).locator('button')});

 // Close and select another row within one task, then let the native close
 // event and React updates run normally. The initial dialog is opened through
 // the same keyboard path as the original failure.
 await targets[0].focus(); await page.keyboard.press('Enter');
 await page.locator('.qp-dialog[open]').waitFor();
 for(let round=0;round<500;round++){
  const target=targets[(round+1)%2]!;
  const expected=await target.textContent();
  await target.evaluate(element=>{const dialog=document.querySelector<HTMLDialogElement>('.qp-dialog')!; dialog.close(); (element as HTMLElement).focus(); (element as HTMLElement).click()});
  const dialog=page.locator('.qp-dialog[open]');
  try { await dialog.waitFor({timeout:5000});
   const actual=await dialog.locator('h2').textContent();
   if(actual!==expected) throw Error(`round ${round}: expected ${expected}, got ${actual}`);
  } catch(error){
   mkdirSync('tmp/dialog210',{recursive:true});
   writeFileSync('tmp/dialog210/failure.json',JSON.stringify({round,expected,error:String(error),trace:await page.evaluate(()=>(window as any).__dialogTrace),html:await page.locator('.qp-dialog').evaluate(node=>node.outerHTML)},null,2));
   throw error;
  }
 }
 await page.keyboard.press('Escape');
 await page.locator('.qp-dialog[open]').waitFor({state:'hidden'});

 assert.deepEqual(errors,[]);assert.deepEqual(forbidden,[]);
 console.log('Runtime dialog rapid same-task close/select: 500 transitions passed in isolated synthetic fixture.');
}finally{await browser?.close();await daemon.close();db.close()}
