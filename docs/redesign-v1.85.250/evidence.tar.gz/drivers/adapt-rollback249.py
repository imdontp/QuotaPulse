from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root/'tmp/prepare-rollback243.py').read_text(encoding='utf-8')
old_previous = "('previous', '236', 'QuotaPulse-v1.85.235-review236.zip', '00-archive.json', '3a711008ab2317f1fd170bcffe00af081cabfac24f1b2b7f8e6a5dd2001c3d48')"
new_previous = "('previous', '243', 'QuotaPulse-v1.85.242-review243.zip', './archive.json', '05b737fcf86a81489e44a6122abc24ec2a475858305fdcd4f3fa3a52f1018e67')"
old_current = "('current', '243', 'QuotaPulse-v1.85.242-review243.zip', './archive.json', '05b737fcf86a81489e44a6122abc24ec2a475858305fdcd4f3fa3a52f1018e67')"
new_current = "('current', '249', 'QuotaPulse-v1.85.248-review249.zip', 'archive.json', '86b49b46373dd3690326f6bb4b18dccd22c27bb87a3e60b3a85702581f6ae0c1')"
assert old_previous in source and old_current in source
source = source.replace(old_previous, new_previous).replace(old_current, new_current)
source = source.replace("tmp/rollback243", "tmp/rollback249")
source = source.replace("'rollback236', 'rollback243'", "'rollback236', 'rollback249'")
source = source.replace("'native236', 'native243'", "'native236', 'native249'")
source = source.replace("f'{stem}243.{ext}'", "f'{stem}249.{ext}'")
target = root/'tmp/prepare-rollback249.py'
assert not target.exists()
target.write_text(source, encoding='utf-8', newline='\n')
print('Prepared review243 to review249 provenance driver')
