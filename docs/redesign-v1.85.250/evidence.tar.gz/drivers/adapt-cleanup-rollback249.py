from pathlib import Path
root = Path(__file__).resolve().parents[1]
fixture = 'run-47501e0194354f499ea9fdd1cbef6d43'
source = (root/'tmp/prepare-rollback243-final-plan.py').read_text(encoding='utf-8')
old = "fixtures=[(project/'tmp/version-rollback243/run-ddb3ce2f549a440e8b173953cd301830',False),(project/'tmp/version-rollback243/run-81ba1a2699c540cf8b1a3795efa0ccb2',True)]"
assert old in source
source = source.replace(old, f"fixtures=[(project/'tmp/version-rollback249/{fixture}',True)]").replace("tmp/rollback243", "tmp/rollback249")
target = root/'tmp/prepare-rollback249-final-plan.py'
assert not target.exists()
target.write_text(source, encoding='utf8', newline='\n')
cleanup = (root/'tmp/cleanup-rollback243-final.ps1').read_text(encoding='utf-8')
old = "$allowed=@((Join-Path $project 'tmp\\version-rollback243\\run-ddb3ce2f549a440e8b173953cd301830'),(Join-Path $project 'tmp\\version-rollback243\\run-81ba1a2699c540cf8b1a3795efa0ccb2'))"
assert old in cleanup
cleanup = cleanup.replace(old, f"$allowed=@((Join-Path $project 'tmp\\version-rollback249\\{fixture}'))").replace('tmp\\rollback243','tmp\\rollback249')
target = root/'tmp/cleanup-rollback249-final.ps1'
assert not target.exists()
target.write_text(cleanup, encoding='utf8', newline='\n')
print('Prepared rollback cleanup for one exact successful fixture')
