import json,math
from pathlib import Path
from PIL import Image,ImageChops
root=Path('tmp/fidelity124')
before=json.loads((root/'before/verification.json').read_text(encoding='utf-8'));after=json.loads((root/'final/verification.json').read_text(encoding='utf-8'))
rows=[]
for route in ['projects','alerts']:
    old=json.loads((root/f'before/{route}-facts.json').read_text(encoding='utf-8'));new=json.loads((root/f'final/{route}-facts.json').read_text(encoding='utf-8'))
    if route=='projects':
        for key in ['text','aria','disabled']:assert old[key]==new[key]
        assert new['rect']==dict(x=1506,y=78,width=147,height=42,top=78,right=1653,bottom=120,left=1506)
        scope=dict(actionBounds=new['rect'],sameRefreshLabelAndAria=True,intendedRegion=[1480,60,1672,145])
    else:
        assert len(old['rows'])==len(new['rows'])==4
        for a,b in zip(old['rows'],new['rows']):
            for key in ['owner','window','level','description','ownerText','value','age','href','vectors']:assert a[key]==b[key],key
        assert old['rect']==new['rect'],'Native risk region must not move or shrink'
        assert all(row['visible'] for row in new['rows'])
        scope=dict(riskFactsAndAllVectorsIdentical=True,rows=4,fullyVisibleBefore=sum(row['visible'] for row in old['rows']),fullyVisibleAfter=4,rowHeightsBefore=[row['rect']['height'] for row in old['rows']],rowHeightsAfter=[row['rect']['height'] for row in new['rows']],region=new['rect'],intendedRegion=[250,503,1187,744])
    prior=next(row for row in before['results'] if row['route']==route);current=next(row for row in after['results'] if row['route']==route)
    assert prior['geometry']==current['geometry'],'Top-level source geometry changed';assert current['repeatIdentical'];assert prior['referenceSha256']==current['referenceSha256']
    a=Image.open(root/f'before/{route}.png').convert('RGB');b=Image.open(root/f'final/{route}.png').convert('RGB')
    c=ImageChops.difference(a,b).split();d=ImageChops.lighter(ImageChops.lighter(c[0],c[1]),c[2]);hist=d.histogram()
    excluded=d.copy();excluded.paste(0,tuple(scope['intendedRegion']));eh=excluded.histogram()
    unplanned=[]
    if sum(eh[1:])<1000:
        for y in range(a.height):
            for x in range(a.width):
                if excluded.getpixel((x,y)):unplanned.append(dict(x=x,y=y,before=a.getpixel((x,y)),after=b.getpixel((x,y))))
    rows.append(dict(route=route,changedPixels=sum(hist[1:]),maxChannelDelta=max(i for i,n in enumerate(hist) if n),bounds=d.getbbox(),outsideIntendedPixels=sum(eh[1:]),outsideBounds=excluded.getbbox(),outsideMaxChannelDelta=max((i for i,n in enumerate(eh) if n),default=0),unplannedPixels=unplanned,topLevelGeometryIdentical=True,**scope))
ref=Image.open('docs/redesign-v1.85.69/refs/projects.png').convert('RGB');actual=Image.open(root/'final/projects.png').convert('RGB')
samples=[dict(x=x,y=y,reference=ref.getpixel((x,y)),current=actual.getpixel((x,y)),maxChannelDelta=max(abs(a-b) for a,b in zip(ref.getpixel((x,y)),actual.getpixel((x,y))))) for x,y in [(1515,90),(1535,86),(1560,86),(1585,86),(1610,86),(1640,90)]]
report=dict(beforeIndex=before['productionIndexSha256'],afterIndex=after['productionIndexSha256'],rendererArgs=after['rendererArgs'],routes=rows,primaryFillSamples=samples,scope='Measured native primary-action and risk density changes, with all unplanned pixels retained; not whole-concept acceptance')
(root/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({**report,'routes':[{k:v for k,v in row.items() if k!='unplannedPixels'} for row in rows]}))
