/** Static canonical reference capture. Isolated synthetic DB, compiled application, no user data. */
import assert from 'node:assert/strict';
import { en } from '../packages/web/src/i18n/en.js';
import { th } from '../packages/web/src/i18n/th.js';
import { installBrowserFixedDate } from '../scripts/browser-fixed-date.mjs';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium, type Page, type Request } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import { recordQuotaAlerts } from '../packages/daemon/src/api/queries.js';
const root = fileURLToPath(new URL('..', import.meta.url));
const output = resolve(root, 'tmp/fidelity124/native'); 
const referenceRoot = 'C:/Users/TH12367283/Downloads/quotapulse_build_blueprint';
const priorTimezone = process.env.TZ;
process.env.TZ = 'Asia/Bangkok';
mkdirSync(output, { recursive: true });

const fixedNow = Date.parse('2025-05-17T13:42:00.000Z');
// Freeze Date only, keeping real timers/performance for HTTP, browser and cleanup.
// This applies to internal query helpers too, without changing production clocks.
const realDate = globalThis.Date;
globalThis.Date = new Proxy(realDate, {
  construct(target, args) { return Reflect.construct(target, args.length ? args : [fixedNow]); },
  apply() { return new realDate(fixedNow).toString(); },
  get(target, property, receiver) { return property === 'now' ? () => fixedNow : Reflect.get(target, property, receiver); },
});
const db = openDb(':memory:');
db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at,account_key,account_provider,account_display_name,account_state,account_last_success_at)
  VALUES (1,'codex','fixed','/synthetic/nonexistent','Codex fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow}),
    (2,'hermes','fixed','/synthetic/nonexistent','Hermes fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (3,'claude-code','fixed','/synthetic/nonexistent','Claude Code fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (4,'opencode','fixed','/synthetic/nonexistent','OpenCode fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow});`);
const referenceProjects = ['QuotaPulse', 'Agent Platform', 'Edge Services', 'Developer Tools', 'Research Lab'];
const referenceModels = [
  { name: 'DeepSeek V4.1', provider: 'deepseek', share: 38 },
  { name: 'GPT-5.x', provider: 'openai', share: 24 },
  { name: 'Claude 3.7', provider: 'anthropic', share: 18 },
  { name: 'Claude 3.5', provider: 'anthropic', share: 11 },
  { name: 'Others', provider: 'openrouter', share: 9 },
  { name: 'GPT-4.1 mini', provider: 'openai', share: 0 },
];
const session = db.prepare('INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (?,?,?,?,?)');
const usage = db.prepare('INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source,cost_input_usd,cost_cached_input_usd,cost_cache_write_usd,cost_output_usd,cost_cache_saving_usd,price_provider) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
// Synthetic catalogue rates for the in-memory visual fixture only. The saved
// amount is derived from the same fresh/cached input components the UI reports.
const fixtureInputUsdPerMillion = 0.0593846153846154, fixtureCachedInputUsdPerMillion = 0.004, fixtureOutputUsdPerMillion = 0.004;
for (let index = 0; index < 12; index++) {
  // Keep the reference map's 4 Codex, 2 Claude Code, 6 Hermes, 0 OpenCode
  // recent-session distribution while preserving the same 12 sessions.
  const source = [1, 1, 1, 1, 3, 3, 2, 2, 2, 2, 2, 2][index]!;
  session.run(index + 1, source, `fixture-session-${index}`, referenceProjects[0], fixedNow - 10_000);
  const model = referenceModels[index % referenceModels.length]!;
  const totalTokens = model.share === 0 ? 1 : model.share * 721_000_000 / 600;
  for (let call = 0; call < 3; call++) {
    const inputShare = [.6, .65, .7][(index + call) % 3]!;
    const inputTokens = totalTokens * inputShare * .58, cachedInputTokens = totalTokens * inputShare * .42;
    const outputTokens = totalTokens * (1 - inputShare);
    const costSource = index === 0 ? 'native' : 'computed';
    const inputUsd = inputTokens / 1_000_000 * fixtureInputUsdPerMillion;
    const cachedInputUsd = cachedInputTokens / 1_000_000 * fixtureCachedInputUsdPerMillion;
    const outputUsd = outputTokens / 1_000_000 * fixtureOutputUsdPerMillion;
    const cacheSavingUsd = cachedInputTokens / 1_000_000 * (fixtureInputUsdPerMillion - fixtureCachedInputUsdPerMillion);
    // Keep each session's latest record within four minutes, then spread older calls across the visible 30-minute interval.
    const ageMs = call === 0 ? 15_000 + index * 20_000 : source === 2
      ? 300_000 + index * 120_000 + (call === 2 ? 30_000 : 0)
      : 300_000 + index * 240_000 + (call === 2 ? 90_000 : 0);
    const recordedAt = fixedNow - ageMs;
    usage.run(source, index + 1, `fixed-${index}-${call}`, recordedAt, model.name, model.provider,
      inputTokens, cachedInputTokens, outputTokens, totalTokens, call + 1,
      costSource === 'native' ? (index + 1) / 100 : inputUsd + cachedInputUsd + outputUsd, costSource,
      costSource === 'native' ? null : inputUsd, costSource === 'native' ? null : cachedInputUsd,
      costSource === 'native' ? null : 0, costSource === 'native' ? null : outputUsd,
      costSource === 'native' ? null : cacheSavingUsd, costSource === 'native' ? null : model.provider);
  }
}
// A stale recorded OpenCode route keeps the concept's zero-active-session edge
// visible without manufacturing a provider relationship or changing live counts.
const openCodeAt = fixedNow - 10 * 60_000;
session.run(13, 4, 'fixture-opencode-quota-pulse', referenceProjects[0], openCodeAt);
usage.run(4, 13, 'fixed-opencode-route', openCodeAt, 'DeepSeek V4.1', 'deepseek', 1, 0, 0, 1, 1,
  null, 'unknown', null, null, null, null, null, null);
// The monthly concept is focused on QuotaPulse while the machine-wide quick
// stats still report all five named projects. Keep four small monthly records
// for the other projects, outside the recent-session window.
for (let index = 1; index < referenceProjects.length; index++) {
  const id = 100 + index, source = [1, 3, 4, 2][index - 1]!;
  const model = referenceModels[index - 1]!;
  const at = fixedNow - 10 * 60_000;
  session.run(id, source, `fixture-project-${index}`, referenceProjects[index], at);
  const inputUsd = fixtureInputUsdPerMillion / 1_000_000;
  usage.run(source, id, `fixture-project-usage-${index}`, at, model.name, model.provider, 1, 0, 0, 1, 1,
    inputUsd, 'computed', inputUsd, 0, 0, 0, 0, model.provider);
}
// Values below the old visual minimum catch inflated nonzero bars in both charts.
const tinyUsage = db.prepare("INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source) VALUES (1,1,?,?,'DeepSeek V4.1','deepseek',1,0,0,1,1,0,'computed')");
tinyUsage.run('fixed-tiny-minute', fixedNow - 15 * 60_000);
tinyUsage.run('fixed-tiny-day', fixedNow - 3 * 86_400_000);
const quota = db.prepare('INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin) VALUES (?,?,?,?,?,?,?,?)');
const addQuotaSample = (sourceId: number, window: string, percent: number | null, resetAt: number | null, observedAt: number) => quota.run(sourceId, window, percent, resetAt, observedAt, observedAt, observedAt, 'fixed-fixture');
// Complete history must include older reset periods, nulls and more than eight
// readings per period, without changing the latest live quota/default selection.
for (let segment = 0; segment < 4; segment++) for (let index = 0; index < 12; index++) {
  const at = fixedNow - (5 - segment) * 3_600_000 + index * 60_000;
  addQuotaSample(1, '5h', index === 4 ? null : index === 1 ? 0.5 : index * 8, segment === 0 ? null : fixedNow - (4 - segment) * 3_600_000, at);
}
addQuotaSample(1, '5h', 38, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 5 * 60_000);
addQuotaSample(1, '5h', 83, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 30_000);
addQuotaSample(1, 'weekly', 62, fixedNow + (3 * 24 + 5) * 3_600_000, fixedNow - 30_000);
const monthlyReset = fixedNow + (6 * 24 + 2) * 3_600_000;
addQuotaSample(1, 'monthly', 59, monthlyReset, fixedNow - 48 * 3_600_000);
addQuotaSample(1, 'monthly', 65.5, monthlyReset, fixedNow - 24 * 3_600_000);
addQuotaSample(1, 'monthly', 72, monthlyReset, fixedNow - 30_000);
addQuotaSample(2, 'monthly', 58, fixedNow + (12 * 24 + 6) * 3_600_000, fixedNow - 30_000);
addQuotaSample(2, 'daily', 34, fixedNow + (7 * 60 + 18) * 60_000, fixedNow - 30_000);
recordQuotaAlerts(db, fixedNow);
const scheduler = new Scheduler(db, [], { pollMs: 1_000_000, detectMs: 1_000_000 });
const daemon = buildServer(db, scheduler, { token: 'stable-capture-test', port: 7816, webRoot: resolve(root, 'packages/web/dist') });

let browser:Awaited<ReturnType<typeof chromium.launch>>|undefined;
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const indexPath=resolve(root,'packages/web/dist/index.html'),index=sha(readFileSync(indexPath));
const results:unknown[]=[];
try{
 await daemon.listen({host:'127.0.0.1',port:7816});browser=await chromium.launch({channel:'chrome',headless:true});
 for(const routeName of ['alerts','projects'])for(const lang of ['en','th'])for(const theme of ['dark','light'])for(const width of [390,1280,1536,1672]){
  const name=[routeName,lang,theme,width].join('-');
  const context=await browser.newContext({viewport:{width,height:941},reducedMotion:'reduce',deviceScaleFactor:1,timezoneId:'Asia/Bangkok',colorScheme:theme as 'dark'|'light'});
  const page=await context.newPage();page.setDefaultTimeout(15000);
  const pending=new Set<Request>(),errors:string[]=[],forbidden:string[]=[],posts:string[]=[];let manual=false;
  page.on('pageerror',error=>errors.push(error.message));
  page.on('response',response=>{if(response.status()>=400)errors.push(response.status()+' '+new URL(response.url()).pathname)});
  page.on('request',request=>{const path=new URL(request.url()).pathname;if(path.startsWith('/api/')&&!path.includes('/events/stream'))pending.add(request);if(request.method()!=='GET')posts.push(request.method()+' '+path)});
  page.on('requestfinished',request=>pending.delete(request));page.on('requestfailed',request=>pending.delete(request));
  await page.route('**/*',route=>{const request=route.request(),url=new URL(request.url());const allowedPost=request.method()==='POST'&&(url.pathname==='/api/model-row-trends'||manual&&url.pathname==='/api/refresh');if(url.origin!=='http://127.0.0.1:7816'||url.pathname.startsWith('/api/')&&request.method()!=='GET'&&!allowedPost){forbidden.push(request.method()+' '+url.pathname);return route.abort()}return route.continue()});
  await page.addInitScript(({lang,theme})=>{(window as unknown as {__QUOTAPULSE_TOKEN__:string}).__QUOTAPULSE_TOKEN__='stable-capture-test';localStorage.setItem('quotapulse-prefs',JSON.stringify({lang,currency:'USD',rate:1,hiddenSubscriptions:[]}));localStorage.setItem('quotapulse-theme',theme)},{lang,theme});
  await installBrowserFixedDate(page,fixedNow);
  await page.goto('http://127.0.0.1:7816/#'+routeName,{waitUntil:'domcontentloaded'});
  const copy=lang==='th'?th:en;
  const settle=async()=>{let idle=0;const end=performance.now()+30000;while(idle<8){assert.ok(performance.now()<end);await page.waitForTimeout(40);idle=pending.size===0?idle+1:0}};
  await page.locator(routeName==='alerts'?'.qp-alert-risk>ul>li[data-level]':'.qp-project-trend').first().waitFor();await page.evaluate(()=>document.fonts.ready);await settle();
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,'Current page must fit before any navigation');
  let facts:any;
  if(routeName==='alerts'){
   const response=await daemon.inject({method:'GET',url:'/api/overview',headers:{'x-quotapulse-token':'stable-capture-test'}});assert.equal(response.statusCode,200);const overview=response.json();
   const rows=page.locator('.qp-alert-risk>ul>li[data-level]');assert.equal(await rows.count(),4);
   facts=await rows.evaluateAll(nodes=>{const region=nodes[0].parentElement!.getBoundingClientRect();return nodes.map(node=>({owner:node.getAttribute('data-owner'),window:node.getAttribute('data-window'),value:node.querySelector('.qp-alert-risk-value>strong')!.textContent,rect:node.getBoundingClientRect().toJSON(),visible:node.getBoundingClientRect().top>=region.top&&node.getBoundingClientRect().bottom<=region.bottom,icon:node.querySelector('.qp-alert-risk-icon')!.getBoundingClientRect().toJSON(),children:Array.from(node.children).map(child=>({className:child.getAttribute('class'),rect:child.getBoundingClientRect().toJSON()}))}))});
   for(const [i,row]of facts.entries()){
    const reading=overview.limits.find((reading:any)=>(reading.subscription_key??reading.account_key??'source:'+reading.source_id)===row.owner&&reading.window_kind===row.window);assert.ok(reading);assert.equal(row.value,new Intl.NumberFormat(lang==='th'?'th-TH':'en-US',{maximumFractionDigits:0}).format(reading.used_percent)+'%');
    const link=rows.nth(i).locator(':scope>a');assert.equal(await link.getAttribute('aria-label'),copy['redesign.alertOpenProvider']);assert.equal(await link.getAttribute('title'),copy['redesign.alertOpenProvider']);assert.equal(await link.locator('span').innerText(),copy['redesign.alertGuidanceView']);
    const linkBox=await link.boundingBox();assert.ok(linkBox&&linkBox.width>=24&&linkBox.height>=24,'Compact View remains a usable target');
    const url=new URL((await link.getAttribute('href'))!,'http://local/');const params=new URLSearchParams(url.hash.split('?')[1]);assert.equal(params.get('owner'),row.owner);assert.equal(params.get('window'),row.window);
    if(width>=1536){assert.equal(row.icon.width,36);assert.equal(row.icon.height,36);assert.equal(row.visible,true,'Every current fixture risk must fit');for(const child of row.children)assert.ok(child.rect.left>=row.rect.left&&child.rect.right<=row.rect.right+1&&child.rect.top>=row.rect.top&&child.rect.bottom<=row.rect.bottom+1,'Risk facts must stay inside their row');}
   }
   await page.screenshot({path:resolve(output,name+'.png'),animations:'disabled'});
   const link=rows.last().locator(':scope>a');const href=await link.getAttribute('href');await link.focus();assert.equal(await link.evaluate(node=>node===document.activeElement),true);await page.keyboard.press('Enter');await page.getByTestId('production-providers').waitFor();await settle();assert.equal(new URL(page.url()).hash,href,'Risk View retains actual owner/window destination');
  }else{
   const button=page.locator('.qp-project-header>button');await button.focus();
   facts=await button.evaluate(node=>{const c=getComputedStyle(node);return{rect:node.getBoundingClientRect().toJSON(),text:node.textContent,aria:node.getAttribute('aria-label'),outlineStyle:c.outlineStyle,outlineWidth:c.outlineWidth,background:c.background,borderRadius:c.borderRadius}});
   assert.equal(facts.aria,copy['app.refreshNow']);assert.equal(await button.isEnabled(),true);assert.ok(facts.outlineStyle!=='none'&&parseFloat(facts.outlineWidth)>=2,'Primary action retains keyboard focus indicator');
   if(width>=1536){assert.equal(facts.rect.width,147);assert.equal(facts.rect.height,42);assert.equal(facts.rect.y,78);assert.equal(facts.rect.right,width-19);assert.ok(facts.background.includes('linear-gradient'));}
   await button.evaluate(node=>node.blur());await page.screenshot({path:resolve(output,name+'.png'),animations:'disabled'});
   if(lang==='en'&&theme==='dark'&&width===1672){
    let release=()=>{};const barrier=new Promise<void>(resolve=>{release=resolve});let held=false;
    const snapshot=()=>JSON.stringify(['source','session','usage_event','limit_sample'].map(table=>db.prepare('SELECT * FROM '+table+' ORDER BY id').all()));
    const beforeRefresh=snapshot();db.exec('BEGIN');manual=true;
    const original=await button.boundingBox();
    await page.route('http://127.0.0.1:7816/api/refresh',async route=>{assert.equal(route.request().method(),'POST');held=true;await barrier;await route.continue()});
    try{
     await button.focus();await page.keyboard.press('Enter');await page.waitForFunction(()=>!!document.querySelector<HTMLButtonElement>('.qp-project-header>button')?.disabled);assert.equal(held,true);
     assert.equal(await button.evaluate(node=>getComputedStyle(node).opacity),'0.55');assert.deepEqual(await button.boundingBox(),original,'Pending refresh does not move the action');
     release();await page.waitForFunction(()=>!document.querySelector<HTMLButtonElement>('.qp-project-header>button')?.disabled);await settle();assert.equal(await button.isEnabled(),true);assert.deepEqual(posts,['POST /api/refresh']);facts.manualRefresh={actualEmptyReaderScheduler:true,pendingDisabled:true,geometryPreserved:true,recovered:true};
    }finally{release();await page.unroute('http://127.0.0.1:7816/api/refresh');if(db.inTransaction)db.exec('ROLLBACK');manual=false;}
    assert.equal(snapshot(),beforeRefresh,'Manual test restores all fixture source/session/usage/quota facts');facts.manualRefresh.fixtureRestored=true;
   }
  }
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);assert.deepEqual(errors,[]);assert.deepEqual(forbidden,[]);
  results.push({name,route:routeName,lang,theme,width,facts,errors,forbidden,posts});console.log('Passed '+name);await context.close();
 }
 assert.equal(sha(readFileSync(indexPath)),index);writeFileSync(resolve(output,'verification.json'),JSON.stringify({status:'passed',index,browser:browser.version(),rendererArgs:[],results},null,2));
}finally{await browser?.close();await daemon.close();db.close();globalThis.Date=realDate;process.env.TZ=priorTimezone}
