from PIL import Image
import json
from pathlib import Path
p=Image.open('docs/redesign-v1.85.69/refs/projects.png').convert('RGB')
scan={}
for y in [77,78,79,80,82,84,86,90,100,118,120,121,122]:
    hits=[x for x in range(1490,1665) if p.getpixel((x,y))[2]>200 and p.getpixel((x,y))[0]<120 and p.getpixel((x,y))[1]<190]
    scan[str(y)]=dict(first=min(hits) if hits else None,last=max(hits) if hits else None,count=len(hits))
samples={str((x,y)):p.getpixel((x,y)) for x,y in [(1515,90),(1535,86),(1560,86),(1585,86),(1610,86),(1640,90)]}
result=dict(reference='refs/projects.png',primaryPlateEstimate=dict(x=1506,y=78,width=147,height=42),nativeRiskRowEstimate=dict(height=48,icon=36),plateScanlines=scan,fillSamples=samples,scope='Raster estimates/samples, not recovered original CSS or whole-screen acceptance')
Path('tmp/fidelity124').mkdir(exist_ok=True,parents=True)
Path('tmp/fidelity124/reference-measurements.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
