const fs=require('node:fs');
const s=fs.readFileSync('tmp/capture-fidelity124.mts','utf8');
let prefix=s.slice(0,s.indexOf('let browser:'));
prefix=prefix.replace("'tmp/fidelity124/'+(process.env.QP_FIDELITY_PHASE??'after')","'tmp/fidelity124/native'");
prefix=prefix.replace("import assert from 'node:assert/strict';", "import assert from 'node:assert/strict';\nimport { en } from '../packages/web/src/i18n/en.js';\nimport { th } from '../packages/web/src/i18n/th.js';");
const body=`
let browser:Awaited<ReturnType<typeof chromium.launch>>|undefined;
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const indexPath=resolve(root,'packages/web/dist/index.html'),index=sha(readFileSync(indexPath));
const results:unknown[]=[];
try{
 await daemon.listen({host:'127.0.0.1',port:7816});browser=await chromium.launch({channel:'chrome',headless:true});
 for(const routeName of ['alerts','projects'])for(const lang of ['en','th'])for(const theme of ['dark','light'])for(const width of [390,1280,1536,1672]){
  const name=[routeName,lang,theme,width].join('-');
  const context=await browser.newContext({viewport:{width,height:941},reducedMotion:'reduce',deviceScaleFactor:1,timezoneId:'Asia/Bangkok',colorScheme:theme as 'dark'|'light'});
  const page=await context.newPage();page.setDefaultTimeout(15000);
  const pending=new Set<Request>(),errors:string[]=[],forbidden:string[]=[],posts:string[]=[];let manual=false;
  page.on('pageerror',error=>errors.push(error.message));
  page.on('response',response=>{if(response.status()>=400)errors.push(response.status()+' '+new URL(response.url()).pathname)});
  page.on('request',request=>{const path=new URL(request.url()).pathname;if(path.startsWith('/api/')&&!path.includes('/events/stream'))pending.add(request);if(request.method()!=='GET')posts.push(request.method()+' '+path)});
  page.on('requestfinished',request=>pending.delete(request));page.on('requestfailed',request=>pending.delete(request));
  await page.route('**/*',route=>{const request=route.request(),url=new URL(request.url());const allowedPost=request.method()==='POST'&&(url.pathname==='/api/model-row-trends'||manual&&url.pathname==='/api/refresh');if(url.origin!=='http://127.0.0.1:7816'||url.pathname.startsWith('/api/')&&request.method()!=='GET'&&!allowedPost){forbidden.push(request.method()+' '+url.pathname);return route.abort()}return route.continue()});
  await page.addInitScript(({lang,theme})=>{(window as unknown as {__QUOTAPULSE_TOKEN__:string}).__QUOTAPULSE_TOKEN__='stable-capture-test';localStorage.setItem('quotapulse-prefs',JSON.stringify({lang,currency:'USD',rate:1,hiddenSubscriptions:[]}));localStorage.setItem('quotapulse-theme',theme)},{lang,theme});
  await installBrowserFixedDate(page,fixedNow);
  await page.goto('http://127.0.0.1:7816/#'+routeName,{waitUntil:'domcontentloaded'});
  const copy=lang==='th'?th:en;
  const settle=async()=>{let idle=0;const end=performance.now()+30000;while(idle<8){assert.ok(performance.now()<end);await page.waitForTimeout(40);idle=pending.size===0?idle+1:0}};
  await page.locator(routeName==='alerts'?'.qp-alert-risk>ul>li[data-level]':'.qp-project-trend').first().waitFor();await page.evaluate(()=>document.fonts.ready);await settle();
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,'Current page must fit before any navigation');
  let facts:any;
  if(routeName==='alerts'){
   const response=await daemon.inject({method:'GET',url:'/api/overview',headers:{'x-quotapulse-token':'stable-capture-test'}});assert.equal(response.statusCode,200);const overview=response.json();
   const rows=page.locator('.qp-alert-risk>ul>li[data-level]');assert.equal(await rows.count(),4);
   facts=await rows.evaluateAll(nodes=>{const region=nodes[0].parentElement!.getBoundingClientRect();return nodes.map(node=>({owner:node.getAttribute('data-owner'),window:node.getAttribute('data-window'),value:node.querySelector('.qp-alert-risk-value>strong')!.textContent,rect:node.getBoundingClientRect().toJSON(),visible:node.getBoundingClientRect().top>=region.top&&node.getBoundingClientRect().bottom<=region.bottom,icon:node.querySelector('.qp-alert-risk-icon')!.getBoundingClientRect().toJSON(),children:Array.from(node.children).map(child=>({className:child.getAttribute('class'),rect:child.getBoundingClientRect().toJSON()}))}))});
   for(const [i,row]of facts.entries()){
    const reading=overview.limits.find((reading:any)=>(reading.subscription_key??reading.account_key??'source:'+reading.source_id)===row.owner&&reading.window_kind===row.window);assert.ok(reading);assert.equal(row.value,new Intl.NumberFormat(lang==='th'?'th-TH':'en-US',{maximumFractionDigits:0}).format(reading.used_percent)+'%');
    const link=rows.nth(i).locator(':scope>a');assert.equal(await link.getAttribute('aria-label'),copy['redesign.alertOpenProvider']);assert.equal(await link.getAttribute('title'),copy['redesign.alertOpenProvider']);assert.equal(await link.locator('span').innerText(),copy['redesign.alertGuidanceView']);
    const linkBox=await link.boundingBox();assert.ok(linkBox&&linkBox.width>=24&&linkBox.height>=24,'Compact View remains a usable target');
    const url=new URL((await link.getAttribute('href'))!,'http://local/');const params=new URLSearchParams(url.hash.split('?')[1]);assert.equal(params.get('owner'),row.owner);assert.equal(params.get('window'),row.window);
    if(width>=1536){assert.equal(row.icon.width,36);assert.equal(row.icon.height,36);assert.equal(row.visible,true,'Every current fixture risk must fit');for(const child of row.children)assert.ok(child.rect.left>=row.rect.left&&child.rect.right<=row.rect.right+1&&child.rect.top>=row.rect.top&&child.rect.bottom<=row.rect.bottom+1,'Risk facts must stay inside their row');}
   }
   await page.screenshot({path:resolve(output,name+'.png'),animations:'disabled'});
   const link=rows.last().locator(':scope>a');const href=await link.getAttribute('href');await link.focus();assert.equal(await link.evaluate(node=>node===document.activeElement),true);await page.keyboard.press('Enter');await page.getByTestId('production-providers').waitFor();await settle();assert.equal(new URL(page.url()).hash,href,'Risk View retains actual owner/window destination');
  }else{
   const button=page.locator('.qp-project-header>button');await button.focus();
   facts=await button.evaluate(node=>{const c=getComputedStyle(node);return{rect:node.getBoundingClientRect().toJSON(),text:node.textContent,aria:node.getAttribute('aria-label'),outlineStyle:c.outlineStyle,outlineWidth:c.outlineWidth,background:c.background,borderRadius:c.borderRadius}});
   assert.equal(facts.aria,copy['app.refreshNow']);assert.equal(await button.isEnabled(),true);assert.ok(facts.outlineStyle!=='none'&&parseFloat(facts.outlineWidth)>=2,'Primary action retains keyboard focus indicator');
   if(width>=1536){assert.equal(facts.rect.width,147);assert.equal(facts.rect.height,42);assert.equal(facts.rect.y,78);assert.equal(facts.rect.right,width-19);assert.ok(facts.background.includes('linear-gradient'));}
   await button.evaluate(node=>node.blur());await page.screenshot({path:resolve(output,name+'.png'),animations:'disabled'});
   if(lang==='en'&&theme==='dark'&&width===1672){
    let release=()=>{};const barrier=new Promise<void>(resolve=>{release=resolve});let held=false;
    const snapshot=()=>JSON.stringify(['source','session','usage_event','limit_sample'].map(table=>db.prepare('SELECT * FROM '+table+' ORDER BY id').all()));
    const beforeRefresh=snapshot();db.exec('BEGIN');manual=true;
    const original=await button.boundingBox();
    await page.route('http://127.0.0.1:7816/api/refresh',async route=>{assert.equal(route.request().method(),'POST');held=true;await barrier;await route.continue()});
    try{
     await button.focus();await page.keyboard.press('Enter');await page.waitForFunction(()=>!!document.querySelector<HTMLButtonElement>('.qp-project-header>button')?.disabled);assert.equal(held,true);
     assert.equal(await button.evaluate(node=>getComputedStyle(node).opacity),'0.55');assert.deepEqual(await button.boundingBox(),original,'Pending refresh does not move the action');
     release();await page.waitForFunction(()=>!document.querySelector<HTMLButtonElement>('.qp-project-header>button')?.disabled);await settle();assert.equal(await button.isEnabled(),true);assert.deepEqual(posts,['POST /api/refresh']);facts.manualRefresh={actualEmptyReaderScheduler:true,pendingDisabled:true,geometryPreserved:true,recovered:true};
    }finally{release();await page.unroute('http://127.0.0.1:7816/api/refresh');if(db.inTransaction)db.exec('ROLLBACK');manual=false;}
    assert.equal(snapshot(),beforeRefresh,'Manual test restores all fixture source/session/usage/quota facts');facts.manualRefresh.fixtureRestored=true;
   }
  }
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);assert.deepEqual(errors,[]);assert.deepEqual(forbidden,[]);
  results.push({name,route:routeName,lang,theme,width,facts,errors,forbidden,posts});console.log('Passed '+name);await context.close();
 }
 assert.equal(sha(readFileSync(indexPath)),index);writeFileSync(resolve(output,'verification.json'),JSON.stringify({status:'passed',index,browser:browser.version(),rendererArgs:[],results},null,2));
}finally{await browser?.close();await daemon.close();db.close();globalThis.Date=realDate;process.env.TZ=priorTimezone}
`;
fs.writeFileSync('tmp/check-fidelity124-native.mts',prefix+body);
