from html.parser import HTMLParser
from pathlib import Path
import hashlib, json

root = Path(__file__).resolve().parents[1]
directory = root / 'docs/redesign-v1.85.245'
report = json.loads((directory / 'verification.json').read_text(encoding='utf-8'))
rows = {entry['route']: entry for entry in report['results']}
class Images(HTMLParser):
    def __init__(self):
        super().__init__()
        self.paths = []
    def handle_starttag(self, tag, attrs):
        if tag == 'img': self.paths.append(dict(attrs)['src'])
parser = Images()
parser.feed((directory / 'review.html').read_text(encoding='utf-8'))
pages = ['overview', 'live', 'projects', 'models', 'cost', 'history', 'alerts', 'providers']
assert len(parser.paths) == 16 and set(pages) == set(rows)
for index, page in enumerate(pages):
    for offset, field in [(0, 'referenceSha256'), (1, 'sha256')]:
        path = (directory / parser.paths[index * 2 + offset]).resolve(strict=True)
        assert hashlib.sha256(path.read_bytes()).hexdigest() == rows[page][field], (page, path)
(directory / 'gallery-verification.json').write_text(json.dumps({'images': len(parser.paths), 'pages': pages, 'imageHashesMatchCapture': True, 'scope': 'link and image byte checks; not visual approval'}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified all 16 gallery image paths and capture hashes.')
