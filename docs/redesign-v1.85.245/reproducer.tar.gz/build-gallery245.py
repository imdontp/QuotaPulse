from pathlib import Path
from html import escape
import hashlib, json, shutil, subprocess

root = Path(__file__).resolve().parents[1]
capture = root / 'tmp/fidelity235/goal245-all8'
dest = root / 'docs/redesign-v1.85.245'
assert not dest.exists()
report = json.loads((capture / 'verification.json').read_text(encoding='utf-8'))
index = hashlib.sha256((root / 'packages/web/dist/index.html').read_bytes()).hexdigest()
assert report['productionIndexSha256'] == index == '05b737fcf86a81489e44a6122abc24ec2a475858305fdcd4f3fa3a52f1018e67'
assert subprocess.check_output(['git', 'rev-parse', 'redesign-native-review-v1.85.243^{}'], cwd=root, text=True).strip() == 'd71aa1480af0b9f332ebf757a3c37f0761628a1e'
rows = {row['route']: row for row in report['results']}
pages = ['overview', 'live', 'projects', 'models', 'cost', 'history', 'alerts', 'providers']
assert set(rows) == set(pages)
dest.mkdir()
sections = []
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
for name in pages:
    row = rows[name]
    reference = root / 'docs/redesign-v1.85.156/refs' / f'{name}.png'
    original = Path('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs') / f'{name}.png'
    first, repeat = capture / f'{name}.png', capture / f'{name}-repeat.png'
    assert sha(reference) == sha(original) == row['referenceSha256']
    assert row['repeatIdentical'] and sha(first) == sha(repeat) == row['sha256'] == row['repeatSha256']
    assert not row['errors'] and not row['forbidden']
    shutil.copyfile(first, dest / f'{name}.png')
    label = escape(name.title())
    ref = f'../redesign-v1.85.156/refs/{name}.png'
    image = f'{name}.png'
    sections.append(f'<details{ " open" if name == "overview" else "" }><summary>{label}</summary><div class="pair"><figure><figcaption>Concept</figcaption><a href="{ref}"><img loading="lazy" src="{ref}" alt="{label} concept"></a></figure><figure><figcaption>แอป review243 — ข้อมูลทดสอบ</figcaption><a href="{image}"><img loading="lazy" src="{image}" alt="{label} จากแอป"></a></figure></div></details>')
html = '''<!doctype html><html lang="th"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>QuotaPulse review243: เปรียบเทียบ Dashboard กับ concept</title>
<style>body{margin:24px;background:#071021;color:#dbe8ff;font:16px/1.5 system-ui,sans-serif}p{color:#b6cbe7}a{color:#73ceff}details{margin:12px 0;border:1px solid #27406b;border-radius:8px}summary{padding:12px;cursor:pointer;font-weight:600}summary:focus-visible{outline:2px solid #73ceff}.pair{display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:12px}figure{margin:0;min-width:0}img{display:block;width:100%;height:auto}figcaption{padding:6px}@media(max-width:900px){.pair{grid-template-columns:1fr}body{margin:12px}}</style>
<h1>เปรียบเทียบ Dashboard กับ concept</h1><p>ด้านซ้ายคือภาพอ้างอิง ด้านขวาคือ build เดียวกับ review243 โดยใช้ข้อมูลจำลองในการทดสอบ จำนวนรายการ ตัวเลข และกราฟจึงต่างจาก concept ได้ คลิกภาพเพื่อดูขนาดเต็ม การเปรียบเทียบนี้ยังไม่ใช่การรับรองความเหมือนทั้งหมด</p><p><a href="README.md">ขอบเขตและสิ่งที่ยังต่าง</a></p>''' + '\n'.join(sections) + '</html>\n'
(dest / 'review.html').write_text(html, encoding='utf-8', newline='\n')
shutil.copyfile(capture / 'verification.json', dest / 'verification.json')
print('Verified eight original reference hashes, eight repeat pairs and all image links.')
