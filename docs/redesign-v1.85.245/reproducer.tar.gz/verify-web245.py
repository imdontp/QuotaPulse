from pathlib import Path
from zipfile import ZipFile
import hashlib, json

root = Path(__file__).resolve().parents[1]
dist = root / 'packages/web/dist'
archive = root.parents[2] / 'tmp/releases/QuotaPulse-v1.85.242-review243.zip'
digest = lambda data: hashlib.sha256(data).hexdigest()
with archive.open('rb') as source:
    assert hashlib.file_digest(source, 'sha256').hexdigest() == '8139b9fec3fcb8e2839f54080b7eed8a763a99ecb3b9a087d20d0f1efeff186c'
with ZipFile(archive) as z:
    prefix = 'packages/web/dist/'
    names = {name[len(prefix):] for name in z.namelist() if name.startswith(prefix) and not name.endswith('/')}
    files = {path.relative_to(dist).as_posix() for path in dist.rglob('*') if path.is_file()}
    assert names == files and len(files) == 88
    hashes = {}
    for name in sorted(files):
        hashes[name] = digest((dist / name).read_bytes())
        assert hashes[name] == digest(z.read(prefix + name)), name
record = {'archiveSha256': '8139b9fec3fcb8e2839f54080b7eed8a763a99ecb3b9a087d20d0f1efeff186c', 'sourceCommit': 'd71aa1480af0b9f332ebf757a3c37f0761628a1e', 'fileCount': len(hashes), 'files': hashes, 'scope': 'compiled web files only; other release components are not compared here'}
(root / 'docs/redesign-v1.85.245/web-bundle-verification.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified all compiled web files match the delivered review ZIP.')
