# Orbit Bot Motion Production Pilot

## Goal
Use Orbit Bot as the pilot character for QuotaPulse Pet Mode animation production before scaling the same pipeline to Pulse Fox, Flux Blob, and Capsule Cat.

## Important distinction
The included PNG boards are production references / keyframe guides, not final runtime animation clips.

They lock:
- character identity,
- proportions,
- silhouette,
- key poses,
- frame counts,
- state timing,
- motion style.

Final runtime assets should be exported as consistent transparent PNG/WebP frames or Animated WebP after approval.

## Pilot animation set

### Phase A — Locomotion
- idle_loop: 8 frames
- walk_right: 8 frames
- walk_left: 8 frames
- turn_right: 6 frames
- turn_left: 6 frames
- stop: 4 frames

### Phase B — Rest
- sit_down: 6 frames
- sit_idle: 6 frames loop
- lie_down: 6 frames
- sleep_loop: 6–8 frames loop
- wake_up: 6 frames
- stretch: 6 frames

### Phase C — Interaction
- hover_react: 4–6 frames
- click_react: 4–6 frames
- talk_loop: 6–8 frames loop

## Recommended runtime timing
- idle: 8–10 fps
- walk: 10–12 fps
- turn: 10–12 fps
- stop: 8–10 fps
- sit/lie/wake/stretch: 8–12 fps
- sleep loop: 6–8 fps
- click/hover: 10–12 fps

## Production canvas
- master: 1024 x 1024
- runtime: 512 x 512 / 256 x 256
- transparent background
- fixed canvas
- fixed pivot
- no text
- no baked UI bubble

## Pivot
- x = 0.5
- y = 0.92

## Desktop movement rule
The animation clip shows Orbit Bot walking in place.
The Electron movement controller owns x/y translation, roaming distance, monitor bounds, and docking.

## Visual identity constraints
Must preserve:
- white/silver shell
- black screen face
- cyan/blue eyes
- cyan status accents
- compact chibi robot proportions
- antenna/live indicator
- chest/quota identity mark where applicable

## Motion personality
Orbit Bot should feel:
- precise,
- calm,
- helpful,
- mechanical but soft,
- low-noise.

Avoid:
- animal gait,
- exaggerated rubber-hose movement,
- extreme squash/stretch,
- large uncontrolled bounce.

## Approval gate
Do not scale to the other 3 Stable characters until:
1. walk loop looks correct in QuotaPulse,
2. sit/lie/sleep works with current window bounds,
3. pivot does not jitter,
4. movement speed feels natural,
5. animation memory/CPU is acceptable.
