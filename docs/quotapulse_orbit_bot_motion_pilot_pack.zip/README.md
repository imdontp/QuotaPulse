# QuotaPulse — Orbit Bot Motion Production Pilot

Start with:
1. `01_production_spec/ORBIT_BOT_MOTION_PILOT_SPEC.md`
2. `02_runtime_manifest/orbit-bot-motion-pilot.json`
3. `03_agent_prompts/AI_AGENT_ORBIT_BOT_PILOT_PROMPT.md`
4. `04_qa/ORBIT_BOT_PILOT_QA.md`

The PNGs in `00_reference/` are visual/keyframe references only.
