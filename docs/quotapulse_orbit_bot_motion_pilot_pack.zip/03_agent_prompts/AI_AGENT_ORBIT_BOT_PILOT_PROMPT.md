# AI Agent Handoff — Orbit Bot Motion Pilot

Use the files in `00_reference/` as visual references and `01_production_spec/ORBIT_BOT_MOTION_PILOT_SPEC.md` as the production contract.

## Mission
Integrate Orbit Bot as the first real motion-production pilot in the existing QuotaPulse Pet Mode.

## Important
The PNG boards are references, not final runtime clips.
Do not crop UI panels from the concept board and ship them as animation assets.

## Required work
1. Inspect existing animation/runtime architecture.
2. Map current semantic ids to the pilot manifest.
3. Create/prepare final transparent frame sequences or Animated WebP for locomotion/rest/interaction clips.
4. Keep identical canvas/pivot across frames.
5. Keep screen movement in the movement controller.
6. Test at 256px first.
7. Tune walk speed against actual desktop movement distance.
8. Validate reduced-motion fallbacks.
9. Measure CPU/memory during idle and walking.
10. Do not copy the pipeline to the other Stable characters until pilot approval.

## Acceptance
- no frame jitter
- no crop jump
- no wrong left/right branding
- sit/lie/sleep fit current Pet window
- walk animation and Electron translation feel synchronized
- no loop restart on quota refresh
- no regression to Tray/Focus logic
