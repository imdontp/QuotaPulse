# Animation/Asset Production Prompt — Orbit Bot Pilot

Use the approved Orbit Bot original concept and pilot reference boards.

Produce one animation at a time.

## Non-negotiable
- exact Orbit Bot identity
- transparent background
- fixed 1024x1024 master canvas
- fixed pivot x=0.5, y=0.92
- same body scale in every frame
- no text
- no UI panel
- no speech bubble baked into art
- no long-distance translation inside frames
- preserve cyan/white/black design
- preserve asymmetrical details correctly

## Priority
1. walk_right
2. walk_left
3. turn_right
4. turn_left
5. stop
6. sit_down
7. lie_down
8. sleep_loop
9. wake_up
10. stretch

First approve key frames, then create in-betweens.
