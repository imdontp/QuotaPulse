# Orbit Bot Motion Pilot QA

## Visual consistency
- [ ] face matches concept
- [ ] shell proportions stable
- [ ] cyan accents stable
- [ ] antenna/live indicator stable
- [ ] no mirrored branding errors

## Frame integrity
- [ ] identical canvas
- [ ] identical pivot
- [ ] no crop jitter
- [ ] no alpha halo
- [ ] no background baked in

## Walk
- [ ] right loop closes smoothly
- [ ] left loop closes smoothly
- [ ] desktop translation matches perceived step speed
- [ ] no excessive foot sliding

## Rest
- [ ] sit readable
- [ ] lie down fits window
- [ ] sleep loop subtle
- [ ] wake transition clean
- [ ] stretch returns cleanly to idle

## Runtime
- [ ] no repeated animation restart
- [ ] no memory growth from switching loops
- [ ] reduced motion safe
- [ ] fallback asset works
- [ ] tray/focus unaffected

## Pilot approval
- [ ] approved for scaling to Pulse Fox
- [ ] approved for scaling to Flux Blob
- [ ] approved for scaling to Capsule Cat
