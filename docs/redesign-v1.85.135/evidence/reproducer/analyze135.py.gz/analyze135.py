from pathlib import Path
from PIL import Image
import numpy as np,json
a=np.asarray(Image.open('tmp/fidelity135/before/models.png').convert('RGB')).astype(int);b=np.asarray(Image.open('tmp/fidelity135/after/models.png').convert('RGB')).astype(int);d=np.abs(a-b);mask=d.max(2)>0
for name,box in [('all',(0,0,1672,941)),('comparison',(236,259,1268,834)),('table header',(246,348,1258,386)),('legend',(1299,410,1500,500)),('ring',(1500,380,1640,520)),('heading',(1299,375,1455,414))]:
 x,y,r,bt=box;yy,xx=np.where(mask[y:bt,x:r]);region=d[y:bt,x:r]
 print(json.dumps({'name':name,'pixels':len(xx),'max':int(region.max()),'bounds':None if not len(xx)else[int(xx.min()+x),int(yy.min()+y),int(xx.max()+x),int(yy.max()+y)]}))
for phase in ['before','after']:
 p=Path('tmp/fidelity135')/phase/'verification.json';data=json.loads(p.read_text());print(phase,data['results'][0]['sha256'])
