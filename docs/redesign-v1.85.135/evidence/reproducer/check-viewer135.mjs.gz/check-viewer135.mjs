import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const browser=await chromium.launch({channel:'chrome',headless:true});
try {
 const page=await browser.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(pathToFileURL(resolve('docs/redesign-v1.85.135/review.html')).href);
 const phases=await page.locator('#phase option').evaluateAll(nodes=>nodes.map(n=>n.value));
 for(const value of phases){await page.locator('#phase').selectOption(value);await page.waitForFunction(()=>{const img=document.querySelector('#frame');return img.complete&&img.naturalWidth>0})}
 assert.equal(phases.length,6);assert.deepEqual(errors,[]);console.log(JSON.stringify({checked:phases.length,errors}));
}finally{await browser.close()}
