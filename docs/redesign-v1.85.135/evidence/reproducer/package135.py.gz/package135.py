from pathlib import Path
from PIL import Image
import json,gzip,hashlib,re,zipfile,numpy as np
out=Path('docs/redesign-v1.85.135');base=Path('tmp/fidelity135');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,zipped=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes();p.write_bytes(gzip.compress(b,mtime=0)if zipped else b)
index=sha(Path('packages/web/dist/index.html').read_bytes())
before=load(base/'before/verification.json');after=load(base/'after/verification.json');motion=load(base/'motion/verification.json');layout=load(base/'layout/verification.json');edge=load(base/'scenarios/verification.json');stable=load('screens/models-comparison/verification.json')
assert before['productionIndexSha256']=='32a0482a0d1c9dbbbfa33780af6b0db3187e9b22f892f8b0b83a571b48f57481'
assert all(value==index for value in [after['productionIndexSha256'],motion['productionIndexSha256'],layout['index'],edge['index'],stable['productionIndexSha256']])
assert motion['status']==layout['status']==edge['status']=='passed'
assert len(motion['results'])==4 and len(layout['results'])==8 and len(edge['results'])==12
assert len(stable['cases'])==4 and all(c['sha256']==c['repeatSha256']for c in stable['cases'])
for phase,data in [('before',before),('after',after)]:
 row=data['results'][0];assert row['route']=='models'and row['repeatIdentical'];assert sha((base/phase/'models.png').read_bytes())==row['sha256'];copy(base/phase/'models.png','images/'+phase+'.png');copy(base/phase/'legend.json','evidence/legend-'+phase+'.json')
assert before['results'][0]['geometry']['mainRegions']==after['results'][0]['geometry']['mainRegions']
a=np.asarray(Image.open(base/'before/models.png').convert('RGB')).astype(int);b=np.asarray(Image.open(base/'after/models.png').convert('RGB')).astype(int);delta=np.abs(a-b);yy,xx=np.where(delta.max(2)>0)
outside=[{'x':int(x),'y':int(y),'before':a[y,x].tolist(),'after':b[y,x].tolist(),'maxDelta':int(delta[y,x].max())}for y,x in zip(yy,xx)if not(1290<=x<1500 and 405<=y<520)]
write('analysis.json',{'scope':'Whole unmasked source134/source135 Models frames; no reference similarity score.','beforeIndex':before['productionIndexSha256'],'index':index,'changedPixels':len(xx),'maxChannelDelta':int(delta.max()),'bounds':None if not len(xx)else[int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())],'mainGeometryEqual':True,'outsideLegendDifferences':outside,'distinctDocumentRasterGate':'open: three comparison border pixels differ; cause unestablished; no mask or tolerance pass','packagingCorrection':'Initial packaging assumption that all changed pixels were inside the legend was disproved. Retain every pixel difference instead of declaring a whole-frame pass.'})
legendBefore=load(base/'before/legend.json');legendAfter=load(base/'after/legend.json')
assert len(legendBefore['rows'][1]['children'][1]['glyphs'])==2
assert all(len(row['children'][1]['glyphs'])==1 for row in legendAfter['rows'])
for name,src in [('motion',base/'motion/verification.json'),('layout',base/'layout/verification.json'),('scenarios',base/'scenarios/verification.json'),('stable','screens/models-comparison/verification.json'),('before',base/'before/verification.json'),('after',base/'after/verification.json')]:copy(src,'evidence/'+name+'.json.gz',True)
for name in ['en-dark-mid','en-dark-settled','th-light-mid','th-light-settled']:copy(base/'motion'/(name+'.png'),'images/motion/'+name+'.png')
for name in ['en-dark-390','th-light-390']:copy(base/'layout'/(name+'.png'),'images/layout/'+name+'.png')
for name in ['Zero-components-en-dark-1672','Output-only-en-dark-1672','Tiny-input-en-dark-1672','Missing-components-th-light-390']:copy(base/'scenarios'/(name+'.png'),'images/scenarios/'+name+'.png')
logs=['build135-web-final.log','test135-web-final.log','motion135-final.log','layout135.log','scenarios135.log','stable135-models.log','measure135-final.log','motion135-reduced-before.log','motion135-initial-reduced-before.log','motion135-direct-guard.log']
for name in logs:copy('tmp/'+name,'evidence/logs/'+name+'.gz',True)
for name in ['check-motion135.mts','check-ring135-layout.mts','check-ring135-scenarios.mts','measure135.mts','check-viewer135.mjs','analyze135.py','package135.py']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
viewer=Path('tmp/viewer135.log').read_bytes();viewer=viewer.decode('utf-16'if viewer[:2]==b'\xff\xfe'else'utf-8').lstrip('\ufeff').strip();assert json.loads(viewer)=={'checked':6,'errors':[]};write('evidence/viewer.json',json.loads(viewer))
archive=Path('docs/quotapulse_build_blueprint_v1.1.zip');assert sha(archive.read_bytes())=='28bc63571ddf7ecda1e12e8821c6184378ccfe6c3a599d6ccec29bf17fedb054'
with zipfile.ZipFile(archive)as z:
 member='quotapulse_build_blueprint/03_DESIGN_SYSTEM_AND_MOTION.md';contract=z.read(member)
 write('evidence/authority.json',{'archive':str(archive),'sha256':sha(archive.read_bytes()),'member':member,'memberSha256':sha(contract),'decision':'Explicit selection transition uses shared180ms token and stable model/provider identity. Reduced motion has immediate values.'})
library=Path('C:/Users/TH12367283/Projects/QuotaPulse/node_modules/framer-motion/dist/es/utils/reduced-motion/use-reduced-motion.mjs')
text=library.read_text(encoding='utf-8');assert 'const [shouldReduceMotion] = useState(prefersReducedMotion.current)'in text
write('evidence/reduced-motion-diagnosis.json',{'installedModule':str(library),'sha256':sha(library.read_bytes()),'mechanism':'Installed useReducedMotion stores the initial preference with useState and no updating setter. Both normal-to-reduced and initial-reduced-to-normal failures were reproduced before using live matchMedia in the ring adapter. Shared duration/easing tokens remain unchanged.','scope':'Ring adapter only; other motion callers are not newly validated for dynamic preferences.'})
sources=['packages/web/src/redesign/models.tsx','packages/web/src/redesign/model-token-distribution-panel.tsx','packages/web/src/redesign/model-token-distribution.css','packages/web/src/redesign/model-ring-motion.ts','packages/web/src/redesign/use-model-ring-motion.ts','packages/web/test/model-ring-motion.test.ts']
write('source-fingerprints.json',[{'path':p,'rawSha256':sha(Path(p).read_bytes()),'lfSha256':sha(Path(p).read_bytes().replace(b'\r\n',b'\n'))}for p in sources])
test=Path('tmp/test135-web-final.log').read_bytes();test=test.decode('utf-16'if test[:2]==b'\xff\xfe'else'utf-8');assert re.search(r'^# pass 349\r?$',test,re.M)and re.search(r'^# fail 0\r?$',test,re.M)
write('summary.json',{'checkpoint':'v1.85.135','parent':'88dd6b623522c0be82d45d461587ee13f4dfa152','index':index,'webTests':349,'motionBrowserContexts':4,'layoutBrowserCases':8,'edgeBrowserCases':12,'stableExactPairs':4,'fullRedesignComplete':False,'latestRunnableZip':'review132/source131; excludes source133–135'})
(out/'README.md').write_text('''# Models ring selection motion v1.85.135

[Open original / source134 / source135](review.html). Validated bounded implementation; full redesign, physical-host behavior and 99–100% visual acceptance remain open.

The approved Models screen retains its detail donut; the shared motion contract requires a 180ms selection transition, stable identity and no reduced-motion movement. The ring now interpolates its two actual component arcs and highlights once on an explicit in-scope model/provider selection. It uses existing DURATION.fast and EASE.motion tokens with native Web Animations. Exact counts, accessible labels and final SVG data attributes update immediately to the selected facts. No counts are animated or fabricated. Zero/unavailable/invalid components settle immediately, and partial total provenance remains visible. Both arc elements persist with a true zero sweep so a disappearing component can settle smoothly without a fabricated positive floor.

Mounts, refreshes, automatic fallback, scope changes and duplicate selections do not replay. Rapid selections cancel old owned animations. Reduced-motion changes, document visibility events, offscreen intersection and unmount stop owned animations and consume the pending selection; restoration has no queue or replay. There are no animation loops, frame callbacks, new timers, data requests or dependencies.

Browser diagnosis found the installed motion hook retained its initial reduced-motion value. A direct live media guard fixed normal-to-reduced behavior; a second reproduction proved retaining the stale initial flag still blocked initial-reduced-to-normal restoration. The ring adapter now uses the actual current media query plus change events. Both failure logs, the intermediate partial correction and installed module hash/mechanism are retained. This does not claim all existing motion callers are fixed or dynamically validated.

Legend measurement showed Output Tokens on two lines (36px row) despite the reference single line. Wide legend padding now reserves enough label width: both rows are 18px and retain their exact values. Heading and ring paint and main region geometry remain unchanged. The whole-frame comparison records 5,365 changed legend pixels plus three comparison-border pixels at x246 (y353–422, maximum channel delta23). The cause of those three border differences is unestablished. Initial packaging incorrectly assumed changes would be confined to the legend; analysis disproved it. Every changed pixel is retained, with no mask or tolerance pass, and the distinct-document whole-frame raster gate remains open. The screenshots use isolated synthetic QA data; no fixture enters production.

Validation: web build and 349 tests passed. Four actual Chrome EN/TH dark/light contexts exercise native 180ms timing, intermediate keyframes, immediate final values, natural completion, rapid cancellation, single-component targets, both directions of reduced-motion changes, offscreen skip/restoration, zero fallback, scope reset and SPA unmount cleanup. The harness pauses only ring animations to inspect exact playheads, then separately tests natural unpaused completion. Eight responsive/reduced cases and twelve zero/missing/mismatch/single/tiny component cases preserve API accounting, keyboard disclosure and geometry. The maintained Models gate passes four byte-identical capture/repeat pairs with its existing assertions unchanged.

Real hidden-window transitions and physical frame performance are not newly exercised: visibility cancellation has a production listener and eligibility guard, while browser evidence here covers actual media and viewport/intersection changes. Native Electron and other pages are not recertified. Previously retained distinct-document header raster findings, the full gap ledger and full requirement trace remain open. Latest runnable ZIP remains review132/source131 and excludes source133–135. Main and unrelated files remain untouched.
''',encoding='utf-8',newline='\n')
html='''<!doctype html><meta charset="utf-8"><title>QuotaPulse ring review135</title><style>body{font:14px system-ui;background:#071020;color:#def;margin:20px}select{padding:8px}img{display:block;max-width:100%;margin:16px 0;border:1px solid #456}a{color:#5cf}</style><h1>Models ring: original / source134 / source135</h1><a href="README.md">Validation and limitations</a><p><select id="phase"><option value="../../docs/redesign-v1.85.69/refs/models.png">Original reference</option><option value="images/before.png">Source134</option><option value="images/after.png" selected>Source135</option><option value="images/motion/en-dark-mid.png">Motion midpoint (QA)</option><option value="images/motion/en-dark-settled.png">Motion settled (QA)</option><option value="images/layout/th-light-390.png">Thai light 390px (QA)</option></select></p><img id="frame" alt="Selected comparison"><script>const phase=document.getElementById('phase'),frame=document.getElementById('frame');function show(){frame.src=phase.value}phase.onchange=show;show()</script>'''
(out/'review.html').write_text(html,encoding='utf-8',newline='\n')
write('artifact-hashes.json',{str(p.relative_to(out)).replace('\\','/'):sha(p.read_bytes())for p in sorted(out.rglob('*'))if p.is_file()and p.name!='artifact-hashes.json'})
print(json.dumps({'index':index,'artifacts':len(load(out/'artifact-hashes.json')),'changedPixels':len(xx),'bounds':[int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())]}))
