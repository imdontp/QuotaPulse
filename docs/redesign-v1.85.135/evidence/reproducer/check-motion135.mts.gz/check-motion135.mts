/** Static canonical reference capture. Isolated synthetic DB, compiled application, no user data. */
import assert from 'node:assert/strict';
import { installBrowserFixedDate } from '../scripts/browser-fixed-date.mjs';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium, type Page, type Request } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import { recordQuotaAlerts } from '../packages/daemon/src/api/queries.js';
const root = fileURLToPath(new URL('..', import.meta.url));
const output = resolve(root, 'tmp/fidelity135/motion'); 
const referenceRoot = 'C:/Users/TH12367283/Downloads/quotapulse_build_blueprint';
const priorTimezone = process.env.TZ;
process.env.TZ = 'Asia/Bangkok';
mkdirSync(output, { recursive: true });

const fixedNow = Date.parse('2025-05-17T13:42:00.000Z');
// Freeze Date only, keeping real timers/performance for HTTP, browser and cleanup.
// This applies to internal query helpers too, without changing production clocks.
const realDate = globalThis.Date;
globalThis.Date = new Proxy(realDate, {
  construct(target, args) { return Reflect.construct(target, args.length ? args : [fixedNow]); },
  apply() { return new realDate(fixedNow).toString(); },
  get(target, property, receiver) { return property === 'now' ? () => fixedNow : Reflect.get(target, property, receiver); },
});
const db = openDb(':memory:');
db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at,account_key,account_provider,account_display_name,account_state,account_last_success_at)
  VALUES (1,'codex','fixed','/synthetic/nonexistent','Codex fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow}),
    (2,'hermes','fixed','/synthetic/nonexistent','Hermes fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (3,'claude-code','fixed','/synthetic/nonexistent','Claude Code fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (4,'opencode','fixed','/synthetic/nonexistent','OpenCode fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow});`);
const referenceProjects = ['QuotaPulse', 'Agent Platform', 'Edge Services', 'Developer Tools', 'Research Lab'];
const referenceModels = [
  { name: 'DeepSeek V4.1', provider: 'deepseek', share: 38 },
  { name: 'GPT-5.x', provider: 'openai', share: 24 },
  { name: 'Claude 3.7', provider: 'anthropic', share: 18 },
  { name: 'Claude 3.5', provider: 'anthropic', share: 11 },
  { name: 'Others', provider: 'openrouter', share: 9 },
  { name: 'GPT-4.1 mini', provider: 'openai', share: 0 },
];
const session = db.prepare('INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (?,?,?,?,?)');
const usage = db.prepare('INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source,cost_input_usd,cost_cached_input_usd,cost_cache_write_usd,cost_output_usd,cost_cache_saving_usd,price_provider) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
// Synthetic catalogue rates for the in-memory visual fixture only. The saved
// amount is derived from the same fresh/cached input components the UI reports.
const fixtureInputUsdPerMillion = 0.0593846153846154, fixtureCachedInputUsdPerMillion = 0.004, fixtureOutputUsdPerMillion = 0.004;
for (let index = 0; index < 12; index++) {
  // Keep the reference map's 4 Codex, 2 Claude Code, 6 Hermes, 0 OpenCode
  // recent-session distribution while preserving the same 12 sessions.
  const source = [1, 1, 1, 1, 3, 3, 2, 2, 2, 2, 2, 2][index]!;
  session.run(index + 1, source, `fixture-session-${index}`, referenceProjects[0], fixedNow - 10_000);
  const model = referenceModels[index % referenceModels.length]!;
  const totalTokens = model.share === 0 ? 1 : model.share * 721_000_000 / 600;
  for (let call = 0; call < 3; call++) {
    const inputShare = [.6, .65, .7][(index + call) % 3]!;
    const inputTokens = totalTokens * inputShare * .58, cachedInputTokens = totalTokens * inputShare * .42;
    const outputTokens = totalTokens * (1 - inputShare);
    const costSource = index === 0 ? 'native' : 'computed';
    const inputUsd = inputTokens / 1_000_000 * fixtureInputUsdPerMillion;
    const cachedInputUsd = cachedInputTokens / 1_000_000 * fixtureCachedInputUsdPerMillion;
    const outputUsd = outputTokens / 1_000_000 * fixtureOutputUsdPerMillion;
    const cacheSavingUsd = cachedInputTokens / 1_000_000 * (fixtureInputUsdPerMillion - fixtureCachedInputUsdPerMillion);
    // Keep each session's latest record within four minutes, then spread older calls across the visible 30-minute interval.
    const ageMs = call === 0 ? 15_000 + index * 20_000 : source === 2
      ? 300_000 + index * 120_000 + (call === 2 ? 30_000 : 0)
      : 300_000 + index * 240_000 + (call === 2 ? 90_000 : 0);
    const recordedAt = fixedNow - ageMs;
    usage.run(source, index + 1, `fixed-${index}-${call}`, recordedAt, model.name, model.provider,
      inputTokens, cachedInputTokens, outputTokens, totalTokens, call + 1,
      costSource === 'native' ? (index + 1) / 100 : inputUsd + cachedInputUsd + outputUsd, costSource,
      costSource === 'native' ? null : inputUsd, costSource === 'native' ? null : cachedInputUsd,
      costSource === 'native' ? null : 0, costSource === 'native' ? null : outputUsd,
      costSource === 'native' ? null : cacheSavingUsd, costSource === 'native' ? null : model.provider);
  }
}
// A stale recorded OpenCode route keeps the concept's zero-active-session edge
// visible without manufacturing a provider relationship or changing live counts.
const openCodeAt = fixedNow - 10 * 60_000;
session.run(13, 4, 'fixture-opencode-quota-pulse', referenceProjects[0], openCodeAt);
usage.run(4, 13, 'fixed-opencode-route', openCodeAt, 'DeepSeek V4.1', 'deepseek', 1, 0, 0, 1, 1,
  null, 'unknown', null, null, null, null, null, null);
// The monthly concept is focused on QuotaPulse while the machine-wide quick
// stats still report all five named projects. Keep four small monthly records
// for the other projects, outside the recent-session window.
for (let index = 1; index < referenceProjects.length; index++) {
  const id = 100 + index, source = [1, 3, 4, 2][index - 1]!;
  const model = referenceModels[index - 1]!;
  const at = fixedNow - 10 * 60_000;
  session.run(id, source, `fixture-project-${index}`, referenceProjects[index], at);
  const inputUsd = fixtureInputUsdPerMillion / 1_000_000;
  usage.run(source, id, `fixture-project-usage-${index}`, at, model.name, model.provider, 1, 0, 0, 1, 1,
    inputUsd, 'computed', inputUsd, 0, 0, 0, 0, model.provider);
}
// Values below the old visual minimum catch inflated nonzero bars in both charts.
const tinyUsage = db.prepare("INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source) VALUES (1,1,?,?,'DeepSeek V4.1','deepseek',1,0,0,1,1,0,'computed')");
tinyUsage.run('fixed-tiny-minute', fixedNow - 15 * 60_000);
tinyUsage.run('fixed-tiny-day', fixedNow - 3 * 86_400_000);
const quota = db.prepare('INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin) VALUES (?,?,?,?,?,?,?,?)');
const addQuotaSample = (sourceId: number, window: string, percent: number | null, resetAt: number | null, observedAt: number) => quota.run(sourceId, window, percent, resetAt, observedAt, observedAt, observedAt, 'fixed-fixture');
// Complete history must include older reset periods, nulls and more than eight
// readings per period, without changing the latest live quota/default selection.
for (let segment = 0; segment < 4; segment++) for (let index = 0; index < 12; index++) {
  const at = fixedNow - (5 - segment) * 3_600_000 + index * 60_000;
  addQuotaSample(1, '5h', index === 4 ? null : index === 1 ? 0.5 : index * 8, segment === 0 ? null : fixedNow - (4 - segment) * 3_600_000, at);
}
addQuotaSample(1, '5h', 38, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 5 * 60_000);
addQuotaSample(1, '5h', 83, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 30_000);
addQuotaSample(1, 'weekly', 62, fixedNow + (3 * 24 + 5) * 3_600_000, fixedNow - 30_000);
const monthlyReset = fixedNow + (6 * 24 + 2) * 3_600_000;
addQuotaSample(1, 'monthly', 59, monthlyReset, fixedNow - 48 * 3_600_000);
addQuotaSample(1, 'monthly', 65.5, monthlyReset, fixedNow - 24 * 3_600_000);
addQuotaSample(1, 'monthly', 72, monthlyReset, fixedNow - 30_000);
addQuotaSample(2, 'monthly', 58, fixedNow + (12 * 24 + 6) * 3_600_000, fixedNow - 30_000);
addQuotaSample(2, 'daily', 34, fixedNow + (7 * 60 + 18) * 60_000, fixedNow - 30_000);
recordQuotaAlerts(db, fixedNow);
for(const [model,input,output]of [['Ring A',900000000,100000000],['Ring B',90000000,810000000],['Ring C',500000000,0],['Ring Zero',0,0]]as const)db.prepare("INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,output_tokens,total_tokens,call_count,cost_source) VALUES(1,1,?, ?,?,'ring-qa',?,?,?,1,'unknown')").run('ring-'+model,fixedNow,model,input,output,input+output);
const scheduler = new Scheduler(db, [], { pollMs: 1_000_000, detectMs: 1_000_000 });
const webRoot = resolve(process.env.QP_FIDELITY_WEB_ROOT ?? resolve(root, 'packages/web/dist'));
const daemon = buildServer(db, scheduler, { token: 'stable-capture-test', port: 7816, webRoot });
let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;
const sha = (bytes: Buffer) => createHash('sha256').update(bytes).digest('hex');
const indexPath = resolve(webRoot, 'index.html');
const productionIndexSha256 = sha(readFileSync(indexPath));
const rendererArgs: string[] = [];
const referenceManifest = JSON.parse(readFileSync(resolve(referenceRoot, 'reference_manifest.json'), 'utf8'));
const targets = { overview: '.qp-activity-item', live: '.qp-live-chart', projects: '.qp-project-trend', models: '.qp-model-trend', history: '[data-testid="usage-history"] tbody tr', alerts: '.qp-quota-point', providers: '.qp-provider-health tbody tr', cost: '.qp-cost-chart' };
const results: unknown[] = [];

try{
 await daemon.listen({host:'127.0.0.1',port:7816});browser=await chromium.launch({channel:'chrome',headless:true});
 for(const lang of ['en','th'])for(const theme of ['dark','light']){
  const name=lang+'-'+theme,initialReduced=theme==='light',context=await browser.newContext({viewport:{width:1672,height:941},reducedMotion:initialReduced?'reduce':'no-preference',deviceScaleFactor:1,timezoneId:'Asia/Bangkok'}),page=await context.newPage(),errors:string[]=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.addInitScript(({lang,theme})=>{
   (window as any).__QUOTAPULSE_TOKEN__='stable-capture-test';localStorage.setItem('quotapulse-prefs',JSON.stringify({lang,currency:'USD',rate:1,hiddenSubscriptions:[]}));localStorage.setItem('quotapulse-theme',theme);
   (window as any).__ringAnimations=[];(window as any).__ringPause=true;const native=Element.prototype.animate;
   Element.prototype.animate=function(...args){const animation=native.apply(this,args);if(this.hasAttribute('data-ring-sector')||this.hasAttribute('data-ring-highlight')){if((window as any).__ringPause)animation.pause();(window as any).__ringAnimations.push({animation,target:this,frames:args[0],options:args[1]})}return animation};
  },{lang,theme});await installBrowserFixedDate(page,fixedNow);
  await page.goto('http://127.0.0.1:7816/#models');await page.locator('.qp-model-detail h3').filter({hasText:'Ring A'}).waitFor();await page.evaluate(()=>document.fonts.ready);
  const count=()=>page.evaluate(()=>(window as any).__ringAnimations.length);
  const choose=async(model:string)=>{await page.locator('.qp-model-table-wrap button').filter({hasText:model}).click();await page.waitForFunction(model=>document.querySelector('.qp-model-detail h3')?.textContent===model,model)};
  assert.equal(await count(),0,'no mount replay');
  if(initialReduced){await choose('Ring B');assert.equal(await count(),0);await page.emulateMedia({reducedMotion:'no-preference'});assert.equal(await page.evaluate(()=>matchMedia('(prefers-reduced-motion: reduce)').matches),false);await choose('Ring A');assert.equal(await count(),4,'restored initial reduced preference allows a fresh selection');await page.evaluate(()=>{for(const r of (window as any).__ringAnimations)r.animation.finish()});await page.waitForFunction(()=>document.querySelector('.qp-model-donut')!.getAnimations({subtree:true}).length===0);await page.evaluate(()=>(window as any).__ringAnimations=[])}
  await choose('Ring B');assert.equal(await count(),4,'two arcs plus two highlights');
  const initial=await page.evaluate(()=>{const records=(window as any).__ringAnimations;for(const r of records)r.animation.currentTime=90;return records.map((r:any)=>({frames:r.frames,options:r.options,timing:r.animation.effect.getComputedTiming(),computed:{dash:getComputedStyle(r.target).strokeDasharray,offset:getComputedStyle(r.target).strokeDashoffset}}))});
  for(const r of initial){assert.equal(r.options.duration,180);assert.equal(r.options.iterations,1);assert.equal(r.options.fill,'none');assert.ok(r.timing.progress>0&&r.timing.progress<1);assert.notEqual(r.computed.dash.replaceAll('px','').replaceAll(',',''),r.frames[0].strokeDasharray)}
  assert.equal(await page.locator('[data-token-sector=input]').getAttribute('data-share'),'10');assert.equal(await page.locator('[data-token-sector=output]').getAttribute('data-share'),'90');
  const mid=await page.screenshot({path:resolve(output,name+'-mid.png'),animations:'allow'});
  await page.evaluate(()=>{for(const r of (window as any).__ringAnimations)r.animation.finish()});await page.waitForFunction(()=>document.querySelector('.qp-model-donut')!.getAnimations({subtree:true}).length===0);
  const settled=await page.screenshot({path:resolve(output,name+'-settled.png'),animations:'allow'});
  await choose('Ring A');assert.equal(await count(),8);await choose('Ring C');assert.equal(await count(),12);
  assert.equal(await page.evaluate(()=>(window as any).__ringAnimations.slice(4,8).every((r:any)=>r.animation.playState==='idle')),true,'rapid selection cancels prior arcs');
  assert.equal(await page.locator('[data-ring-sector=output]').getAttribute('stroke-dasharray'),'0 360');
  await choose('Ring C');assert.equal(await count(),12,'same selection does not replay');
  await page.emulateMedia({reducedMotion:'reduce'});await page.waitForFunction(()=>document.querySelector('.qp-model-donut')!.getAnimations({subtree:true}).length===0);await choose('Ring B');assert.equal(await count(),12,'reduced motion is immediate');
  await page.emulateMedia({reducedMotion:'no-preference'});await choose('Ring A');assert.equal(await count(),16);
  await page.emulateMedia({reducedMotion:'reduce'});await page.waitForFunction(()=>document.querySelector('.qp-model-donut')!.getAnimations({subtree:true}).length===0);await page.emulateMedia({reducedMotion:'no-preference'});assert.equal(await count(),16,'preference restore does not replay');
  await page.setViewportSize({width:1672,height:300});await page.waitForTimeout(60);await page.locator('.qp-model-table-wrap button').filter({hasText:'Ring B'}).evaluate((button:HTMLButtonElement)=>button.click());await page.waitForFunction(()=>document.querySelector('.qp-model-detail h3')?.textContent==='Ring B');assert.equal(await count(),16,'offscreen selection is immediate');
  await page.setViewportSize({width:1672,height:941});await page.waitForTimeout(60);assert.equal(await count(),16,'offscreen restore does not replay');
  await choose('Ring Zero');assert.equal(await count(),16,'zero fallback is immediate');await choose('Ring A');assert.equal(await count(),16,'zero has no invented angular transition');
  await page.locator('.qp-model-header select').selectOption('all');await page.locator('.qp-model-detail h3').waitFor();assert.equal(await count(),16,'scope change is immediate');
  await page.evaluate(()=>(window as any).__ringPause=false);await choose('Ring B');assert.equal(await count(),20);await page.waitForFunction(()=>(window as any).__ringAnimations.slice(16,20).every((r:any)=>r.animation.playState==='idle'),{},{timeout:2000});
  await page.evaluate(()=>(window as any).__ringPause=true);await choose('Ring A');assert.equal(await count(),24);await page.locator('.qp-sidebar a[href="#overview"]').click();await page.getByTestId('production-overview').waitFor();assert.equal(await page.evaluate(()=>(window as any).__ringAnimations.every((r:any)=>r.animation.playState==='idle')),true,'unmount cancels every owned native animation');assert.deepEqual(errors,[]);
  results.push({name,initial,midSha256:sha(mid),settledSha256:sha(settled),finite180ms:true,rapidCancellation:true,singleComponent:true,reducedImmediate:true,offscreenImmediate:true,restoreNoReplay:true,zeroImmediate:true,scopeImmediate:true,errors});console.log('Passed '+name);await context.close();
 }
 assert.equal(sha(readFileSync(indexPath)),productionIndexSha256);writeFileSync(resolve(output,'verification.json'),JSON.stringify({status:'passed',productionIndexSha256,browser:browser.version(),scope:'Native Chrome WAAPI timing and manually positioned playheads; no physical-frame performance or real hidden-window claim.',results},null,2));
}finally{await browser?.close();await daemon.close();db.close();globalThis.Date=realDate;process.env.TZ=priorTimezone}
