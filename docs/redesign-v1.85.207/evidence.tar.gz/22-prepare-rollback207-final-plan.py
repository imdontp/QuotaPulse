from pathlib import Path
from zipfile import ZipFile
import hashlib,json,os,re
root=Path(__file__).resolve().parents[1];project=root.parents[2];out=root/'tmp/rollback207'
archives={}
for label in ('previous','current'):
 receipt=json.loads((out/f'{label}-provenance.json').read_text(encoding='utf-8'))
 with Path(receipt['archive']).open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==receipt['archiveSha256']
 with ZipFile(receipt['archive']) as z:
  entries={}
  for e in z.infolist():
   if not e.is_dir():
    with z.open(e) as f:entries[e.filename]=hashlib.file_digest(f,'sha256').hexdigest()
  archives[label]=entries
fixtures=[(project/'tmp/version-rollback207/run-90ce4e1c0ece4dd29f8924c07ee32c1a',True)]
rows=[]
for fixture,required_success in fixtures:
 assert re.fullmatch(r'run-[a-f0-9]{32}',fixture.name)
 result=json.loads((fixture/'verification.json').read_text(encoding='utf-8-sig'))
 assert result['status']==('passed actual two-archive rollback' if required_success else 'failed or incomplete actual two-archive rollback')
 releases=(fixture/'installation/releases').resolve();assert releases.parent.parent==fixture.resolve()
 for release in releases.iterdir():
  name=release.name
  if name.startswith('.stage-'):assert fixture.name=='run-f6ce736f2c9a46298c192d5377edc8b3';label='previous';full=False
  else:
   assert name.startswith('release-')
   h=name[len('release-'):]
   previous=json.loads((out/'previous-provenance.json').read_text(encoding='utf-8'))['archiveSha256'];current=json.loads((out/'current-provenance.json').read_text(encoding='utf-8'))['archiveSha256']
   assert h in (previous,current);label='previous' if h==previous else 'current';full=True
  assert not (release.lstat().st_file_attributes & 0x400)
  count=0;size=0;seen=set();files_verified=[];prefix='\\\\?\\'+str(release)
  def fail(e):raise e
  for base,dirs,files in os.walk(prefix,followlinks=False,onerror=fail):
   for name in dirs+files:
    p=os.path.join(base,name);assert not (os.lstat(p).st_file_attributes & 0x400),p
   for name in files:
    p=os.path.join(base,name);rel=os.path.relpath(p,prefix).replace('\\','/');assert rel in archives[label],rel
    with open(p,'rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==archives[label][rel],rel
    seen.add(rel);length=os.stat(p).st_size;size+=length;count+=1;files_verified.append({'relative':rel,'bytes':length})
  if full:assert seen==set(archives[label]),(name,len(seen),len(archives[label]))
  rows.append({'target':str(release),'fixture':str(fixture),'label':label,'completeArchive':full,'fileCount':count,'bytes':size,'files':files_verified})
(out/'cleanup-plan-final.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Byte-verified',len(rows),'owned failed/successful runtime trees,',sum(r['bytes'] for r in rows),'bytes; no deletion performed.')
