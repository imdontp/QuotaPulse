from pathlib import Path
from zipfile import ZipFile
import hashlib,json,re
root=Path(__file__).resolve().parents[1];project=root.parents[2];out=root/'tmp/rollback207';out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
runtime_trees=('packages/daemon/dist/','packages/tray/dist/','packages/tray/dist-preload/','packages/web/dist/')
runtime_files={'scripts/task-entry.cjs','scripts/start-review.ps1','scripts/stop-review.ps1','scripts/review-profile.ps1','scripts/install-review.ps1','scripts/uninstall-review.ps1','packages/daemon/package.json','packages/tray/package.json','packages/tray/src/pet.html','packages/tray/src/gallery.html','packages/tray/src/gallery.css'}
for label,delivery,filename in [('previous','docs/redesign-v1.85.198/archive.json','QuotaPulse-v1.85.197-review198.zip'),('current','docs/redesign-v1.85.206/archive.json','QuotaPulse-v1.85.205-review206.zip')]:
 d=json.loads((root/delivery).read_text(encoding='utf-8')); assert d['allEntryBytesMatch'] is True and d['entries']==3161; info=d;archive=project/'tmp/releases'/filename
 expected=info.get('sha256',d.get('archiveSha256')); source=d['sourceCommit'];index=info.get('productionIndexSha256',d.get('productionIndexSha256'))
 with archive.open('rb') as f: actual=hashlib.file_digest(f,'sha256').hexdigest()
 assert actual==expected
 with ZipFile(archive) as z:
  entries=[x for x in z.infolist() if not x.is_dir()];names=[x.filename for x in entries];assert len(names)==len(set(names))==3161
  assert all(not n.startswith('/') and '\\' not in n and all(part not in ('','.','..') for part in n.split('/')) for n in names)
  runtime={n:sha(z.read(n)) for n in names if n.startswith(runtime_trees) or n in runtime_files}
  assert runtime_files.issubset(runtime) and all(any(n.startswith(p) for n in runtime) for p in runtime_trees)
  assert runtime['packages/web/dist/index.html']==index
  manifest=json.loads(z.read('review-manifest.json'));assert manifest['platform']=='win32' and manifest['arch']=='x64' and manifest['requiredNodeAbi']=='127'
  daemon=z.read('packages/daemon/dist/index.js').decode();tray=z.read('packages/tray/dist/main.js').decode();profile=z.read('packages/tray/dist/instance-profile.js').decode()
  assert 'QUOTAPULSE_READERS' in daemon and re.search(r'readersEnabled\s*\?\s*ALL_ADAPTERS\s*:\s*\[\]',daemon)
  assert re.search(r'configureInstanceProfile\(app,\s*process\.env\.QUOTAPULSE_DATA_DIR\)',tray) and "setPath('userData'" in profile and "setPath('sessionData'" in profile
  record={'archive':str(archive),'archiveSha256':actual,'sourceCommit':source,'productionIndexSha256':index,'delivery':delivery,'deliverySha256':sha((root/delivery).read_bytes()),'checkpoint':manifest['checkpoint'],'runtime':dict(sorted(runtime.items())),'entries':len(names),'isolatedEntryChecks':True}
 (out/f'{label}-provenance.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
 print(label,source,manifest['checkpoint'],'runtime files',len(runtime),flush=True)
