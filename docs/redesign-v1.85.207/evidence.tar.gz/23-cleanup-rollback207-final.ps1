$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$project=[IO.Path]::GetFullPath((Join-Path $root '../../..'))
$output=Join-Path $root 'tmp\rollback207'
$allowed=@((Join-Path $project 'tmp\version-rollback207\run-90ce4e1c0ece4dd29f8924c07ee32c1a'))
$plan=Get-Content -LiteralPath (Join-Path $output 'cleanup-plan-final.json') -Raw | ConvertFrom-Json
$results=@()
foreach($row in $plan){
  $fixture=(Resolve-Path -LiteralPath $row.fixture).Path.TrimEnd('\')
  if($fixture -notin $allowed){throw 'Unexpected owned fixture'}
  $target=(Resolve-Path -LiteralPath $row.target).Path.TrimEnd('\')
  $releases=[IO.Path]::GetFullPath((Join-Path $fixture 'installation\releases')).TrimEnd('\')
  if([IO.Path]::GetDirectoryName($target) -ne $releases -or [IO.Path]::GetFileName($target) -notmatch '^(release-[a-f0-9]{64}|\.stage-[a-f0-9]{32})$'){throw 'Unexpected runtime cleanup target'}
  $active=@(Get-CimInstance Win32_Process | Where-Object {$_.CommandLine -and $_.CommandLine.IndexOf($fixture,[StringComparison]::OrdinalIgnoreCase) -ge 0})
  if($active.Count){throw 'An owned fixture process is still running'}
  $targetLong='\\?\'+$target
  $items=@(Get-ChildItem -LiteralPath $targetLong -Force -Recurse -ErrorAction Stop)
  if((Get-Item -LiteralPath $targetLong -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Linked root'}
  if(@($items | Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint}).Count){throw 'Linked entry'}
  $expected=@{};foreach($file in $row.files){$expected[$file.relative.Replace('/','\')] = [long]$file.bytes}
  $files=@($items | Where-Object {-not $_.PSIsContainer})
  if($files.Count -ne $row.fileCount){throw 'File inventory changed since archive verification'}
  foreach($file in $files){
    if(-not $file.FullName.StartsWith($targetLong+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'File escaped runtime root'}
    $relative=$file.FullName.Substring($targetLong.Length+1)
    if(-not $expected.ContainsKey($relative) -or $file.Length -ne $expected[$relative]){throw 'Runtime file changed since archive verification'}
  }
  @{target=$target;action='verified-delete-intent';files=$files.Count;bytes=$row.bytes} | ConvertTo-Json -Compress | Add-Content -LiteralPath (Join-Path $output 'cleanup-journal-final.jsonl') -Encoding UTF8
  foreach($file in $files){if($file.Extension -ne '.asar'){[IO.File]::Delete($file.FullName)}}
  foreach($dir in @($items | Where-Object {$_.PSIsContainer} | Sort-Object {$_.FullName.Length} -Descending)){
    if([IO.Directory]::GetFileSystemEntries($dir.FullName).Count -eq 0){[IO.Directory]::Delete($dir.FullName)}
  }
  $remaining=@(Get-ChildItem -LiteralPath $targetLong -File -Force -Recurse)
  if(@($remaining | Where-Object {$_.Extension -ne '.asar'}).Count){throw 'Unexpected runtime cleanup residue'}
  if($remaining.Count -eq 0){[IO.Directory]::Delete($targetLong)}
  $results+=@{target=$target;status='cleaned';beforeBytes=$row.bytes;retainedBytes=($remaining | Measure-Object Length -Sum).Sum;retainedAsarFiles=$remaining.Count}
  [IO.File]::WriteAllText((Join-Path $output 'cleanup-results-final.json'),($results | ConvertTo-Json -Depth 4),[Text.UTF8Encoding]::new($false))
  Write-Output "Cleaned $target"
}
