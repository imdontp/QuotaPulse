import json
from pathlib import Path
import numpy as np
from PIL import Image
root=Path('tmp/fidelity126')
a=np.array(Image.open(root/'before/live.png').convert('RGB')).astype(int)
b=np.array(Image.open(root/'final/live.png').convert('RGB')).astype(int)
d=np.abs(a-b);changed=d.max(axis=2)>0
native=json.loads((root/'native/verification.json').read_text(encoding='utf8'))
case=next(r for r in native['results'] if r['name']=='en-dark-1672')
r=case['facts']['rect'];x,y,w,h=[round(r[k]) for k in ['x','y','width','height']]
outside=changed.copy();outside[y:y+h,x:x+w]=False
yy,xx=np.where(changed)
before=json.loads((root/'before/verification.json').read_text(encoding='utf8'));after=json.loads((root/'final/verification.json').read_text(encoding='utf8'))
summary={'changedPixels':int(changed.sum()),'maxChannelDelta':int(d.max()),'bbox':[int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())],'tableRegion':[x,y,w,h],'outsideTablePixels':int(outside.sum()),'mainGeometryEqual':before['results'][0]['geometry']['mainRegions']==after['results'][0]['geometry']['mainRegions'],'beforeRepeatExact':before['results'][0]['repeatIdentical'],'afterRepeatExact':after['results'][0]['repeatIdentical'],'rowHeights':[r['rect']['height'] for r in case['facts']['rows']],'index':after['productionIndexSha256'],'scope':'bounded before/after comparison, not a concept similarity percentage'}
(root/'analysis.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps(summary))
