from pathlib import Path
p=Path('tmp/capture-fidelity159.mts');s=p.read_text(encoding='utf-8-sig').replace('fidelity159','fidelity160')
needle="    const first = await page.screenshot({ path: resolve(output, `${routeName}.png`), animations: 'disabled' });"
extra="""    const navPaint=await page.locator('.qp-sidebar .qp-nav-active').evaluateAll(nodes=>nodes.map(node=>{const css=getComputedStyle(node),rim=getComputedStyle(node,'::before');return{href:node.getAttribute('href'),aria:node.getAttribute('aria-current'),rect:node.getBoundingClientRect().toJSON(),background:css.background,border:css.border,color:css.color,rim:{background:rim.background,rect:{width:rim.width,top:rim.top,left:rim.left}}}}));
    writeFileSync(resolve(output,routeName+'-nav-paint.json'),JSON.stringify(navPaint,null,2)+'\\n');
"""
assert s.count(needle)==1;s=s.replace(needle,extra+needle);Path('tmp/capture-fidelity160.mts').write_text(s,encoding='utf-8')
