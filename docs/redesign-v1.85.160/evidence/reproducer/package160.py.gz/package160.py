from pathlib import Path
import gzip,hashlib,json,sys
out=Path('docs/redesign-v1.85.160');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,compressed=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not compressed and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0) if compressed else b)
def log(path):
 b=Path(path).read_bytes();return b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
before=load('tmp/fidelity159/final/verification.json');after=load('tmp/fidelity160/final/verification.json');diffs=load('tmp/fidelity160/analysis.json');paints=load('tmp/fidelity160/all-reference-paint.json');fit=load('tmp/nav160-fit.json')
index=sha(Path('packages/web/dist/index.html').read_bytes())
assert before['productionIndexSha256']=='51c0c0bb98a8b9700914cf6c8bfa570bb8e14f215383820c5e9573467f8781f5'
assert after['productionIndexSha256']==index and load('tmp/nav160-build-result.json')['status']==0
assert len(after['results'])==8 and all(row['repeatIdentical'] and row['errors']==[] and row['forbidden']==[] for row in after['results'])
assert len(paints['results'])==8 and all(row['meanAbsoluteChannelError']['after']<row['meanAbsoluteChannelError']['before'] for row in paints['results'])
assert len([r for r in diffs if r['outsideActiveRowPixels']==0])==7
assert next(r for r in diffs if r['route']=='history')['outsideActiveRowPixels']==523
assert '# pass 353' in log('tmp/nav160-web-tests.log') and '# fail 0' in log('tmp/nav160-web-tests.log')
assert 'History/Overview/Projects/Live/Providers/Models/Cost/Alerts E2E passed' in log('tmp/nav160-integration.log') and 'History teardown: database closed' in log('tmp/nav160-integration.log')
assert 'hmr update' not in log('tmp/nav160-integration.log')
matrix=load('screens/history/responsive-matrix.json');assert len(matrix['cases'])==144 and all(row['streams']<=1 for row in matrix['cases'])
diagnostic=load('tmp/fidelity160/diagnostic/paint-switch.json');switch=load('tmp/fidelity160/diagnostic/comparison.json')
assert diagnostic['productionIndexSha256']==index and [r['outsideRowPixels']for r in switch]==[105,105,105]
assert diagnostic['states'][0]['sha256']==diagnostic['states'][2]['sha256']
for row in after['results']:
 name=row['route'];ref=Path('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs')/(name+'.png')
 assert sha(ref.read_bytes())==row['referenceSha256']==next(r for r in fit if r['route']==name)['referenceSha256'];copy(ref,'refs/'+name+'.png')
 for phase,report,folder in [('before',before,'tmp/fidelity159/final'),('after',after,'tmp/fidelity160/final')]:
  p=Path(folder)/(name+'.png');assert sha(p.read_bytes())==next(r for r in report['results']if r['route']==name)['sha256'];copy(p,phase+'/'+name+'.png')
 copy('tmp/fidelity160/final/'+name+'-nav-paint.json','evidence/nav/'+name+'.json')
for src,dst in [('tmp/fidelity159/final/verification.json','canonical-before.json'),('tmp/fidelity160/final/verification.json','canonical-current.json'),('tmp/fidelity160/analysis.json','comparison.json'),('tmp/fidelity160/all-reference-paint.json','all-reference-paint.json'),('tmp/fidelity160/paint-comparison.json','projects-blank-strips.json'),('tmp/nav160-fit.json','reference-fit.json'),('tmp/nav160-samples.json','initial-reference-samples.json'),('tmp/fidelity160/all-reference-paint-first-palette.json','first-palette-paint.json'),('tmp/fidelity160/canonical-first-palette.json','first-palette-canonical.json'),('tmp/fidelity160/diagnostic/paint-switch.json','diagnostic/paint-switch.json'),('tmp/fidelity160/diagnostic/comparison.json','diagnostic/comparison.json'),('tmp/fidelity160/diagnostic/verification.json','diagnostic/canonical.json'),('screens/history/verification.json','integration.json'),('screens/history/responsive-matrix.json','integration-matrix.json'),('tmp/nav160-build-result.json','build-result.json')]:copy(src,'evidence/'+dst)
for name in ['current-a','previous-paint','current-b']:copy('tmp/fidelity160/diagnostic/'+name+'.png','evidence/diagnostic/'+name+'.png')
for src,dst in [('tmp/nav160-build.log','build'),('tmp/nav160-web-tests.log','web-tests'),('tmp/nav160-integration.log','integration'),('tmp/nav160-integration-first-palette.log','integration-first-palette'),('tmp/fidelity160-final.log','canonical-current'),('tmp/nav160-diagnostic.log','history-paint-diagnostic')]:copy(src,'evidence/logs/'+dst+'.log.gz',True)
for name in ['capture-fidelity160.mts','prepare160.py','sample-nav160.py','sample-all-nav160.py','fit-nav160.py','apply-nav160.py','analyze160.py','prepare-nav-diagnostic160.py','check-nav-diagnostic160.mts','build160.cjs','package160.py','check-viewer160.mjs']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
source='packages/web/src/redesign/overview.css';b=Path(source).read_bytes();write('source-hashes.json',{source:{'rawSha256':sha(b),'lfSha256':sha(b.replace(b'\r\n',b'\n'))}})
verified=(out/'evidence/viewer.json').exists()
if verified:
 viewer=load(out/'evidence/viewer.json');assert viewer['status']=='passed' and viewer['productionIndexSha256']==index and len(viewer['cases'])==16 and viewer['errors']==[]
else:assert '--draft'in sys.argv
write('delivery.json',{'parentCommit':'278187c254cf6fac20d3d28e6d4db890f75a1529','productionIndexSha256':index,'webTests':353,'fullIntegrationPassed':True,'responsiveCases':144,'canonicalRepeatPairs':8,'referencePaintsImproved':8,'otherContentExactFrames':7,'historyOutsideRowPixels':523,'historyDiagnosticPreviousPaintOutsideRowPixels':105,'reviewPageVerified':verified,'nativeRevalidated':False,'newArchiveCreated':False,'fullGoalComplete':False})
(out/'README.md').write_bytes('''# Per-reference selected navigation paint / source160

[Eight-page original / source159 / current gallery](review.html) · [Paint measurements](evidence/all-reference-paint.json) · [Full-frame differences](evidence/comparison.json) · [Latest native ZIP review156](../redesign-v1.85.156/README.md)

The selected sidebar row now uses the measured navy falloff from its own original reference. Overview, Live, Projects, Models, History, Alerts, Providers and Cost each supply four fitted sRGB gradient stops. A transparent1px border preserves the existing space while the existing rasterized decorative rim supplies the bright left edge. The former full cyan outline and common gray/violet right side no longer override those per-page paints. Changes apply only to the dark production dashboard at widths1536px and above. Existing narrow/light/preview styles and unreferenced Settings fallbacks retain their earlier rules. Navigation order, the accepted More grouping, labels, icons, focus outline, link targets, alert count and all data stay unchanged. No dependency or new product behavior is added.

The original reference hashes are checked against the canonical manifest. Each fit uses24 fixed blank-strip pixels at three offsets near the row's top and eight horizontal positions, avoiding text. Four horizontal stops are fitted at0/20/45/100% using ordinary least squares, rounded to8-bit RGB. Exact coordinates, original pixels, source hashes and fit output are retained. A separate fixed ten-pixel strip per page checks the resulting compiled paint. All eight improve their mean absolute channel error; this is a local paint diagnostic and is not a whole-screen similarity percentage or99–100% approval. The initial single Projects palette slightly worsened several other pages; its measurements are retained, and it was replaced before delivery.

## Validation

Validated: production build;353 web tests; full existing dashboard integration including144 responsive cases, at most one SSE listener after navigation and clean browser/Vite/daemon/DB teardown. The final integration ran with frozen source and no HMR updates. No new test mirrors this cosmetic implementation; existing behavioral checks cover the shared navigation. Eight current canonical within-context pairs are byte-identical at their original reference dimensions. Compiled CSSOM confirms each active row's actual paint, preserved dimensions and current-page link.

Seven full frames differ from source159 only within the existing selected navigation rectangle: their content, charts, tables, headers and other sidebar regions are pixel-exact. The final History capture has523 additional pixels outside that rectangle around the global search field and filter icons. Those differences remain unmasked and the corresponding visual gate remains open.

A same-page diagnostic captures current paint A, previous source159 paint, then current paint B without changing the compiled source or underlying data. Current A/B are byte-identical. All three retain105 pixels outside the row versus the historical source159 frame; reverting the navigation paint does not remove them. This falsifies the new palette as the sole cause of that diagnostic's extra pixels. It does not explain the full523-pixel canonical variance or retrospectively resolve older Providers105/Models3 rendering differences. CSSOM/geometry and the complete diagnostic frames are retained. No source correction for an unproven cause, screenshot mask, tolerance relaxation or silent replacement of the canonical frame is used.

```powershell
npm.cmd run build -w @quotapulse/web
npm.cmd run test -w @quotapulse/web
node --import tsx scripts/check-history.mts
```

Source160 changes one CSS file. This improves the shared navigation's reference appearance; it does not complete the original blueprint's remaining art, typography, control, motion, native, performance or migration acceptance. Consistent synthetic QA values differ from the concept; production still displays actual data. Main and unrelated user work are preserved.

Review156 remains the latest runnable ZIP and contains source155. It excludes source157–160 changes. No native/ZIP, physical tray/monitor, customer/provider or two-version migration/rollback acceptance was rerun here.
'''.encode())
routes=[r['route']for r in after['results']]
options=''.join('<option>'+name+'</option>'for name in routes)
html='''<!doctype html><meta charset="utf-8"><title>Reference navigation paint / source160</title><style>body{font:14px system-ui;margin:20px;background:#071020;color:#def}a{color:#5cf}select{padding:8px;margin:6px}section{display:grid;grid-template-columns:1fr 1fr;gap:12px}img{width:100%;border:1px solid #456}figure{margin:0}figcaption{margin:8px 0}@media(max-width:900px){section{grid-template-columns:1fr}}</style><h1>Selected navigation / source160</h1><p>Original concept and actual QA values differ. No whole-screen similarity percentage or approval is claimed. <a href="README.md">Measurements, evidence and open History variance</a></p><select id="route">'''+options+'''</select><select id="left-source"><option value="refs">Original concept</option><option value="before">Before / source159</option></select><section><figure><figcaption id="left-label"></figcaption><img id="left" alt="Original or previous dashboard frame"></figure><figure><figcaption>Current / source160</figcaption><img id="right" alt="Current compiled dashboard frame"></figure></section><script>const source=document.getElementById('left-source'),route=document.getElementById('route');function show(){document.getElementById('left-label').textContent=source.options[source.selectedIndex].text;document.getElementById('left').src=source.value+'/'+route.value+'.png';document.getElementById('right').src='after/'+route.value+'.png'}source.onchange=route.onchange=show;show()</script>'''
(out/'review.html').write_bytes(html.encode())
write('artifact-hashes.json',{p.relative_to(out).as_posix():sha(p.read_bytes())for p in sorted(out.rglob('*'))if p.is_file()and p.name!='artifact-hashes.json'})
print('Sealed',len(load(out/'artifact-hashes.json')),'artifacts; viewer verified:',verified)
