from pathlib import Path
import json
rows=json.loads(Path('tmp/nav160-fit.json').read_text())
p=Path('packages/web/src/redesign/overview.css');b=p.read_bytes()
start=b.index(b'  /* Blank strips in the original Projects row')
end=b.index(b'\n}',start)
lines=['  /* Each original row has its own navy falloff. Preserve the border space',
       '     and decorative rim while using measured, page-specific paint. */']
for row in rows:
 c=row['stops'];lines.append('  .qp-redesign[data-testid=production-'+row['route']+'] { --qp-source-active-border:transparent; --qp-source-active-paint:linear-gradient(90deg,'+c[0]+','+c[1]+' 20%,'+c[2]+' 45%,'+c[3]+'); }')
lines.extend(['  .qp-redesign[data-testid^=production-][data-theme=dark] .qp-sidebar .qp-nav-active {',
 '    border-color:var(--qp-source-active-border,color-mix(in srgb,var(--qp-accent) 45%,transparent));',
 '    background:var(--qp-source-active-paint,linear-gradient(100deg,#091c5f,#0c1636 40%,#161a29));','  }'])
# Match the inserted block's LF endings without normalizing the historical file.
p.write_bytes(b[:start]+'\n'.join(lines).encode()+b[end:])
