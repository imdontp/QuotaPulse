from pathlib import Path
from PIL import Image
import json,hashlib
rows=[]
for phase,path,top in [('reference','C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/projects.png',173),('before','tmp/fidelity159/final/projects.png',172)]:
 img=Image.open(path).convert('RGB')
 rows.append({'phase':phase,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'top':top,'rows':[{ 'offset':dy,'samples':[{'x':x,'rgb':img.getpixel((x,top+dy))}for x in [25,40,65,85,110,140,170,190,205]]} for dy in [2,5,8,36,39,42]]})
Path('tmp/nav160-samples.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:
 print(row['phase'])
 for line in row['rows']:print(line['offset'],[tuple(s['rgb'])for s in line['samples']])
