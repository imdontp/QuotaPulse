from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib
tops={'overview':83,'live':134,'projects':173,'models':229,'history':277,'alerts':325,'providers':377,'cost':273}
rows=[]
for name,top in tops.items():
 p=Path(f'C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/{name}.png');a=np.asarray(Image.open(p).convert('RGB')).astype(float)
 width=190 if name=='overview' else 201
 features=[];values=[];samples=[]
 for dy in [3,5,8]:
  for x in [25,40,65,85,110,140,170,190]:
   t=(x-13)/(width-1);weights=[float(np.interp(t,[0,.2,.45,1],np.eye(4)[:,i]))for i in range(4)]
   features.append(weights);values.append(a[top+dy,x]);samples.append({'x':x,'y':top+dy,'rgb':a[top+dy,x].astype(int).tolist()})
 colors=np.clip(np.rint(np.linalg.lstsq(features,values,rcond=None)[0]),0,255).astype(int);hexes=['#'+''.join(f'{c:02x}'for c in color)for color in colors]
 rows.append({'route':name,'referenceSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'referenceRowTop':top,'method':'least squares sRGB piecewise linear stops at0/20/45/100% against24 fixed blank-strip samples','samples':samples,'stops':hexes})
 print(name,*hexes)
Path('tmp/nav160-fit.json').write_text(json.dumps(rows,indent=2)+'\n')
