from pathlib import Path
from PIL import Image
import numpy as np,json
refTops={'overview':83,'live':134,'projects':173,'models':229,'history':277,'alerts':325,'providers':377,'cost':273}
rows=[]
for name,top in refTops.items():
 ref=np.asarray(Image.open(f'C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/{name}.png').convert('RGB')).astype(int)
 nav=json.loads(Path(f'tmp/fidelity160/final/{name}-nav-paint.json').read_text())[0]['rect'];currentTop=nav['y']
 before=np.asarray(Image.open(f'tmp/fidelity159/final/{name}.png').convert('RGB')).astype(int);after=np.asarray(Image.open(f'tmp/fidelity160/final/{name}.png').convert('RGB')).astype(int)
 values=[]
 for dy in [5,8]:
  for x in [70,100,130,160,190]:
   cy=int(round(currentTop+dy));values.append({'x':x,'referenceY':top+dy,'currentY':cy,'reference':ref[top+dy,x].tolist(),'before':before[cy,x].tolist(),'after':after[cy,x].tolist()})
 metrics={phase:float(np.mean([np.abs(np.array(v[phase])-v['reference']).mean()for v in values]))for phase in ['before','after']}
 rows.append({'route':name,'meanAbsoluteChannelError':metrics,'samples':values});print(name,metrics)
Path('tmp/fidelity160/all-reference-paint.json').write_text(json.dumps({'scope':'10 fixed top-strip paint samples per original route; aligned to visible reference rows and current DOM row; no whole-screen parity claim','results':rows},indent=2)+'\n')
