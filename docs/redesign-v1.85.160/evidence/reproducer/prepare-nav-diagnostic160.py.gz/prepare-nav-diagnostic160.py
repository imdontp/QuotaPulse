from pathlib import Path
s=Path('tmp/capture-fidelity160.mts').read_text()
s=s.replace("'tmp/fidelity160/'+(process.env.QP_FIDELITY_PHASE??'before')","'tmp/fidelity160/diagnostic'")
needle="    const first = await page.screenshot({ path: resolve(output, `${routeName}.png`), animations: 'disabled' });"
extra="""    if(routeName==='history'){
      const states=[];
      for(const state of ['current-a','previous-paint','current-b']){
        const style=state==='previous-paint'?await page.addStyleTag({content:'.qp-redesign[data-testid=production-history] .qp-sidebar .qp-nav-active {border-color:color-mix(in srgb,var(--qp-accent) 45%,transparent)!important;background:linear-gradient(100deg,#091c5f,#0c1636 40%,#161a29)!important}'}):null;
        await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
        const nodes=await page.locator('.qp-header-search,.qp-history-filter-form button,.qp-sidebar .qp-nav-active').evaluateAll(nodes=>nodes.map(node=>{const css=getComputedStyle(node);return{className:node.className,text:node.textContent,rect:node.getBoundingClientRect().toJSON(),background:css.background,border:css.border,filter:css.filter,shadow:css.boxShadow,color:css.color}}));
        const bytes=await page.screenshot({path:resolve(output,state+'.png'),animations:'disabled'});states.push({state,sha256:sha(bytes),nodes});
        await style?.evaluate(node=>node.remove());
      }
      writeFileSync(resolve(output,'paint-switch.json'),JSON.stringify({productionIndexSha256,states},null,2)+'\\n');
    }
"""
assert s.count(needle)==1;s=s.replace(needle,extra+needle)
Path('tmp/check-nav-diagnostic160.mts').write_text(s)
