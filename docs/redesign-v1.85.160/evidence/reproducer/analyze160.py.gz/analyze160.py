from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib,math
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=[]
for name in ['overview','live','projects','models','history','alerts','providers','cost']:
 left=Path(f'tmp/fidelity159/final/{name}.png');right=Path(f'tmp/fidelity160/final/{name}.png')
 a=np.asarray(Image.open(left).convert('RGB')).astype(int);b=np.asarray(Image.open(right).convert('RGB')).astype(int);d=np.abs(a-b);yy,xx=np.where(d.max(2)>0)
 nav=load(f'tmp/fidelity160/final/{name}-nav-paint.json');assert len(nav)==1
 rect=nav[0]['rect'];x0,y0=math.floor(rect['x']),math.floor(rect['y']);x1,y1=math.ceil(rect['right']),math.ceil(rect['bottom'])
 outside=d.copy();outside[y0:y1,x0:x1]=0;oy,ox=np.where(outside.max(2)>0)
 rows.append({'route':name,'beforeSha256':sha(left),'afterSha256':sha(right),'changedPixels':len(xx),'maxChannelDelta':int(d.max()),'bounds':None if not len(xx)else[int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())],'activeRow':rect,'outsideActiveRowPixels':len(ox),'outsideBounds':None if not len(ox)else[int(ox.min()),int(oy.min()),int(ox.max()),int(oy.max())]})
Path('tmp/fidelity160/analysis.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
ref=np.asarray(Image.open('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/projects.png').convert('RGB')).astype(int)
# Fixed blank strips established before editing, aligned by each row's existing top.
# Exclude text/icons and all border pixels; this is a paint-only diagnostic, not parity.
coords=[(x,dy)for dy in [2,5,8,36,39,42]for x in [65,85,110,140,170,190,205]]
before=np.asarray(Image.open('tmp/fidelity159/final/projects.png').convert('RGB')).astype(int)
after=np.asarray(Image.open('tmp/fidelity160/final/projects.png').convert('RGB')).astype(int)
values=[]
for x,dy in coords:
 values.append({'x':x,'rowOffset':dy,'reference':ref[173+dy,x].tolist(),'before':before[172+dy,x].tolist(),'after':after[172+dy,x].tolist()})
metrics={phase:float(np.mean([np.abs(np.array(v[phase])-v['reference']).mean() for v in values]))for phase in ['before','after']}
Path('tmp/fidelity160/paint-comparison.json').write_text(json.dumps({'scope':'42 fixed Projects blank-strip samples only; not a whole-screen similarity measure','meanAbsoluteChannelError':metrics,'samples':values},indent=2)+'\n')
print(metrics)
