const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),crypto=require('node:crypto');
const checkout='C:/Users/TH12367283/Projects/QuotaPulse/tmp/worktrees/redesign-validation-v1.85.140';
const built=JSON.parse(fs.readFileSync(path.join(checkout,'screens/tray-recovery/bundle-build.json')));
const receipt='tmp/release141/build/build.json';const record=JSON.parse(fs.readFileSync(receipt));
assert.equal(record.sourceCommit,'1319c196e85e92e231b13e6a69dff68c97273705');assert.equal(record.steps.length,6);assert.ok(record.steps.every(step=>step.exitCode===0));
const hash=crypto.createHash('sha256').update(fs.readFileSync(path.join(built.bundle,'packages/web/dist/index.html'))).digest('hex');assert.equal(hash,'2bab6990b174526765b76cc512552e3daf1c97a2a9b07aa1157ffd33cdd9b732');
fs.writeFileSync('tmp/release141/inputs.json',JSON.stringify({checkout,bundle:built.bundle,sourceCommit:record.sourceCommit,buildReceipt:path.resolve(receipt),webIndexSha256:hash},null,2)+'\n');
console.log(JSON.stringify({bundle:built.bundle,sourceCommit:record.sourceCommit,index:hash}));
