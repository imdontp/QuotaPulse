from PIL import Image
import numpy as np,json
from pathlib import Path
root=Path('tmp/review141/native-ab7a0d8b-1b1d-495b-ae01-cc7dd83771ed')
a=np.asarray(Image.open(root/'initial-projects-paint-oracle-4.png').convert('RGBA')).astype(int)
b=np.asarray(Image.open(root/'initial-projects-native-attempt-4.png').convert('RGBA')).astype(int)
d=np.abs(a-b);yy,xx=np.where(d.max(2)>0)
print(json.dumps({'pixels':len(xx),'max':int(d.max()),'bounds':None if not len(xx)else[int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())],'rows':{int(y):int((yy==y).sum())for y in np.unique(yy)},'sample':[{'at':[int(x),int(y)],'oracle':a[y,x].tolist(),'native':b[y,x].tolist()}for y,x in list(zip(yy,xx))[:8]]}))
