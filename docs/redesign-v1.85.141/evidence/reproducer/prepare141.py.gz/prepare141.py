from pathlib import Path
root=Path('tmp')
mapping={'release139':'release141','review139':'review141','v1.85.138':'v1.85.140','b027a5365a5cac260c36217716a8da264c2d2aad':'1319c196e85e92e231b13e6a69dff68c97273705','0fd855c959228374a5733d3b0aebbb001e8b3394222eebe6c6836bd503cbc2d4':'2bab6990b174526765b76cc512552e3daf1c97a2a9b07aa1157ffd33cdd9b732'}
for name in ['build-review139.ps1','prepare-review139.cjs','archive-review139.ps1','extract-review139.ps1','check-bundle139.mts','check-native-review139.mts','check-reader-archive139.mts','audit-review139.cjs']:
 text=(root/name).read_text(encoding='utf-8')
 for before,after in mapping.items(): text=text.replace(before,after)
 text=text.replace('[125,349,198]','[125,351,198]').replace('repositoryTests:672','repositoryTests:674')
 (root/name.replace('139','141')).write_text(text,encoding='utf-8',newline='\n')
