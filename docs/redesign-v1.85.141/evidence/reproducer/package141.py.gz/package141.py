from pathlib import Path
import json,gzip,hashlib,sys,subprocess
out=Path('docs/redesign-v1.85.141');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8').lstrip('\ufeff'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,zipped=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not zipped and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0) if zipped else b)
summary=load('tmp/release141/summary.json');inputs=load('tmp/release141/inputs.json');fixture=Path(summary['fixture']);report=load(fixture/'verification.json');archive=summary['archive']
assert report['status']=='passed' and report['sourceCommit']=='1319c196e85e92e231b13e6a69dff68c97273705'
assert report['productionIndexSha256']=='2bab6990b174526765b76cc512552e3daf1c97a2a9b07aa1157ffd33cdd9b732'
assert summary['repositoryTests']==674 and len(report['captures'])==16 and len(report['projectChecks'])==2
assert archive['allEntryBytesMatch'] and sha(Path(archive['archive']).read_bytes())==archive['sha256']
assert sha(Path(inputs['buildReceipt']).read_bytes())==report['buildReceiptSha256']
assert subprocess.check_output(['git','-C',inputs['checkout'],'status','--porcelain','--untracked-files=no'],text=True).strip()==''
assert not (Path(inputs['bundle'])/'review-data').exists()
for row in report['captures']:
 name=row['phase']+'-'+row['route']+'.png';assert sha((fixture/name).read_bytes())==row['sha256'];copy(fixture/name,'images/'+name)
 assert sha((fixture/(row['phase']+'-'+row['route']+'-native-attempt-1.png')).read_bytes())==row['nativeCaptureSha256']
 copy(fixture/(row['phase']+'-'+row['route']+'-native-attempt-1.png'),'images/native-api/'+name)
for name in ['verification.json','settings.json']:copy(fixture/name,'evidence/native/'+name)
for name in ['summary.json','inputs.json','archive.json','reader-smoke.json']:copy('tmp/release141/'+name,'evidence/'+name)
copy('tmp/release141/standalone-smoke/bundle-verification.json','evidence/standalone-smoke.json')
for name in ['reader-ingested.png','reader-incremental.png']:copy('screens/review-readers/'+name,'images/readers/'+name)
for p in Path('tmp/release141/build').iterdir():
 if p.suffix in ['.log','.json']:copy(p,'evidence/build/'+p.name+'.gz',True)
for name in ['prepare141.py','build-review141.ps1','prepare-review141.cjs','archive-review141.ps1','extract-review141.ps1','check-native-review141.mts','check-bundle141.mts','check-reader-archive141.mts','audit-review141.cjs','check-viewer141.mjs','package141.py']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
for name in ['native','archive','zip-smoke','reader-smoke']:copy('tmp/review141-'+name+'.log','evidence/logs/'+name+'.log.gz',True)
for name in ['initial-harness','stale-paint','oracle-initial','oracle-repeat']:copy('tmp/review141-native-'+name+'.log','evidence/logs/native-'+name+'.log.gz',True)
copy('tmp/diagnose-paint141.py','evidence/reproducer/diagnose-paint141.py.gz',True)
diagnostic=Path('tmp/review141/native-ab7a0d8b-1b1d-495b-ae01-cc7dd83771ed')
for name in ['initial-projects-paint-attempts.json','initial-projects-paint-oracle-4.png','initial-projects-native-attempt-4.png']:copy(diagnostic/name,'evidence/paint/'+name)
copy('tmp/review141/native-659b569d-0892-40fc-a07d-3c7534fca95f/initial-projects.png','evidence/paint/initial-stale-loading.png')
write('paint-diagnosis.json',{'symptom':'original capturePage image retained Projects loading state despite ready DOM; initial screenshot acceptance was insufficient','correction':'review images now use actual Electron page screenshot after DOM readiness; separate unmasked capturePage images retained as diagnostics','crossApiExactAcceptance':False,'boundedRepeat':{'attempts':4,'allSameWithinEachApi':True,'changedPixels':913,'maxChannelDelta':2,'bounds':[597,206,713,252]},'mechanism':'stale capturePage frame observed; exact compositor and small-border difference mechanism not established','productionChanges':False,'imageMasksOrTolerancePass':False,'initialHarnessCorrection':'rendered provider innerText is 1+ ?, not 1 + ?; no product change'})
verified=(out/'evidence/viewer.json').exists()
if verified:
 viewer=load(out/'evidence/viewer.json');assert viewer['status']=='passed' and len(viewer['cases'])==16 and viewer['errors']==[]
else:assert '--draft' in sys.argv
write('delivery.json',{'sourceCommit':report['sourceCommit'],'productionIndexSha256':report['productionIndexSha256'],'archive':archive,'repositoryTests':674,'nativeCaptures':16,'nativeProjectChecks':report['projectChecks'],'nativeModelControlChecks':2,'standaloneSmokeChecks':6,'actualArchiveReaderChecks':6,'reviewPageVerified':verified,'fullGoalComplete':False})
(out/'README.md').write_text(f'''# Review141: runnable source140 dashboard

[Review ZIP]({archive['archive'].replace(chr(92),'/')}) · [Actual Electron images](review.html) · [Source140 reference comparison](../redesign-v1.85.140/review.html)

Partially validated redesign delivery. This portable package includes the Projects reference summary/footer from source140, real recorded identity counts with unknown-provider qualification, last-observed time, separate reported-native/API money, and keyboard metadata access. Existing Models controls/motion and opt-in local readers are retained. Frozen source: `{report['sourceCommit']}`. Production web index: `{report['productionIndexSha256']}`. Main and previous archives are unchanged.

## Run

Extract into a new dedicated folder, then run in PowerShell:

```powershell
.\\scripts\\start-review.ps1 -EnableReaders
```

Open http://127.0.0.1:7807/#projects. This explicit mode reads installed harness logs/configured quota readers into separate `review-data`; it does not import the original application database. The initial scan may take several minutes. To start with readers and account probes off and an empty profile, omit `-EnableReaders`. Stop with `.\\scripts\\stop-review.ps1` before changing modes. Restart without the switch preserves collected review data but disables further collection. The switch belongs to the portable launcher; versioned wrappers do not expose it. Pet is disabled. No customer database, credentials or synthetic fixture database is packaged.

Windows x64 and installed Node ABI127 are required; validated with Node22.13.1. Node is external. `-Port` selects a separate port. No logon task is installed.

Archive: {archive['bytes']} bytes; {archive['entries']} entries. SHA256 `{archive['sha256']}`.

## Validation

All six fresh build/package steps passed with 674 repository tests:125 daemon,351 web,198 tray; zero failed/skipped/cancelled. Actual compiled Electron main and sandboxed exact preload ran two cycles with16 dashboard captures: EN/dark then TH/light after restoring THB37.25 and1371x887 window settings. Served web assets matched the bundle. All source-bundle bytes remained unchanged.

Two native Projects checks validate both projects against actual API facts, including sessions distinct from calls, harness/provider counts, `1 + ?` for partially unknown providers, exact221 stored tokens across the owned fixture, recorded timestamps, both monetary bases where reported, keyboard selection and metadata action. Two Models checks retain period controls, keyboard sort, finite180ms native ring interpolation and live reduced-motion behavior without scope/sort replay. The owned three-row database remains unchanged and passes integrity check. All QA jobs stopped.

The actual ZIP passed a fresh extraction outside repository dependencies, six start/WhatIf/stop/data-preservation/restart checks, and a second fresh extraction with six opt-in reader lifecycle checks. An owned synthetic Codex log grows150 to190 tokens while retaining one session across refresh/restart; prompt content is excluded and source/original-profile sentinels remain unchanged. Account probes were disabled for this reader QA; customer logs and credentials were not used. Every ZIP entry was byte-verified.

## Limits

The initial capture-only harness accepted a stale Projects loading bitmap despite ready DOM. Review images now come from Playwright screenshots of the actual production Electron page after readiness; all16 separate `capturePage` images are retained under `images/native-api`. Bitmap comparisons are diagnostics, not an exact-parity pass. A four-attempt control kept identical frames within each method but found913 different pixels (maximum channel delta2) on the selected card border; the compositor mechanism remains unproven. Initial harness whitespace and capture failures are retained. No production files, image masks or tolerance-based pass were introduced for this correction. See [paint diagnosis](paint-diagnosis.json).

The populated images use an owned QA profile, not packaged demo data. Native windows were positioned beyond displays using test-only anti-occlusion/background-throttling overrides. Captures used reduced motion; the Models checks separately exercised normal motion. Initial viewport `{json.dumps(summary['firstViewport'])}`; native image `{json.dumps(summary['firstNativeImageSize'])}`. This proves neither physical monitor/tray operation nor performance, signed installation, two-version migration/rollback, all account/providers, or the full native theme/language matrix.

99–100% reference fidelity and full blueprint acceptance remain open. Source140 has four exact within-context Projects capture pairs and bounded responsive/browser evidence; six unrelated pages remain byte-identical in that comparison. The105px Providers header difference remains open. Projects shared-paint differences were causally isolated to root-height change by a browser-only control; no production height workaround or image mask was introduced. See source140 evidence and the [accepted gap ledger](../redesign-v1.85.109/authority/07-GAP-LEDGER-v1.1.md) / [full requirement trace](../redesign-v1.85.109/REQUIREMENT-TRACE.md). This package is available for user review, not final visual acceptance.
''',encoding='utf-8',newline='\n')
routes=list(dict.fromkeys(row['route'] for row in report['captures']));phases=list(dict.fromkeys(row['phase'] for row in report['captures']))
html='''<!doctype html><meta charset="utf-8"><title>Source140 Electron review141</title><style>body{font:14px system-ui;background:#071020;color:#def;margin:20px}select{padding:8px;margin:6px}img{display:block;max-width:100%;border:1px solid #456}a{color:#5cf}</style><h1>Source140 / actual Electron review141</h1><p>Owned QA data. Reference acceptance remains open. <a href="README.md">Run instructions and limitations</a> · <a href="../redesign-v1.85.140/review.html">Original / before / current</a></p><select id="route">'''+''.join('<option'+(' selected' if route=='projects' else '')+'>'+route+'</option>' for route in routes)+'''</select><select id="phase">'''+''.join('<option>'+phase+'</option>' for phase in phases)+'''</select><img id="image" alt="Actual native dashboard"><script>const route=document.getElementById('route'),phase=document.getElementById('phase'),frame=document.getElementById('image');function show(){frame.src='images/'+phase.value+'-'+route.value+'.png'}route.onchange=phase.onchange=show;show()</script>'''
(out/'review.html').write_text(html,encoding='utf-8',newline='\n')
write('artifact-hashes.json',{str(p.relative_to(out)).replace('\\','/'):sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='artifact-hashes.json'})
print(json.dumps({'artifacts':len(load(out/'artifact-hashes.json')),'archive':archive['archive'],'sha256':archive['sha256'],'viewerVerified':verified}))
