const {spawnSync}=require('node:child_process'),fs=require('node:fs');
for(const lang of ['en','th']){const p='packages/web/src/i18n/'+lang+'.ts';let b=fs.readFileSync(p),s=b.toString('utf8');s=s.replace(/(  'redesign\.project(?:Filter|Recent)Count':[^\r\n]*)\r\n/g,'$1\n');fs.writeFileSync(p,s);}
const result=spawnSync(process.env.ComSpec||'cmd.exe',['/d','/c','npm.cmd run build -w @quotapulse/web'],{encoding:'utf8',maxBuffer:20000000});
fs.writeFileSync('tmp/projects157-build.log',result.stdout+'\n'+result.stderr);fs.writeFileSync('tmp/projects157-build-result.json',JSON.stringify({status:result.status,signal:result.signal},null,2)+'\n');console.log(JSON.stringify({status:result.status,signal:result.signal}));process.exitCode=result.status??1;
