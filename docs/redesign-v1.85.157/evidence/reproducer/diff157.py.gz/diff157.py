from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib
rows=[]
for name in ['overview','live','projects','models','history','alerts','providers','cost']:
 left=Path(f'tmp/fidelity155/final/{name}.png');right=Path(f'tmp/fidelity157/final/{name}.png')
 a=np.asarray(Image.open(left).convert('RGB')).astype(int);b=np.asarray(Image.open(right).convert('RGB')).astype(int);d=np.abs(a-b);yy,xx=np.where(d.max(2)>0)
 rows.append({'route':name,'beforeSha256':hashlib.sha256(left.read_bytes()).hexdigest(),'afterSha256':hashlib.sha256(right.read_bytes()).hexdigest(),'changedPixels':len(xx),'maxChannelDelta':int(d.max()),'bounds':None if not len(xx)else[int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())]})
Path('tmp/fidelity157/analysis.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(rows))
