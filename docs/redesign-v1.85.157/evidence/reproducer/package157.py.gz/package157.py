from pathlib import Path
import gzip,hashlib,json,sys
out=Path('docs/redesign-v1.85.157');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,compressed=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not compressed and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0) if compressed else b)
def log(path):
 b=Path(path).read_bytes();return b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
before=load('tmp/fidelity155/final/verification.json');after=load('tmp/fidelity157/final/verification.json');focused=load('screens/project-filter-counts/verification.json');diffs=load('tmp/fidelity157/analysis.json')
assert before['productionIndexSha256']=='9a57fc2c0243d761bd576e1fed241ececd7ba154feec334b9f0349d26f5261ba'
assert after['productionIndexSha256']==focused['productionIndexSha256']==sha(Path('packages/web/dist/index.html').read_bytes())
assert load('tmp/projects157-build-result.json')['status']==0 and len(focused['cases'])==16 and focused['errors']==[] and all(row['errorUnknown'] and row['retry'] for row in focused['cases'])
assert '# pass 353' in log('tmp/projects157-web-tests-final.log') and '# fail 0' in log('tmp/projects157-web-tests-final.log')
assert 'History/Overview/Projects/Live/Providers/Models/Cost/Alerts E2E passed' in log('tmp/projects157-integration-final.log') and 'History teardown: database closed' in log('tmp/projects157-integration-final.log')
matrix=load('screens/history/responsive-matrix.json');assert len(matrix['cases'])==144 and all(row['streams']<=1 for row in matrix['cases'])
assert len(after['results'])==8 and all(row['repeatIdentical'] and row['errors']==[] and row['forbidden']==[] for row in after['results'])
assert len([row for row in diffs if row['changedPixels']==0])==6 and next(row for row in diffs if row['route']=='providers')['changedPixels']==105
assert next(row for row in diffs if row['route']=='projects')['bounds']==[233,146,846,203]
ref=Path('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/projects.png');assert sha(ref.read_bytes())==next(row for row in after['results'] if row['route']=='projects')['referenceSha256'];copy(ref,'refs/projects.png')
for phase,report,src in [('before',before,'tmp/fidelity155/final/projects.png'),('after',after,'tmp/fidelity157/final/projects.png')]:
 assert sha(Path(src).read_bytes())==next(row for row in report['results'] if row['route']=='projects')['sha256'];copy(src,phase+'/projects.png')
for src,dst in [('tmp/fidelity155/final/verification.json','canonical-before.json'),('tmp/fidelity157/final/verification.json','canonical-current.json'),('tmp/fidelity157/analysis.json','comparison.json'),('screens/project-filter-counts/verification.json','filter-counts.json'),('screens/history/verification.json','integration.json'),('screens/history/responsive-matrix.json','integration-matrix.json'),('tmp/projects157-build-result.json','build-result.json')]:copy(src,'evidence/'+dst)
for name in ['en-dark-1672','th-light-390']:copy('screens/project-filter-counts/'+name+'.png','images/'+name+'.png')
for src,dst in [('tmp/projects157-build.log','build'),('tmp/projects157-browser-final.log','focused-final'),('tmp/projects157-web-tests-final.log','web-tests-final'),('tmp/projects157-integration-final.log','integration-final'),('tmp/projects157-browser-initial.log','focused-before-error-state'),('tmp/projects157-integration-initial.log','integration-before-error-state'),('tmp/fidelity157-final.log','canonical-current')]:copy(src,'evidence/logs/'+dst+'.log.gz',True)
for name in ['capture-fidelity157.mts','diff157.py','build157.cjs','package157.py','check-viewer157.mjs']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
sources={}
for name in ['packages/web/src/redesign/projects.tsx','packages/web/src/redesign/projects.css','packages/web/src/i18n/en.ts','packages/web/src/i18n/th.ts','scripts/check-project-filter-counts.mts']:
 b=Path(name).read_bytes();sources[name]={'rawSha256':sha(b),'lfSha256':sha(b.replace(b'\r\n',b'\n'))}
write('source-hashes.json',sources)
verified=(out/'evidence/viewer.json').exists()
if verified:
 viewer=load(out/'evidence/viewer.json');assert viewer['status']=='passed' and viewer['productionIndexSha256']==after['productionIndexSha256'] and len(viewer['cases'])==2 and viewer['errors']==[]
else:assert '--draft' in sys.argv
write('delivery.json',{'parentCommit':'6287f0a1cbdadfe54a23918321869a155dc05b5a','productionIndexSha256':after['productionIndexSha256'],'webTests':353,'focusedCases':16,'fullIntegrationPassed':True,'responsiveCases':144,'canonicalRepeatPairs':8,'unchangedOtherFrames':6,'providersUnexplainedPixels':105,'reviewPageVerified':verified,'nativeRevalidated':False,'newArchiveCreated':False,'fullGoalComplete':False})
(out/'README.md').write_bytes('''# Projects filter chips and scoped counts / source157

[Original / source155 / current gallery](review.html) · [Current Projects](after/projects.png) · [Thai/light mobile](images/th-light-390.png) · [Latest runnable ZIP review156](../redesign-v1.85.156/README.md)

Projects now follows the reference filter plate's compact chip, selected outline and numeric badge treatment. Its existing truthful filters remain All projects / Recent activity / Unassigned. Recency has a clock icon, rather than an invented Active lifecycle state; no Archived, Personal, Team, budget or authoring controls are fabricated. The original accessible button names and filtering actions remain intact.

Counts refer to distinct matching project groups within the current API period/source/harness scope and metadata search, before applying the tab filter. The existing detailed aggregate API returns every group without a LIMIT, and the metadata rows cover the same scope. Counts therefore do not use page length, record count or machine-wide Quick Stats. Null is the unassigned group; an empty project string remains a separate group, preserving existing behavior. Recent means lastObservedAt is not in the future and is within300000ms of the API snapshot now, inclusive of the exact boundary. Counts do not turn recency into proof that a project is currently running.

Each count is localized and described through the button tooltip/aria-describedby; its decorative badge is aria-hidden so it does not alter the established button name. Pending new scope shows an unknown dash, no old count or false zero, and aria-busy. A failed new request retains unknown counts with a could-not-load description and clears busy. Retry restores actual values. Successful empty results show real zeroes. A retained same-scope snapshot still follows the existing stale-data handling.

## Verification

The final production build passes. Sixteen compiled browser cases cover EN/TH, dark/light and390/900/1280/1672 widths using an isolated real HTTP/in-memory DB. Six groups come from seven records, including a null group, distinct empty string, an exact five-minute observation, one millisecond older observation and a future observation inside the explicit custom scope. Initial counts are6/3/1. Selecting Recent and Unassigned leaves the counts based on all matching groups, while showing3 and1 cards. Metadata search, source/harness scope, pending data,503 failure, retry, zero results, keyboard activation/focus and page overflow all pass.

All353 web tests and the full maintained integration pass. Its144 responsive cases keep at most one SSE server listener after navigation. The earlier initial implementation also passed integration; the final run includes the additional distinction between pending and failed count states. No test assertion, cleanup budget or numeric tolerance was relaxed.

All eight current canonical within-context screenshot pairs are byte-identical. The verified historical source155 baseline is index9a57fc2c0243d761bd576e1fed241ececd7ba154feec334b9f0349d26f5261ba, not a fresh run relabeled as before. Projects changes are confined to233,146–846,203 in the filter toolbar and its glow; card/detail/chart pixels remain unchanged. Six other full page frames are byte-identical. Providers still has105 differing global-header pixels, maximum channel delta4, matching the previously unexplained pattern; its gate remains open and no mask hides the differences. The earlier initial count-only build had seven unchanged pages; the final source-bound comparison is the six-page result above.

```powershell
npm.cmd run build -w @quotapulse/web
npm.cmd run test -w @quotapulse/web
node --import tsx scripts/check-project-filter-counts.mts
node --import tsx scripts/check-history.mts
```

The gallery uses complete unmasked frames and the SHA-verified original Projects reference. Consistent QA data and actual product data differ from the concept; no99–100% approval or similarity percentage is claimed. Review156 remains the latest runnable native ZIP and contains source155, not these source157 chips. No new native/ZIP, performance, tray/monitor or migration/rollback acceptance was performed here. Remaining visual/control/motion, customer/provider and desktop acceptance still need the full blueprint audit. Main and unrelated work remain preserved.
'''.encode())
(out/'review.html').write_bytes('''<!doctype html><meta charset="utf-8"><title>Projects filter plate / source157</title><style>body{font:14px system-ui;margin:20px;background:#071020;color:#def}a{color:#5cf}select{padding:8px;margin:6px}section{display:grid;grid-template-columns:1fr 1fr;gap:12px}img{width:100%;border:1px solid #456}figure{margin:0}figcaption{margin:8px 0}@media(max-width:900px){section{grid-template-columns:1fr}}</style><h1>Projects / original, source155, source157</h1><p>Original concept and consistent QA data differ. No similarity percentage or approval is claimed. <a href="README.md">Changes, evidence and limits</a></p><select id="left-source"><option value="refs">Original concept</option><option value="before">Before / source155</option></select><section><figure><figcaption id="left-label"></figcaption><img id="left" alt="Original or previous Projects frame"></figure><figure><figcaption>Current / source157</figcaption><img id="right" src="after/projects.png" alt="Current compiled Projects frame"></figure></section><script>const source=document.getElementById('left-source');function show(){document.getElementById('left-label').textContent=source.options[source.selectedIndex].text;document.getElementById('left').src=source.value+'/projects.png'}source.onchange=show;show()</script>'''.encode())
write('artifact-hashes.json',{p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='artifact-hashes.json'})
print('Sealed',len(load(out/'artifact-hashes.json')),'artifacts; viewer verified:',verified)
