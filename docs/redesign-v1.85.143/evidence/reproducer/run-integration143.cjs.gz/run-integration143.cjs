const cp=require('child_process'),fs=require('fs'),assert=require('assert/strict');
for(const[script,log]of [['tmp/check-cost143.mts','tmp/cost143-after.log'],['scripts/check-history.mts','tmp/history143-integration-final.log']]){
 const fd=fs.openSync(log,'w'),r=cp.spawnSync(process.execPath,['--import','tsx',script],{env:{...process.env,QP_COST_REPRO_READY:''},stdio:['ignore',fd,fd],windowsHide:true});fs.closeSync(fd);assert.equal(r.status,0,script);console.log('Passed '+script);
}
