/** Real HTTP + in-memory SQLite E2E. Never opens the user's usage database. */
import assert from 'node:assert/strict';
import { mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer } from 'vite';
import { chromium } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { recordQuotaAlerts } from '../packages/daemon/src/api/queries.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import { en as englishMessages } from '../packages/web/src/i18n/en.ts';
import { th as thaiMessages } from '../packages/web/src/i18n/th.ts';
import { checkAlertsLayout } from './check-alerts-layout.mts';
import type { Overview } from '../packages/web/src/api.ts';

const root = fileURLToPath(new URL('..', import.meta.url));
const output = resolve(root, 'tmp/cost143/repro');
mkdirSync(output, { recursive: true });

const db = openDb(':memory:');
const now = Date.now();
db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at) VALUES
  (1,'codex','test','/synthetic/nonexistent','Codex test',0), (2,'hermes','test','/synthetic/nonexistent','Hermes test',0);
  INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (1,1,'synthetic-session','alpha_100%',${now - 1000}), (2,2,'aggregate-session',NULL,NULL);`);
db.prepare(`UPDATE source SET account_key='openai:subscription', account_provider='openai',
  account_display_name='OpenAI Test Subscription', account_state='active', account_last_success_at=? WHERE id=1`).run(now - 15000);
db.prepare(`INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin)
  VALUES (1,'5h',38,?,?,?,?,?)`).run(now + 7200000, now - 15000, now - 15000, now - 15000, 'live-synthetic');
for (const [used, observed, reset] of [[80, now - 10800000, now - 7200000], [10, now - 2400000, now + 7200000], [20, now - 1200000, now + 7200000]]) {
  db.prepare(`INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin)
    VALUES (1,'5h',?,?,?,?,?,?)`).run(used, reset, observed, observed, observed, 'live-synthetic');
}
db.prepare(`INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin)
  VALUES (1,'5h',92,?,?,?,?,?)`).run(now + 7200000, now - 7200000, now - 7200000, now - 7200000, 'old-fallback');
const insert = db.prepare(`INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,total_tokens,call_count,cost_usd,cost_source)
  VALUES (?,?,?,?,?,?,?,1,0.2,'computed')`);
db.transaction(() => {
  for (let i = 0; i < 52; i++) insert.run(1, 1, `test-${i}`, now - 1000 - i, 'gpt-test', 'openrouter', 100 + i);
  insert.run(2, 2, 'aggregate', now - 2000, 'claude-test', 'anthropic', 999);
})();
db.prepare(`UPDATE usage_event SET input_tokens=40,cached_input_tokens=20,
  output_tokens=total_tokens-60,cost_cache_saving_usd=0.03 WHERE source_id=1`).run();
db.prepare(`UPDATE usage_event SET cache_write_tokens=7,duration_ms=1234,service_tier='test-tier',price_provider='anthropic' WHERE id=53`).run();
db.prepare(`UPDATE session SET is_subagent=1 WHERE id=2`).run();
const scheduler = new Scheduler(db, [], { pollMs: 1000000, detectMs: 1000000 });
const daemon = buildServer(db, scheduler, { token: 'history-test', port: 7800, webRoot: resolve(root, 'packages/web/dist') });
const vite = await createServer({ root: resolve(root, 'packages/web'), server: { host: '127.0.0.1', port: 7801, strictPort: true, proxy: { '/api': { target: 'http://127.0.0.1:7800', changeOrigin: true, configure: proxy => {
  // Vite installs response-close cleanup only after upstream headers arrive.
  // StrictMode/reload can cancel SSE before that point; bind cleanup earlier.
  proxy.on('proxyReq', (upstream, request, response) => {
    if (!request.url?.startsWith('/api/events/stream')) return;
    response.once('close', () => upstream.destroy());
    if (response.destroyed) upstream.destroy();
  });
} } } } });
let browser:Awaited<ReturnType<typeof chromium.launch>>|undefined;
const cases:any[]=[];
try{
 await daemon.listen({host:'127.0.0.1',port:7800});await vite.listen();browser=await chromium.launch({channel:'chrome',headless:true});
 for(const mode of ['choose-while-loading','retain-through-module-resolution']){
  const page=await browser.newPage({viewport:{width:1440,height:1000},reducedMotion:'reduce',timezoneId:'Asia/Bangkok'});
  await page.addInitScript(()=>{(window as any).__QUOTAPULSE_TOKEN__='history-test';localStorage.setItem('quotapulse-prefs',JSON.stringify({lang:'en',currency:'USD',rate:1,hiddenSubscriptions:[]}));localStorage.setItem('quotapulse-theme','dark')});
  let release!:()=>void,entered!:()=>void;const held=new Promise<void>(r=>release=r),requested=new Promise<void>(r=>entered=r);
  await page.route('**/src/redesign/production.tsx*',async route=>{entered();await held;await route.continue().catch(()=>{})});
  try{
   await page.goto('http://127.0.0.1:7801/#cost?range=month');await page.locator('.qp-cost-summary .qp-cost-value').first().waitFor();
   await page.goto('http://127.0.0.1:7801/#overview');await requested;await page.locator('[data-route-load-state=loading]').waitFor();
   await page.keyboard.press('Control+k');const palette=page.getByRole('dialog',{name:'Command palette'});await palette.waitFor();await palette.getByRole('searchbox').fill('Cost');
   const before=await page.evaluate(()=>({loading:!!document.querySelector('[data-route-load-state]'),open:!!document.querySelector('dialog[open]'),id:document.querySelector('dialog[open]')?.id,query:(document.querySelector('dialog[open] input')as HTMLInputElement)?.value}));
   assert.equal(before.loading,true);assert.equal(before.query,'Cost');
   if(mode==='choose-while-loading'){
    await palette.getByRole('button',{name:englishMessages['redesign.cost'],exact:true}).click();await page.waitForURL('**/#cost?range=month');release();cases.push({mode,status:'passed',before,url:page.url()});
   }else{
    release();await page.locator('[data-route-load-state]').waitFor({state:'detached'});await page.locator('.qp-metric-rail[data-value]').first().waitFor();
    const after=await page.evaluate(()=>({loading:!!document.querySelector('[data-route-load-state]'),open:!!document.querySelector('dialog[open]'),id:document.querySelector('dialog[open]')?.id,query:(document.querySelector('dialog[open] input')as HTMLInputElement)?.value,focused:document.activeElement?.tagName}));
    await page.screenshot({path:resolve(output,mode+'.png'),fullPage:true});const retained=after.open&&after.query==='Cost';cases.push({mode,status:retained?'passed':'failed',before,after});
    if(retained){await palette.getByRole('button',{name:englishMessages['redesign.cost'],exact:true}).click();await page.waitForURL('**/#cost?range=month');}
   }
  }finally{release();await page.close();}
 }
}finally{await browser?.close();await vite.close();await daemon.close();db.close();writeFileSync(resolve(output,'loading-verification.json'),JSON.stringify({status:cases.length===2&&cases.every(c=>c.status==='passed')?'passed':'failed',cases,fixture:'owned in-memory authenticated API; deliberately held route module; application unmodified'},null,2)+'\n');}
assert.ok(cases.every(c=>c.status==='passed'),'Open command palette and query must survive route module resolution');
