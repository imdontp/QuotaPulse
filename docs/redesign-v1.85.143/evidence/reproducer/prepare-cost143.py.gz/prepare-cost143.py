from pathlib import Path
s=Path('scripts/check-history.mts').read_text(encoding='utf-8')
prefix=s.split("let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;")[0]
prefix=prefix.replace("'screens/history'","'tmp/cost143/repro'")
prefix=prefix.replace("for (const manifest of ['verification.json', 'cost-route-compatibility.json']) rmSync(resolve(output, manifest), { force: true });",'')
Path('tmp/check-cost143.mts').write_text(prefix+Path('tmp/cost143-body.txt').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
