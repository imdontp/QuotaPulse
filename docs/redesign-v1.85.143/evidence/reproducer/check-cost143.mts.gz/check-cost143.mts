/** Real HTTP + in-memory SQLite E2E. Never opens the user's usage database. */
import assert from 'node:assert/strict';
import { mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer } from 'vite';
import { chromium } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { recordQuotaAlerts } from '../packages/daemon/src/api/queries.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import { en as englishMessages } from '../packages/web/src/i18n/en.ts';
import { th as thaiMessages } from '../packages/web/src/i18n/th.ts';
import { checkAlertsLayout } from './check-alerts-layout.mts';
import type { Overview } from '../packages/web/src/api.ts';

const root = fileURLToPath(new URL('..', import.meta.url));
const output = resolve(root, 'tmp/cost143/repro');
mkdirSync(output, { recursive: true });

const db = openDb(':memory:');
const now = Date.now();
db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at) VALUES
  (1,'codex','test','/synthetic/nonexistent','Codex test',0), (2,'hermes','test','/synthetic/nonexistent','Hermes test',0);
  INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (1,1,'synthetic-session','alpha_100%',${now - 1000}), (2,2,'aggregate-session',NULL,NULL);`);
db.prepare(`UPDATE source SET account_key='openai:subscription', account_provider='openai',
  account_display_name='OpenAI Test Subscription', account_state='active', account_last_success_at=? WHERE id=1`).run(now - 15000);
db.prepare(`INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin)
  VALUES (1,'5h',38,?,?,?,?,?)`).run(now + 7200000, now - 15000, now - 15000, now - 15000, 'live-synthetic');
for (const [used, observed, reset] of [[80, now - 10800000, now - 7200000], [10, now - 2400000, now + 7200000], [20, now - 1200000, now + 7200000]]) {
  db.prepare(`INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin)
    VALUES (1,'5h',?,?,?,?,?,?)`).run(used, reset, observed, observed, observed, 'live-synthetic');
}
db.prepare(`INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin)
  VALUES (1,'5h',92,?,?,?,?,?)`).run(now + 7200000, now - 7200000, now - 7200000, now - 7200000, 'old-fallback');
const insert = db.prepare(`INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,total_tokens,call_count,cost_usd,cost_source)
  VALUES (?,?,?,?,?,?,?,1,0.2,'computed')`);
db.transaction(() => {
  for (let i = 0; i < 52; i++) insert.run(1, 1, `test-${i}`, now - 1000 - i, 'gpt-test', 'openrouter', 100 + i);
  insert.run(2, 2, 'aggregate', now - 2000, 'claude-test', 'anthropic', 999);
})();
db.prepare(`UPDATE usage_event SET input_tokens=40,cached_input_tokens=20,
  output_tokens=total_tokens-60,cost_cache_saving_usd=0.03 WHERE source_id=1`).run();
db.prepare(`UPDATE usage_event SET cache_write_tokens=7,duration_ms=1234,service_tier='test-tier',price_provider='anthropic' WHERE id=53`).run();
db.prepare(`UPDATE session SET is_subagent=1 WHERE id=2`).run();
const scheduler = new Scheduler(db, [], { pollMs: 1000000, detectMs: 1000000 });
const daemon = buildServer(db, scheduler, { token: 'history-test', port: 7800, webRoot: resolve(root, 'packages/web/dist') });
const vite = await createServer({ root: resolve(root, 'packages/web'), server: { host: '127.0.0.1', port: 7801, strictPort: true, proxy: { '/api': { target: 'http://127.0.0.1:7800', changeOrigin: true, configure: proxy => {
  // Vite installs response-close cleanup only after upstream headers arrive.
  // StrictMode/reload can cancel SSE before that point; bind cleanup earlier.
  proxy.on('proxyReq', (upstream, request, response) => {
    if (!request.url?.startsWith('/api/events/stream')) return;
    response.once('close', () => upstream.destroy());
    if (response.destroyed) upstream.destroy();
  });
} } } } });
let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;
const records:any[]=[],steps:any[]=[],errors:string[]=[];let page:any,passed=false;
const monthStart=new Date(now);monthStart.setDate(1);monthStart.setHours(0,0,0,0);
try{
 db.exec("UPDATE usage_event SET cost_usd=0.2,cost_source='computed',call_count=1");
 await daemon.listen({host:'127.0.0.1',port:7800});await vite.listen();
 browser=await chromium.launch({channel:'chrome',headless:true});page=await browser.newPage({viewport:{width:1440,height:1000},reducedMotion:'reduce',timezoneId:'Asia/Bangkok'});
 await page.addInitScript(()=>{(window as any).__QUOTAPULSE_TOKEN__='history-test';localStorage.setItem('quotapulse-prefs',JSON.stringify({lang:'en',currency:'USD',rate:1,hiddenSubscriptions:[]}));localStorage.setItem('quotapulse-theme','dark')});
 await page.clock.setFixedTime(now);
 page.on('pageerror',(error:any)=>errors.push(error.message));
 page.on('request',(request:any)=>{if(request.url().includes('/api/'))records.push({event:'request',method:request.method(),url:request.url(),at:Date.now()})});
 page.on('requestfailed',(request:any)=>records.push({event:'requestfailed',url:request.url(),error:request.failure(),at:Date.now()}));
 page.on('response',(response:any)=>{if(response.url().includes('/api/'))records.push({event:'response',status:response.status(),url:response.url(),at:Date.now()})});
 const costMatch=(response:any,from:number,source?:string,basis='api')=>{const u=new URL(response.url());return u.pathname==='/api/cost-analysis'&&u.searchParams.get('from')===String(from)&&u.searchParams.get('basis')===basis&&(source?u.searchParams.get('source_id')===source:!u.searchParams.has('source_id'))};
 for(let cycle=0;cycle<16;cycle++){
  const mode=process.env.QP_COST_REPRO_READY==='populated'?'await-populated-overview':cycle%2===0?'minimal-original-ready':'await-populated-overview';
  const custom=page.waitForResponse((response:any)=>costMatch(response,now-30*86400000,'999','native'));
  await page.goto(`http://127.0.0.1:7801/#cost?range=custom&from=${now-30*86400000}&to=${now+1}&basis=native&source=999`);await custom;
  const bare=page.waitForResponse((response:any)=>costMatch(response,0));await page.goto('http://127.0.0.1:7801/#cost');await bare;
  const sidebar=page.waitForResponse((response:any)=>costMatch(response,monthStart.getTime()));await page.getByTestId('production-cost').locator('.qp-sidebar a[href="#cost?range=month"]').click();await sidebar;await page.waitForURL('**/#cost?range=month');
  await page.goto('http://127.0.0.1:7801/#overview');await page.getByTestId('production-overview').locator(mode==='minimal-original-ready'?'.qp-metric-rail':'.qp-metric-rail[data-value]').first().waitFor();
  await page.keyboard.press('Control+k');const palette=page.getByRole('dialog'),button=palette.getByRole('button',{name:englishMessages['redesign.cost'],exact:true});await button.waitFor();
  const beforeClick=await page.evaluate(()=>({routeLoading:!!document.querySelector('[data-route-load-state]'),loadingState:document.querySelector('[data-route-load-state]')?.getAttribute('data-route-load-state'),dialogId:document.querySelector('dialog[open]')?.id,populatedMetric:!!document.querySelector('.qp-metric-rail[data-value]')}));steps.push({cycle,mode,phase:'beforeClick',...beforeClick});
  await page.evaluate(()=>{(window as any).__costReproEvents=[];for(const type of ['pointerdown','pointerup','click','hashchange','close'])addEventListener(type,event=>{const target=event.target as Element;const button=target?.closest?.('button');(window as any).__costReproEvents.push({type,text:button?.textContent,path:(event.composedPath() as Element[]).map(node=>node.tagName).filter(Boolean),hash:location.hash,trusted:event.isTrusted,dialogs:[...document.querySelectorAll('dialog')].map(d=>({open:d.open,text:d.textContent?.slice(0,120)}))})},true)});
  const requestStart=records.length,started=Date.now();
  try{
   const [response]=await Promise.all([page.waitForResponse((response:any)=>costMatch(response,monthStart.getTime())),(async()=>{await button.click();await page.waitForURL('**/#cost?range=month')})()]);
   const result=await response.json();assert.equal(result.scope.from,monthStart.getTime());steps.push({cycle,mode,status:'passed',elapsedMs:Date.now()-started,url:page.url(),scope:result.scope,events:records.slice(requestStart)});console.log('Cost transition '+cycle+' '+mode+' passed');
  }catch(error){const state={cycle,mode,beforeClick,error:String(error),expectedMonthFrom:monthStart.getTime(),url:page.url(),body:await page.locator('body').innerText(),events:records.slice(requestStart),interactions:await page.evaluate(()=>(window as any).__costReproEvents),errors};writeFileSync(resolve(output,'failure.json'),JSON.stringify(state,null,2)+'\n');await page.screenshot({path:resolve(output,'failure.png'),fullPage:true});throw error;}
 }
 assert.deepEqual(errors,[]);passed=true;
}finally{
 await browser?.close();await vite.close();await daemon.close();db.close();
 writeFileSync(resolve(output,'verification.json'),JSON.stringify({status:passed?'passed; original timeout not reproduced':'failed',runtime:'actual Vite application and authenticated owned in-memory daemon fixture',noProductChanges:true,steps,errors,records,limitations:['bounded16 repeated route chains, not proof of absence of intermittent failures','no exact prior whole-suite chronology or native Electron/customer profile reproduced']},null,2)+'\n');
}
