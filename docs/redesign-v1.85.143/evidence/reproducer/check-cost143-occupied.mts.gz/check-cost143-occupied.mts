/** Real HTTP + in-memory SQLite E2E. Never opens the user's usage database. */
import assert from 'node:assert/strict';
import { mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer } from 'vite';
import { chromium } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { recordQuotaAlerts } from '../packages/daemon/src/api/queries.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import { en as englishMessages } from '../packages/web/src/i18n/en.ts';
import { th as thaiMessages } from '../packages/web/src/i18n/th.ts';
import { checkAlertsLayout } from './check-alerts-layout.mts';
import type { Overview } from '../packages/web/src/api.ts';

const root = fileURLToPath(new URL('..', import.meta.url));
const output = resolve(root, 'tmp/cost143/occupied');
mkdirSync(output, { recursive: true });
for (const manifest of ['verification.json', 'cost-route-compatibility.json']) rmSync(resolve(output, manifest), { force: true });
const db = openDb(':memory:');
const now = Date.now();
db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at) VALUES
  (1,'codex','test','/synthetic/nonexistent','Codex test',0), (2,'hermes','test','/synthetic/nonexistent','Hermes test',0);
  INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (1,1,'synthetic-session','alpha_100%',${now - 1000}), (2,2,'aggregate-session',NULL,NULL);`);
db.prepare(`UPDATE source SET account_key='openai:subscription', account_provider='openai',
  account_display_name='OpenAI Test Subscription', account_state='active', account_last_success_at=? WHERE id=1`).run(now - 15000);
db.prepare(`INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin)
  VALUES (1,'5h',38,?,?,?,?,?)`).run(now + 7200000, now - 15000, now - 15000, now - 15000, 'live-synthetic');
for (const [used, observed, reset] of [[80, now - 10800000, now - 7200000], [10, now - 2400000, now + 7200000], [20, now - 1200000, now + 7200000]]) {
  db.prepare(`INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin)
    VALUES (1,'5h',?,?,?,?,?,?)`).run(used, reset, observed, observed, observed, 'live-synthetic');
}
db.prepare(`INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin)
  VALUES (1,'5h',92,?,?,?,?,?)`).run(now + 7200000, now - 7200000, now - 7200000, now - 7200000, 'old-fallback');
const insert = db.prepare(`INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,total_tokens,call_count,cost_usd,cost_source)
  VALUES (?,?,?,?,?,?,?,1,0.2,'computed')`);
db.transaction(() => {
  for (let i = 0; i < 52; i++) insert.run(1, 1, `test-${i}`, now - 1000 - i, 'gpt-test', 'openrouter', 100 + i);
  insert.run(2, 2, 'aggregate', now - 2000, 'claude-test', 'anthropic', 999);
})();
db.prepare(`UPDATE usage_event SET input_tokens=40,cached_input_tokens=20,
  output_tokens=total_tokens-60,cost_cache_saving_usd=0.03 WHERE source_id=1`).run();
db.prepare(`UPDATE usage_event SET cache_write_tokens=7,duration_ms=1234,service_tier='test-tier',price_provider='anthropic' WHERE id=53`).run();
db.prepare(`UPDATE session SET is_subagent=1 WHERE id=2`).run();
const scheduler = new Scheduler(db, [], { pollMs: 1000000, detectMs: 1000000 });
const daemon = buildServer(db, scheduler, { token: 'history-test', port: 7800, webRoot: resolve(root, 'packages/web/dist') });
const vite = await createServer({ root: resolve(root, 'packages/web'), server: { host: '127.0.0.1', port: 7801, strictPort: true, proxy: { '/api': { target: 'http://127.0.0.1:7800', changeOrigin: true, configure: proxy => {
  // Vite installs response-close cleanup only after upstream headers arrive.
  // StrictMode/reload can cancel SSE before that point; bind cleanup earlier.
  proxy.on('proxyReq', (upstream, request, response) => {
    if (!request.url?.startsWith('/api/events/stream')) return;
    response.once('close', () => upstream.destroy());
    if (response.destroyed) upstream.destroy();
  });
} } } } });
let browser:Awaited<ReturnType<typeof chromium.launch>>|undefined;
const errors:string[]=[];
try{await daemon.listen({host:'127.0.0.1',port:7800});await vite.listen();browser=await chromium.launch({channel:'chrome',headless:true});
  // Occupied Cost: five recorded providers, nine models (top eight), seven projects,
  // twelve sessions (top ten), with values distributed through a 30-day scope.
  const costCaptures: unknown[] = [];
  const costFrom = now - 30 * 86400000;
  const costTo = now + 1;
  const addCostSession = db.prepare('INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (?,1,?,?,?)');
  const addCostUsage = db.prepare("INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,total_tokens,call_count,cost_usd,cost_source) VALUES (1,?,?,?,?,?,?,1,?,'computed')");
  db.transaction(() => {
    for (let index = 0; index < 10; index++) {
      addCostSession.run(300 + index, `cost-session-${index}`, `Cost project ${index % 5}`, now - 100);
      addCostUsage.run(300 + index, `cost-layout-${index}`, now - index * 3 * 86400000, `cost-model-${index % 7}`, ['openrouter', 'anthropic', 'provider-a', 'provider-b', 'provider-c'][index % 5], 1000 * (index + 1), index + 1);
    }
  })();
  try {
    for (const lang of ['en', 'th'] as const) for (const theme of ['dark', 'light'] as const) {
      const messages = lang === 'en' ? englishMessages : thaiMessages;
      const candidate = await browser.newPage({ viewport: { width: 1672, height: 941 }, reducedMotion: 'reduce', deviceScaleFactor: 1, timezoneId: 'Asia/Bangkok' });
      try {
        candidate.on('pageerror', error => errors.push(error.message));
        await candidate.route('**/*', route => new URL(route.request().url()).hostname === '127.0.0.1' ? route.continue() : route.abort());
        await candidate.addInitScript(({ lang, theme }) => {
          (window as unknown as { __QUOTAPULSE_TOKEN__: string }).__QUOTAPULSE_TOKEN__ = 'history-test';
          localStorage.setItem('quotapulse-prefs', JSON.stringify({ lang, currency: 'USD', rate: 1, hiddenSubscriptions: [] }));
          localStorage.setItem('quotapulse-theme', theme);
        }, { lang, theme });
        await candidate.clock.setFixedTime(now);
        const costUrl = `http://127.0.0.1:7801/#cost?range=custom&from=${costFrom}&to=${costTo}&source=1`;
        await candidate.goto(costUrl);
        const screen = candidate.getByTestId('production-cost');
        await screen.getByRole('heading', { name: messages['redesign.costHeading'], exact: true }).waitFor();
        await screen.locator('.qp-cost-sessions tbody tr').nth(9).waitFor();
        await candidate.evaluate(() => document.fonts.ready);
        const money = (amount: number) => new Intl.NumberFormat(lang === 'th' ? 'th-TH' : 'en-US', { style: 'currency', currency: 'USD' }).format(amount);
        assert.equal(await screen.locator('.qp-cost-summary .qp-cost-value > span').first().textContent(), money(65.4));
        assert.equal(await screen.locator('.qp-cost-providers li').count(), 5);
        assert.equal(await screen.locator('.qp-cost-models tbody tr').count(), 8);
        assert.equal(await screen.locator('.qp-cost-projects tbody tr').count(), 6);
        assert.equal(await screen.locator('.qp-cost-sessions tbody tr').count(), 10);
        assert.ok(await screen.locator('.qp-cost-column').evaluateAll(nodes => nodes.some(node => node.getBoundingClientRect().height === 0)), 'Empty Cost buckets show nonzero bars');
        assert.ok((await screen.locator('.qp-cost-chart').getAttribute('aria-label'))?.includes(messages['redesign.costPricedTokens']));
        const before=await screen.locator('.qp-cost-models').evaluate(node=>({panel:node.getBoundingClientRect().toJSON(),table:node.querySelector('.qp-cost-table')!.getBoundingClientRect().toJSON(),tableHeight:node.querySelector('.qp-cost-table')!.scrollHeight,rows:[...node.querySelectorAll('tr')].map(row=>row.getBoundingClientRect().toJSON())}));
        if(process.env.QP_COST_OCCUPIED_CONTROL==='1')await candidate.addStyleTag({content:'@media(min-width:1280px){.qp-cost-models .qp-cost-table{max-height:230px;overflow:auto;overscroll-behavior:contain}}'});
        writeFileSync(resolve(output,`measure-${lang}-${theme}.json`),JSON.stringify({before,control:process.env.QP_COST_OCCUPIED_CONTROL==='1',after:await screen.locator('.qp-cost-models').evaluate(node=>({panel:node.getBoundingClientRect().toJSON(),table:node.querySelector('.qp-cost-table')!.getBoundingClientRect().toJSON(),scrollHeight:node.querySelector('.qp-cost-table')!.scrollHeight}))},null,2)+'\n');
        const regions = await screen.evaluate(node => Object.fromEntries(['.qp-cost-overview', '.qp-cost-summary', '.qp-cost-providers', '.qp-cost-trend', '.qp-cost-models', '.qp-cost-projects', '.qp-cost-sessions', '.qp-cost-insights'].map(selector => {
          const { x, y, width, height, bottom } = node.querySelector(selector)!.getBoundingClientRect();
          return [selector, { x, y, width, height, bottom }];
        })));
        // refs/cost.png aligns the outer overview/provider frames at y72;
        // the summary cards start near y131 inside the overview frame.
        assert.equal(regions['.qp-cost-overview'].y, regions['.qp-cost-providers'].y, 'Cost provider breakdown is below the overview frame');
        assert.ok(regions['.qp-cost-summary'].y > regions['.qp-cost-overview'].y, 'Cost summary is outside its heading frame');
        assert.ok(regions['.qp-cost-summary'].bottom <= regions['.qp-cost-overview'].bottom, 'Cost summary extends beyond its overview frame');
        assert.ok(regions['.qp-cost-providers'].x >= regions['.qp-cost-overview'].x + regions['.qp-cost-overview'].width, 'Provider panel overlaps overview frame');
        assert.equal(await screen.getByTestId('scope-notice').isVisible(), true, 'Custom source scope must remain visible in the heading');
        assert.match(await screen.getByTestId('scope-notice').innerText(), /#1/);
        assert.ok(regions['.qp-cost-providers'].x >= regions['.qp-cost-summary'].x + regions['.qp-cost-summary'].width, 'Provider panel overlaps summary');
        assert.equal(regions['.qp-cost-trend'].y, regions['.qp-cost-models'].y, 'Cost models do not share the trend row');
        for (const selector of ['.qp-cost-projects', '.qp-cost-sessions', '.qp-cost-insights']) assert.ok(regions[selector].bottom < 941, `${lang}/${theme}: Cost outside viewport: ${JSON.stringify(regions)}`);
        const modelTable = screen.locator('.qp-cost-models .qp-cost-table');
        const modelScroll = await modelTable.evaluate(node => ({ clientHeight: node.clientHeight, scrollHeight: node.scrollHeight }));
        if (modelScroll.scrollHeight > modelScroll.clientHeight) {
          await modelTable.focus(); await candidate.keyboard.press('End');
          await candidate.waitForFunction(() => {
            const table = document.querySelector('.qp-cost-models .qp-cost-table')!;
            const last = table.querySelector('tbody tr:last-child')!.getBoundingClientRect();
            const viewport = table.getBoundingClientRect();
            return last.top >= viewport.top && last.bottom <= viewport.bottom + .5;
          });
          await candidate.keyboard.press('Home');
          await candidate.waitForFunction(() => document.querySelector('.qp-cost-models .qp-cost-table')!.scrollTop === 0);
          await modelTable.evaluate(node => (node as HTMLElement).blur());
        }
        const filename = `cost-occupied-${lang}-${theme}.png`;
        await candidate.screenshot({ path: resolve(output, filename), animations: 'disabled' });
        costCaptures.push({ lang, theme, filename, viewport: { width: 1672, height: 941 }, regions, modelScroll, allRankedModelsKeyboardReachable: true });
        for (const width of [390, 900, 1280]) {
          await candidate.setViewportSize({ width, height: 941 });
          assert.equal(await candidate.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `${lang}/${theme}/${width}: occupied Cost overflow`);
        }
        // Exact model + provider drilldown, not a display-name search.
        await screen.locator('.qp-cost-models tbody tr').filter({ hasText: 'cost-model-2' }).getByRole('link').click();
        await candidate.waitForURL(/#history\?/);
        const modelScope = new URLSearchParams(new URL(candidate.url()).hash.split('?')[1]);
        assert.equal(modelScope.get('from'), String(costFrom)); assert.equal(modelScope.get('to'), String(costTo));
        assert.equal(modelScope.get('source'), '1'); assert.equal(modelScope.get('model'), 'cost-model-2'); assert.equal(modelScope.get('provider'), 'provider-c');
        await candidate.getByTestId('usage-history').locator('tbody tr').first().waitFor();
        assert.equal(await candidate.getByTestId('usage-history').locator('tbody tr').count(), 1);
        await candidate.goto(costUrl);
        await screen.locator('.qp-cost-projects tbody tr').first().waitFor();
        await screen.locator('.qp-cost-projects tbody tr').filter({ hasText: 'Cost project 4' }).getByRole('link').click();
        await candidate.waitForURL(/#history\?/);
        assert.equal(new URLSearchParams(new URL(candidate.url()).hash.split('?')[1]).get('project'), 'Cost project 4');
        await candidate.getByTestId('usage-history').locator('tbody tr').nth(1).waitFor();
        assert.equal(await candidate.getByTestId('usage-history').locator('tbody tr').count(), 2);
        if (lang === 'th' && theme === 'light') {
          await candidate.setViewportSize({ width: 390, height: 941 });
          db.prepare('UPDATE session SET project=?,native_session_id=? WHERE id=309').run('โครงการยาว '.repeat(18), 'cost-session-long-'.repeat(18));
          await candidate.goto(costUrl); await candidate.reload();
          await screen.locator('.qp-cost-sessions tbody tr').filter({ hasText: 'cost-session-long-' }).waitFor();
          assert.equal(await candidate.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, 'Long Cost identity overflows mobile');
          await candidate.screenshot({ path: resolve(output, 'cost-occupied-th-light-390-long.png'), fullPage: true });
          db.prepare('UPDATE session SET project=?,native_session_id=? WHERE id=309').run('Cost project 4', 'cost-session-9');
        }
      } finally { await candidate.close(); }
    }
  } finally {
    db.exec("DELETE FROM usage_event WHERE dedup_key LIKE 'cost-layout-%'; DELETE FROM session WHERE id BETWEEN 300 AND 309;");
  }
  writeFileSync(resolve(output, 'cost-occupied-layout.json'), JSON.stringify({ database: 'in-memory synthetic', fixture: { source: 1, addedSessions: 10, providers: 5, displayedModels: 8, displayedProjects: 6, displayedSessions: 10, apiValue: 65.4 }, checks: ['provider beside summary without overlap', 'models beside trend', 'complete occupied bottom panels in concept viewport', 'en/th and dark/light', '390/900/1280 overflow', 'exact model/provider/project History scope', 'zero empty-bucket bars', 'long Thai identities'], captures: costCaptures }, null, 2));
assert.deepEqual(errors,[]);console.log('Occupied Cost cases passed.');
}finally{await browser?.close();await vite.close();await daemon.close();db.close();}
