from pathlib import Path
s=Path('scripts/check-history.mts').read_text(encoding='utf-8')
prefix=s.split("let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;")[0].replace("'screens/history'","'tmp/cost143/occupied'")
block=s[s.index('  // Occupied Cost:'):s.index('  await checkAlertsLayout(browser, db, output, errors, scheduler);')]
needle="        const regions = await screen.evaluate(node => Object.fromEntries("
probe="""        const before=await screen.locator('.qp-cost-models').evaluate(node=>({panel:node.getBoundingClientRect().toJSON(),table:node.querySelector('.qp-cost-table')!.getBoundingClientRect().toJSON(),tableHeight:node.querySelector('.qp-cost-table')!.scrollHeight,rows:[...node.querySelectorAll('tr')].map(row=>row.getBoundingClientRect().toJSON())}));
        if(process.env.QP_COST_OCCUPIED_CONTROL==='1')await candidate.addStyleTag({content:'@media(min-width:1280px){.qp-cost-models .qp-cost-table{max-height:230px;overflow:auto;overscroll-behavior:contain}}'});
        writeFileSync(resolve(output,`measure-${lang}-${theme}.json`),JSON.stringify({before,control:process.env.QP_COST_OCCUPIED_CONTROL==='1',after:await screen.locator('.qp-cost-models').evaluate(node=>({panel:node.getBoundingClientRect().toJSON(),table:node.querySelector('.qp-cost-table')!.getBoundingClientRect().toJSON(),scrollHeight:node.querySelector('.qp-cost-table')!.scrollHeight}))},null,2)+'\\n');
"""
assert needle in block;block=block.replace(needle,probe+needle)
body="""let browser:Awaited<ReturnType<typeof chromium.launch>>|undefined;
const errors:string[]=[];
try{await daemon.listen({host:'127.0.0.1',port:7800});await vite.listen();browser=await chromium.launch({channel:'chrome',headless:true});
"""+block+"""assert.deepEqual(errors,[]);console.log('Occupied Cost cases passed.');
}finally{await browser?.close();await vite.close();await daemon.close();db.close();}
"""
Path('tmp/check-cost143-occupied.mts').write_text(prefix+body,encoding='utf-8',newline='\n')
