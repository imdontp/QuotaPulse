const cp=require('child_process'),fs=require('fs'),assert=require('assert/strict');
for(const[script,log,env]of [['scripts/check-route-loading.mts','tmp/route143-palette-final.log',{QUOTAPULSE_ROUTE_SCOPE:'palette'}],['tmp/capture-fidelity143.mts','tmp/fidelity143-final.log',{QP_FIDELITY_PHASE:'final'}]]){
 const fd=fs.openSync(log,'w'),r=cp.spawnSync(process.execPath,['--import','tsx',script],{env:{...process.env,...env},stdio:['ignore',fd,fd],windowsHide:true});fs.closeSync(fd);assert.equal(r.status,0,script);console.log('Passed '+script);
}
