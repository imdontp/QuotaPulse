from pathlib import Path
import json,gzip,hashlib,sys
out=Path('docs/redesign-v1.85.143');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8').lstrip('\ufeff'))
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,zipped=False):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);b=Path(src).read_bytes()
 if not zipped and str(src).endswith('.json'):b=b.replace(b'\r\n',b'\n')
 p.write_bytes(gzip.compress(b,mtime=0)if zipped else b)
index=sha(Path('packages/web/dist/index.html').read_bytes());assert index=='fe8a649c287962fb33a67b296a21f880f7cafe95cfcb8fbceb0ee8da3ea7bfe1'
palette=load('tmp/route143-palette-final.json');assert palette['productionIndexSha256']==index and len(palette['records'])==24
integration=load('screens/history/verification.json');assert '53 records across pages' in integration['checks']
log=Path('tmp/history143-integration-final.log').read_bytes();text=log.decode('utf-16')if log[:2]==b'\xff\xfe'else log.decode('utf-8');assert 'E2E passed:' in text and 'History teardown: database closed' in text
test=Path('tmp/test143-web-final.log').read_bytes();text=test.decode('utf-16')if test[:2]==b'\xff\xfe'else test.decode('utf-8')
for expected in ['# tests 351','# pass 351','# fail 0','# skipped 0','# cancelled 0']:assert expected in text
before=load('tmp/fidelity142/final/verification.json');final=load('tmp/fidelity143/final/verification.json');analysis=load('tmp/fidelity143/analysis.json');assert final['productionIndexSha256']==index
assert len(final['results'])==8 and all(row['repeatIdentical'] and row['errors']==[] and row['forbidden']==[] for row in final['results'])
assert len([row for row in analysis if row['changedPixels']==0])==7
assert next(row for row in analysis if row['route']=='providers')['bounds']==[955,12,1362,46]
cost=load('screens/history/cost-occupied-layout.json');assert len(cost['captures'])==4 and cost['fixture']['apiValue']==65.4
for row in cost['captures']:assert row['allRankedModelsKeyboardReachable'] and all(row['regions'][name]['bottom']<941 for name in ['.qp-cost-projects','.qp-cost-sessions','.qp-cost-insights'])
source=['packages/web/src/components/command-palette.tsx','packages/web/src/main.tsx','packages/web/src/redesign/cost.css','scripts/check-history.mts','scripts/check-route-loading.mts']
write('source-fingerprints.json',[{'path':p,'sha256':sha(Path(p).read_bytes()),'lfSha256':sha(Path(p).read_bytes().replace(b'\r\n',b'\n'))}for p in source])
for name in ['verification.json','responsive-matrix.json','cost-semantics.json','cost-route-compatibility.json','live-occupied-layout.json','projects-occupied-layout.json','cost-occupied-layout.json','alerts-occupied-layout.json','review-candidates.json']:copy('screens/history/'+name,'evidence/integration/'+name)
copy('tmp/route143-palette-final.json','evidence/palette-production.json')
full=Path('screens/route-loading/verification.json');fullVerified=False
if full.exists():
 record=load(full)
 if record.get('scope','').startswith('full lifecycle'):
  assert record['productionIndexSha256']==index and len(record['records'])==205;fullVerified=True;copy(full,'evidence/full-route-lifecycle.json')
assert '--draft' in sys.argv or fullVerified
for name in ['failure-initial.json','failure-instrumented.json','verification-initial.json','verification-instrumented.json','verification-populated.json','loading-before.json','loading-after.json','occupied-before.json','occupied-control.json']:copy('tmp/cost143/'+name,'evidence/diagnosis/'+name+'.gz',True)
copy('tmp/cost143/repro/verification.json','evidence/diagnosis/original-flow-after.json.gz',True)
copy('tmp/cost143/repro/retain-through-module-resolution.png','images/palette-retained-vite.png')
copy('tmp/cost143/occupied/cost-occupied-layout.json','evidence/diagnosis/occupied-source-after.json')
for row in cost['captures']:copy('screens/history/'+row['filename'],'images/occupied/'+row['filename'])
for phase,report in [('before',before),('final',final)]:
 copy(f'tmp/fidelity{142 if phase=="before" else 143}/final/verification.json','evidence/canonical-'+phase+'.json')
 for row in report['results']:
  file=Path(f'tmp/fidelity{142 if phase=="before" else 143}/final/{row["route"]}.png');assert sha(file.read_bytes())==row['sha256']
  if phase=='before' or row['route']=='providers':copy(file,f'images/{phase}/{row["route"]}.png')
copy('tmp/fidelity143/analysis.json','analysis.json')
logs=['build143-final.log','test143-web-final.log','history143-integration.log','history143-integration-cost-before.log','history143-integration-final.log','route143-palette-final.log','route143-full.log','cost143-repro.log','cost143-instrumented.log','cost143-populated.log','cost143-loading-before.log','cost143-loading-after.log','cost143-after.log','cost143-occupied-before.log','cost143-occupied-control.log','cost143-occupied-after.log','fidelity143-final.log']
for name in logs:copy('tmp/'+name,'evidence/logs/'+name+'.gz',True)
for name in ['prepare-cost143.py','cost143-body.txt','cost143-loading-body.txt','check-cost143.mts','check-cost143-loading.mts','prepare-cost143-occupied.py','check-cost143-occupied.mts','capture-fidelity143.mts','diff143.py','run-integration143.cjs','validate143-final.cjs','package143.py','check-viewer143.mjs']:copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
viewerVerified=(out/'evidence/viewer.json').exists()
if viewerVerified:
 viewer=load(out/'evidence/viewer.json');assert viewer['status']=='passed'and len(viewer['cases'])==24 and viewer['errors']==[]
else:assert '--draft'in sys.argv
write('summary.json',{'parent':'d956d9865347ec9379c9e01e582d6850232d38f6','productionIndexSha256':index,'webTests':351,'paletteCompiledCases':24,'originalFlowAfterCycles':16,'combinedIntegration':'passed','nineRouteResponsiveSets':16,'occupiedCostCombinations':4,'fullRouteLifecycleCases':205 if fullVerified else None,'canonicalExactPairs':8,'canonicalBeforeAfterExactFrames':7,'providersHeaderDifference':{'pixels':105,'maxChannelDelta':4,'bounds':[955,12,1362,46],'cause':'unestablished; full exact gate open'},'reviewPageVerified':viewerVerified,'fullGoalComplete':False,'latestRunnableZip':'review141/source140; excludes History142 and fixes143'})
write('diagnosis.json',{'palette':{'baselineCommit':'d956d9865347ec9379c9e01e582d6850232d38f6','observed':'palette disappears and Cost never receives a request during Overview navigation','control':'16 populated-Overview cycles pass; minimal original readiness fails','causalProbe':'holding the real module allows navigation before release; releasing while query is open loses palette/query and leaves BODY focused','fix':'navigation session state above route Suspense/loading/error boundary; disconnected old dialog close does not clear the session','validated':'same held-module probe passes after fix;24 compiled lifecycle cases and16 original-flow cycles pass'},'cost':{'observed':'occupied eight-model table makes middle row315.390625px and lower panels end946.765625px beyond941px viewport','control':'browser-only max-height230px returns middle row to302px and preserves strict money/layout assertions','fix':'normal desktop CSS bounds the existing focusable table to230px and keeps every row scrollable','validated':'source-only four language/theme combinations pass without injected styles; End/Home reaches last ranked model; lower bottoms933.375/931px'}})
(out/'README.md').write_text(f'''# Source143 — navigation during loading and occupied Cost layout

[Reference comparison](review.html) · [Occupied Cost EN/dark](images/occupied/cost-occupied-en-dark.png) · [Retained palette observation](images/palette-retained-vite.png)

Validated bounded fixes; full redesign/visual/native release acceptance remains partial. Parent `{load(out/'summary.json')['parent']}`; production index `{index}`.

The combined source142 suite exposed a real palette lifetime defect, not a slow Cost API. An eager loading shell and resolved page each mounted their own navigation state. Opening the palette before module resolution could lose its query and close it when the temporary shell disappeared, leaving focus on BODY and no Cost request. The same route chain passed16 times when waiting for populated Overview. A deliberately held real module established the cause: selection before release works; release with an open query loses it. Shared React session state now lives above the replaced route boundary and retains open/query/keyboard index; stale disconnected dialog close events cannot erase it. Legacy/preview instances retain local state outside this provider. No timers, storage, API or visual controls were added for this fix.

Occupied Cost had a separate geometry failure: eight ranked model rows made the middle row315.39px tall and lower panels ended946.77px beyond the941px reference viewport. A browser-only control proved table height caused the growth. Normal desktop CSS now caps the existing focusable model-table viewport at230px, restoring the302px middle row; all eight rows remain available. Four actual source cases pass with65.40 API value, eight models, six projects and ten sessions unchanged. End/Home checks verify keyboard access to the last ranked model. Lower-panel bottoms are933.375px in English and931px in Thai. Responsive overflow, long Thai identities and exact History scopes also pass. No fixture was packaged into the application.

## Evidence

Web build and351 tests pass with zero failed/skipped/cancelled. The same deterministic Vite module-hold reproduction passes after the fix. The original navigation sequence passes16 cycles with original and populated readiness alternated. The maintained production route checker passes24 palette cases: retained query/focus across all nine routes in EN/dark/wide and TH/light/narrow, plus keyboard selected-index retention, closing before resolution, and selecting before resolution in both languages.

Full route lifecycle205-case verification: `{fullVerified}`. This includes18 cold route loads,160 rejected-import/loading/error/reload cases, preserved preferences, legacy/popup entries and the24 palette cases. It is browser/fixture evidence with test-only GPU/color flags, not native desktop or performance acceptance.

The full maintained History/Overview/Projects/Live/Providers/Models/Cost/Alerts integration passes, including16 sets of nine-route language/theme/width checks, authenticated HTTP/SQLite, matching export/paging, pause/in-flight protection, exact scopes, weighted price bases, source/owner states, occupied layouts and Alerts. Readiness selectors now wait for actual project/provider/model/cost data rather than matching loading placeholders; all data and geometry assertions remain. Earlier failed runs are retained.

All eight canonical final within-context capture pairs are exact. Seven before/after frames match source142 byte-for-byte. Providers retains105 differing global-header pixels, maximum channel delta4, bounds `[955,12,1362,46]`; the cause remains unestablished and full exact raster approval stays open. No image mask or tolerance adjustment was used. The successful sparse Cost frame remains unchanged; the bounded table affects occupied datasets.

## Remaining scope

This is not 99–100% reference approval or full blueprint completion. Native/physical/performance, customer/account/all-provider acceptance, installer migration/rollback and remaining original-reference review remain open. The newest runnable ZIP is still [review141/source140](../redesign-v1.85.141/README.md), which excludes History142 and these143 fixes. New executable packaging must bind this source after commit. Main and prior archives are preserved. Accepted scope and overrides remain in the [v1.1 ledger](../redesign-v1.85.109/authority/07-GAP-LEDGER-v1.1.md) and [full trace](../redesign-v1.85.109/REQUIREMENT-TRACE.md).
''',encoding='utf-8',newline='\n')
routes=[row['route']for row in final['results']]
manifest={route:{'original':f'../redesign-v1.85.69/refs/{route}.png','before':f'images/before/{route}.png','current':f'images/final/{route}.png'if route=='providers'else f'images/before/{route}.png'}for route in routes};write('review-manifest.json',manifest)
html='''<!doctype html><meta charset="utf-8"><title>Source143 review</title><style>body{font:14px system-ui;background:#071020;color:#def;margin:20px}select{padding:8px;margin:6px}img{display:block;max-width:100%;border:1px solid #456}a{color:#5cf}</style><h1>Source143 review</h1><p>Owned QA data. <a href="README.md">Evidence and limits</a> · <a href="images/occupied/cost-occupied-en-dark.png">Occupied Cost</a></p><select id="route">'''+''.join('<option'+(' selected'if route=='cost'else'')+'>'+route+'</option>'for route in routes)+'''</select><select id="phase"><option>original</option><option>before</option><option selected>current</option></select><img id="image" alt="Original reference or actual application frame"><script>const manifest='''+json.dumps(manifest)+''';const route=document.getElementById('route'),phase=document.getElementById('phase'),frame=document.getElementById('image');function show(){frame.src=manifest[route.value][phase.value]}route.onchange=phase.onchange=show;show()</script>'''
(out/'review.html').write_text(html,encoding='utf-8',newline='\n')
write('artifact-hashes.json',{str(p.relative_to(out)).replace('\\','/'):sha(p.read_bytes())for p in sorted(out.rglob('*'))if p.is_file()and p.name!='artifact-hashes.json'})
print(json.dumps({'artifacts':len(load(out/'artifact-hashes.json')),'index':index,'fullRouteVerified':fullVerified,'viewerVerified':viewerVerified}))
