const assert=require('node:assert/strict');
const {resolve}=require('node:path');
const {inventory}=require('../scripts/check-release-rollback.cjs');
const [bundle,installed]=process.argv.slice(2);
assert.ok(bundle&&installed);
const before=inventory(resolve(bundle),true),after=inventory(resolve(installed),true);
assert.deepEqual(after,before,'Installed ZIP runtime differs from its independently tested source bundle');
console.log('Installed runtime matches all '+Object.keys(before).length+' bundle files.');
