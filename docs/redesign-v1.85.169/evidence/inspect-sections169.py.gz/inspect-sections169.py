import json
from pathlib import Path
import numpy as np
from PIL import Image
before=Path('tmp/fidelity166/final168');after=Path('tmp/fidelity169/final');results=[]
for name in ['overview','live','projects','models','history','alerts','providers','cost']:
 a=np.array(Image.open(before/f'{name}.png').convert('RGB'));b=np.array(Image.open(after/f'{name}.png').convert('RGB'));d=np.abs(a.astype(int)-b.astype(int));changed=np.any(d,axis=2);ys,xs=np.where(changed)
 inv=json.loads((after/f'{name}-inventory.json').read_text(encoding='utf-8'))
 results.append(dict(page=name,changedPixels=int(changed.sum()),maximumChannelDelta=int(d.max()),bounds=[int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max())] if len(xs) else None,repeatIdentical=bool(np.array_equal(b,np.array(Image.open(after/f'{name}-repeat.png').convert('RGB')))),inventoryCounts={k:len(v) for k,v in inv.items() if isinstance(v,list)}))
Path('tmp/section169/comparison.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(results,indent=2))
old=json.loads((before/'alerts-heading-geometry.json').read_text(encoding='utf-8'));new=json.loads((after/'alerts-heading-geometry.json').read_text(encoding='utf-8'))
assert [x['text'] for x in old]==[x['text'] for x in new]
comparison=[dict(text=a['text'],beforeFont=a['font'],afterFont=b['font'],beforeRect=a['rect'],afterRect=b['rect'],lineBoxUnchanged=a['rect']['height']==b['rect']['height']) for a,b in zip(old,new)]
Path('tmp/section169/headings.json').write_text(json.dumps(comparison,indent=2)+'\n',encoding='utf-8',newline='\n')
assert all(x['lineBoxUnchanged'] for x in comparison)
print('PASS all heading line-box heights unchanged')
