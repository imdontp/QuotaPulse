import json
from pathlib import Path
import numpy as np
from PIL import Image
ref=np.array(Image.open('C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/alerts.png').convert('RGB'))
def mask(a):return a.min(axis=2)>140
def trim(a):
 y,x=np.where(a);return a[y.min():y.max()+1,x.min():x.max()+1], [int(x.min()),int(y.min()),int(x.max()),int(y.max())]
probe=json.loads(Path('tmp/section169/candidates.json').read_text());results=[]
for title in probe['titles']:
 x1,y1,x2,y2=title['roi'];target,box=trim(mask(ref[y1:y2,x1:x2]));sprite=np.array(Image.open('tmp/section169/'+title['key']+'-candidates.png').convert('RGB'));ranked=[]
 for i,row in enumerate(probe['rows']):
  m,b=trim(mask(sprite[i*32:(i+1)*32]));best=0;offset=None
  for dy in range(-3,4):
   for dx in range(-3,4):
    a=np.zeros((48,300),bool);c=a.copy();a[6:6+target.shape[0],6:6+target.shape[1]]=target;c[6+dy:6+dy+m.shape[0],6+dx:6+dx+m.shape[1]]=m
    iou=float(np.logical_and(a,c).sum()/np.logical_or(a,c).sum())
    if iou>best:best=iou;offset=[dx,dy]
  ranked.append(dict(**row,inkDimensions=[int(m.shape[1]),int(m.shape[0])],alignedBinaryIoU=best,offset=offset))
 results.append(dict(**title,referenceInkBounds=[box[0]+x1,box[1]+y1,box[2]+x1,box[3]+y1],referenceInkDimensions=[int(target.shape[1]),int(target.shape[0])],ranked=sorted(ranked,key=lambda r:-r['alignedBinaryIoU'])))
result=dict(threshold='all RGB channels >140',comparison='Bundled Geist and original literal label; translation only, no scaling or mask exclusions; ranks are local measurement, not full-frame parity',sections=results)
Path('tmp/section169/measurement.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps([{k:v for k,v in r.items() if k!='ranked'}|{'ranked':r['ranked'][:2]} for r in results],indent=2))
