import { readFileSync, writeFileSync } from 'node:fs';
import { chromium } from 'playwright';
const controls=JSON.parse(readFileSync('tmp/cost103-matched-inputs.json','utf8'));
const browser=await chromium.launch({channel:'chrome',headless:true});
try{
 const page=await browser.newPage();
 for(const control of controls.controls){
  control.pixels=await page.evaluate(async ({prior,current})=>{
   const images=await Promise.all([prior,current].map(async data=>{const image=new Image();image.src='data:image/png;base64,'+data;await image.decode();const canvas=document.createElement('canvas');canvas.width=image.width;canvas.height=image.height;const context=canvas.getContext('2d')!;context.drawImage(image,0,0);return {width:image.width,height:image.height,data:context.getImageData(0,0,image.width,image.height).data};}));
   const [a,b]=images;let count=0,maxChannelDelta=0,minX=a.width,minY=a.height,maxX=-1,maxY=-1;const samples=[];
   for(let y=0;y<a.height;y++)for(let x=0;x<a.width;x++){const i=(y*a.width+x)*4;let changed=false;for(let c=0;c<4;c++){const delta=Math.abs(a.data[i+c]-b.data[i+c]);maxChannelDelta=Math.max(maxChannelDelta,delta);changed ||=delta>0;}if(changed){count++;minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);if(samples.length<50)samples.push({x,y,before:[...a.data.slice(i,i+4)],after:[...b.data.slice(i,i+4)]});}}
   return {count,maxChannelDelta,bounds:count?[minX,minY,maxX,maxY]:null,samples};
  },{prior:readFileSync(control.previous).toString('base64'),current:readFileSync('tmp/reference103/'+control.route+'.png').toString('base64')});
  console.log(control.route,JSON.stringify(control.pixels));
 }
 writeFileSync('tmp/cost103-matched-pixels.json',JSON.stringify({...controls,masks:false},null,2));
}finally{await browser.close();}
