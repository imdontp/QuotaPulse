import json
from pathlib import Path
import numpy as np
from PIL import Image
before=Path('tmp/fidelity172/final');after=Path('tmp/fidelity173/final');comparison=[]
a=json.loads((before/'verification.json').read_text(encoding='utf-8'));b=json.loads((after/'verification.json').read_text(encoding='utf-8'));boxes=[]
for old,new in zip(a['results'],b['results']):
 name=old['route'];assert name==new['route'];assert old['geometry']['mainRegions']==new['geometry']['mainRegions'],name;boxes.append(dict(page=name,mainRegionBoxesUnchanged=True,regions=new['geometry']['mainRegions']))
 x=np.array(Image.open(before/f'{name}.png').convert('RGB'));y=np.array(Image.open(after/f'{name}.png').convert('RGB'));d=np.abs(x.astype(int)-y.astype(int));mask=np.any(d,axis=2);ys,xs=np.where(mask)
 comparison.append(dict(page=name,changedPixels=int(mask.sum()),maximumChannelDelta=int(d.max()),bounds=list(map(int,[xs.min(),ys.min(),xs.max(),ys.max()])) if len(xs) else None,repeatIdentical=bool(np.array_equal(y,np.array(Image.open(after/f'{name}-repeat.png').convert('RGB'))))))
Path('tmp/type173/comparison.json').write_text(json.dumps(comparison,indent=2)+'\n',encoding='utf-8',newline='\n');Path('tmp/type173/main-regions.json').write_text(json.dumps(boxes,indent=2)+'\n',encoding='utf-8',newline='\n')
s=Path('tmp/measure-positions173.py').read_text(encoding='utf-8').replace('tmp/fidelity173/first','tmp/fidelity173/final').replace('position-measurement.json','position-measurement-final.json');Path('tmp/measure-final173.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(comparison,indent=2));print('PASS all eight main-region boxes unchanged')
