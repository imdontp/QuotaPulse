import json,math
from pathlib import Path
import numpy as np
from PIL import Image
measurement=json.loads(Path('tmp/type173/measurement.json').read_text(encoding='utf-8'));bykey={s['key']:s for s in measurement['sections']};mapping={'live':['live-sessions','live-flow','live-feed','live-advisory','live-matrix'],'cost':['cost-providers','cost-trend','cost-models','cost-projects','cost-sessions','cost-insights']};result=[]
for page,keys in mapping.items():
 image=np.array(Image.open(f'tmp/fidelity173/first/{page}.png').convert('RGB'));nodes=[x for x in json.loads(Path(f'tmp/fidelity173/first/{page}-heading-geometry.json').read_text(encoding='utf-8')) if x['className']=='qp-section-heading-title'];assert len(nodes)==len(keys)
 for key,node in zip(keys,nodes):
  r=node['rect'];x1=max(0,math.floor(r['left'])-1);y1=max(0,math.floor(r['top'])-3);x2=math.ceil(r['right'])+1;y2=math.ceil(r['bottom'])+3;a=image[y1:y2,x1:x2];m=a.min(axis=2)>140;ys,xs=np.where(m);bounds=list(map(int,[xs.min()+x1,ys.min()+y1,xs.max()+x1,ys.max()+y1]));target=bykey[key]['referenceInkBounds'];result.append(dict(key=key,text=node['text'],font=node['font'],actualGlyphBounds=bounds,referenceLiteral=bykey[key]['text'],referenceGlyphBounds=target,translationToReferenceOrigin=[target[0]-bounds[0],target[1]-bounds[1]]))
Path('tmp/type173/position-measurement.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(result,indent=2))
