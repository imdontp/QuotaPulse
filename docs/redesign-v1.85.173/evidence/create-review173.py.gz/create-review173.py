import hashlib,json,os,re,shutil
from pathlib import Path
root=Path('docs/redesign-v1.85.173');(root/'images').mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
verification=json.loads(Path('tmp/fidelity173/final/verification.json').read_text(encoding='utf-8'));priorRoot=Path('docs/redesign-v1.85.172');prior=json.loads((priorRoot/'gallery-images.json').read_text(encoding='utf-8'));byPage={p['page']:p for p in prior['images']}
html=(priorRoot/'review.html').read_text(encoding='utf-8').replace('source172','source173');html=re.sub(r'Compiled index SHA256: <code>[0-9a-f]+</code>',f'Compiled index SHA256: <code>{verification["productionIndexSha256"]}</code>',html);images=[]
for entry in verification['results']:
 name=entry['route'];current=Path('tmp/fidelity173/final',name+'.png');assert sha(current)==entry['sha256'];candidates=[priorRoot/byPage[name]['current'],Path('docs/redesign-v1.85.166/images',name+'.png')];chosen=next((p for p in candidates if p.exists() and sha(p)==entry['sha256']),None)
 if chosen is None:chosen=root/'images'/f'{name}.png';shutil.copyfile(current,chosen)
 path=os.path.relpath(chosen,root).replace('\\','/');html=html.replace(byPage[name]['current'],path);reference=Path('docs/redesign-v1.85.156/refs',name+'.png');assert sha(reference)==entry['referenceSha256'];images.append(dict(page=name,current=path,currentSha256=sha(chosen),reference='../redesign-v1.85.156/refs/'+name+'.png',referenceSha256=sha(reference),reusedPriorImage=not chosen.is_relative_to(root)))
(root/'review.html').write_text(html,encoding='utf-8',newline='\n');(root/'gallery-images.json').write_text(json.dumps(dict(productionIndexSha256=verification['productionIndexSha256'],images=images),indent=2)+'\n',encoding='utf-8',newline='\n')
s=Path('tmp/check-review172.mts').read_text(encoding='utf-8').replace('redesign-v1.85.172','redesign-v1.85.173').replace('tmp/type172','tmp/type173');Path('tmp/check-review173.mts').write_text(s,encoding='utf-8',newline='\n');print('Prepared source173 gallery; reused current PNGs:',sum(x['reusedPriorImage'] for x in images))
