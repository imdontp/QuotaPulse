from pathlib import Path
s=Path('tmp/capture-fidelity166.mts').read_text(encoding='utf-8').replace("'tmp/fidelity166/'","'tmp/fidelity170/'")
anchor="    const first = await page.screenshot"
assert anchor in s
snippet="""    const selectMetadata=await page.locator('.qp-history-filter-form select').evaluateAll(nodes=>nodes.map(el=>({outerHTML:el.outerHTML,font:getComputedStyle(el).font,weight:getComputedStyle(el).fontWeight,variation:getComputedStyle(el).fontVariationSettings,selectedFont:getComputedStyle((el as HTMLSelectElement).selectedOptions[0]).font,rect:el.getBoundingClientRect().toJSON(),disabled:(el as HTMLSelectElement).disabled})));
    const cdp=await context.newCDPSession(page);await cdp.send('DOM.enable');await cdp.send('CSS.enable');const tree=await cdp.send('DOM.getDocument',{depth:-1,pierce:true});const node=await cdp.send('DOM.querySelector',{nodeId:tree.root.nodeId,selector:'.qp-history-filter-form select'});const platform=await cdp.send('CSS.getPlatformFontsForNode',{nodeId:node.nodeId});
    writeFileSync(resolve(output,'select-fonts.json'),JSON.stringify({selectMetadata,platform,faces:await page.evaluate(()=>[...document.fonts].map(face=>({family:face.family,weight:face.weight,status:face.status})))},null,2)+'\\n');await cdp.detach();
    await page.screenshot({path:resolve(output,'native-before.png'),animations:'disabled'});const experiment=await page.addStyleTag({content:'.qp-history-filter-form select{appearance:none!important;line-height:33px!important}'});await page.screenshot({path:resolve(output,'appearance-none.png'),animations:'disabled'});await experiment.evaluate(el=>el.remove());await page.screenshot({path:resolve(output,'native-restored.png'),animations:'disabled'});
"""
s=s.replace(anchor,snippet+anchor)
Path('tmp/capture-select170.mts').write_text(s,encoding='utf-8',newline='\n')
