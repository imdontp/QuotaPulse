import json
from pathlib import Path
import numpy as np
from PIL import Image
root=Path('tmp/fidelity170');phases=sorted(p for p in root.glob('controlled-*') if (p/'native-restored.png').exists())
def load(p,name):return np.array(Image.open(p/name).convert('RGB'))[480:500,1096:1182]
def compare(a,b):
 d=np.abs(a.astype(int)-b.astype(int));return dict(changedPixels=int(np.any(d,axis=2).sum()),maxDelta=int(d.max()))
results=[]
for p in phases:
 native=load(p,'native-before.png');styled=load(p,'appearance-none.png');base=load(phases[0],'native-before.png');stylebase=load(phases[0],'appearance-none.png')
 results.append(dict(context=p.name,nativeVsFirst=compare(base,native),styledVsFirst=compare(stylebase,styled),restoration=compare(native,load(p,'native-restored.png'))))
old=np.array(Image.open('tmp/fidelity166/final/history.png').convert('RGB'))[480:500,1096:1182];shifted=np.array(Image.open('tmp/fidelity170/current-a/history.png').convert('RGB'))[480:500,1096:1182]
maskA=old.min(axis=2)>140;maskB=shifted.min(axis=2)>140
ink=dict(beforePixels=int(maskA.sum()),afterPixels=int(maskB.sum()),samePositionIoU=float((maskA&maskB).sum()/(maskA|maskB).sum()),afterDownOnePixelIoU=float((maskA&np.roll(maskB,1,axis=0)).sum()/(maskA|np.roll(maskB,1,axis=0)).sum()),rgbDifferenceAfterOnePixelShift=compare(old,np.roll(shifted,1,axis=0)))
result=dict(contexts=len(results),roi=[1096,480,1182,500],onePixelEvidence=ink,comparisons=results)
Path('tmp/select170/controlled-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(result,indent=2))
