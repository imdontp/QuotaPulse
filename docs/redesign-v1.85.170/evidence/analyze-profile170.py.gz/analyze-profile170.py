import json,collections
from pathlib import Path
p=json.loads(Path('tmp/select170/projects-profile.json').read_text(encoding='utf-8'))['profile'];nodes={n['id']:n for n in p['nodes']};cost=collections.Counter()
for sample,dt in zip(p['samples'],p['timeDeltas']):cost[sample]+=dt
ranked=[dict(milliseconds=round(t/1000,2),**nodes[n]['callFrame']) for n,t in cost.most_common(22)]
result=dict(durationMs=(p['endTime']-p['startTime'])/1000,sampledMs=sum(p['timeDeltas'])/1000,topSelfTime=ranked,longTasks=json.loads(Path('tmp/select170/projects-longtasks.json').read_text(encoding='utf-8')))
Path('tmp/select170/projects-profile-summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(result,indent=2))
