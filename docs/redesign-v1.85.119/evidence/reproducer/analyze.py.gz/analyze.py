import json,math
from pathlib import Path
from PIL import Image,ImageChops
root=Path('tmp/ring119')
def diff(first,last,box=None):
 a=Image.open(first).convert('RGB');b=Image.open(last).convert('RGB')
 if box:a=a.crop(box);b=b.crop(box)
 cs=ImageChops.difference(a,b).split();d=ImageChops.lighter(ImageChops.lighter(cs[0],cs[1]),cs[2]);h=d.histogram()
 return dict(changedPixels=sum(h[1:]),maxChannelDelta=max(i for i,n in enumerate(h)if n),bounds=d.getbbox())
results=[]
for mode,base in [('original',Path('screens/models-comparison')),('native',root/'native')]:
 for lang in ['en','th']:
  for theme in ['dark','light']:
   name=f'models-{lang}-{theme}.png';paint=json.loads((base/(name+'.ring.json')).read_text(encoding='utf-8'));repeat=json.loads((base/('repeat-'+name+'.ring.json')).read_text(encoding='utf-8'));assert paint==repeat,(mode,lang,theme)
   r=paint[0]['rect'];box=(math.floor(r['left'])-20,math.floor(r['top'])-20,math.ceil(r['right'])+20,math.ceil(r['bottom'])+20)
   full=diff(base/name,base/('repeat-'+name));ring=diff(base/name,base/('repeat-'+name),box);assert ring['changedPixels']==0,(mode,lang,theme,ring)
   results.append(dict(mode=mode,lang=lang,theme=theme,full=full,ringRegion=box,ring=ring,globalGatePass=full['maxChannelDelta']<=10 and full['changedPixels']/(1672*941)<=.00005))
old=json.loads((root/'baseline/models-en-dark.png.ring.json').read_text(encoding='utf-8'))[0];now=json.loads(Path('screens/models-comparison/models-en-dark.png.ring.json').read_text(encoding='utf-8'))[0]
preserved=['rect','background','radius','shadow','outline','pseudo','text']
for key in preserved:assert old[key]==now[key],key
before=json.loads(Path('docs/redesign-v1.85.118/evidence/after-models-trend.json').read_text(encoding='utf-8'));after=json.loads((root/'canonical/models-trend.json').read_text(encoding='utf-8'));assert before==after,'Trend or axes changed'
gate=json.loads(Path('screens/models-comparison/verification.json').read_text(encoding='utf-8'));assert all(row['globalGatePass']for row in results if row['mode']=='original')
nativeA=Image.open(root/'native/models-th-light.png').convert('RGB');nativeB=Image.open(root/'native/repeat-models-th-light.png').convert('RGB')
nativePixels=[]
for y in range(nativeA.height):
 for x in range(nativeA.width):
  a,b=nativeA.getpixel((x,y)),nativeB.getpixel((x,y))
  if a!=b:nativePixels.append(dict(x=x,y=y,before=a,after=b))
report=dict(productionIndexSha256=gate['productionIndexSha256'],pairs=results,preservedPaintInputs=preserved,transformBefore=old['transform'],transformAfter=now['transform'],trendAndAxesEqual=True,
 canonicalBeforeAfter=diff('docs/redesign-v1.85.118/images/models.png',root/'canonical/models.png'),nativeThaiLightPixels=nativePixels,
 baselineSinglePair=diff(root/'baseline/models-en-dark.png',root/'baseline/repeat-models-en-dark.png'),
 evidenceScope='Eight exact ring regions; original four full pairs pass; native full gate fails at two table pixels. Region analysis does not replace or mask full-page gates.',
 diagnosis='Layer-dependent rasterization is supported by the intervention; underlying browser paint/cache mechanism remains unproven.')
(root/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
