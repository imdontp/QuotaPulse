const fs=require('node:fs'),assert=require('node:assert/strict');
let s=fs.readFileSync('scripts/check-stable-captures.mts','utf8');
for(const file of ['check-live-minute-refresh.mjs','check-live-token-flow.mjs','check-section-marks.mjs','browser-fixed-date.mjs'])s=s.replace("'./"+file+"'","'../scripts/"+file+"'");
const renderer=/const rendererArgs = \[[^\n]+\];/;assert.ok(renderer.test(s));s=s.replace(renderer,'const rendererArgs: string[] = [];');
const output=/const output = resolve\(root,[^\n]+\);/;assert.ok(output.test(s));s=s.replace(output,"const output = resolve(root,'tmp/ring119/native');");
fs.writeFileSync('tmp/check-native-ring119.mts',s);
