import json,math
from pathlib import Path
from PIL import Image
root=Path('docs/redesign-v1.85.118/evidence')
a=Image.open(root/'models-en-dark.png').convert('RGB');b=Image.open(root/'repeat-models-en-dark.png').convert('RGB')
rect=json.loads((root/'models-en-dark.png.ring.json').read_text())[0]['rect'];cx=rect['x']+rect['width']/2;cy=rect['y']+rect['height']/2
rows=[];bands={}
for y in range(375,514):
 for x in range(1505,1651):
  first,last=a.getpixel((x,y)),b.getpixel((x,y));delta=max(abs(p-q)for p,q in zip(first,last))
  if delta:
   radius=math.hypot(x+.5-cx,y+.5-cy);band=math.floor(radius);bands[str(band)]=bands.get(str(band),0)+1
   rows.append(dict(x=x,y=y,radius=radius,delta=delta,before=first,after=last))
report=dict(center=[cx,cy],radialHistogram=bands,largest=sorted(rows,key=lambda r:-r['delta'])[:25])
Path('tmp/ring119').mkdir(exist_ok=True);Path('tmp/ring119/radial-analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
