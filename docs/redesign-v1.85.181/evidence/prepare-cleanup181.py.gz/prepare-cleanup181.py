﻿from pathlib import Path
import json,hashlib,zipfile,os,re
root=Path(__file__).resolve().parents[1];project=root.parents[2];out=root/'tmp/release181'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
record=read(out/'delivered-archive.json');source=read(out/'inputs.json');standalone=read(out/'standalone-smoke/bundle-verification.json');reader=read(out/'reader-smoke.json');installed=read(out/'installation-smoke.json')
assert standalone['status']==reader['status']==installed['status']=='passed'
archive=Path(record['archive'])
with archive.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==record['sha256']
temp=Path(os.environ['TEMP']).resolve();fixture=Path(installed['fixture']).resolve()
assert fixture.parent==project/'tmp/installation-review181' and re.fullmatch(r'run-[a-f0-9]{32}',fixture.name)
candidates=[('unused-build',Path(source['bundle']),False),('standalone',Path(standalone['extracted']),True),('reader',Path(reader['extracted']),True),('installed',Path(installed['runtime']),False)]
sha=lambda stream:hashlib.file_digest(stream,'sha256').hexdigest()
with zipfile.ZipFile(archive) as z:
 expected={}
 for e in z.infolist():
  if not e.is_dir():
   with z.open(e) as stream:expected[e.filename]=sha(stream)
 assert len(expected)==record['entries']
 rows=[]
 for stage,path,profile in candidates:
  path=path.resolve()
  if stage=='unused-build':assert path.parent==root/'tmp/review-bundles' and path.name.startswith('QuotaPulse-v1.85.180-review181-')
  elif stage=='installed':assert path==fixture/'review/releases'/('release-'+record['sha256'])
  else:assert path.parent==temp and re.fullmatch(r'QuotaPulse-review-[a-zA-Z0-9]+',path.name)
  files=[];seen=set();prefix='\\\\?\\'+str(path)
  def fail(e):raise e
  for base,dirs,names in os.walk(prefix,followlinks=False,onerror=fail):
   for name in dirs+names:
    p=os.path.join(base,name);assert not (os.lstat(p).st_file_attributes&0x400),p
   for name in names:
    p=os.path.join(base,name);rel=os.path.relpath(p,prefix).replace('\\','/');size=os.stat(p).st_size
    if rel.startswith('review-data/'):assert profile
    else:
     assert rel in expected,rel
     with open(p,'rb') as stream:assert sha(stream)==expected[rel],rel
     seen.add(rel)
    files.append({'relative':rel,'bytes':size})
  assert seen==set(expected),(stage,len(seen),len(expected))
  rows.append({'stage':stage,'path':str(path),'fixture':str(fixture) if stage=='installed' else str(path),'bytes':sum(p['bytes'] for p in files),'files':files,'archiveSha256':record['sha256']})
(out/'cleanup-plan.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Verified all archive bytes in',len(rows),'owned runtime trees;',sum(r['bytes'] for r in rows),'bytes before ASAR retention.')

