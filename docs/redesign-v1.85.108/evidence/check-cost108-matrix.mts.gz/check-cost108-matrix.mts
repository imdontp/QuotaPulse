/** Static canonical reference capture. Isolated synthetic DB, compiled application, no user data. */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium, type Page, type Request } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import { recordQuotaAlerts } from '../packages/daemon/src/api/queries.js';
const root = fileURLToPath(new URL('..', import.meta.url));
const output = resolve(root, 'tmp/cost108-matrix');
const referenceRoot = 'C:/Users/TH12367283/Downloads/quotapulse_build_blueprint';
const priorTimezone = process.env.TZ;
process.env.TZ = 'Asia/Bangkok';
mkdirSync(output, { recursive: true });

const fixedNow = Date.parse('2025-05-17T13:42:00.000Z');
// Freeze Date only, keeping real timers/performance for HTTP, browser and cleanup.
// This applies to internal query helpers too, without changing production clocks.
const realDate = globalThis.Date;
globalThis.Date = new Proxy(realDate, {
  construct(target, args) { return Reflect.construct(target, args.length ? args : [fixedNow]); },
  apply() { return new realDate(fixedNow).toString(); },
  get(target, property, receiver) { return property === 'now' ? () => fixedNow : Reflect.get(target, property, receiver); },
});
const db = openDb(':memory:');
db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at,account_key,account_provider,account_display_name,account_state,account_last_success_at)
  VALUES (1,'codex','fixed','/synthetic/nonexistent','Codex fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow}),
    (2,'hermes','fixed','/synthetic/nonexistent','Hermes fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (3,'claude-code','fixed','/synthetic/nonexistent','Claude Code fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (4,'opencode','fixed','/synthetic/nonexistent','OpenCode fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow});`);
const referenceProjects = ['QuotaPulse', 'Agent Platform', 'Edge Services', 'Developer Tools', 'Research Lab'];
const referenceModels = [
  { name: 'DeepSeek V4.1', provider: 'deepseek', share: 38 },
  { name: 'GPT-5.x', provider: 'openai', share: 24 },
  { name: 'Claude 3.7', provider: 'anthropic', share: 18 },
  { name: 'Claude 3.5', provider: 'anthropic', share: 11 },
  { name: 'Others', provider: 'openrouter', share: 9 },
  { name: 'GPT-4.1 mini', provider: 'openai', share: 0 },
];
const session = db.prepare('INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (?,?,?,?,?)');
const usage = db.prepare('INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source,cost_input_usd,cost_cached_input_usd,cost_cache_write_usd,cost_output_usd,cost_cache_saving_usd,price_provider) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
// Synthetic catalogue rates for the in-memory visual fixture only. The saved
// amount is derived from the same fresh/cached input components the UI reports.
const fixtureInputUsdPerMillion = 0.0593846153846154, fixtureCachedInputUsdPerMillion = 0.004, fixtureOutputUsdPerMillion = 0.004;
for (let index = 0; index < 12; index++) {
  // Keep the reference map's 4 Codex, 2 Claude Code, 6 Hermes, 0 OpenCode
  // recent-session distribution while preserving the same 12 sessions.
  const source = [1, 1, 1, 1, 3, 3, 2, 2, 2, 2, 2, 2][index]!;
  session.run(index + 1, source, `fixture-session-${index}`, referenceProjects[0], fixedNow - 10_000);
  const model = referenceModels[index % referenceModels.length]!;
  const totalTokens = model.share === 0 ? 1 : model.share * 721_000_000 / 600;
  for (let call = 0; call < 3; call++) {
    const inputShare = [.6, .65, .7][(index + call) % 3]!;
    const inputTokens = totalTokens * inputShare * .58, cachedInputTokens = totalTokens * inputShare * .42;
    const outputTokens = totalTokens * (1 - inputShare);
    const costSource = index === 0 ? 'native' : 'computed';
    const inputUsd = inputTokens / 1_000_000 * fixtureInputUsdPerMillion;
    const cachedInputUsd = cachedInputTokens / 1_000_000 * fixtureCachedInputUsdPerMillion;
    const outputUsd = outputTokens / 1_000_000 * fixtureOutputUsdPerMillion;
    const cacheSavingUsd = cachedInputTokens / 1_000_000 * (fixtureInputUsdPerMillion - fixtureCachedInputUsdPerMillion);
    // Keep each session's latest record within four minutes, then spread older calls across the visible 30-minute interval.
    const ageMs = call === 0 ? 15_000 + index * 20_000 : source === 2
      ? 300_000 + index * 120_000 + (call === 2 ? 30_000 : 0)
      : 300_000 + index * 240_000 + (call === 2 ? 90_000 : 0);
    const recordedAt = fixedNow - ageMs;
    usage.run(source, index + 1, `fixed-${index}-${call}`, recordedAt, model.name, model.provider,
      inputTokens, cachedInputTokens, outputTokens, totalTokens, call + 1,
      costSource === 'native' ? (index + 1) / 100 : inputUsd + cachedInputUsd + outputUsd, costSource,
      costSource === 'native' ? null : inputUsd, costSource === 'native' ? null : cachedInputUsd,
      costSource === 'native' ? null : 0, costSource === 'native' ? null : outputUsd,
      costSource === 'native' ? null : cacheSavingUsd, costSource === 'native' ? null : model.provider);
  }
}
// A stale recorded OpenCode route keeps the concept's zero-active-session edge
// visible without manufacturing a provider relationship or changing live counts.
const openCodeAt = fixedNow - 10 * 60_000;
session.run(13, 4, 'fixture-opencode-quota-pulse', referenceProjects[0], openCodeAt);
usage.run(4, 13, 'fixed-opencode-route', openCodeAt, 'DeepSeek V4.1', 'deepseek', 1, 0, 0, 1, 1,
  null, 'unknown', null, null, null, null, null, null);
// The monthly concept is focused on QuotaPulse while the machine-wide quick
// stats still report all five named projects. Keep four small monthly records
// for the other projects, outside the recent-session window.
for (let index = 1; index < referenceProjects.length; index++) {
  const id = 100 + index, source = [1, 3, 4, 2][index - 1]!;
  const model = referenceModels[index - 1]!;
  const at = fixedNow - 10 * 60_000;
  session.run(id, source, `fixture-project-${index}`, referenceProjects[index], at);
  const inputUsd = fixtureInputUsdPerMillion / 1_000_000;
  usage.run(source, id, `fixture-project-usage-${index}`, at, model.name, model.provider, 1, 0, 0, 1, 1,
    inputUsd, 'computed', inputUsd, 0, 0, 0, 0, model.provider);
}
// Values below the old visual minimum catch inflated nonzero bars in both charts.
const tinyUsage = db.prepare("INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source) VALUES (1,1,?,?,'DeepSeek V4.1','deepseek',1,0,0,1,1,0,'computed')");
tinyUsage.run('fixed-tiny-minute', fixedNow - 15 * 60_000);
tinyUsage.run('fixed-tiny-day', fixedNow - 3 * 86_400_000);
const quota = db.prepare('INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin) VALUES (?,?,?,?,?,?,?,?)');
const addQuotaSample = (sourceId: number, window: string, percent: number | null, resetAt: number | null, observedAt: number) => quota.run(sourceId, window, percent, resetAt, observedAt, observedAt, observedAt, 'fixed-fixture');
// Complete history must include older reset periods, nulls and more than eight
// readings per period, without changing the latest live quota/default selection.
for (let segment = 0; segment < 4; segment++) for (let index = 0; index < 12; index++) {
  const at = fixedNow - (5 - segment) * 3_600_000 + index * 60_000;
  addQuotaSample(1, '5h', index === 4 ? null : index === 1 ? 0.5 : index * 8, segment === 0 ? null : fixedNow - (4 - segment) * 3_600_000, at);
}
addQuotaSample(1, '5h', 38, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 5 * 60_000);
addQuotaSample(1, '5h', 83, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 30_000);
addQuotaSample(1, 'weekly', 62, fixedNow + (3 * 24 + 5) * 3_600_000, fixedNow - 30_000);
const monthlyReset = fixedNow + (6 * 24 + 2) * 3_600_000;
addQuotaSample(1, 'monthly', 59, monthlyReset, fixedNow - 48 * 3_600_000);
addQuotaSample(1, 'monthly', 65.5, monthlyReset, fixedNow - 24 * 3_600_000);
addQuotaSample(1, 'monthly', 72, monthlyReset, fixedNow - 30_000);
addQuotaSample(2, 'monthly', 58, fixedNow + (12 * 24 + 6) * 3_600_000, fixedNow - 30_000);
addQuotaSample(2, 'daily', 34, fixedNow + (7 * 60 + 18) * 60_000, fixedNow - 30_000);
recordQuotaAlerts(db, fixedNow);
const scheduler = new Scheduler(db, [], { pollMs: 1_000_000, detectMs: 1_000_000 });
const daemon = buildServer(db, scheduler, { token: 'stable-capture-test', port: 7816, webRoot: resolve(root, 'packages/web/dist') });
let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;
const sha = (bytes: Buffer) => createHash('sha256').update(bytes).digest('hex');
const indexPath = resolve(root, 'packages/web/dist/index.html');
const productionIndexSha256 = sha(readFileSync(indexPath));


const results:any[]=[];
try{
await daemon.listen({host:'127.0.0.1',port:7816});browser=await chromium.launch({channel:'chrome',headless:true});
for(const lang of ['en','th'])for(const theme of ['dark','light'] as const){
 const context=await browser.newContext({viewport:{width:1672,height:941},reducedMotion:'reduce',deviceScaleFactor:1,timezoneId:'Asia/Bangkok',colorScheme:theme});const page=await context.newPage();page.setDefaultTimeout(15000);const errors:string[]=[],forbidden:string[]=[];page.on('pageerror',error=>errors.push(error.message));page.on('response',response=>{if(response.status()>=400)errors.push(response.status()+' '+new URL(response.url()).pathname);});await page.route('**/*',route=>{const request=route.request(),url=new URL(request.url());if(url.origin!=='http://127.0.0.1:7816'||url.pathname.startsWith('/api/')&&request.method()!=='GET'&&!(request.method()==='POST'&&url.pathname==='/api/model-row-trends')){forbidden.push(request.method()+' '+url.pathname);return route.abort();}return route.continue();});
 await page.addInitScript(({lang,theme})=>{(window as any).__QUOTAPULSE_TOKEN__='stable-capture-test';localStorage.setItem('quotapulse-prefs',JSON.stringify({lang,currency:'USD',rate:1,hiddenSubscriptions:[]}));localStorage.setItem('quotapulse-theme',theme);},{lang,theme});await page.clock.setFixedTime(fixedNow);await page.goto('http://127.0.0.1:7816/#cost?range=month');await page.getByTestId('production-cost').waitFor();await page.locator('.qp-cost-chart').waitFor();await page.evaluate(()=>document.fonts.ready);await page.waitForTimeout(350);
 for(const width of [390,900,1280,1536,1586,1672,1920]){
 await page.setViewportSize({width,height:941});await page.waitForTimeout(80);
 const closed=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth>innerWidth,parts:[...document.querySelectorAll('.qp-cost-trend,.qp-cost-trend>.qp-cost-section-head,.qp-cost-plot,.qp-cost-chart,.qp-cost-plot-dates,.qp-cost-chart-footer,.qp-cost-coverage,.qp-cost-chart-footer summary,.qp-cost-axis>span:first-child')].map(element=>({selector:element.matches('.qp-cost-axis>span')?'axis-'+element.parentElement!.getAttribute('data-axis'):element.tagName==='SUMMARY'?'summary':element.className,text:element.matches('.qp-cost-coverage')?element.textContent:null,rect:element.getBoundingClientRect().toJSON()})),domOrder:[...document.querySelector('.qp-cost-trend')!.children].map(element=>element.className),bars:[...document.querySelectorAll('.qp-cost-column')].map(element=>(element as HTMLElement).style.height),dates:[...document.querySelectorAll('.qp-cost-plot-dates time')].map(element=>element.getAttribute('datetime'))}));
 const key=lang+'/'+theme+'/'+width;assert.equal(closed.overflow,false,key+': overflow');const parts=Object.fromEntries(closed.parts.map(part=>[part.selector,part.rect]));const panel=parts['qp-panel qp-cost-trend'],footer=parts['qp-cost-chart-footer'],plot=parts['qp-cost-plot'];assert.ok(closed.domOrder.indexOf('qp-cost-chart-footer')<closed.domOrder.indexOf('qp-cost-plot'),key+': pricing context in reading order');
 for(const part of closed.parts)assert.ok(part.rect.left>=panel.left-.1&&part.rect.right<=panel.right+.1&&part.rect.top>=panel.top-.1&&part.rect.bottom<=panel.bottom+.1,key+': '+part.selector+' outside panel');
 if(width>=1536){assert.ok(footer.bottom<=parts['axis-amount'].top+.1&&footer.bottom<=parts['axis-tokens'].top+.1,key+': disclosure target overlaps first axis tick');if(lang==='en'&&width===1672){assert.ok(Math.abs(parts['qp-cost-chart'].x-298)<1&&Math.abs(parts['qp-cost-chart'].width-658)<1&&Math.abs(parts['qp-cost-chart'].y-410)<2,key+': source plot anchors');assert.equal(panel.height,302);}}
 else assert.ok(plot.bottom<=footer.top+.1,key+': compact chart/disclosure visual order');
 const summary=page.locator('.qp-cost-chart-footer summary');await summary.focus();await page.keyboard.press('Enter');assert.equal(await page.locator('.qp-cost-chart-footer details').getAttribute('open')!==null,true);assert.equal(await page.locator('.qp-cost-chart-footer tbody tr').count(),closed.bars.length);const expanded=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth>innerWidth,panel:document.querySelector('.qp-cost-trend')!.getBoundingClientRect().toJSON(),footer:document.querySelector('.qp-cost-chart-footer')!.getBoundingClientRect().toJSON(),plot:document.querySelector('.qp-cost-plot')!.getBoundingClientRect().toJSON()}));assert.equal(expanded.overflow,false,key+': expanded page overflow');assert.ok(expanded.footer.bottom<=expanded.panel.bottom+.1&&expanded.plot.bottom<=expanded.panel.bottom+.1,key+': expanded content clipped');if(width>=1536)assert.ok(expanded.footer.bottom<=expanded.plot.top+.1,key+': expanded table/plot overlap');else assert.ok(expanded.plot.bottom<=expanded.footer.top+.1,key+': expanded compact order');assert.equal(await summary.evaluate(element=>element===document.activeElement),true);await page.keyboard.press('Enter');assert.equal(await page.locator('.qp-cost-chart-footer details[open]').count(),0);assert.equal(await summary.evaluate(element=>element===document.activeElement),true);
 if([390,1536,1672].includes(width)){await page.evaluate(()=>{window.scrollTo(0,0);document.querySelector('main')!.scrollTop=0;document.activeElement instanceof HTMLElement&&document.activeElement.blur();});await page.screenshot({path:resolve(output,lang+'-'+theme+'-'+width+'.png'),animations:'disabled'});}
 results.push({lang,theme,width,closed,expanded,keyboardOpenClose:true,allBucketRows:true});
 }
 assert.deepEqual(errors,[]);assert.deepEqual(forbidden,[]);console.log('Cost context/plot matrix passed '+lang+'/'+theme);await context.close();
}
assert.equal(sha(readFileSync(indexPath)),productionIndexSha256);writeFileSync(resolve(output,'verification.json'),JSON.stringify({productionIndexSha256,browser:browser.version(),rendererArgs:[],fixture:'isolated synthetic DB; fixed clock',cases:results.length,scope:'Native browser Cost layout/context reading order, all bucket-row keyboard disclosure and focused compact/native containment; not full app acceptance/performance',results},null,2));
}finally{await browser?.close();await daemon.close();db.close();globalThis.Date=realDate;process.env.TZ=priorTimezone;}
