import json
from pathlib import Path
import numpy as np
from PIL import Image
probe=json.loads(Path('tmp/type172/measurement.json').read_text(encoding='utf-8'));rows=[]
for section in probe['sections']:
 name=section['image'];x1,y1,x2,y2=section['roi'];frames={}
 for stage,path in [('reference','C:/Users/TH12367283/Downloads/quotapulse_build_blueprint/refs/'+name+'.png'),('before','tmp/fidelity169/final/'+name+'.png'),('after','tmp/fidelity172/final/'+name+'.png')]:
  a=np.array(Image.open(path).convert('RGB'))[y1:y2,x1:x2];m=a.min(axis=2)>140;y,x=np.where(m);frames[stage]=dict(bounds=list(map(int,[x.min()+x1,y.min()+y1,x.max()+x1,y.max()+y1])),pixels=int(m.sum()))
 rows.append(dict(key=section['key'],**frames,afterPositionDelta=[frames['after']['bounds'][i]-frames['reference']['bounds'][i] for i in [0,1]]))
Path('tmp/type172/painted-bounds.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(rows,indent=2))
