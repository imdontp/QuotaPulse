import json
from pathlib import Path
import numpy as np
from PIL import Image
before=Path('tmp/fidelity169/final');after=Path('tmp/fidelity172/final');results=[]
for name in ['overview','live','projects','models','history','alerts','providers','cost']:
 a=np.array(Image.open(before/f'{name}.png').convert('RGB'));b=np.array(Image.open(after/f'{name}.png').convert('RGB'));d=np.abs(a.astype(int)-b.astype(int));changed=np.any(d,axis=2);ys,xs=np.where(changed)
 results.append(dict(page=name,changedPixels=int(changed.sum()),maximumChannelDelta=int(d.max()),bounds=list(map(int,[xs.min(),ys.min(),xs.max(),ys.max()])) if len(xs) else None,repeatIdentical=bool(np.array_equal(b,np.array(Image.open(after/f'{name}-repeat.png').convert('RGB'))))))
Path('tmp/type172/comparison.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8',newline='\n')
headings=[]
for name in ['overview','models']:
 base=Path('tmp/fidelity172/before') if name=='models' else before
 old=json.loads((base/f'{name}-heading-geometry.json').read_text(encoding='utf-8'));new=json.loads((after/f'{name}-heading-geometry.json').read_text(encoding='utf-8'))
 if name=='overview':new=[x for x in new if x['tag']!='H3']
 assert [x['text'] for x in old]==[x['text'] for x in new],name
 for a,b in zip(old,new):
  headings.append(dict(page=name,text=a['text'],beforeFont=a['font'],afterFont=b['font'],beforeRect=a['rect'],afterRect=b['rect'],beforeText=a['ranges'],afterText=b['ranges'],lineBoxHeightUnchanged=a['rect']['height']==b['rect']['height'],lineBoxHeightDelta=b['rect']['height']-a['rect']['height']))
assert all(abs(x['lineBoxHeightDelta'])<=1/64 for x in headings),[(x['text'],x['lineBoxHeightDelta']) for x in headings if abs(x['lineBoxHeightDelta'])>1/64]
Path('tmp/type172/headings.json').write_text(json.dumps(headings,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(results,indent=2));print('PASS heading line-box heights within1/64px rounding and visible heading text unchanged')
