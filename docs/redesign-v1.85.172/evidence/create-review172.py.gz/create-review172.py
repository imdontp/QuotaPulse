import hashlib,json,os,re,shutil
from pathlib import Path
root=Path('docs/redesign-v1.85.172');(root/'images').mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
verification=json.loads(Path('tmp/fidelity172/final/verification.json').read_text(encoding='utf-8'))
html=Path('docs/redesign-v1.85.166/review.html').read_text(encoding='utf-8').replace('source166','source172')
html=re.sub(r'<p><a href="README.md">.*?</p>', '<p><a href="README.md">Current evidence and scope</a> · <a href="../redesign-v1.85.169/INVENTORY.md">Eight-page inventory and remaining acceptance</a></p>',html,count=1)
html=re.sub(r'Compiled index SHA256: <code>[0-9a-f]+</code>',f'Compiled index SHA256: <code>{verification["productionIndexSha256"]}</code>',html)
images=[]
for entry in verification['results']:
 name=entry['route'];actual=Path('tmp/fidelity172/final',name+'.png');assert sha(actual)==entry['sha256']
 candidates=[Path('docs/redesign-v1.85.166/images',name+'.png')]
 if name=='alerts':candidates += [Path('docs/redesign-v1.85.169/evidence/alerts-current.png')]
 chosen=next((p for p in candidates if p.exists() and sha(p)==entry['sha256']),None)
 if chosen is None:chosen=root/'images'/f'{name}.png';shutil.copyfile(actual,chosen)
 path=os.path.relpath(chosen,root).replace('\\','/');html=html.replace('images/'+name+'.png',path)
 reference=Path('docs/redesign-v1.85.156/refs',name+'.png');assert sha(reference)==entry['referenceSha256']
 images.append(dict(page=name,current=path,currentSha256=sha(chosen),reference='../redesign-v1.85.156/refs/'+name+'.png',referenceSha256=sha(reference),reusedPriorImage=not chosen.is_relative_to(root)))
(root/'review.html').write_text(html,encoding='utf-8',newline='\n')
(root/'gallery-images.json').write_text(json.dumps(dict(productionIndexSha256=verification['productionIndexSha256'],images=images),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared eight-screen review; reused',sum(x['reusedPriorImage'] for x in images),'byte-identical current images and all eight original refs')
