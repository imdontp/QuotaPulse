/** Real compiled daemon/main/preload/web from an unused, checkout-bound bundle. */
import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { createWriteStream, existsSync, lstatSync, mkdirSync, mkdtempSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { tmpdir } from 'node:os';
import { dirname, join, resolve, sep } from 'node:path';
import { spawn, spawnSync, type ChildProcess } from 'node:child_process';
import { once } from 'node:events';
import { setTimeout as delay } from 'node:timers/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { _electron, type ElectronApplication, type Page } from 'playwright';

const root=fileURLToPath(new URL('..',import.meta.url));
const require=createRequire(import.meta.url);
const { inventory }=require(resolve(root,'scripts/check-release-rollback.cjs'));
const sha=(bytes:Buffer)=>createHash('sha256').update(bytes).digest('hex');
const json=(file:string)=>JSON.parse(readFileSync(file,'utf8').replace(/^\uFEFF/,''));
const input=json(process.env.QP_REVIEW_DASHBOARD_INPUT!);
function plain(file:string){let at=resolve(file);for(;;){if(existsSync(at))assert.equal(lstatSync(at).isSymbolicLink(),false,at);const up=dirname(at);if(up===at)break;at=up;}return resolve(file);}
const checkout=plain(realpathSync(input.checkout)),bundle=plain(realpathSync(input.bundle));
assert.ok(bundle.toLowerCase().startsWith((join(checkout,'tmp','review-bundles')+sep).toLowerCase()));
assert.equal(existsSync(join(bundle,'review-data')),false,'Only unused source bundles are accepted');
assert.match(input.sourceCommit,/^[a-f0-9]{40}$/);
const git=spawnSync('git',['-C',checkout,'rev-parse','HEAD'],{encoding:'utf8',windowsHide:true});
assert.equal(git.status,0);assert.equal(git.stdout.trim(),input.sourceCommit);
const receipt=json(input.buildReceipt);assert.equal(receipt.sourceCommit,input.sourceCommit);assert.equal(receipt.steps.length,6);assert.ok(receipt.steps.every((step:any)=>step.exitCode===0));
const manifest=json(join(bundle,'review-manifest.json'));assert.equal(manifest.requiredNodeAbi,process.versions.modules);
const runtime=inventory(bundle);for(const [file,hash]of Object.entries(runtime))assert.equal(sha(readFileSync(join(checkout,file))),hash,file);
const fullBefore=inventory(bundle,true),webRoot=join(bundle,'packages/web/dist'),indexSha256=sha(readFileSync(join(webRoot,'index.html')));
const uid=randomUUID(),output=resolve(root,'tmp','review150','native-'+uid),profile=plain(mkdtempSync(join(realpathSync.native(tmpdir()),'qpdash-')));
mkdirSync(output,{recursive:true});writeFileSync(join(profile,'fixture.json'),JSON.stringify({mode:'owned-native-dashboard-review',uid,bundle,sourceCommit:input.sourceCommit})+'\n');
const data=join(profile,'data');mkdirSync(data);assert.equal(existsSync(join(data,'usage.db')),false);
const bundleRequire=createRequire(join(bundle,'package.json'));
for(const name of ['better-sqlite3','electron'])assert.ok(realpathSync(bundleRequire.resolve(name)).toLowerCase().startsWith((bundle+sep).toLowerCase()));
const { openDb }=await import(pathToFileURL(join(bundle,'packages/daemon/dist/db/index.js')).href);
const db=openDb(join(data,'usage.db')),now=Date.now();
db.transaction(()=>{
 db.prepare(`INSERT INTO source(id,harness,profile,root_path,display_name,enabled,detected_at,account_key,account_provider,account_display_name,account_state,account_last_success_at) VALUES(?,?,?,?,?,0,?,?,?,?,?,?)`).run(1,'codex','native-review','/synthetic/nonexistent','Native review source A',now,'review:openai','openai','Native review OpenAI','active',now);
 db.prepare(`INSERT INTO source(id,harness,profile,root_path,display_name,enabled,detected_at,account_key,account_provider,account_display_name,account_state,account_last_success_at) VALUES(?,?,?,?,?,0,?,?,?,?,?,?)`).run(2,'claude-code','native-review','/synthetic/nonexistent','Native review source B',now,'review:anthropic','anthropic','Native review Anthropic','active',now);
 db.prepare('INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES(1,1,?,?,?)').run('native-review-a','Native review project',now);
 db.prepare('INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES(2,2,?,?,?)').run('native-review-b','Native review second project',now);
 const event=db.prepare(`INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source,cost_input_usd,cost_cached_input_usd,cost_output_usd,cost_cache_saving_usd,price_provider) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
 event.run(1,1,'native-review-1',now-30000,'Native Model A','openai',100,0,50,150,1,.25,'native',null,null,null,null,null);
 event.run(2,2,'native-review-2',now-60000,'Native Model B','anthropic',40,10,20,70,2,.0123,'computed',.004,.0003,.008,.0007,'anthropic');
 event.run(1,1,'native-review-3',now-90000,null,null,1,0,0,1,1,null,'unknown',null,null,null,null,null);
 const quota=db.prepare('INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin) VALUES(?,?,?,?,?,?,?,?)');
 quota.run(1,'5h',83,now+7200000,now,now,now,'native-review');quota.run(2,'monthly',62,now+86400000,now,now,now,'native-review');
 db.exec(`INSERT OR REPLACE INTO app_setting(id,pet_enabled,tray_animation_enabled,hidden_subscriptions,updated_at) VALUES(1,0,0,'[]',0);INSERT OR REPLACE INTO notification_setting(id,enabled,snooze_until,quiet_start,quiet_end,updated_at) VALUES(1,0,4102444800000,1320,420,0);`);
})();
const factsBefore=db.prepare('SELECT * FROM usage_event ORDER BY id').all();db.close();
writeFileSync(join(data,'pet-settings.json'),JSON.stringify({schemaVersion:4,enabled:false}));
const port=7819,base=`http://127.0.0.1:${port}`;
let daemon:ChildProcess|undefined,desktop:ElectronApplication|undefined,lock:any,success=false,failure:string|undefined;
const errors:string[]=[],forbidden:string[]=[],writes:string[]=[],served:Record<string,string>={},responseChecks:Promise<void>[]=[],captures:any[]=[],cycles:any[]=[];
const modelControls:any[]=[],projectChecks:any[]=[],paletteChecks:any[]=[],historyChecks:any[]=[],calendarChecks:any[]=[];
const logs=createWriteStream(join(output,'daemon.log'));
async function until(check:()=>Promise<boolean>,label:string){const end=performance.now()+30000;while(performance.now()<end){if(await check())return;await delay(100);}throw Error(label);}
async function request(path:string){const response=await fetch(base+path,{headers:{'x-quotapulse-token':lock.token},signal:AbortSignal.timeout(3000)});assert.equal(response.status,200,path);return response.json() as Promise<any>;}
async function launch(){
 desktop=await _electron.launch({timeout:30000,executablePath:bundleRequire('electron'),args:['--disable-backgrounding-occluded-windows','--disable-renderer-backgrounding','--disable-features=CalculateNativeWinOcclusion',join(bundle,'scripts/task-entry.cjs'),'--role','tray','--port',String(port),'--data-dir',data,'--node-exe',process.execPath,'--no-readers'],env:{...process.env,ELECTRON_RUN_AS_NODE:undefined}});
 await desktop.evaluate(({app})=>app.whenReady());
 await desktop.evaluate(({app,ipcMain,screen})=>{
  (globalThis as any).reviewNative={ready:[],shown:[],preloadErrors:[],placementErrors:[]};
  app.on('browser-window-created',(_event,window)=>{
   window.webContents.setBackgroundThrottling(false);
   const displays=screen.getAllDisplays().map(display=>display.bounds);
   window.setPosition(Math.max(...displays.map(bounds=>bounds.x+bounds.width))+2048,Math.max(...displays.map(bounds=>bounds.y+bounds.height))+2048,false);
   window.setSkipTaskbar(true);window.setFocusable(false);
   window.on('show',()=>{(globalThis as any).reviewNative.shown.push(window.id);const r=window.getBounds();if(displays.some(b=>r.x<b.x+b.width&&r.x+r.width>b.x&&r.y<b.y+b.height&&r.y+r.height>b.y)){window.hide();(globalThis as any).reviewNative.placementErrors.push({id:window.id,bounds:r});}});
   window.webContents.on('preload-error',(_event,path,error)=>(globalThis as any).reviewNative.preloadErrors.push({path,message:error.message}));
  });
  ipcMain.on('qp-dashboard-ready',event=>(globalThis as any).reviewNative.ready.push({id:event.sender.id,url:event.sender.getURL()}));
 });
 const context=desktop.context();
 await context.route('**/*',route=>{const req=route.request(),url=new URL(req.url());const readPost=req.method()==='POST'&&url.pathname==='/api/model-row-trends';const settingsPut=req.method()==='PUT'&&url.pathname==='/api/settings';if(url.origin!==base||!['GET','HEAD'].includes(req.method())&&!readPost&&!settingsPut){forbidden.push(req.method()+' '+url.origin+url.pathname);return route.abort();}if(!['GET','HEAD'].includes(req.method()))writes.push(req.method()+' '+url.pathname);return route.continue();});
 context.on('page',page=>{
  page.on('pageerror',error=>errors.push(error.message));
  page.on('response',response=>{const url=new URL(response.url());if(response.status()>=400)errors.push(response.status()+' '+url.pathname);if(url.origin!==base||url.pathname.startsWith('/api/'))return;
   responseChecks.push((async()=>{const relative=url.pathname==='/'?'index.html':decodeURIComponent(url.pathname.slice(1)),file=join(webRoot,relative);assert.ok(plain(file).startsWith(webRoot+sep));let expected=readFileSync(file);if(relative.endsWith('.html'))expected=Buffer.from(expected.toString('utf8').replace('</head>',`<script>window.__QUOTAPULSE_TOKEN__=${JSON.stringify(lock.token)};</script></head>`));const bytes=await response.body();assert.equal(sha(bytes),sha(expected),relative);served[relative]=sha(bytes);})().catch(error=>{errors.push('Served asset: '+String(error));}));
  });
 });
 await desktop.evaluate(({ipcMain})=>{ipcMain.emit('qp-popup-open-dashboard');});
 const page=await desktop.firstWindow();page.setDefaultTimeout(20000);await page.emulateMedia({reducedMotion:'reduce'});
 await page.getByTestId('production-live').locator('.qp-live-metrics').waitFor();
 await page.waitForFunction(()=>typeof (window as any).qpDashboard?.ready==='function');
 const identity=await desktop.evaluate(({app,BrowserWindow})=>{const window=BrowserWindow.getAllWindows()[0];return{pid:process.pid,id:window.id,userData:app.getPath('userData'),sessionData:app.getPath('sessionData'),preferences:window.webContents.getLastWebPreferences(),evidence:(globalThis as any).reviewNative};});
 cycles.push(identity);
 assert.equal(identity.userData,join(data,'electron'));assert.equal(identity.sessionData,identity.userData);assert.equal(identity.preferences.contextIsolation,true);assert.equal(identity.preferences.nodeIntegration,false);assert.equal(identity.preferences.sandbox,true);
 const inspector=await context.newCDPSession(page),parsed:Array<{scriptId:string;url:string}>=[];
 inspector.on('Debugger.scriptParsed',script=>parsed.push({scriptId:script.scriptId,url:script.url}));
 await inspector.send('Debugger.enable');
 writeFileSync(join(output,'preload-scripts-'+cycles.length+'.json'),JSON.stringify(parsed,null,2)+'\n');
 const expectedPreload=readFileSync(join(bundle,'packages/tray/dist-preload/dashboard-preload.js'),'utf8');
 let loadedPreload:any=null;
 try{for(const script of parsed.filter(script=>!script.url||/preload/i.test(script.url))){const source=await inspector.send('Debugger.getScriptSource',{scriptId:script.scriptId});if(source.scriptSource.includes(expectedPreload.trim())){loadedPreload={url:script.url,scriptSourceSha256:sha(Buffer.from(source.scriptSource)),compiledPreloadSha256:sha(Buffer.from(expectedPreload)),exactCompiledSourceContained:true};break;}}}finally{await inspector.detach();}
 assert.ok(loadedPreload,'Loaded isolated-world script must contain the exact compiled bundle preload');
 (identity as any).loadedPreload=loadedPreload;
 await until(async()=>desktop!.evaluate(()=>(globalThis as any).reviewNative.ready.length>0&&(globalThis as any).reviewNative.shown.length>0),'Real preload readiness/show event missing');
 assert.equal(await page.evaluate(()=>typeof (window as any).require),'undefined');
 return page;
}
async function stopElectron(){if(!desktop)return;const app=desktop;const closed=app.waitForEvent('close',{timeout:15000});await app.evaluate(({app,session})=>{session.defaultSession.flushStorageData();setTimeout(()=>app.quit(),0);});await closed;desktop=undefined;}
async function checkModelControls(page:Page,phase:string){
 await page.goto(base+'/#models');await page.locator('.qp-model-detail h3').filter({hasText:'Native Model A'}).waitFor();
 assert.equal(await page.locator('.qp-model-header select').count(),1);assert.equal(await page.locator('.qp-model-toolbar select').count(),3);
 await page.evaluate(`(()=>{window.__qpRingAnimations=[];window.__qpNativeAnimate=Element.prototype.animate;Element.prototype.animate=function(...args){const a=window.__qpNativeAnimate.apply(this,args);if(this.hasAttribute('data-ring-sector')||this.hasAttribute('data-ring-highlight'))window.__qpRingAnimations.push({animation:a,options:args[1]});return a}})()`);
 await page.emulateMedia({reducedMotion:'no-preference'});
 await page.locator('.qp-model-table-wrap button').filter({hasText:'Native Model B'}).click();
 await page.waitForFunction(()=>document.querySelector('.qp-model-detail h3')?.textContent==='Native Model B');
 const timing=await page.evaluate(`window.__qpRingAnimations.map(r=>r.options)`);assert.equal(timing.length,4,'Actual Electron model selection must animate two arcs and highlights');for(const options of timing){assert.equal(options.duration,180);assert.equal(options.iterations,1);assert.equal(options.fill,'none')}
 assert.ok(Math.abs(Number(await page.locator('[data-token-sector=input]').getAttribute('data-share'))-50/70*100)<1e-10);
 await page.waitForFunction(()=>document.querySelector('.qp-model-donut')!.getAnimations({subtree:true}).length===0);
 await page.emulateMedia({reducedMotion:'reduce'});await page.locator('.qp-model-table-wrap button').filter({hasText:'Native Model A'}).click();await page.waitForFunction(()=>document.querySelector('.qp-model-detail h3')?.textContent==='Native Model A');assert.equal(await page.evaluate(`window.__qpRingAnimations.length`),4);
 const order=page.locator('.qp-model-order');await order.focus();await page.keyboard.press('Enter');assert.equal(await order.getAttribute('aria-pressed'),'true');assert.equal(new URLSearchParams(new URL(page.url()).hash.split('?')[1]).get('order'),'asc');await order.click();assert.equal(await order.getAttribute('aria-pressed'),'false');
 await page.locator('.qp-model-header select').selectOption('today');await page.locator('.qp-model-detail h3').waitFor();assert.equal(new URLSearchParams(new URL(page.url()).hash.split('?')[1]).get('range'),'today');
 await page.locator('.qp-model-header select').selectOption('month');await page.locator('.qp-model-detail h3').waitFor();assert.equal(await page.evaluate(`window.__qpRingAnimations.length`),4,'scope/sort must not replay ring selection');
 await page.evaluate(`Element.prototype.animate=window.__qpNativeAnimate`);modelControls.push({phase,periodInHeader:true,threeToolbarFilters:true,keyboardSort:true,ringTiming:timing,reducedImmediate:true,sourceScopedNoReplay:true});
}
async function captureRoutes(page:Page,phase:string){
 const targets:Record<string,string>={overview:'.qp-metrics strong',live:'.qp-live-metrics',projects:'.qp-project-card',models:'.qp-model-table-wrap tbody tr',history:'[data-testid=history-total-tokens]',alerts:'.qp-alert-summary article strong',providers:'.qp-provider-health tbody tr',cost:'.qp-cost-chart'};
 for(const [route,ready]of Object.entries(targets)){
  await page.goto(base+'/#'+route+(route==='cost'?'?range=month':route==='history'?'?range=all':''),{waitUntil:'domcontentloaded'});
  await page.getByTestId('production-'+route).locator(ready).first().waitFor();await page.evaluate(()=>document.fonts.ready);await page.waitForTimeout(300);
  const prefs=await page.evaluate(()=>({lang:document.documentElement.lang,theme:localStorage.getItem('quotapulse-theme'),prefs:JSON.parse(localStorage.getItem('quotapulse-prefs')??'{}'),overflow:document.documentElement.scrollWidth>innerWidth,viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio}}));
  assert.equal(prefs.overflow,false,route+' overflow');
  const summaryLayout=route==='models'?await page.evaluate(()=>{
   const unknown=document.querySelector('[data-testid=models-provider-count] abbr')!,value=document.querySelector('.qp-model-summary article:last-child>strong .qp-cost-value>span:first-child')!;
   const unknownRange=document.createRange(),valueRange=document.createRange();unknownRange.selectNodeContents(unknown);valueRange.selectNodeContents(value);
   const values=[...document.querySelectorAll('.qp-model-summary article>strong')].map(strong=>{const node=strong.querySelector('.qp-cost-value>span:first-child')??strong;const range=document.createRange();range.selectNodeContents(node);return{text:node.textContent,lineTops:[...new Set([...range.getClientRects()].filter(r=>r.width>0).map(r=>r.top))]}});
   return{values,unknown:unknown.textContent,value:value.textContent,unknownLineTops:[...new Set([...unknownRange.getClientRects()].filter(r=>r.width>0).map(r=>r.top))],valueLineTops:[...new Set([...valueRange.getClientRects()].filter(r=>r.width>0).map(r=>r.top))]};
  }):null;
  if(summaryLayout){for(const value of summaryLayout.values)assert.equal(value.lineTops.length,1,'Native summary value wraps: '+value.text);assert.equal(summaryLayout.unknownLineTops.length,1,'Native unknown-provider qualifier wraps');assert.equal(summaryLayout.valueLineTops.length,1,'Native partial monetary value wraps');}

  let paintOracle!:Buffer,native:any;const paintAttempts=[];
  for(let attempt=1;attempt<=1;attempt++){
   paintOracle=await page.screenshot({animations:'disabled'});
   writeFileSync(join(output,phase+'-'+route+'-paint-oracle-'+attempt+'.png'),paintOracle);
   native=await Promise.race([desktop!.evaluate(async({BrowserWindow,nativeImage},oracle)=>{const image=await BrowserWindow.getAllWindows()[0].webContents.capturePage(undefined,{stayHidden:true,stayAwake:true});const expected=nativeImage.createFromBuffer(Buffer.from(oracle,'base64'));const actualPixels=image.toBitmap(),expectedPixels=expected.toBitmap();let changedBytes=0;for(let i=0;i<Math.max(actualPixels.length,expectedPixels.length);i++)if(actualPixels[i]!==expectedPixels[i])changedBytes++;return{empty:image.isEmpty(),size:image.getSize(),png:image.toPNG().toString('base64'),paintOracleSize:expected.getSize(),paintOraclePixelsExact:actualPixels.equals(expectedPixels),changedBytes};},paintOracle.toString('base64')),delay(15000).then(()=>{throw Error('Native hidden capture timed out');})]);
   writeFileSync(join(output,phase+'-'+route+'-native-attempt-'+attempt+'.png'),Buffer.from(native.png,'base64'));
   paintAttempts.push({attempt,exact:native.paintOraclePixelsExact,changedBytes:native.changedBytes,oracleSha256:sha(paintOracle),nativeSha256:sha(Buffer.from(native.png,'base64'))});
   writeFileSync(join(output,phase+'-'+route+'-paint-attempts.json'),JSON.stringify(paintAttempts,null,2)+'\n');
   if(native.paintOraclePixelsExact)break;
   await page.waitForTimeout(100);
  }
  assert.equal(native.empty,false);assert.ok(native.size.width>0&&native.size.height>0);assert.deepEqual(native.size,native.paintOracleSize);
  const screenshot=paintOracle;writeFileSync(join(output,phase+'-'+route+'.png'),screenshot);captures.push({phase,route,summaryLayout,...prefs,nativeImageSize:native.size,paintOracleSize:native.paintOracleSize,paintOraclePixelsExact:native.paintOraclePixelsExact,paintOracleSha256:sha(paintOracle),nativeCaptureSha256:sha(Buffer.from(native.png,'base64')),paintAttempts,captureMethod:'Playwright screenshot of actual Electron page after DOM readiness; separate capturePage bitmap comparison is diagnostic only, not an exact-parity pass',sha256:sha(screenshot)});console.log('Native dashboard '+phase+' '+route+' passed');
 }
}
async function checkProjects(page:Page,phase:string){
 const ready=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/projects'&&r.status()===200);
 await page.goto(base+'/#projects');const data=await(await ready).json();await page.locator('.qp-project-trend').waitFor();
 const lang=await page.evaluate(()=>document.documentElement.lang),nf=new Intl.NumberFormat(lang==='th'?'th-TH':'en-US',{maximumFractionDigits:0});
 const cards=page.locator('.qp-project-card');assert.equal(await cards.count(),2);
 const checks=[];
 for(const group of data.groups){
  const card=cards.filter({has:page.locator('.qp-project-card-identity>strong',{hasText:group.key})});
  const rows=data.rows.filter((r:any)=>r.project===group.key),providers=new Set(rows.map((r:any)=>r.provider).filter((p:any)=>typeof p==='string'&&p.trim()!=='')),missing=rows.some((r:any)=>typeof r.provider!=='string'||r.provider.trim()===''),harnesses=new Set(rows.map((r:any)=>r.harness));
  const providerText=nf.format(providers.size)+(missing?'+ ?':'');
  assert.equal(await card.locator('[data-project-fact=sessions]>strong').innerText(),nf.format(group.sessions));
  assert.equal(await card.locator('[data-project-fact=harnesses]>strong').innerText(),nf.format(harnesses.size));
  assert.equal(await card.locator('[data-project-fact=providers]>strong').innerText(),providerText);
  assert.ok((await card.locator('.qp-project-card-calls').innerText()).startsWith(nf.format(group.calls)));
  await card.focus();await page.keyboard.press('Enter');await page.locator('.qp-project-detail h2').filter({hasText:group.key}).waitFor();
  const panel=page.locator('.qp-project-detail');assert.equal(await panel.locator('.qp-project-detail-metrics>div').count(),3);
  assert.equal(await panel.locator('[data-project-fact=calls]>strong').innerText(),nf.format(group.calls));
  assert.equal(await panel.locator('[data-project-fact=sessions]>strong').innerText(),nf.format(group.sessions));
  assert.equal(await panel.locator('[data-project-fact=providers]>strong').innerText(),providerText);
  assert.equal(await panel.locator('.qp-project-reference-token>strong').getAttribute('data-value'),String(group.tokens));
  assert.equal(await panel.locator('.qp-project-reference-observed time').getAttribute('datetime'),new Date(group.lastObservedAt).toISOString());
  const prefs=await page.evaluate(()=>JSON.parse(localStorage.getItem('quotapulse-prefs')??'{}')),money=new Intl.NumberFormat(lang==='th'?'th-TH':'en-US',{style:'currency',currency:prefs.currency??'USD'});
  for(const [index,amount,priced]of [[0,group.reported_native_usd,group.native_calls],[1,group.api_value_usd,group.computed_calls+group.estimated_calls]])if(priced>0){const value=panel.locator('.qp-project-money>div').nth(index).locator('.qp-cost-value');assert.equal(await value.locator('span').first().innerText(),money.format(prefs.currency==='THB'?amount*prefs.rate:amount)+(priced<group.calls?'+':''));assert.ok((await value.getAttribute('title'))!.includes(priced+' / '+group.calls));}
  const action=panel.locator('.qp-project-detail-link');await action.focus();await page.keyboard.press('Enter');await panel.locator('.qp-project-full-breakdown').waitFor();assert.equal(await panel.locator('.qp-project-full-breakdown>li').count(),rows.length);
  await page.locator('[data-project-detail-tab=overview]').click();await panel.locator('.qp-project-detail-metrics').waitFor();
  checks.push({key:group.key,sessions:group.sessions,calls:group.calls,tokens:group.tokens,providers:providerText,keyboardSelection:true,recordedTimestamp:true,exactMoneyBases:true,metadataAction:true});
 }
 projectChecks.push({phase,lang,checks});console.log('Native Projects facts and keyboard actions '+phase+' passed');
}
async function checkPaletteLoading(page:Page,phase:string){
 const context=desktop!.context(),pattern=/\/assets\/production-[^/?]+\.js(?:\?.*)?$/;
 let release!:()=>void,entered!:()=>void;const gate=new Promise<void>(r=>release=r),held=new Promise<void>(r=>entered=r);
 const handler=async(route:any)=>{entered();await gate;await route.fallback().catch((error:any)=>{if(!page.isClosed())throw error;});};
 await context.route(pattern,handler);
 try{
  await page.goto(base+'/#overview');await Promise.race([held,delay(10000).then(()=>{throw Error('Native cold Overview module not intercepted');})]);
  await page.locator('[data-route-load-state=loading]').waitFor();
  const costLabel=(await page.locator('.qp-sidebar a[href="#cost?range=month"]').textContent())!.trim();
  await page.keyboard.press('Control+k');const palette=page.locator('dialog[open]');await palette.getByRole('searchbox').fill(costLabel);
  release();await page.locator('[data-route-load-state]').waitFor({state:'detached'});await page.locator('.qp-metric-rail[data-value]').first().waitFor();
  assert.equal(await palette.getByRole('searchbox').inputValue(),costLabel);assert.equal(await palette.getByRole('searchbox').evaluate(el=>document.activeElement===el),true);
  await page.screenshot({path:join(output,phase+'-palette-retained.png'),animations:'disabled'});
  await palette.getByRole('button',{name:costLabel,exact:true}).click();await page.waitForURL('**/#cost?range=month');await page.locator('.qp-cost-summary .qp-cost-value').first().waitFor();
  paletteChecks.push({phase,lang:await page.evaluate(()=>document.documentElement.lang),queryRetained:true,focusRetained:true,coldCompiledModuleHeld:true,costMonthNavigation:true});console.log('Native palette module handoff '+phase+' passed');
 }finally{release();await context.unroute(pattern,handler);}
}
async function checkCalendar(page:Page,phase:string){
 const from=now-120000,to=now;
 const ready=page.waitForResponse(response=>{const url=new URL(response.url());return url.pathname==='/api/history-summary'&&url.searchParams.get('from')===String(from)&&response.ok()});
 await page.goto(base+`/#history?range=custom&from=${from}&to=${to}&source=1&session_id=1`);
 const result=await(await ready).json();assert.equal(result.scope.from,from);assert.equal(result.scope.to,to);assert.equal(result.scope.sourceId,1);assert.equal(result.scope.sessionId,1);assert.equal(result.totals.tokens,151);
 await page.waitForFunction(()=>document.querySelector('[data-testid=history-total-tokens]')?.getAttribute('aria-label')==='151');
 const fields=page.getByTestId('usage-history').locator('input[type=date]'),actualDates=await fields.evaluateAll(nodes=>nodes.map(node=>(node as HTMLInputElement).value));
 const expectedDates=await page.evaluate(({from,to})=>[from,to-1].map(value=>{const date=new Date(value);return`${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`}),{from,to});assert.deepEqual(actualDates,expectedDates);
 const originalUrl=page.url();await fields.nth(1).fill('');assert.equal(page.url(),originalUrl);assert.equal(await fields.nth(1).inputValue(),expectedDates[1]);
 await page.screenshot({path:join(output,phase+'-calendar-subday.png'),animations:'disabled'});
 calendarChecks.push({phase,from,to,actualDates,expectedDates,exactScope:true,tokens:151,clearedEndIgnored:true});console.log('Native custom calendar '+phase+' passed');
}
async function checkHistoryFilters(page:Page,phase:string){
 const summaryReady=page.waitForResponse(response=>{const url=new URL(response.url());return url.pathname==='/api/history-summary'&&url.searchParams.get('source_id')==='1'&&url.searchParams.get('session_id')==='1'&&response.ok();});
 await page.goto(base+'/#history?range=all&source=1&session_id=1');
 const summaryResponse=await summaryReady,usage=await summaryResponse.json();assert.equal(new URL(summaryResponse.url()).searchParams.get('timeline'),'observed');
 const history=page.getByTestId('usage-history'),form=history.locator('.qp-history-filter-form');
 await history.locator('tbody tr').first().waitFor();await page.waitForFunction(()=>document.querySelector('[data-testid=history-total-tokens]')?.getAttribute('aria-label')==='151');assert.equal(await history.locator('tbody tr').count(),2);
 const timeline=page.getByTestId('history-timeline'),firstRecordedAt=Math.min(...factsBefore.filter((row:any)=>row.source_id===1&&row.session_id===1).map((row:any)=>row.ts));
 assert.equal(usage.scope.from,0);assert.equal(usage.timelineRange.from,firstRecordedAt);assert.equal(usage.totals.tokens,151);
 await timeline.locator(`[data-axis-at="${firstRecordedAt}"]`).waitFor();
 assert.equal(JSON.parse((await timeline.getAttribute('data-scope'))!).from,0);assert.equal(JSON.parse((await timeline.getAttribute('data-timeline-range'))!).from,firstRecordedAt);
 const plottedTokens=await timeline.locator('g[data-bucket-at]').evaluateAll(nodes=>nodes.reduce((sum,node)=>sum+Number(node.getAttribute('data-input'))+Number(node.getAttribute('data-output')),0));assert.equal(plottedTokens,151);
 assert.equal(await timeline.locator('svg[role=group]>polygon').count(),0,'Native single bucket must retain points without extrapolated areas');assert.equal(await timeline.locator('g[data-bucket-at]>circle').count(),2);const plot=timeline.locator('svg[role=group]');await plot.scrollIntoViewIfNeeded();await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))));await plot.focus();await page.keyboard.press('Home');
 assert.equal(await timeline.locator('[role=status]').getAttribute('data-bucket-at'),String(firstRecordedAt));assert.deepEqual(await timeline.locator('[role=status] dd').evaluateAll(nodes=>nodes.map(node=>Number(node.getAttribute('data-value')))),[101,50]);
 await page.screenshot({path:join(output,phase+'-history-observed.png'),animations:'disabled'});await page.keyboard.press('Escape');
 const search=form.locator('.qp-history-filter-search input');await search.fill('no-match-native-draft');assert.equal(await history.locator('tbody tr').count(),2);assert.equal(new URLSearchParams(new URL(page.url()).hash.split('?')[1]).has('q'),false);
 const extra=form.locator('.qp-history-extra-filters'),summary=extra.locator('summary');await summary.focus();await page.keyboard.press('Enter');await extra.locator('input[type=text]').fill('no-native-vendor-match');await page.keyboard.press('Escape');assert.equal(await extra.getAttribute('open'),null);assert.equal(await summary.evaluate(el=>document.activeElement===el),true);
 await form.locator('.qp-history-filter-apply').click();await page.waitForFunction(()=>document.querySelector('[data-testid=history-total-tokens]')?.getAttribute('aria-label')==='0');assert.equal(await history.locator('tbody tr').count(),0);
 assert.equal(await timeline.locator('[data-axis-at]').count(),0);assert.equal(await timeline.locator('g[data-bucket-at]').count(),0);
 await form.locator('.qp-history-filter-clear').focus();await page.keyboard.press('Enter');await page.waitForFunction(()=>document.querySelector('[data-testid=history-total-tokens]')?.getAttribute('aria-label')==='151');assert.equal(await history.locator('tbody tr').count(),2);
 const params=new URLSearchParams(new URL(page.url()).hash.split('?')[1]);assert.equal(params.get('range'),'all');assert.equal(params.get('source'),'1');assert.equal(params.get('session_id'),'1');assert.equal(params.has('q'),false);assert.equal(params.has('vendor'),false);assert.equal(await search.evaluate(el=>document.activeElement===el),true);
 historyChecks.push({phase,lang:await page.evaluate(()=>document.documentElement.lang),tokens:151,records:2,unappliedDraft:true,keyboardMoreFilters:true,escapeFocus:true,appliedEmptyQuery:true,clearRestoresDataAndScope:true,singleBucketPointsOnly:true,observedExtent:true,queryStartsAtEpoch:true,firstRecordedAt,firstAxisAt:firstRecordedAt,plottedTokens,exactKeyboardTotals:true,emptyHasNoAxis:true});console.log('Native History filters/observed extent '+phase+' passed');
}
try{
 daemon=spawn(process.execPath,[join(bundle,'scripts/task-entry.cjs'),'--role','daemon','--port',String(port),'--data-dir',data,'--node-exe',process.execPath,'--no-readers'],{cwd:bundle,windowsHide:true,env:{...process.env,ELECTRON_RUN_AS_NODE:undefined},stdio:['ignore','pipe','pipe']});daemon.stdout!.pipe(logs,{end:false});daemon.stderr!.pipe(logs,{end:false});
 await until(async()=>{if(daemon!.exitCode!==null)throw Error('Owned daemon exited '+daemon!.exitCode);if(!existsSync(join(data,'daemon.lock')))return false;try{lock=json(join(data,'daemon.lock'));assert.equal(lock.pid,daemon!.pid);const health=await request('/api/health');return health.ok&&health.scheduler.sources.length===0;}catch{return false;}},'Actual readers-off daemon not ready');
 const facts=await request('/api/usage-events?from=0&to='+Date.now()+'&limit=50');assert.equal(facts.rows.reduce((sum:number,row:any)=>sum+row.total_tokens,0),221);
 let page=await launch();
 await desktop!.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].setContentSize(1672,941));
 if(await page.evaluate(()=>document.documentElement.lang)!=='en'){await page.locator('.qp-tools button').last().click();await page.waitForFunction(()=>document.documentElement.lang==='en');}
 if(await page.locator('.qp-redesign').getAttribute('data-theme')!=='dark')await page.getByRole('button',{name:'Switch color theme',exact:true}).click();
 await checkPaletteLoading(page,'initial');await captureRoutes(page,'initial');await checkProjects(page,'initial');await checkHistoryFilters(page,'initial');await checkCalendar(page,'initial');await checkModelControls(page,'initial');
 await page.goto(base+'/#settings');await page.getByTestId('production-settings').getByRole('button',{name:/THB$/}).click();
 const rate=page.getByRole('textbox',{name:'Rate',exact:true});await rate.fill('37.25');await rate.press('Enter');
 await page.getByRole('spinbutton',{name:'Width (px)',exact:true}).fill('1371');await page.getByRole('spinbutton',{name:'Height (px)',exact:true}).fill('887');
 await until(async()=>existsSync(join(data,'window-size.json'))&&json(join(data,'window-size.json')).width===1371&&json(join(data,'window-size.json')).height===887,'Actual size IPC did not persist');
 const actualSize=await desktop!.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].getSize());assert.deepEqual(actualSize,[1371,887]);
 await page.getByRole('button',{name:'Thai',exact:true}).click();await page.waitForFunction(()=>document.documentElement.lang==='th');
 await page.locator('.qp-tools button').first().click();await page.waitForFunction(()=>localStorage.getItem('quotapulse-theme')==='light');
 const expected=await page.evaluate(()=>({prefs:JSON.parse(localStorage.getItem('quotapulse-prefs')??'{}'),theme:localStorage.getItem('quotapulse-theme'),windowSize:JSON.parse(localStorage.getItem('quotapulse_window_size')??'{}')}));assert.equal(expected.prefs.lang,'th');assert.equal(expected.prefs.currency,'THB');assert.equal(expected.prefs.rate,37.25);
 await stopElectron();page=await launch();
 const restored=await page.evaluate(()=>({prefs:JSON.parse(localStorage.getItem('quotapulse-prefs')??'{}'),theme:localStorage.getItem('quotapulse-theme'),windowSize:JSON.parse(localStorage.getItem('quotapulse_window_size')??'{}')}));assert.deepEqual(restored,expected);
 assert.deepEqual(await desktop!.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].getSize()),[1371,887]);
 await checkPaletteLoading(page,'restored-th-light');await captureRoutes(page,'restored-th-light');await checkProjects(page,'restored-th-light');await checkHistoryFilters(page,'restored-th-light');await checkCalendar(page,'restored-th-light');await checkModelControls(page,'restored-th-light');
 await page.goto(base+'/#sessions?range=all');await page.getByTestId('production-history').waitFor();assert.equal(new URL(page.url()).hash,'#history?range=all');
 await Promise.all(responseChecks);assert.deepEqual(errors,[]);assert.deepEqual(forbidden,[]);
 const event=await desktop!.evaluate(()=>(globalThis as any).reviewNative);assert.deepEqual(event.preloadErrors,[]);assert.deepEqual(event.placementErrors,[]);
 await stopElectron();
 const checked=openDb(join(data,'usage.db'));assert.deepEqual(checked.prepare('SELECT * FROM usage_event ORDER BY id').all(),factsBefore);assert.equal(checked.pragma('integrity_check',{simple:true}),'ok');checked.close();
 assert.deepEqual(inventory(bundle,true),fullBefore,'Unused source bundle changed during test');
 success=true;
 writeFileSync(join(output,'settings.json'),JSON.stringify({expected,restored,actualSize},null,2)+'\n');
}catch(error){failure=String(error);throw error;}finally{
 const cleanup:string[]=[];try{await stopElectron();}catch(error){cleanup.push(String(error));try{await desktop?.close();}catch{}}
 if(daemon&&daemon.exitCode===null&&daemon.signalCode===null){const stopped=once(daemon,'exit');daemon.kill();await Promise.race([stopped,delay(10000).then(()=>{throw Error('Owned daemon stop timed out');})]).catch(error=>cleanup.push(String(error)));}
 logs.end();
 writeFileSync(join(output,'verification.json'),JSON.stringify({status:success&&cleanup.length===0?'passed':'failed',sourceCommit:input.sourceCommit,checkout,bundle,profile,output,productionIndexSha256:indexSha256,buildReceiptSha256:sha(readFileSync(input.buildReceipt)),bundleFiles:Object.keys(fullBefore).length,served,captures,cycles,modelControls,projectChecks,paletteChecks,historyChecks,calendarChecks,errors,forbidden,writes,failure,cleanup,daemonStopped:!!daemon&&(daemon.exitCode!==null||daemon.signalCode!==null),daemonExit:{pid:daemon?.pid,exitCode:daemon?.exitCode,signalCode:daemon?.signalCode},limitations:['actual production windows placed beyond all displays, nonfocusable and absent from taskbar; anti-occlusion flags/background-throttling override and capture reduced motion are test-only; bounded model selection checks explicitly exercise normal/reduced motion','initial content resized by test to1672x941; restored native size1371x887 tested through real Settings/preload/main','same-version Electron restart with explicit storage flush; no installer or two-version upgrade exercised here','two native language/theme combinations; not complete four-combination matrix','synthetic owned DB only; readers/account probes disabled; no physical tray-click/minimize/monitor or resource proof']},null,2)+'\n');
 console.log('Native dashboard review '+(success?'finished':'failed')+': '+output);
 if(cleanup.length)process.exitCode=1;
}


