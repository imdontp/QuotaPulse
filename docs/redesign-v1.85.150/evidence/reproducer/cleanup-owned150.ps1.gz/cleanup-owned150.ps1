param([Parameter(Mandatory=$true)][ValidateSet('standalone','reader')][string]$Stage,[Parameter(Mandatory=$true)][string]$ExpectedTarget)
$ErrorActionPreference='Stop'
. ./scripts/review-profile.ps1
$archiveRecord=Get-Content -LiteralPath tmp/release150/archive.json -Raw | ConvertFrom-Json
$expectedArchive='C:\Users\TH12367283\Projects\QuotaPulse\tmp\worktrees\redesign-validation-v1.85.149\tmp\review-bundles\QuotaPulse-v1.85.149-review150.zip'
if($archiveRecord.archive -ne $expectedArchive -or $archiveRecord.sourceCommit -ne '5eb188edcfe8bddcf545ce952b13d36848daa066'){throw 'Wrong archive provenance'}
Assert-ReviewPlainPath $expectedArchive
if((Get-FileHash -LiteralPath $expectedArchive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $archiveRecord.sha256){throw 'Archive changed'}
$receiptFile=if($Stage -eq 'standalone'){'tmp/release150/standalone-smoke/bundle-verification.json'}else{'tmp/release150/reader-smoke.json'}
$record=Get-Content -LiteralPath $receiptFile -Raw | ConvertFrom-Json
if($record.status -ne 'passed' -or $record.archive -ne $expectedArchive -or $record.archiveSha256 -ne $archiveRecord.sha256){throw 'Wrong owned QA receipt'}
$targetAbsolute=(Resolve-Path -LiteralPath $record.extracted).Path
$expectedAbsolute=[IO.Path]::GetFullPath($ExpectedTarget)
$tempRoot=(Resolve-Path -LiteralPath ([IO.Path]::GetTempPath())).Path.TrimEnd('\')
if($targetAbsolute -ne $expectedAbsolute -or (Split-Path -Parent $targetAbsolute).TrimEnd('\') -ne $tempRoot -or (Split-Path -Leaf $targetAbsolute) -notmatch '^QuotaPulse-review-[a-zA-Z0-9]+$'){throw 'Target is outside the exact owned temporary extraction'}
Assert-ReviewPlainPath $targetAbsolute
if(@(Get-ChildItem -LiteralPath $targetAbsolute -Recurse -Force -Attributes ReparsePoint).Count -ne 0){throw 'Linked entries are not eligible for cleanup'}
if((Get-FileHash -LiteralPath (Join-Path $targetAbsolute 'packages/web/dist/index.html') -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'f9df009691e9ccf99f7c674dfc560c4861cef60273cf327d0c5f46b41c253500'){throw 'Wrong extracted web build'}
$state=Get-Content -LiteralPath (Join-Path $targetAbsolute 'review-data/review-processes.json') -Raw | ConvertFrom-Json
foreach($role in @('daemon','tray')){if(Get-Process -Id $state.$role.pid -ErrorAction SilentlyContinue){throw 'Owned QA process remains alive'}}
$bytes=(Get-ChildItem -LiteralPath $targetAbsolute -Recurse -File -Force | Measure-Object Length -Sum).Sum
$freeBefore=([IO.DriveInfo]::new('C:\')).AvailableFreeSpace
Remove-Item -LiteralPath $targetAbsolute -Recurse -Force
$receipt=@{stage=$Stage;path=$targetAbsolute;bytes=$bytes;recordedProcessesStopped=$true;sourceReceipt=$receiptFile;archive=$expectedArchive;archiveSha256=$archiveRecord.sha256;freeBefore=$freeBefore;freeAfter=([IO.DriveInfo]::new('C:\')).AvailableFreeSpace}
[IO.File]::WriteAllText((Join-Path (Get-Location) ('tmp/release150/cleanup-'+$Stage+'.json')),($receipt|ConvertTo-Json -Depth 6)+"`n",[Text.UTF8Encoding]::new($false))
$receipt|ConvertTo-Json -Depth 6
