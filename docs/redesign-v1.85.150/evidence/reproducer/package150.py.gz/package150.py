from pathlib import Path
import gzip, hashlib, json, sys
out=Path('docs/redesign-v1.85.150');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(name,value):
    path=out/name;path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def copy(src,name,compressed=False):
    path=out/name;path.parent.mkdir(parents=True,exist_ok=True);data=Path(src).read_bytes()
    if not compressed and str(src).endswith('.json'):data=data.replace(b'\r\n',b'\n')
    path.write_bytes(gzip.compress(data,mtime=0) if compressed else data)
summary=load('tmp/release150/summary.json');inputs=load('tmp/release150/inputs.json')
fixture=Path(summary['fixture']);report=load(fixture/'verification.json');archive=summary['archive']
assert report['status']=='passed' and report['sourceCommit']=='5eb188edcfe8bddcf545ce952b13d36848daa066'
assert report['productionIndexSha256']=='f9df009691e9ccf99f7c674dfc560c4861cef60273cf327d0c5f46b41c253500'
assert summary['repositoryTests']==678 and len(report['captures'])==16
assert len(report['historyChecks'])==2 and all(row['singleBucketPointsOnly'] and row['observedExtent'] and row['queryStartsAtEpoch'] and row['plottedTokens']==151 and row['exactKeyboardTotals'] and row['emptyHasNoAxis'] for row in report['historyChecks'])
assert len(report['calendarChecks'])==2 and all(row['exactScope'] and row['tokens']==151 and row['actualDates']==row['expectedDates'] and row['clearedEndIgnored'] for row in report['calendarChecks'])
assert report['daemonStopped'] and report['cleanup']==[] and report['errors']==[] and report['forbidden']==[]
assert archive['allEntryBytesMatch'] and sha(Path(archive['archive']).read_bytes())==archive['sha256']
assert sha(Path(inputs['buildReceipt']).read_bytes())==report['buildReceiptSha256']
for row in report['captures']:
    name=row['phase']+'-'+row['route']+'.png'
    assert sha((fixture/name).read_bytes())==row['sha256'];copy(fixture/name,'images/'+name)
    if not row['paintOraclePixelsExact']:
        raw=fixture/(row['phase']+'-'+row['route']+'-native-attempt-1.png')
        assert sha(raw.read_bytes())==row['nativeCaptureSha256'];copy(raw,'images/native-api/'+name)
for phase in ['initial','restored-th-light']:
    for kind in ['palette-retained','history-observed','calendar-subday']:copy(fixture/(phase+'-'+kind+'.png'),'images/'+phase+'-'+kind+'.png')
for name in ['verification.json','settings.json']:copy(fixture/name,'evidence/native/'+name)
for name in ['summary.json','inputs.json','archive.json','reader-smoke.json']:copy('tmp/release150/'+name,'evidence/'+name)
copy('tmp/release150/standalone-smoke/bundle-verification.json','evidence/standalone-smoke.json')
if Path('tmp/release150/cleanup150.json').exists():copy('tmp/release150/cleanup150.json','evidence/cleanup150.json')
for name in ['reader-ingested.png','reader-incremental.png']:copy('screens/review-readers/'+name,'images/readers/'+name)
for path in Path('tmp/release150/build').iterdir():
    if path.suffix in ['.log','.json']:copy(path,'evidence/build/'+path.name+'.gz',True)
for name in ['prepare150.py','build-review150.ps1','prepare-review150.cjs','archive-review150.ps1','extract-review150.ps1',
    'check-native-review150.mts','check-bundle150.mts','check-reader-archive150.mts','audit-review150.cjs','package150.py','check-viewer150.mjs']:
    copy('tmp/'+name,'evidence/reproducer/'+name+'.gz',True)
if Path('tmp/cleanup-owned150.ps1').exists():copy('tmp/cleanup-owned150.ps1','evidence/reproducer/cleanup-owned150.ps1.gz',True)
for name in ['native','archive','zip-smoke','reader-smoke']:copy('tmp/review150-'+name+'.log','evidence/logs/'+name+'.log.gz',True)
verified=(out/'evidence/viewer.json').exists()
if verified:
    viewer=load(out/'evidence/viewer.json');assert viewer['sourceCommit']==report['sourceCommit'] and viewer['productionIndexSha256']==report['productionIndexSha256'];assert viewer['status']=='passed' and len(viewer['cases'])==16 and viewer['errors']==[]
else:assert '--draft' in sys.argv
write('delivery.json',{'sourceCommit':report['sourceCommit'],'productionIndexSha256':report['productionIndexSha256'],'archive':archive,
    'repositoryTests':678,'nativeCaptures':16,'nativeHistoryChecks':report['historyChecks'],'nativeCalendarChecks':report['calendarChecks'],
    'nativePaletteChecks':report['paletteChecks'],'standaloneSmokeChecks':6,'actualArchiveReaderChecks':6,'reviewPageVerified':verified,'fullGoalComplete':False})
(out/'README.md').write_bytes(f'''# Review150 — runnable source149

[Review ZIP]({archive['archive'].replace(chr(92),'/')}) · [Actual Electron gallery](review.html) · [Observed extent implementation](../redesign-v1.85.145/README.md) · [Single-bucket diagnosis/fix](../redesign-v1.85.146/README.md)

Validated bounded portable delivery of frozen source `{report['sourceCommit']}`. This replaces review147 for testing and includes both History corrections: an all-time chart starting at the first matching recorded timestamp, and observed points without a declining area when there is just one bucket. Complete query/export scope and actual token/money facts remain intact. Source145's native diagnostic build146 was not published as a ZIP after visual inspection exposed the single-bucket defect; this source149 package includes its correction.

## Try it

Extract into a new dedicated folder and run PowerShell there:

```powershell
.\\scripts\\start-review.ps1 -EnableReaders
```

Open http://127.0.0.1:7807/#overview. Explicit `-EnableReaders` enables installed harness/configured quota readers into separate review-data, without importing the original application database. Initial scans may take several minutes. Without the switch, readers/account probes stay off and the fresh profile is empty. Stop with `.\\scripts\\stop-review.ps1` before changing modes. Restart without the switch keeps collected review data but disables collection. The switch applies to the portable launcher; versioned wrappers do not expose it. Pet is disabled. No customer DB, credentials or synthetic fixture DB is packaged. Windows x64 with installed Node ABI127 is required (validated Node22.13.1); Node is external. `-Port` selects another port. No logon task is installed.

Archive: {archive['bytes']} bytes; {archive['entries']} entries. SHA256 `{archive['sha256']}`. Production web index `{report['productionIndexSha256']}`.

## Validation

This archive additionally includes the [source148 calendar correction](../redesign-v1.85.148/README.md) and [source149 SSE canceled-response guard](../redesign-v1.85.149/README.md). [Native sub-day calendar image](images/initial-calendar-subday.png). Two native sub-day calendar checks preserve exact from/to/source/session scope and151 tokens, display the final included date, and ignore a cleared date without navigating to NaN.

All six frozen application-only sparse-checkout build/package steps pass with678 tests (129 daemon,351 web,198 tray), zero failures/skips/cancellations. Matching daemon, web, Electron main/preload, runtime assets and notices are packaged. The unused bundle remains byte-identical after validation.

Actual production Electron main plus the exact sandboxed compiled preload run two cycles: EN/dark and restored TH/light with THB37.25 and1371x887 window preferences. Sixteen dashboard captures cover all eight routes. {summary['servedFiles']} served web assets match the bundle and all{summary['bundleFiles']} runtime files stay unchanged. The owned three-row QA DB retains221 tokens, native/computed/unknown price bases and passes integrity checks. This data is not bundled demo content.

Two native History checks keep the complete epoch-origin query but plot from the first recorded match. They preserve151 tokens/two records, exact101-input/50-output keyboard values, both observed points with no extrapolated area for a single bucket, no date axes for empty matches, unapplied drafts and keyboard filter/clear/source/session scope. Two cold compiled-module palette checks retain query/focus and navigate to monthly Cost. Existing two Projects fact/keyboard and two Models sorting/period/180ms/reduced-motion checks pass. Both native cycles stop cleanly.

Every ZIP entry is byte-verified against the unused bundle. Fresh extraction outside repository dependencies passes six WhatIf/start/stop/preserve/restart checks. A separate fresh extraction passes six opt-in reader lifecycle checks with an owned fake home/Codex log:150→190 tokens, one session through refresh/restart, no prompt fields, original-profile/source sentinels unchanged. Account probes are disabled only in reader QA. No customer logs/credentials are used.

After validation, only the two newly created QA extraction copies were removed manually after exact path/receipt/archive/index checks and confirming their recorded processes were stopped. The cleanup receipt is retained. The executable ZIP, unused source bundle, frozen source and native QA profile remain. This QA-only cleanup is not launcher behavior; normal Stop preserves the user's review data.

## Limits and remaining work

The gallery contains actual Electron page screenshots after DOM readiness, using owned QA data. Separate capturePage bitmap comparisons are diagnostics, not exact-raster passes; non-exact frames are retained. Native windows are beyond physical displays with test-only anti-occlusion/background-throttling settings. Captures use reduced motion except explicit Models motion checks. Actual initial viewport `{json.dumps(summary['firstViewport'])}`; native image `{json.dumps(summary['firstNativeImageSize'])}`. These are two native language/theme combinations, not the full matrix or physical tray/monitor/performance acceptance.

The sub-day calendar defect is corrected and checked natively here; the full three-timezone/DST matrix is separate source148 browser evidence. Source149 deterministically reproduces and corrects a daemon-side canceled-before-handler listener leak and passes the unchanged full integration; the exact historical source145 proxy occurrence lacks connection identities, so this is not a retrospective proof that every old failure had that cause. The forced cancellation regression is daemon/HTTP evidence, not a newly forced native cancellation test. The sparse native Cost fixture does not certify the occupied eight-model case. Original-reference99–100% approval, complete provider/customer/native matrices, installation and two-version migration/rollback remain open. No mask or tolerance change closes a visual gate, and fullGoalComplete remains false. Existing main, origin and prior review ZIPs are preserved.
'''.encode())
routes=list(dict.fromkeys(row['route'] for row in report['captures']));phases=list(dict.fromkeys(row['phase'] for row in report['captures']))
html='''<!doctype html><meta charset="utf-8"><title>Source149 Electron review150</title><style>body{font:14px system-ui;background:#071020;color:#def;margin:20px}select{padding:8px;margin:6px}img{display:block;max-width:100%;border:1px solid #456}a{color:#5cf}</style><h1>Source149 / actual Electron review150</h1><p>Owned QA data. <a href="README.md">Run instructions and limits</a> · <a href="images/initial-history-observed.png">Observed single-bucket History</a> · <a href="images/initial-palette-retained.png">Retained native palette</a> · <a href="images/initial-calendar-subday.png">Native custom dates</a></p><select id="route">'''+''.join('<option'+(' selected' if route=='history' else '')+'>'+route+'</option>' for route in routes)+'''</select><select id="phase">'''+''.join('<option>'+phase+'</option>' for phase in phases)+'''</select><img id="image" alt="Actual production Electron dashboard"><script>const route=document.getElementById('route'),phase=document.getElementById('phase'),frame=document.getElementById('image');function show(){frame.src='images/'+phase.value+'-'+route.value+'.png'}route.onchange=phase.onchange=show;show()</script>'''
(out/'review.html').write_bytes(html.encode())
write('artifact-hashes.json',{p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='artifact-hashes.json'})
print(json.dumps({'artifacts':len(load(out/'artifact-hashes.json')),'archive':archive['archive'],'sha256':archive['sha256'],'viewerVerified':verified}))
