from pathlib import Path
mapping={'release147':'release150','review147':'review150','v1.85.146':'v1.85.149',
 '2fd5353173d5820fbf6407f8548ac76d689e0c6d':'5eb188edcfe8bddcf545ce952b13d36848daa066',
 'bbc7208eeeb1c4f9e4c36fb6f639c7a138447ddb67a5867ebd267c91adc4f240':'f9df009691e9ccf99f7c674dfc560c4861cef60273cf327d0c5f46b41c253500'}
for name in ['build-review147.ps1','prepare-review147.cjs','archive-review147.ps1','extract-review147.ps1',
 'check-bundle147.mts','check-native-review147.mts','check-reader-archive147.mts','audit-review147.cjs','check-viewer147.mjs']:
 s=Path('tmp',name).read_text(encoding='utf-8-sig')
 for before,after in mapping.items():s=s.replace(before,after)
 if name=='audit-review147.cjs':
  s=s.replace('[126,351,198]','[129,351,198]').replace('repositoryTests:675','repositoryTests:678')
  s=s.replace("const preload=sha(","assert.equal(report.calendarChecks.length,2);for(const row of report.calendarChecks){assert.equal(row.exactScope,true);assert.equal(row.tokens,151);assert.equal(row.clearedEndIgnored,true);assert.deepEqual(row.actualDates,row.expectedDates);}\nconst preload=sha(")
  s=s.replace('nativeCaptures:16,modelControlChecks:','nativeCaptures:16,nativeCalendarChecks:report.calendarChecks,modelControlChecks:')
 if name=='check-viewer147.mjs':
  s=s.replace('redesign-v1.85.147','redesign-v1.85.150')
  s=s.replace("const browser=await", "assert.equal(report.sourceCommit,'5eb188edcfe8bddcf545ce952b13d36848daa066');\nconst browser=await")
  s=s.replace("{status:'passed',browser:browser.version(),cases,errors}","{status:'passed',sourceCommit:report.sourceCommit,productionIndexSha256:report.productionIndexSha256,browser:browser.version(),cases,errors}")
 if name=='check-native-review147.mts':
  s=s.replace('historyChecks:any[]=[];','historyChecks:any[]=[],calendarChecks:any[]=[];')
  marker='async function checkHistoryFilters(page:Page,phase:string){'
  fn='''async function checkCalendar(page:Page,phase:string){
 const from=now-120000,to=now;
 const ready=page.waitForResponse(response=>{const url=new URL(response.url());return url.pathname==='/api/history-summary'&&url.searchParams.get('from')===String(from)&&response.ok()});
 await page.goto(base+`/#history?range=custom&from=${from}&to=${to}&source=1&session_id=1`);
 const result=await(await ready).json();assert.equal(result.scope.from,from);assert.equal(result.scope.to,to);assert.equal(result.scope.sourceId,1);assert.equal(result.scope.sessionId,1);assert.equal(result.totals.tokens,151);
 await page.waitForFunction(()=>document.querySelector('[data-testid=history-total-tokens]')?.getAttribute('aria-label')==='151');
 const fields=page.getByTestId('usage-history').locator('input[type=date]'),actualDates=await fields.evaluateAll(nodes=>nodes.map(node=>(node as HTMLInputElement).value));
 const expectedDates=await page.evaluate(({from,to})=>[from,to-1].map(value=>{const date=new Date(value);return`${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`}),{from,to});assert.deepEqual(actualDates,expectedDates);
 const originalUrl=page.url();await fields.nth(1).fill('');assert.equal(page.url(),originalUrl);assert.equal(await fields.nth(1).inputValue(),expectedDates[1]);
 await page.screenshot({path:join(output,phase+'-calendar-subday.png'),animations:'disabled'});
 calendarChecks.push({phase,from,to,actualDates,expectedDates,exactScope:true,tokens:151,clearedEndIgnored:true});console.log('Native custom calendar '+phase+' passed');
}
'''
  assert marker in s;s=s.replace(marker,fn+marker)
  for phase in ['initial','restored-th-light']:
   before=f"await checkHistoryFilters(page,'{phase}');await checkModelControls"
   assert before in s;s=s.replace(before,f"await checkHistoryFilters(page,'{phase}');await checkCalendar(page,'{phase}');await checkModelControls")
  assert 'paletteChecks,historyChecks,errors' in s;s=s.replace('paletteChecks,historyChecks,errors','paletteChecks,historyChecks,calendarChecks,errors')
 Path('tmp',name.replace('147','150')).write_bytes(s.encode())
