from pathlib import Path

root = Path(__file__).resolve().parents[1]
for stem, ext in [('check-archive-rollback', 'ps1'), ('check-archive-rollback', 'cjs'), ('check-rollback-native', 'mts')]:
    source = (root / 'tmp' / f'{stem}225.{ext}').read_text(encoding='utf-8')
    source = source.replace('rollback225', 'rollback231').replace('native225', 'native231')
    if ext == 'cjs':
        source = source.replace('assert.equal(provenance.entries,3161)', 'assert.ok([3161,3163].includes(provenance.entries))')
    destination = root / 'tmp' / f'{stem}231.{ext}'
    assert not destination.exists(), destination
    destination.write_text(source, encoding='utf-8', newline='\n')
source = (root / 'tmp/create-rollback225-provenance.py').read_text(encoding='utf-8')
source = (source.replace('tmp/rollback225', 'tmp/rollback231')
          .replace('docs/redesign-v1.85.218/archive.json', 'docs/redesign-v1.85.224/archive.json')
          .replace('QuotaPulse-v1.85.217-review218.zip', 'QuotaPulse-v1.85.223-review224.zip')
          .replace('tmp/release224/archive.json', 'docs/redesign-v1.85.230/archive.json')
          .replace('QuotaPulse-v1.85.223-review224.zip\')]:', 'QuotaPulse-v1.85.229-review230.zip\')]:')
          .replace("d['entries']==3161", "d['entries'] in (3161,3163)")
          .replace('len(names)==len(set(names))==3161', "len(names)==len(set(names))==d['entries']"))
destination = root / 'tmp/create-rollback231-provenance.py'
assert not destination.exists(), destination
destination.write_text(source, encoding='utf-8', newline='\n')
print('Prepared isolated rollback drivers for review224 and review230')
