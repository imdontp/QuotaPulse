/** Static canonical reference capture. Isolated synthetic DB, compiled application, no user data. */
import assert from 'node:assert/strict';
import { checkLiveTokenFlow } from '../scripts/check-live-token-flow.mts';
import { installBrowserFixedDate } from '../scripts/browser-fixed-date.mjs';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium, type Page, type Request } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import { recordQuotaAlerts } from '../packages/daemon/src/api/queries.js';
const root = fileURLToPath(new URL('..', import.meta.url));
const output = resolve(root, 'tmp/fidelity173/'+(process.env.QP_FIDELITY_PHASE??'before')); 
const referenceRoot = 'C:/Users/TH12367283/Downloads/quotapulse_build_blueprint';
const priorTimezone = process.env.TZ;
process.env.TZ = 'Asia/Bangkok';
mkdirSync(output, { recursive: true });

const fixedNow = Date.parse('2025-05-17T13:42:00.000Z');
// Freeze Date only, keeping real timers/performance for HTTP, browser and cleanup.
// This applies to internal query helpers too, without changing production clocks.
const realDate = globalThis.Date;
globalThis.Date = new Proxy(realDate, {
  construct(target, args) { return Reflect.construct(target, args.length ? args : [fixedNow]); },
  apply() { return new realDate(fixedNow).toString(); },
  get(target, property, receiver) { return property === 'now' ? () => fixedNow : Reflect.get(target, property, receiver); },
});
const db = openDb(':memory:');
db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at,account_key,account_provider,account_display_name,account_state,account_last_success_at)
  VALUES (1,'codex','fixed','/synthetic/nonexistent','Codex fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow}),
    (2,'hermes','fixed','/synthetic/nonexistent','Hermes fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (3,'claude-code','fixed','/synthetic/nonexistent','Claude Code fixture',0,'opencode:go','opencode','OpenCode Go Subscription','active',${fixedNow}),
    (4,'opencode','fixed','/synthetic/nonexistent','OpenCode fixture',0,'openai:subscription','openai','OpenAI Subscription','active',${fixedNow});`);
const referenceProjects = ['QuotaPulse', 'Agent Platform', 'Edge Services', 'Developer Tools', 'Research Lab'];
const referenceModels = [
  { name: 'DeepSeek V4.1', provider: 'deepseek', share: 38 },
  { name: 'GPT-5.x', provider: 'openai', share: 24 },
  { name: 'Claude 3.7', provider: 'anthropic', share: 18 },
  { name: 'Claude 3.5', provider: 'anthropic', share: 11 },
  { name: 'Others', provider: 'openrouter', share: 9 },
  { name: 'GPT-4.1 mini', provider: 'openai', share: 0 },
];
const session = db.prepare('INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (?,?,?,?,?)');
const usage = db.prepare('INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source,cost_input_usd,cost_cached_input_usd,cost_cache_write_usd,cost_output_usd,cost_cache_saving_usd,price_provider) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
// Synthetic catalogue rates for the in-memory visual fixture only. The saved
// amount is derived from the same fresh/cached input components the UI reports.
const fixtureInputUsdPerMillion = 0.0593846153846154, fixtureCachedInputUsdPerMillion = 0.004, fixtureOutputUsdPerMillion = 0.004;
for (let index = 0; index < 12; index++) {
  // Keep the reference map's 4 Codex, 2 Claude Code, 6 Hermes, 0 OpenCode
  // recent-session distribution while preserving the same 12 sessions.
  const source = [1, 1, 1, 1, 3, 3, 2, 2, 2, 2, 2, 2][index]!;
  session.run(index + 1, source, `fixture-session-${index}`, referenceProjects[0], fixedNow - 10_000);
  const model = referenceModels[index % referenceModels.length]!;
  const totalTokens = model.share === 0 ? 1 : model.share * 721_000_000 / 600;
  for (let call = 0; call < 3; call++) {
    const inputShare = [.6, .65, .7][(index + call) % 3]!;
    const inputTokens = totalTokens * inputShare * .58, cachedInputTokens = totalTokens * inputShare * .42;
    const outputTokens = totalTokens * (1 - inputShare);
    const costSource = index === 0 ? 'native' : 'computed';
    const inputUsd = inputTokens / 1_000_000 * fixtureInputUsdPerMillion;
    const cachedInputUsd = cachedInputTokens / 1_000_000 * fixtureCachedInputUsdPerMillion;
    const outputUsd = outputTokens / 1_000_000 * fixtureOutputUsdPerMillion;
    const cacheSavingUsd = cachedInputTokens / 1_000_000 * (fixtureInputUsdPerMillion - fixtureCachedInputUsdPerMillion);
    // Keep each session's latest record within four minutes, then spread older calls across the visible 30-minute interval.
    const ageMs = call === 0 ? 15_000 + index * 20_000 : source === 2
      ? 300_000 + index * 120_000 + (call === 2 ? 30_000 : 0)
      : 300_000 + index * 240_000 + (call === 2 ? 90_000 : 0);
    const recordedAt = fixedNow - ageMs;
    usage.run(source, index + 1, `fixed-${index}-${call}`, recordedAt, model.name, model.provider,
      inputTokens, cachedInputTokens, outputTokens, totalTokens, call + 1,
      costSource === 'native' ? (index + 1) / 100 : inputUsd + cachedInputUsd + outputUsd, costSource,
      costSource === 'native' ? null : inputUsd, costSource === 'native' ? null : cachedInputUsd,
      costSource === 'native' ? null : 0, costSource === 'native' ? null : outputUsd,
      costSource === 'native' ? null : cacheSavingUsd, costSource === 'native' ? null : model.provider);
  }
}
// A stale recorded OpenCode route keeps the concept's zero-active-session edge
// visible without manufacturing a provider relationship or changing live counts.
const openCodeAt = fixedNow - 10 * 60_000;
session.run(13, 4, 'fixture-opencode-quota-pulse', referenceProjects[0], openCodeAt);
usage.run(4, 13, 'fixed-opencode-route', openCodeAt, 'DeepSeek V4.1', 'deepseek', 1, 0, 0, 1, 1,
  null, 'unknown', null, null, null, null, null, null);
// The monthly concept is focused on QuotaPulse while the machine-wide quick
// stats still report all five named projects. Keep four small monthly records
// for the other projects, outside the recent-session window.
for (let index = 1; index < referenceProjects.length; index++) {
  const id = 100 + index, source = [1, 3, 4, 2][index - 1]!;
  const model = referenceModels[index - 1]!;
  const at = fixedNow - 10 * 60_000;
  session.run(id, source, `fixture-project-${index}`, referenceProjects[index], at);
  const inputUsd = fixtureInputUsdPerMillion / 1_000_000;
  usage.run(source, id, `fixture-project-usage-${index}`, at, model.name, model.provider, 1, 0, 0, 1, 1,
    inputUsd, 'computed', inputUsd, 0, 0, 0, 0, model.provider);
}
// Values below the old visual minimum catch inflated nonzero bars in both charts.
const tinyUsage = db.prepare("INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,cached_input_tokens,output_tokens,total_tokens,call_count,cost_usd,cost_source) VALUES (1,1,?,?,'DeepSeek V4.1','deepseek',1,0,0,1,1,0,'computed')");
tinyUsage.run('fixed-tiny-minute', fixedNow - 15 * 60_000);
tinyUsage.run('fixed-tiny-day', fixedNow - 3 * 86_400_000);
const quota = db.prepare('INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin) VALUES (?,?,?,?,?,?,?,?)');
const addQuotaSample = (sourceId: number, window: string, percent: number | null, resetAt: number | null, observedAt: number) => quota.run(sourceId, window, percent, resetAt, observedAt, observedAt, observedAt, 'fixed-fixture');
// Complete history must include older reset periods, nulls and more than eight
// readings per period, without changing the latest live quota/default selection.
for (let segment = 0; segment < 4; segment++) for (let index = 0; index < 12; index++) {
  const at = fixedNow - (5 - segment) * 3_600_000 + index * 60_000;
  addQuotaSample(1, '5h', index === 4 ? null : index === 1 ? 0.5 : index * 8, segment === 0 ? null : fixedNow - (4 - segment) * 3_600_000, at);
}
addQuotaSample(1, '5h', 38, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 5 * 60_000);
addQuotaSample(1, '5h', 83, fixedNow + (2 * 60 + 17) * 60_000, fixedNow - 30_000);
addQuotaSample(1, 'weekly', 62, fixedNow + (3 * 24 + 5) * 3_600_000, fixedNow - 30_000);
const monthlyReset = fixedNow + (6 * 24 + 2) * 3_600_000;
addQuotaSample(1, 'monthly', 59, monthlyReset, fixedNow - 48 * 3_600_000);
addQuotaSample(1, 'monthly', 65.5, monthlyReset, fixedNow - 24 * 3_600_000);
addQuotaSample(1, 'monthly', 72, monthlyReset, fixedNow - 30_000);
addQuotaSample(2, 'monthly', 58, fixedNow + (12 * 24 + 6) * 3_600_000, fixedNow - 30_000);
addQuotaSample(2, 'daily', 34, fixedNow + (7 * 60 + 18) * 60_000, fixedNow - 30_000);
recordQuotaAlerts(db, fixedNow);
const scheduler = new Scheduler(db, [], { pollMs: 1_000_000, detectMs: 1_000_000 });
const webRoot = resolve(process.env.QP_FIDELITY_WEB_ROOT ?? resolve(root, 'packages/web/dist'));
const daemon = buildServer(db, scheduler, { token: 'stable-capture-test', port: 7816, webRoot });
let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;
const sha = (bytes: Buffer) => createHash('sha256').update(bytes).digest('hex');
const indexPath = resolve(webRoot, 'index.html');
const productionIndexSha256 = sha(readFileSync(indexPath));
const rendererArgs: string[] = [];
const referenceManifest = JSON.parse(readFileSync(resolve(referenceRoot, 'reference_manifest.json'), 'utf8'));
const allTargets = { overview: '.qp-activity-item', live: '.qp-live-chart', projects: '.qp-project-trend', models: '.qp-model-trend', history: '[data-testid="usage-history"] tbody tr', alerts: '.qp-quota-point', providers: '.qp-provider-health tbody tr', cost: '.qp-cost-chart' };
const targets=Object.fromEntries(Object.entries(allTargets).filter(([name])=>!process.env.QP_FIDELITY_ONLY||name===process.env.QP_FIDELITY_ONLY));
const results: unknown[] = [];
try {
  await daemon.listen({ host: '127.0.0.1', port: 7816 });
  browser = await chromium.launch({ channel: 'chrome', headless: true, args: rendererArgs });
  for (const [routeName, readySelector] of Object.entries(targets)) {
    
    const entry = referenceManifest.references.find((entry: { file: string }) => entry.file === `refs/${routeName}.png`);
    assert.ok(entry, routeName);
    const reference = readFileSync(resolve(referenceRoot, entry.file));
    assert.equal(sha(reference), entry.sha256, `${routeName} original reference hash`);
    assert.equal(reference.readUInt32BE(16), entry.width); assert.equal(reference.readUInt32BE(20), entry.height);
    const context = await browser.newContext({ viewport: { width: entry.width, height: entry.height }, reducedMotion: 'reduce', deviceScaleFactor: 1, timezoneId: 'Asia/Bangkok', colorScheme: 'dark' });
    const page = await context.newPage();
    page.setDefaultTimeout(20000);
    const errors: string[] = [], forbidden: string[] = [], pending = new Set<Request>();
    let streams = 0;
    const modelReads:Promise<unknown>[]=[];
    page.on('response',response=>{const url=new URL(response.url());if(url.pathname==='/api/models'&&url.searchParams.get('detailed')==='1'&&response.status()===200)modelReads.push(response.body().then(bytes=>{const data=JSON.parse(bytes.toString());return{url:url.pathname+url.search,bytes:bytes.length,breakdown:data.breakdown??null,hasRows:Object.hasOwn(data,'rows'),groups:data.groups.length,tokens:data.totals.tokens};}));});
    page.on('pageerror', error => errors.push(error.message));
    page.on('response', response => { if (response.status() >= 400) errors.push(`${response.status()} ${new URL(response.url()).pathname}`); });
    page.on('request', request => {
      const path = new URL(request.url()).pathname;
      if (path.includes('/events/stream')) streams++;
      else if (path.startsWith('/api/')) pending.add(request);
    });
    page.on('requestfinished', request => pending.delete(request)); page.on('requestfailed', request => pending.delete(request));
    await page.route('**/*', route => {
      const request = route.request(), url = new URL(request.url());
      const readPost = request.method() === 'POST' && url.pathname === '/api/model-row-trends';
      if (url.origin !== 'http://127.0.0.1:7816' || url.pathname.startsWith('/api/') && request.method() !== 'GET' && !readPost) {
        forbidden.push(`${request.method()} ${url.origin}${url.pathname}`); return route.abort();
      }
      return route.continue();
    });
    const taskLang = process.env.QP_LIVE183_LANG ?? 'en', taskTheme = process.env.QP_LIVE183_THEME ?? 'dark';
    await page.addInitScript(({lang,theme}) => {
      (window as unknown as { __QUOTAPULSE_TOKEN__: string }).__QUOTAPULSE_TOKEN__ = 'stable-capture-test';
      localStorage.setItem('quotapulse-prefs', JSON.stringify({ lang, currency: 'USD', rate: 1, hiddenSubscriptions: [] }));
      localStorage.setItem('quotapulse-theme', theme);
    }, {lang:taskLang,theme:taskTheme});
    await installBrowserFixedDate(page, fixedNow);
    await page.goto(`http://127.0.0.1:7816/#${routeName}${routeName === 'cost' ? '?range=month' : ''}`, { waitUntil: 'domcontentloaded' });
    try { await page.getByTestId(`production-${routeName}`).waitFor(); await page.locator(readySelector).first().waitFor(); }
    catch(error){writeFileSync(resolve(output,'ready-failure.json'),JSON.stringify({route:routeName,index:productionIndexSha256,webRoot,errors,forbidden,body:await page.locator('body').innerText()},null,2));await page.screenshot({path:resolve(output,'ready-failure.png')});throw error;}
    await page.waitForFunction(() => /^\d[\d,]*$/.test(document.querySelector('[data-stat=models]')?.textContent ?? ''));
    if (routeName === 'history') await page.locator('[data-history-detail-rail]').waitFor();
    await page.evaluate(() => document.fonts.ready);
    const deadline = performance.now() + 30000; let idle = 0;
    while (idle < 12) { assert.ok(performance.now() < deadline, `${routeName} API did not settle`); await page.waitForTimeout(40); idle = pending.size === 0 ? idle + 1 : 0; }
    await page.evaluate(() => { document.activeElement instanceof HTMLElement && document.activeElement.blur(); window.scrollTo(0, 0); document.querySelector('.qp-sidebar')!.scrollTop = 0; });
    await page.mouse.move(0, 0); await page.waitForTimeout(150);
    const geometry = await page.evaluate(() => {
      const main = document.querySelector('.qp-redesign main')!;
      const nav = document.querySelector('.qp-sidebar nav')!;
      return {
        viewport: { width: innerWidth, height: innerHeight }, pageOverflow: document.documentElement.scrollWidth > innerWidth,
        main: main.getBoundingClientRect().toJSON(), sidebar: document.querySelector('.qp-sidebar')!.getBoundingClientRect().toJSON(), quickStats: document.querySelector('.qp-quick-stats')!.getBoundingClientRect().toJSON(),
        moreOpen: document.querySelector('.qp-nav-more')?.hasAttribute('open') ?? false, visibleNavigation: [...document.querySelectorAll('.qp-sidebar nav a')].filter(node => getComputedStyle(node).visibility !== 'hidden' && getComputedStyle(node).display !== 'none').map(node => node.getAttribute('href')),
        mainRegions: [...main.children].map(element => ({ tag: element.tagName, className: element.className, ...element.getBoundingClientRect().toJSON() })),
        navigationOrder: [...nav.children].flatMap(element => element.matches('.qp-nav-secondary') ? [element.querySelector(':scope > a span')!.textContent!.trim()] : element.tagName === 'A' ? [element.querySelector('span')!.textContent!.trim()] : []),
        headings: [...main.querySelectorAll('h1,h2')].map(element => ({ text: element.textContent, ...element.getBoundingClientRect().toJSON(), fontSize: getComputedStyle(element).fontSize, fontWeight: getComputedStyle(element).fontWeight })),
      };
    });
    assert.equal(geometry.pageOverflow, false, `${routeName} page overflow`); assert.equal(geometry.moreOpen, false);
    if(routeName==='overview'){
      const rows=await page.locator('.qp-quota').evaluateAll(elements=>elements.map(element=>{const fill=element.querySelector('.qp-bar>span')!;return{owner:element.getAttribute('data-owner'),window:element.getAttribute('data-window'),text:element.textContent,aria:element.getAttribute('aria-label'),selected:element.getAttribute('aria-pressed'),stale:element.getAttribute('data-stale'),rect:element.getBoundingClientRect().toJSON(),fillRect:fill.getBoundingClientRect().toJSON(),fillStyle:fill.getAttribute('style'),background:getComputedStyle(fill).backgroundImage,numberColor:getComputedStyle(element.querySelector('.qp-quota-number strong')!).color}}));
      writeFileSync(resolve(output,'quota-rows.json'),JSON.stringify(rows,null,2));
    }
    if(routeName==='live'){
      const rows=await page.locator('.qp-live-feed li').evaluateAll(elements=>elements.map(element=>({identity:element.getAttribute('data-live-record'),grain:element.getAttribute('data-grain'),text:element.textContent,rect:element.getBoundingClientRect().toJSON(),children:Array.from(element.children).map(child=>({tag:child.tagName,text:child.textContent,title:child.getAttribute('title'),dateTime:child.getAttribute('datetime'),rect:child.getBoundingClientRect().toJSON()}))})));
      writeFileSync(resolve(output,'feed-rows.json'),JSON.stringify(rows,null,2));
    }
    if(routeName==='live'){
      const rows=await page.locator('.qp-live-matrix-row').evaluateAll(elements=>elements.map(element=>{const label=element.querySelector('.qp-live-matrix-label')!,strip=element.querySelector('.qp-live-minute-strip')!,total=element.querySelector('.qp-live-matrix-total')!;return {key:element.getAttribute('data-pair-key'),callRecords:element.getAttribute('data-call-records'),aggregateRecords:element.getAttribute('data-aggregate-records'),unknownRecords:element.getAttribute('data-unknown-records'),label:label.textContent,exactTotal:total.querySelector('span')!.getAttribute('aria-label'),rowRect:element.getBoundingClientRect().toJSON(),labelRect:label.getBoundingClientRect().toJSON(),stripRect:strip.getBoundingClientRect().toJSON(),totalRect:total.getBoundingClientRect().toJSON(),cells:Array.from(strip.children).map(cell=>({at:cell.getAttribute('data-at'),state:cell.getAttribute('data-state'),tokens:cell.getAttribute('data-tokens'),records:cell.getAttribute('data-records'),calls:cell.getAttribute('data-calls'),partial:cell.getAttribute('data-partial'),intensity:(cell as HTMLElement).style.getPropertyValue('--qp-minute-intensity'),rect:cell.getBoundingClientRect().toJSON(),background:getComputedStyle(cell).backgroundColor}))};}));
      writeFileSync(resolve(output,'matrix-rows.json'),JSON.stringify(rows,null,2));
    }
    const marks=await page.locator('svg[data-dashboard-harness],svg[data-subscription-mark]').evaluateAll(nodes=>nodes.map(node=>{const slot=node.closest('.qp-provider-icon,.qp-quota-brand,.qp-node-icon,.qp-project-identity-mark,.qp-history-detail-identity>i')??node;return{harness:node.getAttribute('data-dashboard-harness'),owner:node.getAttribute('data-subscription-mark'),rect:node.getBoundingClientRect().toJSON(),slot:slot.getBoundingClientRect().toJSON()}}));
    writeFileSync(resolve(output,routeName+'-marks.json'),JSON.stringify(marks,null,2));
    if(routeName==='history'){
      const density=await page.locator('.qp-history-table').evaluate(node=>({clientWidth:node.clientWidth,scrollWidth:node.scrollWidth,rows:[...node.querySelectorAll('tbody tr')].slice(0,10).map(row=>({height:row.getBoundingClientRect().height,bottom:row.getBoundingClientRect().bottom}))}));
      writeFileSync(resolve(output,'history-table-density.json'),JSON.stringify(density,null,2)+'\n');
      assert.ok(density.scrollWidth<=density.clientWidth+1,'Reference-width History columns must fit without horizontal scrolling');
      assert.equal(density.rows.length,10);assert.ok(density.rows.every(row=>row.height<=34&&row.bottom<=entry.height),'First ten History rows must retain reference viewport density');
    }
    if(routeName==='models'){
      const table=await page.locator('.qp-model-table-wrap table').evaluate(node=>({width:node.getBoundingClientRect().width,scrollWidth:node.scrollWidth,wrapperWidth:node.parentElement!.clientWidth,rows:[...node.querySelectorAll('tbody tr')].map(row=>({rect:row.getBoundingClientRect().toJSON(),ratios:[...row.querySelectorAll('.qp-model-ratio')].map(ratio=>({kind:ratio.getAttribute('data-ratio-kind'),width:ratio.getBoundingClientRect().width,height:ratio.getBoundingClientRect().height,track:ratio.querySelector('.qp-bar')!.getBoundingClientRect().toJSON(),color:getComputedStyle(ratio.querySelector('.qp-bar>span')!).backgroundImage}))}))}));
      writeFileSync(resolve(output,'models-table.json'),JSON.stringify(table,null,2)+'\n');
      assert.ok(table.width<=table.wrapperWidth+1,'Models reference-width columns must fit their viewport');assert.ok(table.rows.every(row=>row.rect.height===37),'Reference model rows must retain their37px density');
    }
    const navPaint=await page.locator('.qp-sidebar .qp-nav-active').evaluateAll(nodes=>nodes.map(node=>{const css=getComputedStyle(node),rim=getComputedStyle(node,'::before');return{href:node.getAttribute('href'),aria:node.getAttribute('aria-current'),rect:node.getBoundingClientRect().toJSON(),background:css.background,border:css.border,color:css.color,rim:{background:rim.background,rect:{width:rim.width,top:rim.top,left:rim.left}}}}));
    writeFileSync(resolve(output,routeName+'-nav-paint.json'),JSON.stringify(navPaint,null,2)+'\n');
    const trendQuery = await daemon.inject({method:'GET',url:`/api/trend?bucket=minute&group_by=none&from=${fixedNow-1_800_000}&to=${fixedNow+1}`,headers:{'x-quotapulse-token':'stable-capture-test'}});
    assert.equal(trendQuery.statusCode,200);
    const flowEvidence=await checkLiveTokenFlow(page,trendQuery.json(),taskLang,taskTheme,pending,output);
    writeFileSync(resolve(output,'flow-evidence.json'),JSON.stringify(flowEvidence,null,2)+'\n');
    const first = await page.screenshot({ path: resolve(output, `${routeName}.png`), animations: 'disabled' });
    await page.waitForTimeout(150);
    const repeat = await page.screenshot({ path: resolve(output, `${routeName}-repeat.png`), animations: 'disabled' });
    assert.deepEqual(errors, [], `${routeName} browser errors`); assert.deepEqual(forbidden, [], `${routeName} forbidden requests`);
    results.push({ route: routeName, viewport: { width: entry.width, height: entry.height }, referenceSha256: entry.sha256, sha256: sha(first), repeatSha256: sha(repeat), repeatIdentical: first.equals(repeat), geometry, errors, forbidden, totalStreamRequests: streams });
    console.log(`Captured ${routeName} ${entry.width}x${entry.height}; repeat identical=${first.equals(repeat)}`);

    if(routeName==='live'){
      const liveMarks=await page.locator('.qp-heading-reference-svg--live').evaluateAll(nodes=>nodes.map(node=>({rect:node.getBoundingClientRect().toJSON(),gradient:node.querySelector('radialGradient')?.id,fill:node.querySelector('circle[fill^="url"]')?.getAttribute('fill')})));
      assert.equal(liveMarks.length,2);assert.equal(new Set(liveMarks.map(m=>m.gradient)).size,2);assert.ok(liveMarks.every(m=>m.fill===`url(#${m.gradient})`));
      writeFileSync(resolve(output,'live-heading-marks.json'),JSON.stringify(liveMarks,null,2)+'\n');
    }
    const headingGeometry=await page.locator('main h1,main h2,main h3,.qp-overview-heading-title,.qp-section-heading-title').evaluateAll(elements=>elements.map(element=>{
      const css=getComputedStyle(element);const ranges=[];for(const child of element.childNodes){if(child.nodeType!==Node.TEXT_NODE||!child.textContent?.trim())continue;const range=document.createRange();range.selectNodeContents(child);ranges.push(...[...range.getClientRects()].map(rect=>rect.toJSON()));}
      return {text:element.textContent,className:element.className,tag:element.tagName,rect:element.getBoundingClientRect().toJSON(),ranges,font:css.font,tracking:css.letterSpacing,color:css.color,shadow:css.textShadow,transform:css.transform};
    }));
    writeFileSync(resolve(output,routeName+'-heading-geometry.json'),JSON.stringify(headingGeometry,null,2));
    writeFileSync(resolve(output,routeName+'-model-requests.json'),JSON.stringify(await Promise.all(modelReads),null,2));
    if(routeName==='live'){
      const disclosures=[];
      for(const [rootSelector,bodySelector] of [['.qp-live-session-note','.qp-live-session-note>p'],['.qp-live-matrix-note','.qp-live-matrix-explanation']]){
        const summary=page.locator(rootSelector+'>summary');await summary.focus();await page.keyboard.press('Enter');await page.locator(bodySelector).waitFor();
        const paint=await page.locator(bodySelector).evaluate(el=>{const r=el.getBoundingClientRect();const x=Math.min(innerWidth-1,Math.max(0,r.left+r.width/2)),y=Math.min(innerHeight-1,Math.max(0,r.top+Math.min(12,r.height/2)));const hit=document.elementFromPoint(x,y);return{rect:r.toJSON(),visibleHit:!!hit&&(hit===el||el.contains(hit)),insideViewport:r.left>=0&&r.right<=innerWidth&&r.top>=0&&r.bottom<=innerHeight};});
        assert.ok(paint.visibleHit,rootSelector+' disclosure paints over underlying content');assert.ok(paint.insideViewport,rootSelector+' disclosure fits viewport');
        await summary.focus();await page.keyboard.press('Space');assert.equal(await page.locator(rootSelector).getAttribute('open'),null);assert.equal(await summary.evaluate(el=>document.activeElement===el),true);disclosures.push({rootSelector,...paint,keyboardToggle:true});
      }
      writeFileSync(resolve(output,'live-disclosures.json'),JSON.stringify(disclosures,null,2)+'\n');
      const hitTargets=await page.locator('.qp-live-session-tools button,.qp-live-session-tools input,.qp-live-session-tools summary,.qp-live-feed-tools button,.qp-live-feed-tools a,.qp-live-matrix-heading summary').evaluateAll(nodes=>nodes.map(el=>{const r=el.getBoundingClientRect();const hit=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return {tag:el.tagName,text:el.textContent,rect:r.toJSON(),hit:!!hit&&(el===hit||el.contains(hit))};}));
      assert.ok(hitTargets.length>=10);assert.ok(hitTargets.every(t=>t.hit),'Moved Live toolbar hit targets remain reachable');assert.deepEqual(errors,[]);assert.deepEqual(forbidden,[]);
      writeFileSync(resolve(output,'live-hit-targets.json'),JSON.stringify(hitTargets,null,2)+'\n');

    }
    await context.close();
  }
  assert.equal(sha(readFileSync(indexPath)), productionIndexSha256, 'Build changed while capturing');
  writeFileSync(resolve(output, 'verification.json'), JSON.stringify({ productionIndexSha256, browser: browser.version(), language: process.env.QP_LIVE183_LANG ?? 'en', theme: process.env.QP_LIVE183_THEME ?? 'dark', deviceScaleFactor: 1, reducedMotion: 'reduce', rendererArgs, fixture: 'same isolated in-memory synthetic fixture as v1.85.95', scope: 'Current compiled application screenshots and geometry; unapproved concept parity', results }, null, 2));
} finally { await browser?.close(); await daemon.close(); db.close(); globalThis.Date = realDate; process.env.TZ = priorTimezone; }
