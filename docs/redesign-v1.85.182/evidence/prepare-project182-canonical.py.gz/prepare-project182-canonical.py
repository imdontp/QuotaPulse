from pathlib import Path
root = Path(__file__).resolve().parents[1]
code = (root/'tmp/capture-project117.mts').read_text(encoding='utf-8')
code = code.replace("'tmp/project117/'", "'tmp/project182-canonical/'").replace('QUOTAPULSE_PROJECT_PHASE','QUOTAPULSE_PROJECT182_PHASE')
code = code.replace("document.querySelector('.qp-nav-more')!.hasAttribute('open')", "document.querySelector('.qp-nav-more')?.hasAttribute('open') ?? false")
(root/'tmp/capture-project182-canonical.mts').write_text(code,encoding='utf-8',newline='\n')
