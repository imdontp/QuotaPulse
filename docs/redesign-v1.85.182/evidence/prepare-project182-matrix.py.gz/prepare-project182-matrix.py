from pathlib import Path
root = Path(__file__).resolve().parents[1]
code = (root/'tmp/capture-project182.mts').read_text(encoding='utf-8')
code = code.replace('tmp/project182/', 'tmp/project182-matrix/')
code = code.replace('assert.equal(cardTrends.length,5)', 'assert.equal(cardTrends.length,6)')
anchor = 'const scheduler = new Scheduler(db, [], { pollMs: 1_000_000, detectMs: 1_000_000 });'
assert code.count(anchor) == 1
code = code.replace(anchor, '''session.run(250,1,'fixture-zero-project','Zero synthetic',fixedNow-1000);
projectDaily.run(1,250,'project182-zero',fixedNow-1000,'DeepSeek V4.1','deepseek',0,0,0,1,'unknown');
''' + anchor)
anchor = '    await context.close();'
assert code.count(anchor) == 1
extra = '''    const month = new Date(fixedNow); month.setDate(1); month.setHours(0,0,0,0);
    const query = new URLSearchParams({detailed:'1',trends:'1',from:String(month.getTime()),to:String(fixedNow+1)});
    const response = await daemon.inject({method:'GET',url:`/api/projects?${query}`,headers:{'x-quotapulse-token':'stable-capture-test'}});
    assert.equal(response.statusCode,200);const data=JSON.parse(response.body);
    const cases=[];
    for(const theme of ['dark','light']) for(const width of [390,900,1280,1535,1536,1672]) {
      await page.setViewportSize({width,height:941});
      await page.locator('[data-testid=production-projects]').evaluate((e,t)=>e.setAttribute('data-theme',t),theme);
      await page.waitForTimeout(50);
      const cards=page.locator('.qp-project-card');assert.equal(await cards.count(),6);
      for(const group of data.groups) {
        const card=cards.filter({has:page.locator('.qp-project-card-identity>strong',{hasText:group.key})});assert.equal(await card.count(),1);
        const spark=card.locator('.qp-project-spark');const values=await spark.locator(':scope>circle').evaluateAll(nodes=>nodes.map(c=>({at:Number(c.getAttribute('data-at')),value:Number(c.getAttribute('data-value'))})));
        const expected=Array.from({length:Math.ceil((data.scope.to-data.scope.from)/data.trends.bucketMs)},(_,i)=>{const at=data.scope.from+i*data.trends.bucketMs;return{at,value:data.trends.points.find((p:any)=>p.project===group.key&&p.start===at)?.tokens??0}});
        assert.deepEqual(values,expected);assert.equal(values.reduce((n,p)=>n+p.value,0),group.tokens);
        const style=await spark.evaluate(e=>{const stops=e.querySelectorAll('linearGradient stop'),last=e.querySelector('circle:last-of-type')!;return{opacity:getComputedStyle(stops[0]!).stopOpacity,color:getComputedStyle(stops[0]!).stopColor,stroke:getComputedStyle(e.querySelector('.qp-observed-line')!).stroke,r:getComputedStyle(last).r,zeroYs:[...e.querySelectorAll(':scope>circle')].map(c=>c.getAttribute('cy'))}});
        const applies=theme==='dark'&&width>=1536;assert.equal(style.opacity,applies?'0.48':'0.28');assert.equal(style.r,applies?'8px':'2px');
        if(applies)assert.equal(style.color,style.stroke);
        if(group.key==='Zero synthetic')assert.ok(style.zeroYs.every(y=>y==='94'));
      }
      assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
      cases.push({theme,width,cards:data.groups.length,actualDataMatched:true,zeroBaseline:true});
    }
    writeFileSync(resolve(output,'matrix.json'),JSON.stringify({cases},null,2)+'\\n');
    console.log(`Project trend paint and data passed ${cases.length} responsive cases.`);
'''
code = code.replace(anchor,extra+anchor)
(root/'tmp/check-project182-matrix.mts').write_text(code,encoding='utf-8',newline='\n')
print('Prepared responsive project trend and zero-data checks')
