from pathlib import Path
root = Path(__file__).resolve().parents[1]
code = (root / 'tmp/capture-project117.mts').read_text(encoding='utf-8')
code = code.replace("'tmp/project117/'", "'tmp/project182/'").replace('QUOTAPULSE_PROJECT_PHASE', 'QUOTAPULSE_PROJECT182_PHASE')
code = code.replace("document.querySelector('.qp-nav-more')!.hasAttribute('open')", "document.querySelector('.qp-nav-more')?.hasAttribute('open') ?? false")
code = code.replace("same isolated in-memory synthetic fixture as v1.85.95", "isolated synthetic fixture with additional distributed project usage")
anchor = 'const scheduler = new Scheduler(db, [], { pollMs: 1_000_000, detectMs: 1_000_000 });'
assert code.count(anchor) == 1
addition = '''// Additional explicitly synthetic daily usage exposes real filled areas on each card.
const projectDaily = db.prepare("INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,input_tokens,output_tokens,total_tokens,call_count,cost_source) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
for (let project = 0; project < 5; project++) for (let day = 1; day <= 14; day++) {
  const sessionId = project === 0 ? 1 : 100 + project;
  const sourceId = project === 0 ? 1 : [1,3,4,2][project-1]!;
  const total = (15 + ((day * 7 + project * 11) % 31)) * (project === 0 ? 100000 : 1000);
  projectDaily.run(sourceId,sessionId,`project182-${project}-${day}`,fixedNow-day*86_400_000,'DeepSeek V4.1','deepseek',total,0,total,1,'unknown');
}
'''
code = code.replace(anchor, addition + anchor)
anchor = '    const first = await page.screenshot('
assert code.count(anchor) == 1
probe = '''    const cardTrends = await page.locator('.qp-project-card').evaluateAll(cards=>cards.map(card=>{
      const spark=card.querySelector<SVGSVGElement>('.qp-project-spark')!;
      return {name:card.querySelector('.qp-project-card-identity strong')?.textContent,tone:card.getAttribute('data-tone'),rect:spark.getBoundingClientRect().toJSON(),points:[...spark.querySelectorAll('circle[data-value]')].map(c=>({at:c.getAttribute('data-at'),value:c.getAttribute('data-value'),cx:c.getAttribute('cx'),cy:c.getAttribute('cy')})),polygons:[...spark.querySelectorAll('polygon')].map(p=>({points:p.getAttribute('points'),fill:p.getAttribute('fill')})),colors:[...spark.querySelectorAll('linearGradient stop')].map(s=>getComputedStyle(s).stopColor),path:spark.querySelector('.qp-observed-line')?.getAttribute('points')};
    }));
    assert.equal(cardTrends.length,5);assert.ok(cardTrends.every(card=>card.points.length>=15&&card.polygons.length>0));
    writeFileSync(resolve(output,'card-trends.json'),JSON.stringify(cardTrends,null,2)+'\\n');
'''
code = code.replace(anchor, probe + anchor)
(root / 'tmp/capture-project182.mts').write_text(code, encoding='utf-8', newline='\n')
print('Prepared isolated, distributed project-trend capture')
