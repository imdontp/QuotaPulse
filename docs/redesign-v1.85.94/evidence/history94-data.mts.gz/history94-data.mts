/** Real HTTP + in-memory SQLite E2E. Never opens the user's usage database. */
import assert from 'node:assert/strict';
import { mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer } from 'vite';
import { chromium } from 'playwright';
import { openDb } from '../packages/daemon/src/db/index.js';
import { buildServer } from '../packages/daemon/src/api/server.js';
import { recordQuotaAlerts } from '../packages/daemon/src/api/queries.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import { en as englishMessages } from '../packages/web/src/i18n/en.ts';
import { th as thaiMessages } from '../packages/web/src/i18n/th.ts';
import { checkAlertsLayout } from './check-alerts-layout.mts';
import type { Overview } from '../packages/web/src/api.ts';

const root = fileURLToPath(new URL('..', import.meta.url));
const output = resolve(root, 'tmp/history94-data');
mkdirSync(output, { recursive: true });
for (const manifest of ['verification.json', 'cost-route-compatibility.json']) rmSync(resolve(output, manifest), { force: true });
const db = openDb(':memory:');
const now = Date.now();
db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at) VALUES
  (1,'codex','test','/synthetic/nonexistent','Codex test',0), (2,'hermes','test','/synthetic/nonexistent','Hermes test',0);
  INSERT INTO session(id,source_id,native_session_id,project,last_seen_at) VALUES (1,1,'synthetic-session','alpha_100%',${now - 1000}), (2,2,'aggregate-session',NULL,NULL);`);
db.prepare(`UPDATE source SET account_key='openai:subscription', account_provider='openai',
  account_display_name='OpenAI Test Subscription', account_state='active', account_last_success_at=? WHERE id=1`).run(now - 15000);
db.prepare(`INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin)
  VALUES (1,'5h',38,?,?,?,?,?)`).run(now + 7200000, now - 15000, now - 15000, now - 15000, 'live-synthetic');
for (const [used, observed, reset] of [[80, now - 10800000, now - 7200000], [10, now - 2400000, now + 7200000], [20, now - 1200000, now + 7200000]]) {
  db.prepare(`INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin)
    VALUES (1,'5h',?,?,?,?,?,?)`).run(used, reset, observed, observed, observed, 'live-synthetic');
}
db.prepare(`INSERT INTO limit_sample(source_id,window_kind,used_percent,resets_at,observed_at,last_seen_at,source_fetched_at,origin)
  VALUES (1,'5h',92,?,?,?,?,?)`).run(now + 7200000, now - 7200000, now - 7200000, now - 7200000, 'old-fallback');
const insert = db.prepare(`INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,total_tokens,call_count,cost_usd,cost_source)
  VALUES (?,?,?,?,?,?,?,1,0.2,'computed')`);
db.transaction(() => {
  for (let i = 0; i < 52; i++) insert.run(1, 1, `test-${i}`, now - 1000 - i, 'gpt-test', 'openrouter', 100 + i);
  insert.run(2, 2, 'aggregate', now - 2000, 'claude-test', 'anthropic', 999);
})();
db.prepare(`UPDATE usage_event SET input_tokens=40,cached_input_tokens=20,
  output_tokens=total_tokens-60,cost_cache_saving_usd=0.03 WHERE source_id=1`).run();
db.prepare(`UPDATE usage_event SET cache_write_tokens=7,duration_ms=1234,service_tier='test-tier',price_provider='anthropic' WHERE id=53`).run();
db.prepare(`UPDATE session SET is_subagent=1 WHERE id=2`).run();
const scheduler = new Scheduler(db, [], { pollMs: 1000000, detectMs: 1000000 });
const daemon = buildServer(db, scheduler, { token: 'history-test', port: 7800, webRoot: resolve(root, 'packages/web/dist') });
const vite = await createServer({ root: resolve(root, 'packages/web'), server: { host: '127.0.0.1', port: 7801, strictPort: true, proxy: { '/api': { target: 'http://127.0.0.1:7800', changeOrigin: true, configure: proxy => {
  // Vite installs response-close cleanup only after upstream headers arrive.
  // StrictMode/reload can cancel SSE before that point; bind cleanup earlier.
  proxy.on('proxyReq', (upstream, request, response) => {
    if (!request.url?.startsWith('/api/events/stream')) return;
    response.once('close', () => upstream.destroy());
    if (response.destroyed) upstream.destroy();
  });
} } } } });
let browser: Awaited<ReturnType<typeof chromium.launch>> | undefined;
try {
  await daemon.listen({ host: '127.0.0.1', port: 7800 });
  await vite.listen();
  browser = await chromium.launch({ channel: 'chrome', headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, reducedMotion: 'reduce', deviceScaleFactor: 1, timezoneId: 'Asia/Bangkok', permissions: ['clipboard-read', 'clipboard-write'] });
  await page.addInitScript(() => { (window as unknown as { __QUOTAPULSE_TOKEN__: string }).__QUOTAPULSE_TOKEN__ = 'history-test'; });
  await page.addInitScript(() => {
    const Original = window.EventSource;
    const state = { opened: 0, closed: 0 };
    (window as unknown as { __streamCounts: typeof state }).__streamCounts = state;
    window.EventSource = class extends Original {
      constructor(url: string | URL, options?: EventSourceInit) { super(url, options); state.opened++; }
      close() { state.closed++; super.close(); }
    };
  });
  const errors: string[] = [];
  const requests: string[] = [];
  const liveRequests: string[] = [];
  const modelRequests: string[] = [];
  const costRequests: string[] = [];
  type UsageMetricSnapshot = { range: { from: number; to: number }; totals: { total_tokens: number } };
  const overviewUsageResponses: Array<Promise<UsageMetricSnapshot | null>> = [];
  const overviewSnapshots: Array<Promise<Overview | null>> = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('response', response => { if (new URL(response.url()).pathname === '/api/usage' && response.ok()) overviewUsageResponses.push(response.json().catch(() => null)); });
  page.on('response', response => { if (new URL(response.url()).pathname === '/api/overview' && response.ok()) overviewSnapshots.push(response.json().catch(() => null)); });
  page.on('request', request => { if (request.url().includes('/api/usage-events')) requests.push(request.url()); if (request.url().includes('/api/live-sessions')) liveRequests.push(request.url()); if (request.url().includes('/api/models?detailed=1')) modelRequests.push(request.url()); if (request.url().includes('/api/cost-analysis?')) costRequests.push(request.url()); });
  await page.route('**/*', route => new URL(route.request().url()).hostname === '127.0.0.1' ? route.continue() : route.abort());
  await page.goto('http://127.0.0.1:7801/#history?range=all');
  const history = page.getByTestId('usage-history');
  await history.getByText('1–50 of 53 records', { exact: true }).waitFor();
  await history.locator('[data-testid="history-total-tokens"][aria-label="7525"]').waitFor();
  assert.equal(await history.getByTestId('history-total-tokens').getAttribute('title'), '7,525');
  const historyRail = page.locator('[data-history-detail-rail]');
  await historyRail.waitFor();
  assert.equal(await page.locator('dialog[aria-labelledby=history-detail-title]').count(), 0, 'Initial History rail must leave pagination operable');
  await history.getByRole('button', { name: 'Next page', exact: true }).click();
  await history.getByText('51–53 of 53 records', { exact: true }).waitFor();
  assert.equal(await history.getByTestId('history-total-tokens').getAttribute('aria-label'), '7525', 'timeline total changed with pagination');
  await history.getByRole('button', { name: 'Record details 53', exact: true }).click();
  await historyRail.waitFor();
  assert.match(await historyRail.innerText(), /Session aggregate|session_aggregate/);
  for (const name of ['Event summary', 'Token breakdown', 'Pricing source', 'Runtime metadata', 'Related records and metadata']) {
    await historyRail.getByRole('heading', { name, exact: true }).waitFor();
  }
  await historyRail.getByText('Cache write', { exact: true }).waitFor();
  await historyRail.getByText('Subagent', { exact: true }).waitFor();
  assert.match(await historyRail.getByRole('region', { name: 'Token breakdown' }).innerText(), /Cache write\s+7/);
  assert.match(await historyRail.getByRole('region', { name: 'Runtime metadata' }).innerText(), /Subagent\s+Yes/);
  assert.match(await historyRail.getByRole('region', { name: 'Runtime metadata' }).innerText(), /1,234 ms/);
  const openTheme = await page.getByTestId('production-history').getAttribute('data-theme');
  await page.screenshot({ path: resolve(output, `history-detail-open-en-${openTheme}-1440.png`) });
  await historyRail.getByRole('button', { name: 'Copy safe metadata', exact: true }).click();
  await historyRail.getByText('Metadata copied', { exact: true }).waitFor();
  const copied = JSON.parse(await page.evaluate(() => navigator.clipboard.readText()));
  assert.equal(copied.event_id, 53);
  for (const field of ['root_path', 'cwd', 'native_session_id', 'request_id', 'dedup_key']) assert.equal(field in copied, false);
  const relatedParams = new URLSearchParams((await historyRail.getByRole('link', { name: 'Open related session records' }).getAttribute('href'))!.split('?')[1]);
  assert.equal(relatedParams.get('session_id'), '2');
  const detailTheme = await page.getByTestId('production-history').getAttribute('data-theme');
  await page.screenshot({ path: resolve(output, `history-detail-en-${detailTheme}-1440.png`) });
  await historyRail.focus();
  await page.keyboard.press('Escape');
  assert.equal(await history.getByRole('button', { name: 'Record details 53', exact: true }).evaluate(element => element === document.activeElement), true);
  await history.getByRole('button', { name: 'Pause view', exact: true }).click();
  assert.equal(await history.getByRole('button', { name: 'Export matching records', exact: true }).isDisabled(), true);
  const atPause = requests.length;
  await page.evaluate(() => window.dispatchEvent(new Event('online')));
  await page.waitForTimeout(1600);
  assert.equal(requests.length, atPause, 'paused view queried usage records');
  assert.equal(await history.getByRole('button', { name: 'Apply filters', exact: true }).isDisabled(), true);
  await history.getByRole('button', { name: 'Resume latest', exact: true }).click();
  await history.getByText('1–50 of 53 records', { exact: true }).waitFor();
  await history.getByLabel('Search metadata', { exact: true }).fill('%');
  await history.getByRole('button', { name: 'Apply filters', exact: true }).click();
  await history.getByText('1–50 of 52 records', { exact: true }).waitFor();
  const downloading = page.waitForEvent('download');
  await history.getByRole('button', { name: 'Export matching records', exact: true }).click();
  const download = await downloading;
  const stream = await download.createReadStream();
  const chunks: Buffer[] = [];
  for await (const chunk of stream!) chunks.push(Buffer.from(chunk));
  const csv = Buffer.concat(chunks).toString('utf8');
  assert.equal(csv.trimEnd().split('\r\n').length, 53, 'export truncated to loaded page');
  assert.match(csv.split('\r\n')[0]!, /,grain$/);
  await history.getByLabel('Search metadata', { exact: true }).fill('nothing-matches');
  await history.getByRole('button', { name: 'Apply filters', exact: true }).click();
  await history.getByText('No matching usage records', { exact: true }).waitFor();
  await history.getByLabel('Search metadata', { exact: true }).fill('');
  await history.getByLabel('Unassigned projects only', { exact: true }).check();
  await history.getByRole('button', { name: 'Apply filters', exact: true }).click();
  await history.getByText('1–1 of 1 records', { exact: true }).waitFor();
  await history.getByText('Session aggregate', { exact: true }).last().waitFor();
  // Hold a real request across Pause: its late result must not replace the frozen rows.
  let release!: () => void;
  let entered!: () => void;
  const held = new Promise<void>(resolve => { release = resolve; });
  const requested = new Promise<void>(resolve => { entered = resolve; });
  let holdOnce = true;
  await page.route('**/api/usage-events?**', async route => {
    const q = new URL(route.request().url()).searchParams.get('q');
    if (q === 'synthetic-error') return route.fulfill({ status: 500, contentType: 'application/json', body: '{"error":"synthetic failure"}' });
    if (holdOnce && q === 'alpha') { holdOnce = false; entered(); await held; }
    return route.continue();
  });
  await history.getByLabel('Unassigned projects only', { exact: true }).uncheck();
  await history.getByLabel('Search metadata', { exact: true }).fill('alpha');
  await history.getByRole('button', { name: 'Apply filters', exact: true }).click();
  await requested;
  await history.getByRole('button', { name: 'Pause view', exact: true }).click();
  const response = page.waitForResponse(res => res.url().includes('/api/usage-events') && res.url().includes('q=alpha'));
  release();
  await response;
  await page.waitForTimeout(150);
  await history.getByText('1–1 of 1 records', { exact: true }).waitFor();
  await history.getByRole('button', { name: 'Resume latest', exact: true }).click();
  await history.getByText('1–50 of 52 records', { exact: true }).waitFor();
  await history.getByLabel('Search metadata', { exact: true }).fill('synthetic-error');
  await history.getByRole('button', { name: 'Apply filters', exact: true }).click();
  await history.getByText('Showing the last successful snapshot.', { exact: false }).waitFor();
  assert.equal(await history.getByRole('button', { name: 'Export matching records', exact: true }).isDisabled(), true);
  await history.getByLabel('Search metadata', { exact: true }).fill('');
  await history.getByRole('button', { name: 'Apply filters', exact: true }).click();
  await history.getByText('1–50 of 53 records', { exact: true }).waitFor();
  for (const width of [390, 900, 1440]) {
    await page.setViewportSize({ width, height: 1000 });
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `overflow at ${width}`);
    await page.screenshot({ path: resolve(output, `history-${width}.png`) });
  }
  for (const lang of ['en', 'th']) {
    for (const theme of ['dark', 'light']) {
      await page.evaluate(({ lang, theme }) => {
        localStorage.setItem('quotapulse-prefs', JSON.stringify({ lang, currency: lang === 'th' ? 'THB' : 'USD', rate: 35, hiddenSubscriptions: [] }));
        localStorage.setItem('quotapulse-theme', theme);
      }, { lang, theme });
      await page.reload();
      await page.getByRole('heading', { name: lang === 'th' ? 'รายการใช้งาน' : 'Usage records', exact: true }).waitFor();
      await page.locator('[data-testid=usage-history] tbody tr').first().waitFor();
      assert.equal(await page.locator('html').getAttribute('lang'), lang);
      if (lang === 'th') assert.match(await page.locator('[data-testid=usage-history] tbody tr').first().innerText(), /฿|THB/);
      for (const width of [390, 900, 1440]) {
        await page.setViewportSize({ width, height: 1000 });
        assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `${lang}/${theme}/${width}`);
        await page.screenshot({ path: resolve(output, `${lang}-${theme}-${width}.png`) });
      }
    }
  }
  assert.deepEqual(errors, []);
  writeFileSync(resolve(output, 'verification.json'), JSON.stringify({scope:'History-only excerpt of check-history.mts; real Vite/API synthetic memory DB, not whole application E2E', passed:true, records:53, checks:['pagination while rail open','safe metadata allowlist and aggregate fields','whole-range CSV','literal search','pause and held late response','failed snapshot/export disabled/recovery','EN/TH light/dark 390/900/1440 currency'], requestCount:requests.length,errors},null,2));
  console.log('Bounded History data/metadata/export/pause/retained recovery checks passed');
} finally {
 await browser?.close(); await vite.close(); await daemon.close(); db.close();
}
