import { buildServer } from '../packages/daemon/src/api/server.js';
import { Scheduler } from '../packages/daemon/src/ingest/scheduler.js';
import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { cpus, platform, release } from 'node:os';
import { openDb } from '../packages/daemon/src/db/index.js';
import { modelPairTrends, type ModelPair } from '../packages/daemon/src/api/model-pair-trends.js';
import { detailedAggregates } from '../packages/daemon/src/api/detailed-aggregates.js';
import type { UsageScope } from '../packages/daemon/src/api/usage-scope.js';

const db = openDb(':memory:');
const from = 1_700_000_000_000;
const to = from + 30 * 60_000;
const identities: ModelPair[] = Array.from({ length: 1265 }, (_, index) => ({
  model: index === 0 ? null : index === 1 ? '' : `model-${Math.floor(index / 3)}`,
  provider: index === 0 ? '' : index === 1 ? null : index % 3 === 0 ? null : index % 3 === 1 ? '' : `route-${index % 5}`,
}));
const fixtureStart = performance.now();
try {
  db.exec(`INSERT INTO source(id,harness,profile,root_path,display_name,detected_at) VALUES
    (1,'codex','synthetic','/synthetic/call','Call',0),
    (2,'hermes','synthetic','/synthetic/aggregate','Aggregate',0),
    (3,'future','synthetic','/synthetic/unknown','Unknown',0)`);
  const addSession = db.prepare('INSERT INTO session(id,source_id,native_session_id,project) VALUES(?,?,?,?)');
  for (let id = 1; id <= 120; id++) addSession.run(id, (id - 1) % 3 + 1, `session-${id}`, id % 4 === 0 ? null : id % 4 === 1 ? '' : id % 4 === 2 ? 'One' : 'Two');
  const insert = db.prepare(`INSERT INTO usage_event(source_id,session_id,dedup_key,ts,model,provider,total_tokens,call_count,effort,input_tokens,output_tokens)
    VALUES(?,?,?,?,?,?,?,?,?,?,?)`);
  let sequence = 0;
  const add = (pair: ModelPair, ordinal: number, bin: number) => {
    const session = ordinal % 120 + 1;
    const tokens = ordinal % 701;
    insert.run((session - 1) % 3 + 1, session, `event-${sequence++}`, from + bin * 60_000 + ordinal % 500,
      pair.model, pair.provider, tokens, ordinal % 9 + 1, ordinal % 2 ? 'high' : null, tokens, 0);
  };
  db.transaction(() => {
    identities.forEach((pair, index) => { for (let i = 0; i < 80; i++) add(pair, index * 83 + i, i % 3 * 10); });
    identities.slice(0, 20).forEach((pair, index) => { for (let i = 0; i < 3000; i++) add(pair, index * 3001 + i, i % 30); });
  })();
  const fixtureMs = performance.now() - fixtureStart;
  const rowCount = (db.prepare('SELECT COUNT(*) n FROM usage_event').get() as {n:number}).n;
  assert.equal(rowCount, 161200);
  assert.equal((db.prepare('SELECT COUNT(*) n FROM (SELECT model,provider FROM usage_event GROUP BY model,provider)').get() as {n:number}).n, identities.length);

  const scope={from,to};const beforeChanges=db.prepare('SELECT total_changes() n').get();
  const nativePrepare=db.prepare;let trace:string[]|null=null;
  db.prepare=function(sql:string){if(trace)trace.push(sql);return nativePrepare.call(db,sql);} as typeof db.prepare;
  const run=(mode:'full'|'omitted')=>{trace=[];const begin=performance.now();const result=detailedAggregates(db,scope,'model',mode);const elapsedMs=performance.now()-begin;const queries=trace;trace=null;return {result,elapsedMs,queries};};
  const warmFull=run('full'),warmSummary=run('omitted');assert.deepEqual(warmSummary.result,{totals:warmFull.result.totals,groups:warmFull.result.groups,breakdown:'omitted'});assert.equal(warmFull.queries!.length,3);assert.equal(warmSummary.queries!.length,2);
  const trials=[];for(let index=0;index<5;index++){const first=run(index%2?'omitted':'full'),second=run(index%2?'full':'omitted');const full=index%2?second:first,summary=index%2?first:second;assert.deepEqual(summary.result,{totals:full.result.totals,groups:full.result.groups,breakdown:'omitted'});trials.push({order:index%2?'summary/full':'full/summary',fullMs:full.elapsedMs,summaryMs:summary.elapsedMs});}
  const fullBytes=Buffer.byteLength(JSON.stringify(warmFull.result)),summaryBytes=Buffer.byteLength(JSON.stringify(warmSummary.result));assert.equal(warmFull.result.groups.length,1265);assert.equal(warmFull.result.rows!.length,7590);assert.equal(fullBytes,4009433);assert.ok(summaryBytes<fullBytes/3,'unused breakdown should dominate this fixture payload');
  const app=buildServer(db,new Scheduler(db,[],{pollMs:1_000_000,detectMs:1_000_000}),{port:0,token:'model110-benchmark',webRoot:'.'});let http;
  try{const path='/api/models?detailed=1&trends=1&from='+from+'&to='+to,headers={'x-quotapulse-token':'model110-benchmark'};const full=await app.inject({url:path,headers}),summary=await app.inject({url:path+'&breakdown=0',headers});assert.equal(full.statusCode,200);assert.equal(summary.statusCode,200);const {now:fullNow,rows,...expected}=full.json(),{now:summaryNow,breakdown,...actual}=summary.json();assert.deepEqual(actual,expected);assert.equal(breakdown,'omitted');http={fullBytes:Buffer.byteLength(full.body),summaryBytes:Buffer.byteLength(summary.body),fullRows:rows.length,groups:actual.groups.length,trendBuckets:actual.trends.points.length,exactFactsAndTrends:true};}finally{await app.close();}
  db.prepare=nativePrepare;assert.deepEqual(db.prepare('SELECT total_changes() n').get(),beforeChanges);
  const median=(values:number[])=>[...values].sort((a,b)=>a-b)[Math.floor(values.length/2)];const report={fixture:{records:rowCount,pairs:1265,sessions:120,grains:3,fixtureMs},environment:{node:process.version,platform:platform(),release:release(),cpu:cpus()[0]?.model},functionResult:{fullBytes,summaryBytes,reductionFraction:1-summaryBytes/fullBytes,fullQueries:warmFull.queries!.length,summaryQueries:warmSummary.queries!.length,fullSha256:createHash('sha256').update(JSON.stringify(warmFull.result)).digest('hex'),unchangedTotalsAndAllGroups:true},http,trials,medians:{fullMs:median(trials.map(item=>item.fullMs)),summaryMs:median(trials.map(item=>item.summaryMs))},readOnly:true,limitations:'Warm local in-memory synthetic fixture, interleaved same-process five trials after warmup. Not disk/network/native startup or general SLO evidence. Full group cardinality and vendor-filter work remain O(N).',queryPlans:warmFull.queries!.map((sql,index)=>({index,sql,plan:db.prepare('EXPLAIN QUERY PLAN '+sql).all(scope)}))};writeFileSync('tmp/model110-benchmark.json',JSON.stringify(report,null,2));console.log(JSON.stringify({...report,queryPlans:undefined},null,2));
}finally{db.close();}
