const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),crypto=require('node:crypto');
const checkout='C:/Users/TH12367283/Projects/QuotaPulse/tmp/worktrees/redesign-validation-v1.85.138';
const built=JSON.parse(fs.readFileSync(path.join(checkout,'screens/tray-recovery/bundle-build.json')));
const receipt='tmp/release139/build/build.json';const record=JSON.parse(fs.readFileSync(receipt));
assert.equal(record.sourceCommit,'b027a5365a5cac260c36217716a8da264c2d2aad');assert.equal(record.steps.length,6);assert.ok(record.steps.every(step=>step.exitCode===0));
const hash=crypto.createHash('sha256').update(fs.readFileSync(path.join(built.bundle,'packages/web/dist/index.html'))).digest('hex');assert.equal(hash,'0fd855c959228374a5733d3b0aebbb001e8b3394222eebe6c6836bd503cbc2d4');
fs.writeFileSync('tmp/release139/inputs.json',JSON.stringify({checkout,bundle:built.bundle,sourceCommit:record.sourceCommit,buildReceipt:path.resolve(receipt),webIndexSha256:hash},null,2)+'\n');
console.log(JSON.stringify({bundle:built.bundle,sourceCommit:record.sourceCommit,index:hash}));
