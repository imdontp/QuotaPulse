import json
from pathlib import Path
from PIL import Image, ImageChops
root=Path('tmp/project117')
before=json.loads((root/'before/project-trend.json').read_text())
after=json.loads((root/'after/project-trend.json').read_text())
for key in ['label','points','lines']: assert before['plot'][key]==after['plot'][key],key
assert len(after['axes'])==10
assert before['plot']['rect']['height']==after['plot']['rect']['height']==76
left=Image.open(root/'before/projects.png').convert('RGB');right=Image.open(root/'after/projects.png').convert('RGB')
channels=ImageChops.difference(left,right).split(); delta=ImageChops.lighter(ImageChops.lighter(channels[0],channels[1]),channels[2]);hist=delta.histogram()
outside=0
for y in range(left.height):
    for x in range(left.width):
        if left.getpixel((x,y))!=right.getpixel((x,y)) and not (1126<=x<1656 and 432<=y<939): outside+=1
new=json.loads((root/'after/verification.json').read_text())
controls={}
for name,box in dict(header=(0,0,1672,60),sidebar=(0,60,226,941),headingToolbar=(226,60,1672,206),cards=(226,206,1120,941)).items():
    region=delta.crop(box);h=region.histogram();controls[name]=dict(changedPixels=sum(h[1:]),maxChannelDelta=max(i for i,n in enumerate(h)if n),localBounds=region.getbbox())
report=dict(productionIndexSha256=new['productionIndexSha256'],preservedPoints=len(after['plot']['points']),preservedPlotFields=['label','points: at/value/cx/cy','polyline points'],axes=len(after['axes']),plotBefore=before['plot']['rect'],plotAfter=after['plot']['rect'],changedPixels=sum(hist[1:]),maxChannelDelta=max(i for i,n in enumerate(hist)if n),changedBounds=delta.getbbox(),pixelsOutsideRightRail=outside,unplannedControls=controls,immediateRepeatIdentical=new['results'][0]['repeatIdentical'],scope='Projects recorded-value axes only; not whole-reference acceptance')
(root/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
